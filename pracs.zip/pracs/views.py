from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
import datetime
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from .models import *
from .forms import *
from . import pins as pinss
from .assignment import uniuyo1, uniuyo2

from .gst_questions import book11

from . import assignments

import math
from django.http import FileResponse
from django.utils import timezone
from datetime import timedelta, datetime
from django.templatetags.static import static
import random
import requests
import re
import inspect
from . import assignments
from .templatetags.languages import translations
from .lessons import lessons, quiz, notes
import uuid
from django.core.mail import EmailMessage
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from .tokens import account_activation_token
# from PyPDF2 import PdfWriter, PdfReader
from django.template.loader import render_to_string
from xhtml2pdf import pisa
# from .utils import generate_pdf
from django.conf import settings
import os

from io import BytesIO
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

from django.apps import apps
# from django.db import connection

# with connection.cursor() as cursor:
#     cursor.execute("DROP TABLE myapp_mymodel;")

start = ['CUSTOM','PRAAT']
compul = ['Can not find what you are looking for?']
categories = ['Updates']
courses = ['mathematics', 'biology', 'physics', 'chemistry']
uniuyo = start + ['GST111','GST211', 'GST311', 'SED211', 'SOC112', 'POL114'] + compul
aksu = start + [] + compul
akscoe = start + [] + compul
specials = ['calixotu@gmail.com',]
prof_max = 100
amounts = {'weekly':500, 'monthly':1500}
admin = ['calixotu@gmail.com', 'calixguru@gmail.com']
currency = ['naira','dollar', 'pound']

# categories = [
#     'Campus Life',          # For university/student-related vibes
#     'Love & Dating',        # Relationship advice, real stories, heartbreaks
#     'Money & Hustle',       # Business, finance, side hustles
#     'Tech & Innovation',    # Gadgets, coding, startups
#     'Politics & Power',     # News, elections, government critique
#     'Health & Wellness',    # Fitness, mental health, lifestyle
#     'Faith & Spirituality', # Religion, belief systems, moral debates
#     'Trends & Vibes',       # Pop culture, Gen Z gist, social media drama
#     'Hot Gist',             # Controversies, gossip, viral moments
#     'Career & Skills',      # Career growth, CV tips, digital skills
#     'Entertainment Zone',   # Music, movies, games, celebrity stories
#     'Education & Exams',    # School news, ASUU, JAMB, tutorials
#     'Real Life Stories',    # True stories, anonymous confessions
#     'Science & Nature',     # Curious facts, nature talk, research
#     'Sports Arena',         # Football, AFCON, Olympics, analysis
#     'DIY & Hacks',          # How-tos, tutorials, life tricks
#     'Food & Culture',       # Recipes, cultural dishes, food trends
# ]


def cover_page_form(request):
    if request.method == 'POST':
        form = CoverPageForm(request.POST)
        if form.is_valid():
            # Render HTML template with form data
            html_string = render_to_string('pdf/cover_page.html', {'data': form.cleaned_data})

            # Generate PDF
            response = HttpResponse(content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="cover_page.pdf"'

            # Create PDF from HTML string
            pisa_status = pisa.CreatePDF(html_string, dest=response)

            # Check for errors
            if pisa_status.err:
                return HttpResponse('Error generating PDF', status=500)

            return response
    else:
        form = CoverPageForm()
    return render(request, 'pdf/cover_form.html', {'form': form})


# from bs4 import BeautifulSoup



# def reset_done(request):
#     pass1= request.POST.get('new_password1')
#     pass2 = request.POST.get('new_password1')
#     context = {'page': status}
#     return render(request, 'password/password_reset_done.html', context)


def custom_bad_request(request, exception):
    status = 400
    context = {'page': status}
    return render(request, 'error.html', context, status=400)

def custom_permission_denied(request, exception):
    status = 403
    context = {'page': status}
    return render(request, 'error.html', context, status=403)

def custom_page_not_found(request, exception):
    status = 404
    context = {'page': status}
    return render(request, 'error.html', context, status=404)

def custom_server_error(request):
    status = 500
    context = {'page': status}
    return render(request, 'error.html', context, status=500)

def test_500_error(request):
    return 1 / 0

def terms(request):
    return render(request, "terms.html")



def inv(request):
    return messages.error(request, 'Please input valid numerical values')

def inactive(request):
    messages.error(request, 'You are not yet activated')
    return redirect('buypin')

# def counts(text):
#     numbers = re.findall(r'\b\d+(?:\.\d+)?\b', text)
#     count = len(numbers)
#     return count

def error_500(request):
    text2 = 'Some Error Occured'
    data = {'text2': text2}
    return render(request, 'base/Failed2.html', data)


def error_404(request, exception):
    text2 = 'Unexpected Error Occured'
    data = {'text2': text2}
    return render(request, 'base/Failed2.html', data)

def loginPage(request):
    page = 'login'
    if request.user.is_authenticated:
        return redirect('home')

    next_url = request.GET.get('next') or request.POST.get('next')

    if request.method == 'POST':
        translate = {item["id"]: item for item in translations}
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            option = request.POST.get('option')
            messages.error(request, f"{translate.get('Invalid Credentials').get(option, 'Invalid Credentials')}")
            return render(request, 'base/login_register.html', {'page': page})

        user = authenticate(request, email=email, password=password)
        if user is not None:
            option = request.POST.get('option')
            login(request, user)
            messages.success(request, f"{translate.get('Login Successful').get(option, 'Login Successful')}")

            # ✅ Redirect to intended page if available
            if next_url:
                return redirect(next_url)
            else:
                return redirect('home')
        else:
            option = request.POST.get('option')
            messages.error(request, f"{translate.get('Invalid Credentials').get(option, 'Invalid Credentials')}")

    context = {'page': page, 'next': request.GET.get('next', '')}
    return render(request, 'base/login_register.html', context)


def language(request):
    if request.method == 'POST':
        option = request.POST.get('language')
        langs = {'en':'English','fr':'French','it':'Italian','esp':'Spanish','igb':'Igbo','hau':'Hausa','yor':'Yoruba','pid':'Pidgin', }
        translate = {item["id"]: item for item in translations}
        request.session['option'] = option
        messages.success(request, f"{translate.get('Language changed to').get(option, 'Translation not found') + ' ' + langs[option]}")
    return redirect(request.META.get('HTTP_REFERER', '/'))


def logoutUser(request):
    logout(request)
    return redirect('home')


def registerPage(request):
    form = MyUserCreationForm()

    if request.method == 'POST':
        form = MyUserCreationForm(request.POST)
        ref = request.POST.get('ref')
        if form.is_valid():
            user = form.save(commit=False)
            user.ref = ref
            user.is_active = True  # Set user as inactive until email confirmation
            user.cbt_details = []
            user.cbt_quests = []
            user.save()

            # Send confirmation email
            # current_site = get_current_site(request)
            # mail_subject =  'Complete your account registration'
            # message = render_to_string('base/activate_account.html', {
            #     'user': user,
            #     'domain': current_site.domain,
            #     'uid': urlsafe_base64_encode(force_bytes(user.pk)),
            #     'token': account_activation_token.make_token(user),
            # })
            # to_email = request.POST.get('email')
            # email = EmailMessage(mail_subject, message, to=[to_email])
            # email.content_subtype = 'html'
            # email.send()

            # messages.success(request, 'Please confirm your email to complete the registration.')
            # return redirect('confirm')
            messages.success(request, 'Registration Successful, Please Login now')
            return redirect('login')
        else:
            messages.error(request, 'Registration failed. Please try again. Email may have already been registered')

    return render(request, 'base/login_register.html', {'form': form})

def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        messages.success(request, 'Thank you for confirming your email! You can now log in.')
        return redirect('login')
    else:
        messages.error(request, 'Invalid or expired link')
        return redirect('home')


def confirm(request):
    return render(request, 'base/confirm.html')


def home(request):
    rooms = Cbtroom.objects.all()
    duration = {'daily':2, 'weekly':8, 'monthly':32,}
    everyone = Pins.objects.all()
    for i in everyone:
        if i.created_at+timedelta(days=duration[i.duration]) <= timezone.now():
          i.delete()

    blogs = BlogPost.objects.all().order_by('-created_at')[:6]

    context = {'admin': admin, 'rooms': rooms, 'blogs': blogs, 'categories': categories, 'everyone': everyone,
               'courses':courses, 'uniuyo': uniuyo, 'aksu': aksu, 'akscoe': akscoe}
    return render(request, 'base/index.html', context)

@login_required(login_url='login')
def selectTournament(request):
    return render(request, 'base/select_tournament.html', {'courses':courses, 'uniuyo': uniuyo,
                                                           'aksu': aksu, 'akscoe': akscoe})


@login_required(login_url='login')
def buypin(request):
    # for i in User.objects.all():
    #     if i.is_active == False:
    #         i.is_active = True
    #         i.save()
    #         login(request, i)
    #         messages.success(request, "Everyone is logged in")
    one = 1200
    sfive = 2500
    five = 3000
    user = request.user
    ps = []
    for i in Pins.objects.all():
        ps.append(i.name)
    if request.user in ps:
        owner = Pins.objects.get(pin=request.user.id)
    else:
        owner = ''

    if request.user.email in specials:
        plans = [
            # {"label": "₦500/Week activation", "amount": 500, "name": "weekly", "color": "orange"},
            # {"label": "₦1500/Month activation", "amount": 1500, "name": "monthly", "color": "purple"},
            # {"label": f"₦{one} for 1 download", "amount": one, "name": "1 Download", "color": "#f97316"},
            {"label": f"₦{sfive} for 5 downloads", "amount": sfive, "name": "5 Downloads", "color": "#3b82f6"},
            # {"label": "₦5,000 for 10 downloads", "amount": 5000, "name": "10 Downloads", "color": "#8b5cf6"},
            # {"label": "₦7,000 for 15 downloads", "amount": 7000, "name": "15 Downloads", "color": "#10b981"},
        ]
        downloads = [
            # {"label": f"₦{one} for 1 download", "amount": one, "name": "1 Download", "color": "#f97316"},
            {"label": f"₦{sfive} for 5 downloads", "amount": sfive, "name": "5 Downloads", "color": "#3b82f6"},
            # {"label": "₦5,000 for 10 downloads", "amount": 5000, "name": "10 Downloads", "color": "#8b5cf6"},
            # {"label": "₦7,000 for 15 downloads", "amount": 7000, "name": "15 Downloads", "color": "#10b981"},
        ]
    else:
        plans = [
            # {"label": "₦500/Week activation", "amount": 500, "name": "weekly", "color": "orange"},
            # {"label": "₦1500/Month activation", "amount": 1500, "name": "monthly", "color": "purple"},
            # {"label": f"₦{one} for 1 download", "amount": one, "name": "1 Download", "color": "#f97316"},
            {"label": f"₦{five} for 5 downloads", "amount": five , "name": "5 Downloads", "color": "#3b82f6"},
            # {"label": "₦5,000 for 10 downloads", "amount": 5000, "name": "10 Downloads", "color": "#8b5cf6"},
            # {"label": "₦7,000 for 15 downloads", "amount": 7000, "name": "15 Downloads", "color": "#10b981"},
        ]
        downloads = [
            # {"label": f"₦{one} for 1 download", "amount": one, "name": "1 Download", "color": "#f97316"},
            {"label": f"₦{five} for 5 downloads", "amount": five , "name": "5 Downloads", "color": "#3b82f6"},
            # {"label": "₦5,000 for 10 downloads", "amount": 5000, "name": "10 Downloads", "color": "#8b5cf6"},
            # {"label": "₦7,000 for 15 downloads", "amount": 7000, "name": "15 Downloads", "color": "#10b981"},
        ]
    context = {'user': user, 'plans': plans, 'ps': ps,
               'downloads': downloads, 'owner': owner}
    return render(request, 'base/buypin.html', context)


def select(request):
    return render(request, 'base/select.html')


@login_required(login_url='login')
def profile(request, pk):
    all = Req.objects.filter(hosts=request.user)
    user = User.objects.get(id=pk)
    try:
        code = Tutor.objects.get(email=user.email).code
    except:
        code = ''
    pins = []
    userpin = Pins.objects.all()

    for i in userpin:
        pins.append(i.pin)

    try:
        pin = Pins.objects.get(pin=user.id)
        duration = {'daily':2, 'weekly':8, 'monthly':32,}
        deactive = timezone.now()+timedelta(days=duration[pin.duration])
    except:
        deactive = "Your are currently not activated"

    if request.method == 'POST':
        downloads = int(request.POST.get('has_downloaded'))
        if downloads > int(user.has_downloaded):
            Pays.objects.create(
            user=user,
            title = 'Offline downloads',
            trace = f'{user.email} downloads',
            amount= 500*(downloads - user.has_downloaded),
            )
        form = UserForm(request.POST, request.FILES, instance=user)
        if form.is_valid():

            user.has_downloaded = downloads
            user.save()
            form.save()
            messages.success(request, "👍")
            return redirect('profile', pk)
        else:
            messages.error(request, "😢")
    context = {'user': user, 'pins': pins,
               'deactive': deactive, 'all': all, 'code': code, 'admin': admin}
    return render(request, 'base/profile.html', context)

@login_required(login_url='login')
def label_zero(request):
    idy = request.GET.get('id')
    owner = User.objects.get(id=idy)
    owner.amount = 0
    owner.save()
    messages.success(request, f"{owner.firstname} has been labelled as paid")
    return redirect('profile', idy)

@login_required(login_url='login')
def request(request):
    user = request.user
    if Pins.objects.filter(pin=user.id):
        if request.method == 'POST':
            current = request.POST.get('currency')
            amount = 0
            title = request.POST.get('title')
            body = request.POST.get('body')
            if int(amount) < 10000000001:
                Req.objects.create(
                hosts=user,
                amount=amount,
                currency=current,
                title=title,
                body=body,
                        )
                messages.success(request, "Posted👍, Awaiting approval")
            else:
                messages.error(request, "Amount's limit is 1 Billion")


        context = {'currency':currency}
        return render(request, 'base/special.html', context)
    else:
        messages.error(request, 'You must be activated to have this access')
        return redirect('buypin')

@login_required(login_url='login')
def customcon(request):
    user = request.user
    return render(request, 'base/customcon.html')


@login_required(login_url='login')
def custom(request):
    user = request.user
    m = int(request.POST.get("u"))
    n = int(request.POST.get("v"))
    o = int(request.POST.get("w"))
    if o > n:
        messages.error(request, 'Number of columns has to be greater than columns with formular')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        u = []
        man = []
        rem = []
        manual = n-o
        w2 = 0
        while w2 < manual:
            w2 = w2 + 1
            man.append(w2)
        maxmanual = max(man)

        w3 = 0
        while w3 < o:
            w3 = w3 + 1
            rem.append(w3)
        remain = max(rem)


        w1 = 0
        while w1 < m:
            w1 = w1 + 1
            u.append(w1)
        uu = max(u)

        w0 = 0
        x = []
        while w0 < n:
            w0 = w0 + 1
            x.append(w0)
        vv = max(x)
        # try:
        context = {
                'u': u,
                'm': m,
                'n': n,
                'o': o,
                'uu': uu,
                'vv': vv,
                'x': x,
                'man': man,
                'maxmanual': maxmanual,
                'remain': remain,
                'rem': rem,

                        }
        return render(request, 'base/custom.html', context)
        # except:
        #     messages.error(request, 'Some values may be missing or invalid')
        #     return redirect(request.META.get('HTTP_REFERER', '/'))


@login_required(login_url='login')
def customans(request):
    user = request.user
    m = (int(request.GET["m"]))
    n = (int(request.GET["n"]))
    o = (int(request.GET["o"]))
    dp = (int(request.GET["dp"]))
    x = (int(request.GET["x-axis"]))-1
    y = (int(request.GET["y-axis"]))-1
    # a2 = (float(request.GET["nu"]))
    dpp = round(dp)


    def preprocess_formula(formula):
        # Replace 'colN!' with 'factorial(colN)'
        formula = re.sub(r'(col\d+)!', r'factorial(\1)', formula)
        return formula

    def evaluate_formula(formula, col_data):
        try:
            # Create a dictionary for evaluating the formula
            data = {f'col{i+1}': col for i, col in enumerate(col_data)}
            # Define the safe math functions we allow
            safe_math = {
                "sin": lambda x: math.sin(math.radians(x)),
                "cos": lambda x: math.cos(math.radians(x)),
                "tan": lambda x: math.tan(math.radians(x)),
                "log": math.log10,  # base 10 logarithm
                "sqrt": math.sqrt,
                "factorial": math.factorial,
                "pow": pow,
                "radians": math.radians,
                "degrees": math.degrees,
                "pi": math.pi,
                "e": math.e
            }
            result = [eval(formula, {"__builtins__": None, **safe_math}, {"col_data": col_data, **{k: v[i] for k, v in data.items()}}) for i in range(len(col_data[0]))]
            return result
        except Exception as e:
            text = f"Cannot calculate for that formula: {e}"
            messages.error(request, text)

    try:
        num_rows = m
        num_columns = n
        num_formula_columns = o
        main_list = []

        for i in range(num_columns - num_formula_columns):
            col = []
            for j in range(num_rows):
                col.append(float(request.GET[f"{i+1}-{j+1}"]))
            main_list.append(col)

        final = []
        w3 = 0
        while w3 < o:
            w3 = w3 + 1
            final.append(w3)
        for i in final:
            formula = request.GET[f"formular{i}"]#"col1*2"
            formula = preprocess_formula(formula)
            result = evaluate_formula(formula, main_list)
            if result is not None:
                main_list.append(result)
                # print(f"Result for formula '{formula}': {result}")
            else:
                text = f"Invalid Formular"
                messages.error(request, text)

    except ValueError as ve:
        text = f"Invalid input: {ve}"
        messages.error(request, text)

    def round_to_decimal_places(lst):
        return [[round(num, dp) for num in sublist] for sublist in lst]
    main_list2 = round_to_decimal_places(main_list)
    ch = []
    for u, v in zip(main_list2[x],main_list2[y]):
        ch.append([u, v])
    chh = (','.join(map(str, ch)))

    if Pins.objects.filter(pin=user.id):
        try:
            context = {'main': main_list2,
                       'chh': chh,
                        'final': final,
                        }
            return render(request, 'base/customans.html', context)
        except TypeError:
            messages.error(request, 'Some values may be missing or invalid')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')




def gst1(request):
    # user = request.user

        # text = f"Hello {user.firstname}, review of this book is in progress"
        # context = {'first': first, 'second': second, 'extra1': extra1, 'extra2': extra2}
        # messages.success(request, text)
        # return redirect('select-gst')
    return render(request, 'base/gst1.html')

@login_required(login_url='login')
def phy111(request):
    sort = Phy1.objects.order_by('-score')
    sorts = sort[:5]
    context = {'sorts': sorts}
    return render(request, 'base/physcorers1.html', context)

@login_required(login_url='login')
def mth111(request):
    sort = Mth1.objects.order_by('-score')
    sorts = sort[:5]
    context = {'sorts': sorts}
    return render(request, 'base/mthscorers1.html', context)

@login_required(login_url='login')
def gst112(request):
    sort = Gst2.objects.order_by('-score')
    sorts = sort[:5]
    context = {'sorts': sorts}
    return render(request, 'base/gstscorers2.html', context)


@login_required(login_url='login')
def engr(request):
    return render(request, 'base/engrcourses.html')



@login_required(login_url='login')
def updateUser(request):
    user = request.user
    form = UserForm(instance=user)

    if request.method == 'POST':
        form = UserForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            return redirect('home')

    return render(request, 'base/update-user.html', {'form': form})


def topicsPage(request):
    # q = request.GET.get('q') if request.GET.get('q') != None else ''
    # topics = User.objects.filter(name__icontains=q)
    # context = {'topics': topics}
    return render(request, 'base/topics.html')


def selectpractical(request):
    #q = request.GET.get('q') if request.GET.get('q') != None else ''
    topics = uniuyo1.prac1
    return render(request, 'base/select_practical.html', {'topics': topics})


from io import BytesIO
from django.http import FileResponse, HttpResponse
from django.shortcuts import redirect
from django.contrib import messages
from django.conf import settings
import os
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors

# ---------------- Windows-safe image loader ----------------
def img(name):
    path = os.path.join(settings.BASE_DIR, 'static', 'img', name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Image not found: {path}")
    return path

# ---------------- Optional header/footer ----------------
def _draw_header_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica-Bold', 12)
    canvas.setFillColor(colors.HexColor("#1F3A5F"))
    canvas.drawString(36, A4[1]-50, "CALIXGURU AUTOMATED PHYSICS PRACTICALS GUIDE")
    canvas.setFont('Helvetica', 9)
    canvas.setFillColor(colors.grey)
    canvas.drawString(36, 36, "© CALIXGURU — Digital Learning at its Finest")
    canvas.restoreState()

# ---------------- PDF view ----------------
def generate_physics_practicals_pdf(request):
    """
    Generate a beautifully styled PDF for automated Physics Practicals,
    including all steps, images, and subscription notice.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=36,
        leftMargin=36,
        topMargin=90,
        bottomMargin=72,
    )

    # Styles
    base = getSampleStyleSheet()
    styles = {
        "title": ParagraphStyle("title", parent=base["Heading1"], fontName="Helvetica-Bold", fontSize=18, alignment=1, spaceAfter=12, textColor=colors.HexColor("#1F3A5F")),
        "subtitle": ParagraphStyle("subtitle", parent=base["Normal"], fontSize=10, alignment=1, textColor=colors.HexColor("#6B7280")),
        "step_header": ParagraphStyle("step_header", parent=base["Heading2"], fontSize=14, spaceAfter=6, textColor=colors.HexColor("#0F172A")),
        "step_text": ParagraphStyle("step_text", parent=base["Normal"], fontSize=11, leading=16, spaceAfter=12, textColor=colors.HexColor("#1F2937")),
        "small_grey": ParagraphStyle("small_grey", parent=base["Normal"], fontSize=8, textColor=colors.HexColor("#6B7280")),
    }

    elements = []

    # ---------------- COVER PAGE ----------------
    elements.append(Paragraph("CalixGuru Automated Physics Practicals Guide", styles["title"]))
    elements.append(Spacer(1, 20))
    elements.append(Paragraph(
        "This guide explains how students can carry out automated physics practicals "
        "using the CalixGuru online practicals engine. Each step is supported with "
        "screenshots and diagrams for easy understanding.",
        styles["step_text"]
    ))
    elements.append(Image(img("logo2.png"), width=6*inch, height=6*inch))
    elements.append(PageBreak())

    # ---------------- STEP 1 ----------------
    elements.append(Paragraph("1. Tap on ‘Physics Practicals’", styles["step_header"]))
    elements.append(Paragraph(
        "Open CalixGuru home page or enter any CBT room and tap the <b>Physics Practicals</b> section. All available "
        "experiments labeled M1, M2, etc., will appear.",
        styles["step_text"]
    ))
    elements.append(Image(img("tap_practicals.jpg"), width=5*inch, height=7*inch))
    elements.append(PageBreak())

    # ---------------- STEP 2 ----------------
    elements.append(Paragraph("2. Select Number of Rows", styles["step_header"]))
    elements.append(Paragraph(
        "Enter the number of rows your table will contain (usually 5, 6, or 7) depending on the experiment.",
        styles["step_text"]
    ))
    elements.append(Image(img("select_rows.jpg"), width=5*inch, height=7*inch))
    elements.append(PageBreak())

    # ---------------- STEP 3 ----------------
    elements.append(Paragraph("3. Input Experimental Values", styles["step_header"]))
    elements.append(Paragraph(
        "Now enter your readings for each variable as obtained from your manual like this real-life experiment here.",
        styles["step_text"]
    ))
    elements.append(Image(img("manual_table.jpg"), width=5*inch, height=7*inch))
    elements.append(Image(img("online_table_empty.jpg"), width=5*inch, height=7*inch))
    # elements.append(Paragraph("Real-Life Manual Table", styles["step_header"]))

    elements.append(PageBreak())

    # ---------------- STEP 4 ----------------
    elements.append(Paragraph("4. Automated Calculations Page", styles["step_header"]))
    elements.append(Paragraph(
        "After submitting your readings, CalixGuru performs all necessary calculations "
        "instantly, such as slopes, reciprocals, averages, and constants.",
        styles["step_text"]
    ))
    elements.append(Image(img("online_table_filled.jpg"), width=5*inch, height=7*inch))
    elements.append(Spacer(1, 6))
    elements.append(Image(img("online_table_filled2.jpg"), width=5*inch, height=7*inch))
    elements.append(PageBreak())

    # ---------------- STEP 5 ----------------
    elements.append(Paragraph("5. Final Computed Solution", styles["step_header"]))
    elements.append(Paragraph(
        "All final results and required answers appear below the automated table.",
        styles["step_text"]
    ))
    elements.append(Image(img("final_solution.jpg"), width=5*inch, height=7*inch))
    # elements.append(PageBreak())

    # ---------------- STEP 6 ----------------
    elements.append(Paragraph("6. Graph Display", styles["step_header"]))
    elements.append(Paragraph(
        "Tap the <b>View Graph</b> button to visualize a plotted graph of your readings.",
        styles["step_text"]
    ))
    elements.append(Image(img("graph_display.jpg"), width=5*inch, height=7*inch))
    # elements.append(PageBreak())

    # ---------------- SUBSCRIPTION NOTICE ----------------
    elements.append(Paragraph("Subscription Requirement", styles["step_header"]))
    elements.append(Paragraph(
        "To access automated calculations, graphs, and full practical solutions, "
        "students must be subscribed to a CalixGuru CBT Room.",
        styles["step_text"]
    ))

    # Footer note
    elements.append(Spacer(1, 18))
    elements.append(Paragraph("<para align=center><font size=12 color='grey'>© CALIXGURU — DIGITAL LEARNING AT IT'S FINEST</font></para>", base["Normal"]))

    # ---------------- BUILD PDF ----------------
    doc.build(elements, onFirstPage=_draw_header_footer, onLaterPages=_draw_header_footer)

    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename="CalixGuru_Physics_Practicals_Guide.pdf")


# ------------------------------- Django view -------------------------------
def physics_practicals_pdf_view(request):
    return generate_physics_practicals_pdf(request)

def selectpractical2(request):
    #q = request.GET.get('q') if request.GET.get('q') != None else ''
    topics = uniuyo1.prac2
    return render(request, 'base/select_practical2.html', {'topics': topics})



@login_required(login_url='login')
def share_contact(request):
    contacts = Contact.objects.filter(user_id = request.user.id)
    all = Contact.objects.all()
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        name = request.POST.get('name')
        contact = request.POST.get('phone_number')
        Contact.objects.create(name=name, phone_number=contact, user_id=user_id)
        messages.success(request, 'Contact successfully added')
        return redirect('share_contact')
    return render(request, 'base/contact.html', {'contacts': contacts, 'all': all})


def delete_contact(request, pk):
    contact = Contact.objects.get(id = pk)
    contact.delete()
    messages.success(request, 'Contact successfully deleted')
    return redirect ('share_contact')


@login_required(login_url='login')
def download_vcf(request):
    contacts = Contact.objects.all()
    if request.method == 'POST':
        vcf_content = ""
        for contact in contacts:
            vcf_content += f"BEGIN:VCARD\nVERSION:3.0\nFN:uniuyo_{contact.name}\nTEL:{contact.phone_number}\nEND:VCARD\n\n"

        response = HttpResponse(vcf_content, content_type="text/vcard")
        response["Content-Disposition"] = 'attachment; filename="contacts.vcf"'
        return response
    return render(request, 'base/all_contact.html', {'contacts': contacts})



def activate_practicals(request):
    room = Room.objects.first()

    if room is None:
        room = Room.objects.create(is_correct_active=False)

    is_correct_active = request.POST.get('is_correct_active', None)

    if is_correct_active == 'on':
        room.is_correct_active = True
    else:
        room.is_correct_active = False

    room.save()

    messages.success(request, "Practicals updated successfully!")

    return redirect(request.META.get('HTTP_REFERER', '/'))




def select_lessons(request):
    request.session['name_index'] = 0
    subject = request.GET.get('subject')
    request.session['subject'] = subject
    learn = []
    mathematics = quiz.mth
    chemistry = quiz.chm
    biology = quiz.bio
    physics = quiz.phy
    government = quiz.government
    # eng = quiz.english
    subject = request.session.get('subject')
    dict = {'physics':physics, 'biology':biology,'chemistry':chemistry,'government':government,'mathematics':mathematics,}
    for i in dict[subject]:
        if i['topic'] not in learn:
            learn.append(i['topic'])
    lesson = learn
    context = {'lessons': lesson}
    return render(request, 'base/select.html', context)

def update_number(request):
    request.session['name_index'] = 0
    return render(request, 'base/mthtest.html')


def get_current_name_index(request):
    if 'name_index' not in request.session:
        request.session['name_index'] = 0
    elif request.session['name_index'] < 0:
        request.session['name_index'] = -1
    else:
        pass

    return request.session['name_index']

def update_name_index(request, index):
    request.session['name_index'] = index

def homes(request):
    subject = request.session.get('subject')
    if request.method == 'POST':
        less = request.POST.get('courses')
        lessons = []
        for i in eval(less):
            lessons.append(i.replace(' ', '-'))
        request.session['lessons'] = lessons

    names = request.session.get('lessons', "")
    index = get_current_name_index(request)
    translate = {item["id"]: item for item in translations}
    option = request.session.get('option', "en")
    html = sorted([d['notes'] for d in notes.notes if d['topic'].replace(' ', '-') == names[index]])
    try:
        next = f"{translate.get('Next').get(option, 'Next')} ({names[index+1]})"
    except IndexError:
        next = f"{translate.get('Take Test').get(option, 'Next')}"
    context = {
        'current_name': names[index],
        'notes': html,
        'next_name': next,
        'index': index,
        'names_length': len(names),
        'subject': subject
    }
    return render(request, 'base/lesson.html', context)

def next_name(request):
    if request.method == 'POST':
        pass
    names = request.session.get('lessons', "")
    index = get_current_name_index(request)
    if index + 1 >= len(names):
        messages.success(request, "Test time")
        context = {
        'lesson': 'This is the last name',
        'id': len(names)
    }
        return lessons.lessons(request)
    else:
        update_name_index(request, index + 1)
        return redirect('homes')

def previous_name(request):
    index = get_current_name_index(request)
    if index - 1 < 0:
        messages.success(request, "This is where your lessons begins")
        return redirect('homes')
    else:
        update_name_index(request, index - 1)
        return redirect('homes')

def change_value(request):
    question = request.POST.get("question")
    f = request.POST.get("function")
    function = eval(request.POST.get("function"))
    correct = request.POST.get("correct")
    # params = counts(function)
    pattern = r'-?\d+\.?\d*'
    matches = re.findall(pattern, question)
    numbers = [float(num) if '.' in num else int(num) for num in matches]
    context = {
      'function': function,
        'question': question,
        # 'params': params,
        'numbers': numbers,
        'f': f,
        'correct': correct
    }
    return render(request, 'base/change_value.html', context)

def answers(request):
    numbers = eval(request.POST.get("numbers"))
    question = str(request.POST.get("question"))
    correct = request.POST.get("correct")
    f = str(request.POST.get("function"))
    nums = []
    nums2 = []
    q = 0
    while q<len(numbers):
        q=q+1
        nums2.append(q)
    for i, v in zip(numbers, nums2):
        nums.append(int(request.POST.get(f'{i}{v}')))
    func = str(nums).replace('[', '(')
    function = func.replace(']', ')')
    answer = round(eval(f'{f}{function}'), 3)
    combined = zip(numbers, nums)

    context = {
      'function': function,
        'question': question,
        'answer': answer,
        'combined': combined,
        'correct': correct
    }
    return render(request, 'base/answers.html', context)

def edit_project(request):
    user = request.user
    id = request.GET.get('id')
    all = Req.objects.get(id=id)
    if Pins.objects.filter(pin=user.id):
        if request.method == 'POST':
            current = request.POST.get('currency')
            title = request.POST.get('title')
            body = request.POST.get('body')
            amount = request.POST.get('amount')
            all.title = title
            all.body = body
            all.currency = current
            all.amount = amount
            if int(amount) > 10000000000:
                messages.error(request, "Amount's limit is 1 Billion")
            elif user.whatsapp == None:
                messages.error(request, "Ensure you have a whatsapp link in your profile")
            else:
                all.save()
                messages.success(request, "👍")
        context = {'all': all, 'currency': currency}
        return render(request, 'base/special2.html', context)
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def project(request):
    all = Req.objects.filter(status='Yes')
    context = {'all': all}
    if request.method == 'POST':
        ass = request.POST.get('assignment')
        assignment = Req.objects.get(id=ass)
        assignment.delete()
        messages.success(request, '👍')
        # return redirect(request.META.get('HTTP_REFERER', '/'))
    return render(request, 'base/projects.html', context)


def delproject(request):
    ass = request.GET.get('assignment')
    assignment = Req.objects.get(id=ass)
    assignment.delete()
    messages.success(request, '👍')
    return redirect(request.META.get('HTTP_REFERER', '/'))

def approve(request):
    ass = request.GET.get('assignment')
    assignment = Req.objects.get(id=ass)
    if assignment.status == 'No':
        assignment.status = 'Yes'
        assignment.save()
        messages.success(request, 'Approved')
    else:
        assignment.status = 'No'
        assignment.save()
        messages.success(request, 'Disapproved')
    return redirect(request.META.get('HTTP_REFERER', '/'))


def assignment(request):
    number = request.GET.get('assignment')
    assignment = Req.objects.get(id=number)
    context = {'ass': assignment}
    return render(request, 'base/assignment.html', context)

def pending(request):
    all = Req.objects.all().order_by('status')
    context = {'all': all}
    if request.method == 'POST':
        ass = request.POST.get('assignment')
        assignment = Req.objects.get(id=ass)
        assignment.delete()
        messages.success(request, '👍')
    return render(request, 'suf/projects.html', context)

def graph(request):
    number = request.GET.get('values')
    slope = request.GET.get('slope')
    intercept = request.GET.get('intercept')
    value = eval(number)
    x = []
    y = []

    for i in value:
        x.append(i[0])
        y.append(i[1])

    y_min = random.uniform(math.ceil(min(y)), math.floor(max(y)))
    y_max = random.uniform(math.ceil(min(y)), math.floor(max(y)))
    x_min = random.uniform(math.ceil(min(x)), math.floor(max(x)))
    x_max = random.uniform(math.ceil(min(x)), math.floor(max(x)))
    slope_y = [y_min, y_max]
    slope_x = [x_min, x_max]
    y1 = min(slope_y)
    y2 = max(slope_y)
    x1 = min(slope_x)
    x2 = max(slope_x)
    chh = []
    for i, v in zip(x, y):
        chh.append([i, v])
    context = {'x': x, 'y': y, 'x1': x1, 'y1': y1,
               'x2': x2, 'y2': y2, 'slope': slope,
               'intercept': intercept, 'chh': chh}
    return render(request, 'base/graph.html', context)

import requests, json
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST


@require_GET
def paystack_banks(request):
    """Fetch all Nigerian banks & wallets"""
    url = "https://api.paystack.co/bank"
    headers = {"Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}"}
    params = {"country": "nigeria"}
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 200:
        data = response.json().get("data", [])
        banks = [{"name": b["name"], "code": b["code"]} for b in data]
        return JsonResponse({"banks": banks})
    return JsonResponse({"banks": []}, status=500)

@csrf_exempt
@require_POST
def paystack_verify(request):
    """Verify bank account using Paystack API"""
    try:
        data = json.loads(request.body.decode())
        bank_code = data.get("bank_code")
        account_number = data.get("account_number")

        if not bank_code or not account_number:
            return JsonResponse({"status": False, "error": "Missing bank code or account number"}, status=400)

        headers = {"Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}"}
        url = f"https://api.paystack.co/bank/resolve?account_number={account_number}&bank_code={bank_code}"
        response = requests.get(url, headers=headers)

        # Log the API response for debugging
        print("PAYSTACK RESPONSE:", response.text)

        if response.status_code == 200:
            res_json = response.json()
            if res_json.get("status") and res_json.get("data"):
                info = res_json["data"]
                return JsonResponse({
                    "status": True,
                    "account_name": info.get("account_name"),
                    "account_number": info.get("account_number"),
                    "bank_code": bank_code
                })
            else:
                return JsonResponse({
                    "status": False,
                    "error": res_json.get("message", "Could not verify account")
                }, status=400)
        else:
            return JsonResponse({
                "status": False,
                "error": "Paystack request failed",
                "details": response.text
            }, status=response.status_code)

    except Exception as e:
        print("PAYSTACK VERIFY ERROR:", str(e))
        return JsonResponse({"status": False, "error": str(e)}, status=500)



