from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from datetime import timedelta
from django.utils.text import slugify
from django.template.defaultfilters import slugify
import uuid
import os


class User(AbstractUser):
    username = models.CharField(unique=True, max_length=50, null=True, blank=True)
    firstname = models.CharField(max_length=200, null=True, blank=True)
    lastname = models.CharField(max_length=200, null=True, blank=True)
    email = models.EmailField(unique=True, null=True, blank=True)
    contact = models.BigIntegerField(null=True, blank=True)
    ref = models.CharField(max_length=200, null=True, blank=True)
    amount = models.IntegerField(null=True, blank=True, default=0)
    whatsapp = models.CharField(max_length=200, null=True, blank=True)
    avatar = models.ImageField(upload_to='images/', default="avatar.svg")
    has_downloaded = models.IntegerField(default=0)
    cbt_details = models.JSONField(null=True, blank=True)
    cbt_quests = models.JSONField(null=True, blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

class UserLoginHistory(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    last_login_ip = models.GenericIPAddressField(blank=True, null=True)
    last_login_time = models.DateTimeField(blank=True, null=True)

class Pins(models.Model):
    pin = models.IntegerField(unique=True, null=True)
    name = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    duration = models.CharField(max_length=200, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    expiration_date = models.DateTimeField(default=timezone.now()+timedelta(days=14), null=True)
    
    def __str__(self):
        return self.name.username

class Tutor(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default='', unique=False)
    sent_mail = models.IntegerField(null=True, blank=True, default=0)

    def __str__(self):
        return f"{self.user.email}" 
       
class Pinbin(models.Model):
    name = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    pin = models.IntegerField(null=True, unique=False)

class Pinbin2(models.Model):
    name = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    pin = models.IntegerField(null=True, unique=True)



class Req(models.Model):
    hosts = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    amount = models.IntegerField(null=True, blank=True)
    currency = models.CharField(max_length=200, null=True, blank=True)
    title = models.CharField(max_length=200, null=True)
    body = models.TextField(null=True, blank=True)
    status = models.TextField(null=True, blank=True, default="No")
    updated = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True, null=True)
    # slug = models.SlugField(unique=True, blank=True)

    class Meta:
        ordering = ['-updated', '-created']
    
    def __str__(self):
        return self.title


class Cbtroom(models.Model):
    host = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    admins = models.JSONField(null=True, blank=True)
    name = models.TextField(null=True, blank=True)
    notification = models.TextField(null=True, blank=True)
    chats = models.ManyToManyField(
        User, related_name='chats', blank=True)
    quiz = models.JSONField(null=True, blank=True)
    pins = models.JSONField(null=True, blank=True)
    code = models.BigIntegerField(default=12345)
    number = models.BigIntegerField(default=1)
    downloads = models.BigIntegerField(default=1000)
    subscription = models.BigIntegerField(default=1000)
    pending = models.BigIntegerField(default=0)
    total = models.JSONField(null=True, blank=True)
    additions = models.BigIntegerField(default=0)
    course = models.TextField(null=True, blank=True)
    topics = models.JSONField(null=True, blank=True)
    used_pins = models.JSONField(null=True, blank=True)
    performers = models.JSONField(null=True, blank=True)
    allowed = models.JSONField(null=True, blank=True)
    is_active = models.BooleanField(default=False)
    is_correct_active = models.BooleanField(default=False)
    save_score = models.BooleanField(default=False)
    all_time = models.JSONField(null=True, blank=True)
    cheated = models.BooleanField(default=False)
    ac_name = models.TextField(null=True, blank=True)
    bank = models.TextField(null=True, blank=True)
    ac_number = models.TextField(null=True, blank=True)
    free_slots = models.BigIntegerField(default=5)
    departments = models.TextField(null=True, blank=True, default='')
    wagroup = models.TextField(null=True, blank=True, default = '')
    status = models.TextField(null=True, blank=True, default='Inactive')
    duration = models.IntegerField(null=True, blank=True, default=30)
    updated = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-updated', '-created']

    def __str__(self):
        return self.name

class Message(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    room = models.ForeignKey(Cbtroom, on_delete=models.CASCADE)
    chats = models.TextField()
    updated = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['updated', 'created']

    def __str__(self):
        return self.body

class Pays(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    trace =  models.CharField(max_length=255, default='Untraced')
    amount = models.BigIntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class CoverPage(models.Model):
    title = models.CharField(max_length=200)
    subtitle = models.CharField(max_length=200, blank=True)
    submitted_by = models.CharField(max_length=100)
    student_id = models.CharField(max_length=50, blank=True)
    submitted_to = models.CharField(max_length=100)
    course_name = models.CharField(max_length=100)
    institution_name = models.CharField(max_length=100)
    date_of_submission = models.DateField()
    style_choice = models.CharField(max_length=50, choices=[('style1', 'Classic'), ('style2', 'Modern')])

    def __str__(self):
        return self.title


# class QuestionRequest(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
#     image = models.ImageField(upload_to='questions/')
#     solution = models.TextField()
#     timestamp = models.DateTimeField(auto_now_add=True)
#
#     def __str__(self):
#         return f"Request by {self.user} at {self.timestamp}"

class Room(models.Model):
    is_correct_active = models.BooleanField(default=False)
    # Other fields...
    def __str__(self):
        return self.is_correct_active

class Contact(models.Model):
    name = models.CharField(max_length=255)
    user_id = models.BigIntegerField()
    phone_number = models.CharField(max_length=15, unique=True)

    def __str__(self):
        return self.name

class UploadedFile(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField()
    amount = models.BigIntegerField(default=1000)
    requests = models.JSONField(null=True, blank=True)
    allowed = models.JSONField(null=True, blank=True)
    file = models.CharField(max_length=255, unique=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class League(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    pin = models.CharField(max_length=255, unique=True)
    department = models.TextField()
    level = models.TextField(null=True, blank=True, default='No department')
    institution = models.TextField(null=True, blank=True, default='No Institution')
    phone = models.BigIntegerField(default=12345)
    courses = models.JSONField(null=True, blank=True)
    scores = models.JSONField(null=True, blank=True,)
    
    def __str__(self):
        return self.user.firstname

class Questions(models.Model):
    course = models.CharField(max_length=255, unique=False)
    topic = models.CharField(max_length=255, unique=False)
    pre = models.CharField(max_length=255, unique=False)
    eqn = models.CharField(max_length=255, unique=False)
    options = models.JSONField(null=True, blank=True)
    correct = models.IntegerField(null=True, blank=True,unique=False)
    # yt = models.CharField(max_length=255, default='')
    active = models.BooleanField(default=False)
    
    def __int__(self):
        return self.id
    
class TakenT(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default='', unique=False)
    topic = models.CharField(max_length=255, unique=False, default='')
    
    def __str__(self):
        return self.user.email
    

class BlogPost(models.Model):
    category = models.CharField(max_length=200, default='None')
    title = models.CharField(max_length=200)
    thumbnail = models.CharField(max_length=200, default='None')
    content = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    slug = models.SlugField(unique=True, blank=True)
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title
    
class Payment(models.Model):
    email = models.EmailField()
    reference = models.CharField(max_length=100, unique=True)
    amount = models.PositiveIntegerField()
    reason = models.CharField(max_length=50)  # e.g., 1-month-sub, 5-download, etc.
    created_at = models.DateTimeField(auto_now_add=True)
    paid = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.email} - {self.reference}"
    

class Question(models.Model):
    topic = models.CharField(max_length=200)
    subject = models.CharField(max_length=100)
    question_intro = models.TextField(default='')
    question_text = models.TextField(default='')
    option1 = models.CharField(max_length=255)
    option2 = models.CharField(max_length=255)
    option3 = models.CharField(max_length=255)
    option4 = models.CharField(max_length=255)
    correct_answer = models.CharField(max_length=225)
    function_name = models.CharField(max_length=100)
    variable_names = models.JSONField(default=list)  # E.g. ["a", "b", "c"]

    def __str__(self):
        return self.question_intro

# models.py
class Asspin(models.Model):
    code = models.CharField(max_length=10, unique=True)
    current_index = models.IntegerField(default=0)
    used = models.BooleanField(default=False)
    device_id = models.CharField(max_length=255, null=True, blank=True)  # lock PIN to one device



class Advertise(models.Model):
    business_name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    whatsapp_profile = models.URLField(max_length=255, help_text="WhatsApp link starting with https://wa.me/", blank=True)
    duration_days = models.PositiveIntegerField(default=1, help_text="Duration the advert should stay active (in days).")
    display_duration = models.PositiveIntegerField(default=10, help_text="Time (seconds) per slide.")
    created_at = models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=True)

    @property
    def end_date(self):
        return self.created_at + timezone.timedelta(days=self.duration_days)

    def is_active(self):
        now = timezone.now()
        return self.active and now <= self.end_date

    def __str__(self):
        return f"{self.business_name}"

    def deactivate_if_expired(self):
        """Automatically deactivate and delete if expired."""
        if timezone.now() > self.end_date:
            # Delete related images first
            for img in self.images.all():
                if img.image and os.path.isfile(img.image.path):
                    os.remove(img.image.path)
            self.delete()


class AdvertImage(models.Model):
    advertiser = models.ForeignKey(Advertise, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='adverts/')
    caption = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.advertiser.business_name} - Image"
    
# class Mails(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE, default='', unique=False)
#     sent_mail = models.IntegerField(null=True, blank=True, default=0)

#     def __str__(self):
#         return f"{self.user.email}" 

