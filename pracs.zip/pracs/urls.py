from django.urls import path
from . import views, uniuyo, ai, assignments
from pracs.dash import dash
from .pq import pq
from . import cbt as questions
from .gst_questions import gst
from .league import register
from .blogs import blog
import random
from .lessons import lessons
from django.contrib.auth import views as auth_views

# test = ["mathquiz1", "mathquiz2", "phyquiz1", "phyquiz2", "gstquiz1", "gstquiz2"]

# testviews = [questions.mathquiz1, questions.mathquiz2, questions.phyquiz1, questions.phyquiz2,
            #  questions.gstquiz1, questions.gstquiz2]


urlpatterns = [


    path('download-physics-practicals-guide/', views.physics_practicals_pdf_view, name='physics_practicals_pdf'),

    path('download/solutions/<int:room_id>/', questions.download_solutions_pdf, name='download_solutions_pdf'),
    path('quiz_competition/', assignments.assignment_view, name='assignment_view'),
    path('validate-pin/', assignments.validate_pin, name='validate_pin'),
    path('get-data/<int:index>/', assignments.get_data, name='get_data'),
    path('update-progress/', assignments.update_progress, name='update_progress'),

    path("score_history/<int:user_id>/", register.show_history, name="show_history"),
    path("get-questions/", register.get_random_questions, name="get_questions"),
    path("submit-quiz/", register.submit_quiz, name="submit_quiz"),
    path('leagueans/', register.leagueans, name="leagueans"),
    path('initiate-payment/', register.initiate_payment, name='initiate_payment'),
    path('verify-payment/', register.process_payment, name='verify-payment'),
    path('payment-cancelled/', register.payment_cancelled, name='payment-cancelled'),

    path('all-contestants/', register.all_con, name='all_con'),

    path('get-topic-rankings/', register.get_topic_rankings, name='get_topic_rankings'),

    path('post/<str:category>', blog.blog_list, name='blog_list'),
    path('post/new/', blog.blog_create, name='blog_create'),
    path('post/<str:slug>/', blog.blog_detail, name='blog_detail'),
    path('post/<int:pk>/edit/', blog.blog_update, name='blog_update'),
    path('post/<int:pk>/delete/', blog.blog_delete, name='blog_delete'),

    # path('solution/<str:function_name>/<int:a>/<int:b>/<int:c>/', pq.solution, name='solution'),  # Example of passing values to the function
    path('change_value/<int:question_id>/', pq.change_value, name='change_value'),
    path('question_lists/', pq.question_lists, name='question_lists'),
    path('delq', pq.delq, name='delq'),


    path('questions', register.q_list, name='q_list'),
    path('questions/new/',register.q_create, name='q_create'),
    path('questions/<int:pk>/', register.q_detail, name='q_detail'),
    path('questions/<int:pk>/edit/', register.q_update, name='q_update'),
    path('questions/<int:pk>/delete/', register.q_delete, name='q_delete'),

    # path("result/<int:score>/", register.result_page, name="result_page"),
    path("verify-pin/", register.verify_pin, name="verify_pin"),
    
    path("register-courses/", register.register_courses, name="register_courses"),
    path("competition/", register.competition, name="competition"),

    path("download_vcf/", views.download_vcf, name="download_vcf"),
    path("share_contact/", views.share_contact, name="share_contact"),
    path("delete_contact/<str:pk>", views.delete_contact, name="delete_contact"),

    path("uploads/", questions.upload_file, name="upload_file"),
    path("files/", questions.file_list, name="file_list"),
    path("edit_pdf/<int:file_id>/", questions.edit_pdf, name="edit_pdf"),
    path("request_pdf/<int:file_id>/", questions.request_pdf, name="request_pdf"),
    path("view_request_pdf/<int:file_id>/", questions.view_request_pdf, name="view_request_pdf"),
    path("all_docs/", questions.all_docs, name="all_docs"),
    path("view/<int:file_id>/", questions.view_pdf, name="view_pdf"),
    path("delete/<int:file_id>/", questions.delete_pdf, name="delete_pdf"),
    path("accept_req/", questions.accept_req, name="accept_req"),
    path("decline_req/", questions.decline_req, name="decline_req"),

    # path('adverts', views.adverts_slider, name='adverts_slider'),
    path('add_adverts/', dash.add_advert, name='add_advert'),
    path('advert_delete/<int:advert_id>/', dash.advert_delete, name='advert_delete'),


    path('reset_password/',
     auth_views.PasswordResetView.as_view(template_name="password/password_reset.html"),
     name="reset_password"),

    path('reset_password_sent/', 
        auth_views.PasswordResetDoneView.as_view(template_name="password/password_reset_sent.html"), 
        name="password_reset_done"),

    path('reset/<uidb64>/<token>/',
     auth_views.PasswordResetConfirmView.as_view(template_name="password/password_reset_form.html"), 
     name="password_reset_confirm"),

    path('reset_password_complete/', 
        auth_views.PasswordResetCompleteView.as_view(template_name="password/password_reset_done.html"), 
        name="password_reset_complete"),

    path("api/paystack/banks/", views.paystack_banks, name="paystack-banks"),
    path("api/paystack/verify/", views.paystack_verify, name="paystack-verify"),

    path('upload', ai.upload_image, name='upload_image'),
    path('reset_usage/', ai.reset_usage, name='reset_usage'),
    path('select-tournament/mathquiz1/mathscores1', uniuyo.mathscores1, name='mathscores1'),
    path('login/', views.loginPage, name="login"),
    path('activate/<uidb64>/<token>/', views.activate, name='activate'),
    path('confirm/', views.confirm, name="confirm"),
    path('project/', views.project, name="project"),
    path('graph/', views.graph, name="graph"),
    path('cbt/', questions.cbt, name="cbt"),
    path('edit_question/', questions.edit_question, name="edit_question"),
    path('del_question/', questions.del_question, name="del_question"),
    path('cbt_info/', questions.cbtinfo, name="cbt_info"),
    path('custom_downloads/', questions.custom_downloads, name="custom_downloads"),
    path('add_question/', questions.add_question, name="add_question"),
    path('cbt/host23547<str:pk>33153/', questions.cbtroom, name="cbtroom"),
    path('cbt/host23547<str:pk>33153/cbtroom_score', questions.cbtroom_score, name="cbt_score"),
    path('createcbt/', questions.createcbt, name="createcbt"),
    path('cbtans/', questions.cbtans, name="cbtans"),
    path('cbt_allowed/', questions.cbtallowed, name="cbtallowed"),
    
    path('cbt_personal/<str:pk>/', questions.cbt_personal, name="cbt_personal"),
    path('cbt_personal_test/<int:pk>/', questions.personal_test, name="personal_test"),
    path('download_solutions_pdf_custom/<int:pk>/', questions.download_solutions_pdf_custom, name="download_solutions_pdf_custom"),

    path('remove_allowed/', questions.remove_allowed, name="remove_allowed"),
    path('remove_admin/', questions.remove_admin, name="remove_admin"),
    path('del_cbtroom/', questions.del_cbtroom, name="del_cbtroom"),
    path('check-pin/', questions.check_pin, name='check_pin'),
    path('delete_msg/', questions.delete_message, name="delete_msg"),
    path('questions/', questions.questions, name="questions"),
    path('edit_room/', questions.notification, name="notification"),
    path('edit_project/', views.edit_project, name="edit_project"),
    path('assignment/', views.assignment, name="assignment"),
    path('select/next/change_value', views.change_value, name="change_value"),
    path('select/next/answers', views.answers, name="answers"),
    path('activate_practicals', views.activate_practicals, name="activate_practicals"),

    path('dashboard/', dash.dashboard, name="dashboard"),
    path('all_pins/', dash.all_pins, name="all_pins"),
    path('payments/', dash.payments, name="payments"),
    path('label_zero/', views.label_zero, name="label_zero"),
    path('projects/', views.pending, name="projects"),
    path('delproject/', views.delproject, name="delproject"),
    path('dashboard/addTutor', dash.addTutor, name="addTutor"),
    path('dashboard/delTutor', dash.delTutor, name="delTutor"),
    path('user/<int:pk>/delete/', dash.user_delete, name='user_delete'),
    path('message', dash.message, name="message"),
    path('approve/', views.approve, name="approve"),
    path('dashboard/dashboard-data', dash.dashboard_data, name="dashboard_data"),
    path('userinfo', dash.userinfo, name="userinfo"),
    path('dashboard/activation', dash.activation, name="activation"),
    path('dashboard/deactivation', dash.deactivation, name="deactivation"),

    path('logout/', views.logoutUser, name="logout"),
    path('phy111/', views.phy111, name="phy111"),
    path('mth111/', views.mth111, name="mth111"),
    path('gst112/', views.gst112, name="gst112"),
    path('register/', views.registerPage, name="register"),
    path('buypin/', views.buypin, name="buypin"),
    path('lessons/', lessons.lessons, name="lessons"),
    path('language/', views.language, name="language"),
    path('cover/', views.cover_page_form, name='cover'),

    path('', views.home, name="home"),
    path('select-tournament/select-gst/gst1', views.gst1, name="gst1"),
    path('select-tournament/select-gst/uniuyo/', assignments.uniuyo_ass, name="uniuyo_ass"),
    path('select-tournament/select-gst/aksu/', assignments.uniuyo_ass, name="aksu_ass"),
    path('select-tournament/select-gst/akscoe/', assignments.akscoe_ass, name="akscoe_ass"),

    path('select-tournament/cbtb1/', gst.cbtb1, name="cbtb1"),
    path('select-tournament/cbtb1/cbtb2', gst.cbtb2, name="cbtb2"),
    path('select-tournament/db1/', gst.db1, name="db1"),
    path('select-tournament/db2/', gst.db2, name="db2"),
    path('view_qa', gst.view_qa, name="view_qa"),
    path('select-tournament/db2/check-pin/', gst.check_pin, name="check_pin2"),

    path('select-tournament/select-practical/', views.selectpractical, name="select-practical"),
    path('select-tournament/select-practical2/', views.selectpractical2, name="select-practical2"),
    path('select-tournament/engr/', views.engr, name="engr"),
    path('select/', views.select_lessons, name="select"),
    path('select-tournament/', views.selectTournament, name="select-tournament"),
    path('update-user/', views.updateUser, name="update-user"),
    path('request/', views.request, name="request"),
    path('customcon/', views.customcon, name="customcon"),
    path('customcon/custom', views.custom, name="custom"),
    path('customcon/customans', views.customans, name="customans"),

    path('profile/user768474<str:pk>647893/', views.profile, name="profile"),
    path('topics/phy111', views.phy111, name="topphy111"),
    path('topics/mth111', views.mth111, name="topmth111"),
    path('topics/gst112', views.gst112, name="topgst112"),
    path('terms/', views.terms, name="terms"),

    path('select/homes', views.homes, name="homes"),
    path('update_number/', views.update_number, name="update_number"),

    path('select/next/', views.next_name, name='next_name'),
    path('select/previous/', views.previous_name, name='previous_name'),


    path('select-tournament/select-practical/p102/', uniuyo.p102, name="p102"),
    path('select-tournament/select-practical/p02/', uniuyo.p02, name="p02"),

    path('select-tournament/select-practical/p102/c00/', uniuyo.c00, name="c102"),
    path('select-tournament/select-practical/p02/c01/', uniuyo.c01, name="c02"),
    path('select-tournament/select-practical/p102/c00/L01', uniuyo.L01, name="L01"),
    path('select-tournament/select-practical/p02/c01/L02', uniuyo.L02, name="L02"),
    path('select-tournament/select-gst/pdfdownload', uniuyo.pdfdownload, name='pdfdownload'),

    path('test500/', views.test_500_error, name='test500'),


]
pracviews = [uniuyo.p0, uniuyo.p1, uniuyo.p2, uniuyo.p3, uniuyo.p5, uniuyo.p6, uniuyo.p7, uniuyo.p8, uniuyo.p9,uniuyo.p10, uniuyo.p11, uniuyo.p12, uniuyo.p13, uniuyo.p14, uniuyo.p15, uniuyo.p16,         uniuyo.p17, uniuyo.p18, uniuyo.p19, uniuyo.p20, uniuyo.p21, uniuyo.p22, uniuyo.p23,          uniuyo.p24, uniuyo.p25, uniuyo.p26, uniuyo.p27,uniuyo.p8, uniuyo.p29, uniuyo.p30, uniuyo.p31,uniuyo.p32, uniuyo.p33, uniuyo.p34, uniuyo.p35, uniuyo.p36, uniuyo.p37, uniuyo.p38]
pracviews2 = [uniuyo.p19, uniuyo.p20, uniuyo.p21, uniuyo.p22, uniuyo.p23,uniuyo.p24, uniuyo.p25, uniuyo.p26, uniuyo.p27,uniuyo.p8, uniuyo.p29, uniuyo.p30, uniuyo.p31,uniuyo.p32, uniuyo.p33,uniuyo.p34,uniuyo.p35, uniuyo.p36, uniuyo.p37, uniuyo.p38]
prac = []
p = -1
while p < 38+1:
    p = p + 1
    if p == 4:
        continue
    prac.append(p)
for i, v in zip(prac, pracviews):
    urlpatterns.append(path(f'select-tournament/select-practical/p{i}/', v, name=f"p{i}"))
    urlpatterns.append(path(f'select-tournament/select-practical2/p{i}/', v, name=f"p{i}"))
list1 = []
mm = -1
while mm < 18+1:
    mm = mm + 1
    if mm == 4:
        continue
    list1.append(mm)
list11 = []
m = 18
while m < 38+1:
    m = m + 1
    list11.append(m)
list2 = [uniuyo.c0, uniuyo.c1, uniuyo.c2, uniuyo.c3, uniuyo.c5, uniuyo.c6, uniuyo.c7, uniuyo.c8, uniuyo.c9,uniuyo.c10, uniuyo.c11, uniuyo.c12, uniuyo.c13, uniuyo.c14, uniuyo.c15, uniuyo.c16,uniuyo.c17, uniuyo.c18]
list21 = [uniuyo.c19, uniuyo.c20, uniuyo.c21, uniuyo.c22, uniuyo.c23,uniuyo.c24, uniuyo.c25, uniuyo.c26, uniuyo.c27,uniuyo.c28, uniuyo.c29, uniuyo.c30, uniuyo.c31,         uniuyo.c32, uniuyo.c33, uniuyo.c34, uniuyo.c35, uniuyo.c36, uniuyo.c37, uniuyo.c38]
list3 = [uniuyo.L0, uniuyo.L1, uniuyo.L2, uniuyo.L3, uniuyo.L5, uniuyo.L6, uniuyo.L7, uniuyo.L8, uniuyo.L9,uniuyo.L10, uniuyo.L11, uniuyo.L12, uniuyo.L13, uniuyo.L14, uniuyo.L15, uniuyo.L16,uniuyo.L17, uniuyo.L18]
list31 = [uniuyo.L19, uniuyo.L20,uniuyo.L21, uniuyo.L22, uniuyo.L23, uniuyo.L24, uniuyo.L25, uniuyo.L26, uniuyo.L27,uniuyo.L28, uniuyo.L29, uniuyo.L30, uniuyo.L31,uniuyo.L32, uniuyo.L33, uniuyo.L34, uniuyo.L35, uniuyo.L36, uniuyo.L37, uniuyo.L38]

for i, v in zip(list1, list2):
    urlpatterns.append(path(f'select-tournament/select-practical/p{i}/c{i}/', v, name=f'c{i}'))
for i, v in zip(list11, list21):
    urlpatterns.append(path(f'select-tournament/select-practical2/p{i}/c{i}/', v, name=f'c{i}'))
for i, v in zip(list1, list3):
    urlpatterns.append(path(f'select-tournament/select-practical/p{i}/c{i}/L{i}', v, name=f'c{i}'))
for i, v in zip(list11, list31):
    urlpatterns.append(path(f'select-tournament/select-practical2/p{i}/c{i}/L{i}', v, name=f'c{i}'))

# for i, v in zip(test, testviews):
#     urlpatterns.append(path(f'{i}/', v, name=f'{i}'))

