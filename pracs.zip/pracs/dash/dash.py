from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from pracs.models import *
from pracs.forms import *

from django.templatetags.static import static

# from PyPDF2 import PdfWriter, PdfReader
from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string
from xhtml2pdf import pisa
# from .utils import generate_pdf

from django.utils.timezone import now
from django.utils import timezone
from datetime import timedelta
from django.db.models import Sum
from pracs.views import categories,courses,uniuyo,aksu,akscoe,specials,prof_max, amounts,admin,currency
from pracs.mails import emails

def add_advert(request):
    if request.user.email in admin:
        if request.method == 'POST':
            ad_form = AdvertiserForm(request.POST)
            image_form = AdvertImageForm(request.POST, request.FILES)
            if ad_form.is_valid() and image_form.is_valid():
                advertiser = ad_form.save()
                img = image_form.save(commit=False)
                img.advertiser = advertiser
                img.save()
                messages.success(request, 'Advert added successfully')
                return redirect(request.META.get('HTTP_REFERER', '/'))
            else:
                messages.error(request, 'Error placing Advert')
                return redirect(request.META.get('HTTP_REFERER', '/'))
        else:
            ad_form = AdvertiserForm()
            image_form = AdvertImageForm()
    else:
        messages.error(request, 'Restricted')
        return redirect('home')
    return render(request, 'ads/add_advert.html', {'ad_form': ad_form, 'image_form': image_form})



def dashboard_data(request):
    now = timezone.now()  # timezone-aware datetime
    today = now.date()

    # Start of this month
    this_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    # Start of last month
    last_month = (this_month - timedelta(days=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    # Start of this week (Monday)
    this_week = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)

    # Start of last week
    last_week = this_week - timedelta(days=7)

    # Start of today & yesterday
    start_of_today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    start_of_tomorrow = start_of_today + timedelta(days=1)
    start_of_yesterday = start_of_today - timedelta(days=1)

    # Total users
    total_users = User.objects.count()

    # Total earnings
    total_earnings = Pays.objects.aggregate(total=Sum("amount"))["total"] or 0

    # Current month vs last month
    earnings_this_month = (
        Pays.objects.filter(created__gte=this_month).aggregate(total=Sum("amount"))["total"] or 0
    )
    earnings_last_month = (
        Pays.objects.filter(created__gte=last_month, created__lt=this_month).aggregate(total=Sum("amount"))["total"] or 0
    )

    # Current week vs last week
    earnings_this_week = (
        Pays.objects.filter(created__gte=this_week).aggregate(total=Sum("amount"))["total"] or 0
    )
    earnings_last_week = (
        Pays.objects.filter(created__gte=last_week, created__lt=this_week).aggregate(total=Sum("amount"))["total"] or 0
    )

    # Today vs yesterday
    earnings_today = (
        Pays.objects.filter(created__gte=start_of_today, created__lt=start_of_tomorrow).aggregate(total=Sum("amount"))["total"] or 0
    )
    earnings_yesterday = (
        Pays.objects.filter(created__gte=start_of_yesterday, created__lt=start_of_today).aggregate(total=Sum("amount"))["total"] or 0
    )

    # Chart (grouped by title)
    chart_data = (
        Pays.objects.values("title")
        .annotate(total_amount=Sum("amount"))
        .order_by("-total_amount")
    )

    result = {
        "cards": {
            "users": total_users,
            "total": {"value": total_earnings, "compare": None},  # no compare
            "month": {
                "value": earnings_this_month,
                "compare": earnings_last_month,
            },
            "week": {
                "value": earnings_this_week,
                "compare": earnings_last_week,
            },
            "day": {
                "value": earnings_today,
                "compare": earnings_yesterday,
            },
        },
        "chart": {
            "labels": [item["title"] for item in chart_data],
            "amounts": [item["total_amount"] for item in chart_data],
        },
    }
    return JsonResponse(result)


def dashboard(request):
    advertisers = Advertise.objects.filter(active=True)
    rooms = Cbtroom.objects.all()
    payments = Pays.objects.order_by('-id')[:5]
    users = User.objects.all()
    if request.user.email in admin:
        page = 'users'
        projects = Req.objects.filter(status='No')
        pins = []
        pin = Pins.objects.all()
        # code = Tutor.objects.all()
        # codes = []
        # for i in code:
        #     codes.append(i.email)
        for i in pin:
            pins.append({'pin':i.pin, 'duration':i.duration})
        pb = Pins.objects.all().order_by('name')
        pbm = list(Pins.objects.values_list('name', flat=True))
        usedpin = pb.count()
        amount = Pinbin.objects.all()
        amt = 1000*amount.count()
        context = {'user': users, 'usedpin': usedpin, 'amt': amt, 'projects': projects, 'adverts': advertisers,
                   'pb': pb,'pbm': pbm, 'pins': pins, 'pin': pin, 'page': page,
                   'rooms': rooms, 'pays': payments}
        return render(request, 'dash/dash.html', context)
    else:
        messages.error(request, 'Restricted')
        return redirect('home')

def all_pins(request):
    advertisers = Advertise.objects.filter(active=True)
    rooms = Cbtroom.objects.all()
    payments = Pays.objects.order_by('-id')[:10]
    users = User.objects.order_by('-id')[:10]
    if request.user.email in admin:
        context = {'rooms': rooms, 'users': users, 'pays': payments, 'adverts': advertisers,}
        return render(request, 'dash/pages/tables.html', context)
    else:
        messages.error(request, 'Restricted')
        return redirect('home')



def message2(request):
    # subject = "ENT221 BOOK REVIEW NOW ON CALIXGURU"
    # body = "Please visit https://calixguru.pythonanywhere.com/ to download your copy"

    # mails2 = ['dorcaseffretei@gmail.com','elijahudofia1234@gmail.com','victoriabigcity@gmail.com','domjosh111@gmail.com','rankindavid61@gmail.com','odupromise9@gmail.com','mondayblessed643@gmail.com','francisosung60@gmail.com','deborahsamuelup@gmail.com','matthiasedet0@gmail.com','debbygoldyoudoro7425@gmail.com','mosesharmony363@gmail.com','wisonguyo@gmail.com','akco4sure@gmail.com','etimubokutom@gmail.com','idaraumoh4455@gmail.com','thankgodetim90@gmail.com','vboniface2007@gmail.com','egbenonwue@gmail.com','giftibeh315@gmail.com','favourntia69@gmail.com','fortuneowarume05@gmail.com','akpanabigail583@gmail.com','etinimbosco@gmail.com','victorkalu229@gmail.com','bonifaceinyang9@gmail.com','blessingubong40@gmail.com','solomonblessing829@gmail.com','solomoniboro034@gmail.com','princewilldaniel2009@gmail.com','maduanastasia08@gmail.com','Osungemmanuel7@gmail.com','johnakeobong@gmail.com','queenolive.antia99@gmail.com','willsetim111@gmail.com','meyencyrus28@gmail.com','samuelnkanga25@gmail.com','dicksonkingsley49@gmail.com','nkantaemmanuel87@gmail.com','theeoneandonlyfaebae@gmail.com','emee.tok@gmail.com','malachimiracle8@gmail.com','lounelukpong@gmail.com','georgeeffiong224@gmail.com','sg7441411@gmail.com','axelblaze2k9@gmail.com','gideonsamuel181@gmail.com','okerekegideon75@gmail.com','okadigbojoshua900@gmail.com','contactellly@gmail.com','ebukaanagboso44@gmail.com','a8448789@gmail.com','preciousud23@gmail.com','etokfavour36@gmail.com','anyanwuchisom629@gmail.com','vickyhenz1122@gmail.com','emmaudoudos@gmail.com','ijeomaaguocha84@gmail.com','geenafrank06@gmail.com','udemegeorge75@gmail.com','Victorkalu229@gmail.com','smolfhorbo@gmail.com','egbenonwuchinedu@gmail.com','abasimfrekeokon@gmail.com','micaiahmfon@gmail.com','sampsonabasiuko@gmail.com','emmyironbar@gmail.com','uwakmfonabasi25@gmail.com','joyedjacob@gmail.com','godblessnya4@gmail.com','dominionsunday016@gmail.com','paulbethany92@gmail.com','gloryekanem15@gmail.com','favourene655@gmail.com','jaysaga.a1@gmail.com','joeldewonderboy@gmail.com','etimbukakapso@gmail.com','favouremet0508@gmail.com','canicechelsea@gmail.com','eme4preu@gmail.com','mfonwalter2022@gmail.com','prosperr776@gmail.com','estherolachi722@gmail.com','yhuteemee@gmail.com','preciousigwe707@gmail.com','ini485724@gmail.com','etoromicheal@gmail.com','its.royalekelly@gmail.com','vanessaraymond2005@gmail.com','miriamessien67@gmail.com','dominicglorious@gmail.com','johnabasiekong@gmail.com','destiny649paul@gmail.com','austinechideraf4@gmail.com','ikpaisongp@gmail.com','savemanalfred32udoh@gmail.com']
    # for i in mails2:
    #     to_email = i
    #     email = EmailMessage(subject, f'{body}', to=[to_email])
    #     email.send()

    # Send email to all users
    def split_in_fives(data):
        return [data[i:i+200] for i in range(0, len(data), 200)]

    # Example usage
    my_list = []
    for i in User.objects.all():
        my_list.append(i.email)
    result = split_in_fives(my_list)

    room = Room.objects.first()
    users = User.objects.all()#User.objects.all()
    if request.method == 'POST':
        try:
            mail = request.POST.get('mail')
            owner = User.objects.get(email=mail)
            return redirect('profile', owner.id)
        except:
            messages.error(request, f'Email does not exist')



    context = {'users': users, 'room': room, 'userss': result}
    return render(request, 'dash/all.html', context)

# def message(request):
#     users = User.objects.all()
#     if request.method == 'POST':
#         mail_subject = request.POST.get('subject')
#         message = request.POST.get('body')
#         for i in users:
#             try:
#                 to_email = i.email
#                 email = EmailMessage(mail_subject, f'Dear {i.firstname}, {message}', to=[to_email])
#                 # email.content_subtype = 'html'
#                 email.send()
#             except:
#                 continue
#         messages.success(request, 'Messages Sent!')
#         return redirect('dashboard')
#     context = {'users': users}
#     return render(request, 'dash/all.html', context)

def addTutor(request):
    if request.method == 'POST':
        try:
            user = request.POST.get("id")
            tutor = Tutor.objects.create(email=user)
            name = User.objects.get(email=tutor.email)
            messages.success(request, f'{name.firstname.upper()} is now your tutor')
            return redirect('dashboard')
        except:
            messages.success(request, f'{name.firstname.upper()} is already your tutor')
            return redirect('dashboard')

def delTutor(request):
    user = request.GET.get("id")
    tutor = User.objects.get(email=user)
    tutor.delete()
    # name = User.objects.get(email=user)
    messages.success(request, f'User deleted successfully')
    return redirect('dashboard')

def user_delete(request, pk):
    user = User.objects.get(id=pk)
    if request.method == 'POST':
        user.delete()
        messages.success(request, 'User successfully deleted')
        return redirect('dashboard')
    return render(request, 'base/user_confirm_delete.html', {'user': user})

def advert_delete(request, advert_id):
    if request.user.email in admin:
        advert = get_object_or_404(Advertise, id=advert_id)

        if request.method == 'POST':
            # Find and delete related AdvertImage files
            related_images = AdvertImage.objects.filter(advertiser=advert.id)
            for img in related_images:
                if img.image and os.path.exists(img.image.path):
                    os.remove(img.image.path)
                img.delete()  # Remove the database record too

            # Delete main advert if it has an image field
            if hasattr(advert, 'image') and advert.image:
                if os.path.exists(advert.image.path):
                    os.remove(advert.image.path)

            # Finally, delete the advert itself
            advert.delete()
            messages.success(request, 'Advertisement and all related files deleted successfully.')
            return redirect('dashboard')
    else:
        messages.error(request, 'Restricted')
        return redirect('home')

    return render(request, 'base/advert_confirm_delete.html', {'user': advert})

# file_path = file_obj.file.path  # Get full path

    # # Delete the file from storage if it exists
    # if os.path.exists(file_path):
    #     os.remove(file_path)

def userinfo(request):
    subject = request.GET.get('subject')
    if subject == 'all_daily_users':
        users = Pins.objects.filter(duration="daily")
        topic = 'DAILY SUBSCRIBED USERS'
    elif subject == 'all_weekly_users':
        users = Pins.objects.filter(duration="weekly")
        topic = 'WEEKLY SUBSCRIBED USERS'
    elif subject == 'all_monthly_users':
        users = Pins.objects.filter(duration="monthly")
        topic = 'MONTHLY SUBSCRIBED USERS'
    else:
        users = Pins.objects.all()
        topic = 'SUBSCRIBED USERS'
    context = {'users': users, 'topic': topic}
    return render(request, 'suf/users.html', context)

@login_required(login_url='login')
def activation(request):
    num = int(request.POST.get("id"))
    duration = request.POST.get("duration")
    users = User.objects.get(id=num)
    date = timezone.now().date()
    pindb = Pins.objects.filter(pin=num)
    if not pindb:
        values = Pins.objects.create(pin=num, name=users,
                                     duration=duration)
        values.save()
        values2 = Pinbin.objects.create(name=users, pin=num)
        values2.save()
        text = f"{users.email} is now activated"
        users.save()
        try:
            owner = Tutor.objects.get(code=users.ref.lower())
            tutor = User.objects.get(email=owner.email)
            if tutor.amount == None:
                tutor.amount = 0
            if duration.lower() == 'daily':
                tutor.amount = tutor.amount + (30*amounts['daily'])/100
            elif duration.lower() == 'weekly':
                tutor.amount = tutor.amount + (30*amounts['weekly'])/100
            elif duration.lower() == 'monthly':
                tutor.amount = tutor.amount + (30*amounts['monthly'])/100
            else:
                pass
            tutor.save()
        except:
            pass
        messages.success(request, text)
        return redirect('dashboard')
    else:
        day = Pins.objects.get(pin=num)
        text = f"{users.email} is already activated"
        messages.error(request, text)
        return redirect('dashboard')

@login_required(login_url='login')
def deactivation(request):
    num = int(request.POST.get("id"))
    pindb = Pins.objects.filter(pin=num)
    if pindb:
        user = User.objects.get(id=num)
        pindb.delete()
        text = f"{user} has successfully been deactivated"
        messages.success(request, text)
        return redirect('dashboard')
    else:
        user = User.objects.get(id=num)
        text = f"{user.firstname} is not active"
        messages.error(request, text)
        return redirect('dashboard')

@login_required(login_url='login')
def payments(request):
    if request.user.email in admin:
        rooms = Cbtroom.objects.all()
        users = User.objects.all()
        payments = Pays.objects.all()

        q = request.POST.get('q')

        searchr1 = Cbtroom.objects.filter(name__icontains=q)
        searchr2 = Cbtroom.objects.filter(host__firstname__icontains=q)
        searchr3 = Cbtroom.objects.filter(host__email__icontains=q)
        searchr4 = Cbtroom.objects.filter(host__lastname__icontains=q)

        searchu1 = User.objects.filter(id__icontains=q)
        searchu2 = User.objects.filter(firstname__icontains=q)
        searchu3 = User.objects.filter(email__icontains=q)
        searchu4 = User.objects.filter(lastname__icontains=q)

        searchp1 = Pays.objects.filter(title__icontains=q)
        searchp2 = Pays.objects.filter(user__firstname__icontains=q)
        searchp3 = Pays.objects.filter(user__email__icontains=q)
        searchp4 = Pays.objects.filter(user__lastname__icontains=q)

        room = searchr1|searchr2|searchr3|searchr4
        user = searchu1|searchu2|searchu3|searchu4
        pays = searchp1|searchp2|searchp3|searchp4

        context = {'rooms': room, 'users': user, 'pays': pays}
        return render(request, 'dash/pages/billing.html', context)
    else:
        messages.error(request, 'Restricted')
        return redirect('home')



@login_required(login_url='login')
def message(request):
    try:
        send = 'calixotu@gmail.com'
        if request.method == 'POST':
            try:
                idd = int(request.POST.get("mail_id"))
            except (TypeError, ValueError):
                messages.error(request, "Invalid Mail ID")
                return redirect(request.path)

            extra_message = request.POST.get("extra_message", "").strip()

            # 1️⃣ Find mail content by ID
            mail_data = next((m for m in emails.mails if m["id"] == idd), None)

            sent = User.objects.filter(ref=idd)

            if not mail_data:
                messages.error(request, "Mail ID not found")
                return redirect(request.path)

            subject = mail_data["email_header"]

            sent_count = 0

            # 2️⃣ Loop through users
            for user in User.objects.all():
                # user.ref = 0
                # user.save()

                # Skip users without email
                if not user.email:
                    continue

                # 3️⃣ Check if already sent
                if User.objects.filter(email=user.email, ref=idd).exists():
                    continue

                # 4️⃣ Render email
                html_message = render_to_string(
                    "email/custom_mails.html",
                    {
                        "user": user,
                        "mail": mail_data,
                        "extra_message": extra_message,
                    }
                )

                # 5️⃣ Send email
                send_mail(
                    subject=subject,
                    message="",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[user.email],
                    html_message=html_message,
                    fail_silently=False,
                )
                # send_mail(subject, "", settings.DEFAULT_FROM_EMAIL, [user.email], html_message=html_message)

                # 6️⃣ Track sent mail
                user.ref = idd
                user.save()

                sent_count += 1

            messages.success(
                request,
                f"Mail ID {idd} sent successfully to {sent_count} user(s) succesfully but {sent.count()} users in general"
            )
    except:
        pass

    # Always render page with mails for JS preview
    context = {
        "mails": emails.mails,
        "sent": User.objects.filter(ref = '1').count(),
    }
    return render(request, "dash/pages/mails.html", context)
