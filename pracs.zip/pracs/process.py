
def option(request):
    return {
        'option': request.session.get('option', 'en')  
    }