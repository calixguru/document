import math, re
import sympy

def sci(value):
    try:
        # Convert to float if possible
        number = float(value)
        
        # If it’s already in scientific notation or long decimal, format it
        if 'e' in str(value).lower() or ('.' in str(value) and len(str(value).split('.')[-1]) > 3):
            base_exponent = f"{number:.3e}"  # format as scientific notation
            base, exponent = base_exponent.split('e')
            base = base.rstrip('0').rstrip('.') if '.' in base else base
            exponent = int(exponent)
            return f"{{{base}}} × 10^{{{exponent}}}"

        # Otherwise return as-is
        return str(value)
    except:
        return str(value)
    

def area_under_curve(a, b, c, d):
    steps = []
    if c > d:
        c, d = d, c

    power = b + 1
    coefficient = round(a / power, 1)

    area_expr = lambda x: round(coefficient * (x ** power), 1)
    area_c = area_expr(c)
    area_d = area_expr(d)
    area = round(area_d - area_c, 1)

    question_text = rf''' <b>Find the area under the curve <br> \( y = {a}x^{{{{{b}}}}} \) from \( x = {c} \) to \( x = {d} \)<hr><hr>
       To find the area under \( y = {a}x^{{{{{b}}}}} \) from \( x = {c} \) to \( x = {d} \), <hr><hr> we integrate:
            \(
            \int_{{{c}}}^{{{d}}} {a}x^{{{{{b}}}}} \, dx
            \)<hr><hr>
            \(
            \int {a}x^{{{{{b}}}}} \, dx = {a} \cdot \frac{{x^{{{{{power}}}}}}}{{{power}}} 
            \)<br>
            \(
            = {coefficient}x^{{{power}}}
            \)<br><br>
            \(
            \text{{Evaluate at limits: }} \left({coefficient}x^{{{{{power}}}}}\right)_{{{c}}}^{{{d}}} 
            \)<hr><hr>
            \(= {coefficient}({d})^{{{{{power}}}}} - {coefficient}({c})^{{{{{power}}}}}\)<hr><hr>
            \(= {area_d} - {area_c} \)<hr><hr>
            \(= {area} \)'''
    steps.append(question_text)

    return {
        "steps": steps,
        "result": rf"\( \text{{Area}} = {area} \text{{ units}}^2 \)"
    }


def inverse_function(a, b, c):
    steps = []

    # Original function: f(x) = a(bx - c)
    # To find the inverse, solve for x in terms of y, then swap x and y

    steps.append(rf"<b>Given:</b> \( f(x) = {a}({b}x - {c}) \)<hr><hr>")
    steps.append(rf"Let \( y = {a}({b}x - {c}) \)<hr><hr>")
    steps.append(rf"Solve for \( x \):<br>")
    steps.append(rf"\( y = {a}({b}x - {c}) \)<br>")
    steps.append(rf"\( \frac{{y}}{{{a}}} = {b}x - {c} \)<br>")
    steps.append(rf"\( \frac{{y}}{{{a}}} + {c} = {b}x \)<br>")
    steps.append(rf"\( x = \frac{{\frac{{y}}{{{a}}} + {c}}}{{{b}}} \)<br>")
    steps.append(rf"Now, swap \( x \) and \( y \):<hr><hr>")
    steps.append(rf"\( f^{{-1}}(x) = \frac{{\frac{{x}}{{{a}}} + {c}}}{{{b}}} \)")

    inverse_expr = rf"\( f^{{-1}}(x) = \frac{{\frac{{x}}{{{a}}} + {c}}}{{{b}}} \)"

    return {
        "steps": steps,
        "result": inverse_expr
    }


def domain_of_function(c):
    steps = []

    steps.append(rf"<b>Given:</b> \( f(u) = \sqrt{{{c} - u}} \)<hr><hr>")
    steps.append(rf"To ensure \( f(u) \) is real, the expression under the square root must be ≥ 0:<br><br>")
    steps.append(rf"\( {c} - u \ge 0 \)<br>")
    steps.append(rf"\( u \le {c} \)<br><br>")
    steps.append(rf"So the domain of \( f(u) \) is:<br>")
    steps.append(rf"\( u \in (-\infty, {c}] \)")

    return {
        "steps": steps,
        "result": rf"\( \text{{Domain}} = (-\infty, {c}] \)"
    }

def average_rate_of_change(a, b, c, d):
    steps = []

    fx = lambda x: round(a * (x ** b), 1)
    f_c = fx(c)
    f_d = fx(d)
    rate = round((f_d - f_c) / (d - c), 1)

    steps.append(rf"<b>Given:</b> \( f(x) = {a}x^{{{{{b}}}}} \)<hr><hr>")
    steps.append(rf"Find the average rate of change from \( x = {c} \) to \( x = {d} \):<br><br>")
    steps.append(rf"\( f({d}) = {a}({d})^{{{{{b}}}}} = {f_d} \)<br>")
    steps.append(rf"\( f({c}) = {a}({c})^{{{{{b}}}}} = {f_c} \)<br><br>")
    steps.append(rf"Average rate of change formula:<br>")
    steps.append(rf"\( \frac{{f({d}) - f({c})}}{{{d} - {c}}} = \frac{{{f_d} - {f_c}}}{{{d - c}}} = {rate} \)")

    return {
        "steps": steps,
        "result": rf"\( \text{{Average rate of change}} = {rate} \)"
    }

def area_enclosed(a, b, c, d):
    steps = []
    if c > d:
        c, d = d, c

    power = b + 1
    coefficient = round(a / power, 1)

    area_expr = lambda x: round(coefficient * (x ** power), 1)
    area_c = area_expr(c)
    area_d = area_expr(d)
    area = round(area_d - area_c, 1)

    question_text = rf'''<b>Find the area enclosed by the curve <br> \( y = {a}x^{{{{{b}}}}} \) and the x-axis between \( x = {c} \) and \( x = {d} \)<hr><hr>
       To find the area under \( y = {a}x^{{{{{b}}}}} \) from \( x = {c} \) to \( x = {d} \), <hr><hr> we integrate:
            \(
            \int_{{{c}}}^{{{d}}} {a}x^{{{{{b}}}}} \, dx
            \)<hr><hr>
            \(
            \int {a}x^{{{{{b}}}}} \, dx
            \)
            =
            \(
            {a} \cdot \frac{{x^{{{{{power}}}}}}}{{{power}}}
            \)
            =
            \(
            {coefficient}x^{{{{{power}}}}}
            \)<br><br>
            \(
            \text{{Evaluate at limits: }} \left({coefficient}x^{{{{{power}}}}}\right)_{{{c}}}^{{{d}}}
            \)<hr><hr>
            \(= {coefficient}({d})^{{{{{power}}}}} - {coefficient}({c})^{{{{{power}}}}}\)<hr><hr>
            \(= {area_d} - {area_c} \)<hr><hr>
            \(= {area} \)'''
    steps.append(question_text)

    return {
        "steps": steps,
        "result": rf"\( \text{{Area}} = {area} \text{{ units}}^2 \)"
    }


def range_of_cubic(a, b):
    steps = []

    if b % 2 == 0:
        range_text = r"\( \text{Range} = [0, \infty) \)"
    else:
        range_text = r"\( \text{Range} = (-\infty, \infty) \)"

    explanation = rf'''<b>Find the range of the function <br> \( f(x) = {a}x^{{{{{b}}}}} \)<hr><hr>
The function \( f(x) = {a}x^{{{{{b}}}}} \) is a power function.<hr><hr>
Because the power is <b>{b}</b> and it is {'odd' if b % 2 != 0 else 'even'}, <br>the function is {'increasing and passes through all real numbers' if b % 2 != 0 else 'non-negative and has a minimum at x = 0'}<hr><hr>
Hence, the range is:<br><br>
{range_text}
'''
    steps.append(explanation)

    return {
        "steps": steps,
        "result": range_text
    }

def limit_sin_over_linear_cos(a, b):
    steps = []

    steps.append(rf'''<b>We are to evaluate:</b><br><br>
\[
\lim_{{x \to 0}} \frac{{\sin({a}x)}}{{{b}x + \cos x}}
\]
<hr>

<b>Step 1: Expand or use standard limits.</b><br><br>
As \( x \to 0 \), we know:
\[
\sin({a}x) \approx {a}x \quad \text{{and}} \quad \cos x \approx 1
\]

So the limit becomes:
\[
\lim_{{x \to 0}} \frac{{{a}x}}{{{b}x + 1}} = \frac{{{a} \cdot 0}}{{{b} \cdot 0 + 1}} = 0
\]

<b>Therefore,</b>
\[
\lim_{{x \to 0}} \frac{{\sin({a}x)}}{{{b}x + \cos x}} = 0
\]
''')

    return {
        "steps": steps,
        "result": r"\( \boxed{0} \)"
    }



def evaluate_exp_integral(k, a, b):
    steps = []
    if a > b:
        a, b = b, a

    coefficient = round(1 / k, 1)
    upper = round(coefficient * math.exp(k * b), 1)
    lower = round(coefficient * math.exp(k * a), 1)
    area = round(upper - lower, 1)

    steps.append(rf'''<b>Evaluate:</b><br><br>
\(
\int_{{{a}}}^{{{b}}} e^{{{k}x}} \, dx
\)<br><br>
Integrating:<br><br>
\(
\int e^{{{k}x}} \, <br>dx = \frac{{1}}{{{k}}}e^{{{k}x}}<br> ={coefficient}e^{{{k}x}}
\)<br><br>
Evaluate at the limits:<br><br>
\(
\left( {coefficient}e^{{{k}x}} \right)_{{{a}}}^{{{b}}}
\)<br><br>
\(
= {coefficient}e^{{{k} \cdot {b}}} - {coefficient}e^{{{k} \cdot {a}}}
\)<br>
\(
= {upper} - {lower}
\)<br>
= {area}<br><br>
Answer: <b>{area}</b>
''')

    return {
        "steps": steps,
        "result": rf"\( \text{{Area}} = {area} \)"
    }

def displacement_from_velocity(a, p1, b, given_t, given_s):
    steps = []

    # Integral part
    power = p1 + 1
    first_term_coeff = round(a / power, 1)
    integral_expr = rf"{first_term_coeff}t^{{{{{power}}}}} - {b}"

    # General s(t)
    steps.append(rf'''<b>Given:</b> \( v(t) = {a}t^{{{{{p1}}}}} - {b} \), and \( s({given_t}) = {given_s} \)<br><br>
We integrate \( v(t) \) to get \( s(t) \):<br><br>
\(
s(t) = \int v(t) \, dt = \int \left({a}t^{{{{{p1}}}}} - {b} \right) dt
\)<br><br>
\(
= \int {a}t^{{{{{p1}}}}} \, dt - \int {b} \, dt
\)<br><br>
\(
= {first_term_coeff}t^{{{{{power}}}}} - {b}t + C
\)<br><br>
We’re told \( s({given_t}) = {given_s} \):<br><br>
\(
s({given_t}) = {first_term_coeff}({given_t})^{{{{{power}}}}} - {b}({given_t}) + C = {given_s}
\)<br><br>
\(
= {round(first_term_coeff * (given_t**power), 1)} - {b * given_t} + C = {given_s}
\)<br><br>
\(
C = {given_s} - {round(first_term_coeff * (given_t**power), 1) - b * given_t} = {round(given_s - (first_term_coeff * (given_t**power) - b * given_t), 1)}
\)<br><br>
So:<br><br>
\(
s(t) = {first_term_coeff}t^{{{{{power}}}}} - {b}t + {round(given_s - (first_term_coeff * (given_t**power) - b * given_t), 1)}
\)
''')

    return {
        "steps": steps,
        "result": rf"\( s(t) = {first_term_coeff}t^{{{{{power}}}}} - {b}t + {round(given_s - (first_term_coeff * (given_t**power) - b * given_t), 1)} \)"
    }


def implicit_differentiation_quad(a, p1, b, p2, c):
    steps = []

    # Display given
    steps.append(rf'''<b>Given:</b> \( {a}x^{{{p1}}}y + {b}y^{{{p2}}} = {c}x \)<br><br>
Differentiate both sides with respect to \( x \):<br><br>
Left side:<br>
\(
\frac{{d}}{{dx}}[{a}x^{{{p1}}}y] + \frac{{d}}{{dx}}[{b}y^{{{p2}}}]
\)<br><br>
Use product rule on first term:<br>
\(
= {a}\left(x^{{{p1}}} \cdot \frac{{dy}}{{dx}} + {p1}x^{{{p1 - 1}}}y\right)
\)<br>
Use chain rule on second term:<br>
\(
= + {b} \cdot {p2}y^{{{p2 - 1}}} \cdot \frac{{dy}}{{dx}}
\)<br><br>

Differentiate the right side:<br>
\(
\frac{{d}}{{dx}}[{c}x] = {c}
\)<br><br>

Now combine all:<br>
\(
{a}x^{{{p1}}} \frac{{dy}}{{dx}} + {a * p1}x^{{{p1 - 1}}}y + {b * p2}y^{{{p2 - 1}}} \frac{{dy}}{{dx}} = {c}
\)<br><br>

Group \( \frac{{dy}}{{dx}} \) terms:<br>
\(
\left({a}x^{{{p1}}} + {b * p2}y^{{{p2 - 1}}}\right)\frac{{dy}}{{dx}} = {c} - {a * p1}x^{{{p1 - 1}}}y
\)<br><br>

Finally, solve for \( \frac{{dy}}{{dx}} \):<br>
\(
\frac{{dy}}{{dx}} = \frac{{{c} - {a * p1}x^{{{p1 - 1}}}y}}{{{a}x^{{{p1}}} + {b * p2}y^{{{p2 - 1}}}}}
\)
''')

    # Final result
    result = rf"\( \frac{{dy}}{{dx}} = \frac{{{c} - {a * p1}x^{{{p1 - 1}}}y}}{{{a}x^{{{p1}}} + {b * p2}y^{{{p2 - 1}}}}} \)"
    
    return {
        "steps": steps,
        "result": result
    }


def gradient_of_normal_quadratic(ax, bx, cy, x0, y0):
    steps = []

    # Compute partial derivatives
    dF_dx = 2 * ax * x0 - bx
    dF_dy = 2 * cy * y0

    # Handle edge case: fy = 0 (i.e., vertical tangent)
    if dF_dy == 0:
        steps.append(rf"""
        <b>Find the gradient of the normal to the curve:</b><br>
        \[
        {ax}x^2 - {bx}x + {cy}y^2 = 0
        \]
        at the point \( ({x0}, {y0}) \)<br><br>

        Partial derivatives:<br>
        \[
        \frac{{\partial F}}{{\partial x}} = 2({ax})({x0}) - {bx} = {dF_dx} \quad , \quad \frac{{\partial F}}{{\partial y}} = 2({cy})({y0}) = {dF_dy}
        \]<br><br>

        Since \(\frac{{\partial F}}{{\partial y}} = 0\), the derivative \(\frac{{dy}}{{dx}}\) is undefined.<br>
        The tangent is vertical ⇒ normal is horizontal.<br><br>

        <b>Final Answer:</b><br>
        \[
        \boxed{{\text{{Gradient of normal}} = 0}}
        \]
        """)
        return {
            "steps": steps,
            "result": r"\( \text{Gradient of normal} = 0 \)"
        }

    # Compute dy/dx and gradient of normal
    dydx = -dF_dx / dF_dy
    dydx = round(dydx, 4)

    # Avoid division by 0 when tangent is horizontal
    if dydx == 0:
        steps.append(rf"""
        <b>Find the gradient of the normal to the curve:</b><br>
        \[
        {ax}x^2 - {bx}x + {cy}y^2 = 0
        \]
        at the point \( ({x0}, {y0}) \)<br><br>

        Partial derivatives:<br>
        \[
        \frac{{\partial F}}{{\partial x}} = 2({ax})({x0}) - {bx} = {dF_dx} \quad , \quad \frac{{\partial F}}{{\partial y}} = 2({cy})({y0}) = {dF_dy}
        \]<br><br>

        \[
        \frac{{dy}}{{dx}} = - \frac{{{dF_dx}}}{{{dF_dy}}} = {dydx}
        \]
        Since tangent is horizontal ⇒ normal is vertical<br><br>

        <b>Final Answer:</b><br>
        \[
        \boxed{{\text{{Gradient of normal}} = \infty}}
        \]
        """)
        return {
            "steps": steps,
            "result": r"\( \text{Gradient of normal} = \infty \)"
        }

    # Normal gradient (reciprocal with flipped sign)
    normal = round(-1 / dydx, 4)

    steps.append(rf"""
<b>Find the gradient of the normal to the curve:</b><br>
\[
{ax}x^2 - {bx}x + {cy}y^2 = 0
\]
at the point \( ({x0}, {y0}) \)<br><br>

<b>Step 1: Differentiate implicitly:</b><br>
\[
\frac{{d}}{{dx}}({ax}x^2 - {bx}x + {cy}y^2) = 0
\]<br>
\[
2 \cdot {ax} \cdot x - {bx} + 2 \cdot {cy} \cdot y \cdot \frac{{dy}}{{dx}} = 0
\]<br><br>

<b>Step 2: Plug in the point ({x0}, {y0}):</b><br>
\[
2({ax})({x0}) - {bx} + 2({cy})({y0}) \cdot \frac{{dy}}{{dx}} = 0
\]<br>
\[
{dF_dx} + {dF_dy} \cdot \frac{{dy}}{{dx}} = 0 \Rightarrow \frac{{dy}}{{dx}} = - \frac{{{dF_dx}}}{{{dF_dy}}} = {dydx}
\]<br><br>

<b>Step 3: Gradient of the normal =</b><br>
\[
- \frac{{1}}{{{dydx}}} = \boxed{{{normal}}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \text{{Gradient of normal}} = {normal} \)"
    }



def limit_rational_at_infinity(a1, b1, c1, a2, b2, c2):
    steps = []

    steps.append(rf"""
<b>Evaluate the limit:</b><br>
\[
\lim_{{x \to \infty}} \frac{{{a1}x^3 + {b1}x^2 + {c1}}}{{{a2}x^3 + {b2}x^2 + {c2}}}
\]<br><br>

<b>Step 1: Identify the leading terms (highest powers of x):</b><br>
\[
\frac{{{a1}x^3}}{{{a2}x^3}} = \frac{{{a1}}}{{{a2}}}
\]<br><br>

<b>Step 2: As \( x \to \infty \), lower-order terms become negligible:</b><br>
\[
\lim_{{x \to \infty}} \frac{{{a1}x^3 + \dots}}{{{a2}x^3 + \dots}} = \frac{{{a1}}}{{{a2}}}
\]<br><br>

<b>Final Answer:</b><br>
\[
\boxed{{{round(a1/a2, 2)}}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \lim_{{x \to \infty}} = \boxed{{{round(a1/a2, 2)}}} \)"
    }


def coulombs_law_force_micro(q1_micro, q2_micro, r):
    steps = []
    q1 = q1_micro * 1e-6
    q2 = q2_micro * 1e-6
    k = 9e9

    F = round(k * abs(q1 * q2) / r**2, 2)

    steps.append(rf"""
<b>Calculate the magnitude of the electrostatic force between two charges:</b><br>
Given:<br>
- \( q_1 = {q1_micro} \mu C = {sci(q1)} \, C \)<br>
- \( q_2 = {q2_micro} \mu C = {sci(q2)} \, C \)<br>
- \( r = {r} \, m \)<br><br>

<b>Step 1: Use Coulomb's Law:</b><br>
\[
F = \frac{{k \cdot |q_1 \cdot q_2|}}{{r^2}}
\]
Where \( k = 9 \times 10^9 \, Nm^2/C^2 \)<br><br>

<b>Step 2: Plug in the values:</b><br>
\[
F = \frac{{9 \times 10^9 \cdot {sci(q1)} \cdot {sci(q2)}}}{{({r})^2}} = {F} \, N
\]<br><br>

<b>Final Answer:</b><br>
\[
\boxed{{F = {sci(F)} \, N}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \boxed{{F = {sci(F)} \, \text{{N}}}} \)"
    }

def electric_field_from_point_charge(q_micro, r):
    steps = []
    q = q_micro * 1e-6
    k = 9e9

    E = round(k * q / r**2, 2)

    steps.append(rf"""
<b>Calculate the electric field at a distance from a point charge:</b><br>
Given:<br>
- \( q = {q_micro} \mu C = {sci(q)} \, C \)<br>
- \( r = {r} \, m \)<br><br>

<b>Step 1: Use the electric field formula:</b><br>
\[
E = \frac{{k \cdot q}}{{r^2}}
\]
Where \( k = 9 \times 10^9 \, Nm^2/C^2 \)<br><br>

<b>Step 2: Plug in the values:</b><br>
\[
E = \frac{{9 \times 10^9 \cdot {sci(q)}}}{{({r})^2}} = {E} \, N/C
\]<br><br>

<b>Final Answer:</b><br>
\[
\boxed{{E = {sci(E)} \, \text{{N/C}}}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \boxed{{E = {sci(E)} \, \text{{N/C}}}} \)"
    }

def force_on_proton(E, q=1.6e-19):
    steps = []

    F = E * q

    steps.append(rf"""
<b>Calculate the force experienced by a proton in an electric field:</b><br>
Given:<br>
- \( E = {E} \, N/C \)<br>
- \( q = 1.6 \times 10^{{-19}} \, C \) (charge of a proton)<br><br>

<b>Step 1: Use the formula:</b><br>
\[
F = qE
\]<br><br>

<b>Step 2: Plug in the values:</b><br>
\[
F = 1.6 \times 10^{{-19}} \cdot {E} \, N
\]<br><br>

<b>Final Answer:</b><br>
\[
\boxed{{F = {sci(F)} \, \text{{N}}}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \boxed{{F = {sci(F)} \, \text{{N}}}} \)"
    }

def identical_charge_from_force(F, r):
    from math import sqrt
    k = 9e9
    q = sqrt(F * r**2 / k)

    steps = []

    steps.append(rf"""
<b>Calculate the magnitude of each identical charge given the force between them:</b><br>
Given:<br>
- \( F = {F} \, N \)<br>
- \( r = {r} \, m \)<br><br>

<b>Step 1: Use rearranged Coulomb's Law:</b><br>
\[
F = \frac{{k \cdot q^2}}{{r^2}} \Rightarrow q = \sqrt{{\frac{{F \cdot r^2}}{{k}}}}
\]<br><br>

<b>Step 2: Plug in values:</b><br>
\[
q = \sqrt{{\frac{{{F} \cdot ({r})^2}}{{9 \times 10^9}}}} = {sci(q)} \, C
\]<br><br>

<b>Final Answer:</b><br>
\[
\boxed{{q = {sci(q)} \, \text{{C}}}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \boxed{{q = {sci(q)} \, \text{{C}}}} \)"
    }

def work_done_by_charge(q_micro, V1, V2):
    steps = []
    q = q_micro * 1e-6
    delta_V = V1 - V2
    W = q * delta_V

    steps.append(rf"""
<b>Calculate the work done in moving a charge across a potential difference:</b><br>
Given:<br>
- \( q = {q_micro} \mu C \)<br>
- \( V_1 = {V1} \, V \)<br>
- \( V_2 = {V2} \, V \)<br><br>

<b>Step 1: Use the work-energy relation:</b>
\[
W = q \cdot (V_1 - V_2)
\]

<b>Step 2: Plug in the values:</b>
\[
W = {q_micro} \mu C \cdot ({V1} - {V2}) \, J
\]<br><br>

<b>Final Answer:</b>
\[
\boxed{{W = {sci(W)} \, \text{{J}}}}
\]
""")

    return {
        "steps": steps,
        "result": rf"\( \boxed{{W = {sci(W)} \, \text{{J}}}} \)"
    }

# def inverse_fractional_linear_alt(a, b, c, x):
#     steps = []
#     steps.append(rf"Given f(x) = ({a}x − {b}) / {c}")
#     steps.append("Step 1: Replace f(x) with y:")
#     steps.append(rf"y = ({a}x − {b}) / {c}")
#     steps.append("Step 2: Swap x and y:")
#     steps.append(rf"x = ({a}y − {b}) / {c}")
#     steps.append("Step 3: Solve for y:")
#     steps.append(rf"{a}y − {b} = {c}x")
#     steps.append(rf"{a}y = {c}x + {b}")
#     steps.append(rf"y = ({c}x + {b}) / {a}")
#     result = round((c * x + b) / a, 2)
#     steps.append(rf"Substitute x = {x}: y = {result}")
#     return {
#         "steps": steps,
#         "result": rf"f⁻¹({x}) = {result}"
#     }


# def limit_tangent_small_angle(k, x_val):
#     steps = []
#     steps.append(rf"Evaluate: lim x → {x_val} of tan({k}x)/x")
#     steps.append("Step 1: Use identity: lim x→0 tan(kx)/x = k")
#     steps.append(rf"Since x → 0, lim tan({k}x)/x = {k}")
#     return {
#         "steps": steps,
#         "result": rf"lim x → {x_val} = {k}"
#     }

# def limit_highest_power_ratio(a, b, c, d, e, f):
#     steps = []
#     steps.append(rf"Evaluate: lim x → ∞ of ({a}x³ + {b}x² − {c}) / ({d}x² + {e}x⁴ − {f})")
#     steps.append("Step 1: Identify highest powers: x³ (numerator), x⁴ (denominator)")
#     steps.append("Step 2: As x → ∞, divide both numerator and denominator by x⁴")
#     steps.append(rf"= ({a}/x + {b}/x² − {c}/x⁴) / ({d}/x² + {e} − {f}/x⁴)")
#     steps.append("Step 3: As x → ∞, terms with 1/xⁿ tend to 0")
#     steps.append(rf"Limit = 0 / {e} = 0")
#     return {
#         "steps": steps,
#         "result": "lim x → ∞ = 0"
#     }


# def limit_trig_composite(a, b, x_val):
#     steps = []
#     steps.append(rf"Evaluate: lim x → {x_val} of sin({a}x) / ({b}x + cos(x))")
#     steps.append("Step 1: Substitute x = 0 directly:")
    
#     numerator = math.sin(a * x_val)
#     denominator = b * x_val + math.cos(x_val)
    
#     steps.append(rf"sin({a}×{x_val}) = {round(numerator, 5)}")
#     steps.append(rf"{b}×{x_val} + cos({x_val}) = {round(denominator, 5)}")

#     if denominator == 0:
#         steps.append("Denominator is zero. Limit is undefined or infinite.")
#         result = "undefined"
#     else:
#         result = round(numerator / denominator, 5)
#         steps.append(rf"Limit = {numerator} / {denominator} = {result}")

#     return {
#         "steps": steps,
#         "result": rf"lim x → {x_val} = {result}"
#     }

# def limit_cancel_factor(x_val):
#     steps = []
#     steps.append(rf"Given: lim x → {x_val} of (x² − {x_val**2}) / (x − {x_val})")
#     steps.append(rf"Factor numerator: (x − {x_val})(x + {x_val})")
#     steps.append(rf"Cancel (x − {x_val}) in numerator and denominator")
#     steps.append(rf"Resulting expression: x + {x_val}")
#     result = x_val + x_val
#     steps.append(rf"Substitute x = {x_val}: {x_val} + {x_val} = {result}")
#     return {
#         "steps": steps,
#         "result": rf"lim x → {x_val} = {result}"
#     }

# def limit_rational_infinity(a, b, c, d, e, f):
#     steps = []
#     steps.append(rf"Evaluate: lim x → ∞ of ({a}x³ + {b}x + {c}) / ({d}x³ + {e}x + {f})")
#     steps.append("Step 1: Divide numerator and denominator by x³:")
#     steps.append(rf"= ({a} + {b}/x² + {c}/x³) / ({d} + {e}/x² + {f}/x³)")
#     result = round(a / d, 2)
#     steps.append("As x → ∞, terms with x in denominator vanish.")
#     steps.append(rf"Limit = {a}/{d} = {result}")
#     return {
#         "steps": steps,
#         "result": rf"lim x → ∞ = {result}"
#     }

# def limit_cube_diff(a):
#     steps = []
#     steps.append(rf"Given the limit: lim x → {a} of (x³ − {a}³) / (x − {a})")
#     steps.append(rf"Factor the numerator: x³ − {a}³ = (x − {a})(x² + {a}x + {a**2})")
#     steps.append(rf"= (x − {a})({{x² + {a}x + {a**2}}})")
#     steps.append("Cancel (x − a) in numerator and denominator:")
#     steps.append(rf"→ {a}² + {a}*{a} + {a**2}")
#     value = a**2 + a*a + a**2
#     steps.append(rf"Substitute x = {a}: {a**2} + {a*a} + {a**2} = {value}")
#     return {
#         "steps": steps,
#         "result": rf"lim x → {a} = {value}"
#     }

# def inverse_root_linear(a, b, x):
#     steps = []
#     steps.append(rf"Given f(x) = √({a}x − {b})")
#     steps.append("Step 1: Replace f(x) with y → y = √(ax − b)")
#     steps.append(rf"y = √({a}x − {b})")
#     steps.append("Step 2: Swap x and y → x = √(ay − b)")
#     steps.append(rf"x = √({a}y − {b})")
#     steps.append("Step 3: Square both sides:")
#     steps.append(rf"x² = {a}y − {b}")
#     steps.append(rf"{a}y = x² + {b}")
#     steps.append(rf"y = (x² + {b}) / {a}")
#     inverse_value = round((x**2 + b) / a, 2)
#     steps.append(rf"Substitute x = {x}: y = {inverse_value}")
#     return {
#         "steps": steps,
#         "result": rf"f⁻¹({x}) = {inverse_value}"
#     }

# def inverse_fractional_linear(a, b, c, x):
#     steps = []
#     steps.append(rf"Given f(x) = ({a}x + {b}) / {c}")
#     steps.append("Step 1: Replace f(x) with y → y = (ax + b)/c")
#     steps.append(rf"y = ({a}x + {b}) / {c}")
#     steps.append("Step 2: Swap x and y → x = (ay + b)/c")
#     steps.append(rf"x = ({a}y + {b}) / {c}")
#     steps.append("Step 3: Solve for y:")
#     steps.append(rf"{a}y + {b} = {c}x")
#     steps.append(rf"{a}y = {c}x - {b}")
#     steps.append(rf"y = ({c}x - {b}) / {a}")
#     inverse_value = round((c * x - b) / a, 2)
#     steps.append(rf"Substitute x = {x}: y = {inverse_value}")
#     return {
#         "steps": steps,
#         "result": rf"f⁻¹({x}) = {inverse_value}"
#     }

# def inverse_linear_expression(a, b, x):
#     steps = []
#     steps.append(rf"Given f(x) = {a}(x - {b})")
#     steps.append("Step 1: Replace f(x) with y → y = a(x - b)")
#     steps.append(rf"y = {a}(x - {b})")
#     steps.append("Step 2: Swap x and y → x = a(y - b)")
#     steps.append(rf"x = {a}(y - {b})")
#     steps.append("Step 3: Solve for y:")
#     steps.append(rf"→ y = x/{a} + {b}")
#     inverse_value = round(x / a + b, 2)
#     steps.append(rf"Substitute x = {x}: y = {inverse_value}")
#     return {
#         "steps": steps,
#         "result": rf"f⁻¹({x}) = {inverse_value}"
#     }

