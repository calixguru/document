

from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from pracs.models import Question, Pins, Cbtroom
from django.contrib import messages
# from pracs.forms import QuestionForm
from django.http import JsonResponse
from . import functions
import importlib


def question_lists(request):
    questions = Question.objects.all().order_by('-id')
    # for i in questions:
    #     i.delete()
    # Question.objects.create(
    # question_intro='''<b>Find the area under the curve \( y = 6x^2 \) from \( x = 1 \) to \( x = 4 \)''',
    # question_text='''<b>To find the area under \( y = 6x^2 \) from \( x = 1 \) to \( x = 4 \), we integrate:<br><br>
    #         \(
    #         \int_1^4 6x^2 \, dx
    #         \)<br><br>
    #         \(
    #         \int 6x^2 \, dx = 6 \cdot \\frac{x^3}{3} = 2x^3
    #         \)<br><br>
    #         \(
    #         \\text{Evaluate at limits: } \\left(2x^3\\right)_1^4
    #         \)<br><br>
    #         \( = 2(4)^3 - 2(1)^3 = 128 - 2 = 126
    #         \)<br><br>
    #         = 126 units²
    #         <br>''',
    # option1="x = 0.15 and y = 3.52",
    # option2="x = 0.35 and y = 1.52",
    # option3="x = 0.25 and y = 2.52",
    # option4="None of the above.",
    # correct_answer='126 units²',
    # topic="Application of Integration",
    # subject="MATH",
    # function_name="area_under_curve",
    # variable_names=["In place of 6 ?", "In place of the square i.e 2", "In place of lower boundary i.e 1?", "In place of upper boundary i.e 4?"]
    # )

#     Question.objects.create(
#     question_intro='''<b>Find the inverse function \( f^{-1} \) of the function \( f \colon \mathbb{R} \to \mathbb{R} \), where \( f(x) = 7(1x - 3) \)''',
#     question_text='''<b>To find the inverse function, follow these steps:<br><br>
# Let \( y = 7(1x - 3) \)<br><br>
# Solve for \( x \):<br>
# \( y = 7(1x - 3) \)<br>
# \( \frac{y}{7} = 1x - 3 \)<br>
# \( \frac{y}{7} + 3 = 1x \)<br>
# \( x = \frac{\frac{y}{7} + 3}{1} \)<br><br>
# Now swap \( x \) and \( y \):<br><br>
# \( f^{-1}(x) = \frac{\frac{x}{7} + 3}{1} \)
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l'),
#     option1="\\( f^{-1}(x) = \\frac{\\frac{x}{7} + 3}{1} \\)",
#     option2="\\( f^{-1}(x) = \\frac{\\frac{x}{3} + 7}{1} \\)",
#     option3="\\( f^{-1}(x) = \\frac{\\frac{x}{1} - 3}{7} \\)",
#     option4="None of the above.",
#     correct_answer='\\( f^{-1}(x) = \\frac{\\frac{x}{7} + 3}{1} \\)',
#     topic="Functions and Inverses",
#     subject="MATH",
#     function_name="inverse_function",
#     variable_names=["In place of 7 ?", "In place of 1 ?", "In place of 3 ?"]
# )

    # Question.objects.create(
    #     question_intro='''<b>Find the domain of the function \( f(u) = \sqrt{1 - u} \) such that \( f(u) \) is real.</b>''',
    #     question_text='''To ensure the function is real, the expression under the square root must be greater than or equal to zero:<br><br>
    # \( 1 - u \ge 0 \)<br>
    # \( u \le 1 \)<br><br>
    # So the domain is:<br>
    # \( u \in (-\infty, 1] \)
    # ''',
    #     option1="\\( u \in [1, \infty) \\)",
    #     option2="\\( u \in (-\infty, 1] \\)",
    #     option3="\\( u \in (-\infty, -1] \\)",
    #     option4="None of the above.",
    #     correct_answer='\\( u \in (-\infty, 1] \\)',
    #     topic="Functions and Domain",
    #     subject="MATH",
    #     function_name="domain_of_function",
    #     variable_names=["In place of 1 ?"]
    # )

#     Question.objects.create(
#     question_intro='''<b>The average rate of change of \( f(x) = 8x^2 \) from \( x = 1 \) to \( x = 2 \) is:</b>''',
#     question_text='''We are given the function \( f(x) = 8x^2 \) and asked to find the average rate of change from \( x = 1 \) to \( x = 2 \).<br><br>
# Using the formula:<br>
# \(
# \frac{f(2) - f(1)}{2 - 1}
# \)<br><br>
# First evaluate the function values:<br>
# \(
# f(2) = 8(2)^2 = 32
# \)<br>
# \(
# f(1) = 8(1)^2 = 8
# \)<br><br>
# Now compute the average rate:<br>
# \(
# \frac{32 - 8}{1} = 24
# \)<br><br>
# = 24
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l'),
#     option1="16",
#     option2="32",
#     option3="24",
#     option4="None of the above.",
#     correct_answer="24",
#     topic="Functions and Rates",
#     subject="MATH",
#     function_name="average_rate_of_change",
#     variable_names=["In place of 8 ?", "In place of the power i.e 2 ?", "Start value of x ?", "End value of x ?"]
# )

    
#     Question.objects.create(
#     question_intro='''<b>Find the range of the function \( f(x) = 2x^3 \)</b>''',
#     question_text='''<b>The function \( f(x) = 2x^3 \) is a power function.<br><br>
# Because the power is <b>3</b> and it is odd, <br>the function is increasing and passes through all real numbers.<br><br>
# Hence, the range is:<br><br>
# \( \text{Range} = (-\infty, \infty) \)
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l'),
#     option1="(0, ∞)",
#     option2="(-∞, ∞)",
#     option3="(-∞, 0]",
#     option4="None of the above.",
#     correct_answer="(-∞, ∞)",
#     topic="Functions",
#     subject="MATH",
#     function_name="range_of_cubic",
#     variable_names=["In place of 2 ?", "In place of the power i.e 3 ?"]
# )


#     Question.objects.create(
#     question_intro='''<b>Evaluate the limit as \( x \to 0 \) of \( \frac{\sin(2x)}{3x + \cos x} \)</b>'''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     question_text='''<b>As \( x \to 0 \), we approximate using standard limits:<br><br>
# \(
# \sin(2x) \approx 2x \quad \text{and} \quad \cos x \approx 1
# \)<br><br>
# So, the limit becomes:<br><br>
# \(
# \lim_{x \to 0} \frac{2x}{3x + 1} = \frac{2 \cdot 0}{3 \cdot 0 + 1} = 0
# \)<br><br>
# Hence, the limit is \( \boxed{0} \)
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="0",
#     option2="2",
#     option3="1",
#     option4="Undefined",
#     correct_answer="0",
#     topic="Limit",
#     subject="MATH",
#     function_name="limit_sin_over_linear_cos",
#     variable_names=["In place of 2 ?", "In place of 3 ?"]
# )



#     Question.objects.create(
#     question_intro='''<b>Find the displacement \( s(t) \) of a particle travelling with velocity \( v(t) = 3t^2 - 1 \), given that \( s(2) = 16 \)</b>''',
#     question_text='''<b>We are given:</b> \( v(t) = 3t^2 - 1 \), and \( s(2) = 16 \)<br><br>
# We integrate \( v(t) \) to get \( s(t) \):<br><br>
# \(
# s(t) = \int (3t^2 - 1) \, dt = \int 3t^2 \, dt - \int 1 \, dt
# \)<br><br>
# \(
# = t^3 - t + C
# \)<br><br>
# Given \( s(2) = 16 \):<br><br>
# \(
# s(2) = (2)^3 - (2) + C = 8 - 2 + C = 6 + C = 16 \Rightarrow C = 10
# \)<br><br>
# \(
# \text{Therefore, } s(t) = t^3 - t + 10
# \)
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="s(t) = t³ - t + 10",
#     option2="s(t) = t³ - t + 12",
#     option3="s(t) = t³ - t + 8",
#     option4="None of the above.",
#     correct_answer="s(t) = t³ - t + 10",
#     topic="Application of Integration",
#     subject="MATH",
#     function_name="displacement_from_velocity",
#     variable_names=["In place of 3?", "In place of power 2?", "In place of -1?", "Given t?", "Given s(t)?"]
# )

#     Question.objects.create(
#     question_intro='''<b>If \( x^2 y + 3y^2 = 5x \), find \( \frac{dy}{dx} \)</b>'''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     question_text='''<b>Given:</b> \( x^2 y + 3y^2 = 5x \)<br><br>
# Differentiate both sides with respect to \( x \):<br><br>
# Left side:<br>
# \(
# \frac{d}{dx}[x^2 y] + \frac{d}{dx}[3y^2]
# \)<br><br>
# Use product rule on the first term:<br>
# \(
# = x^2 \cdot \frac{dy}{dx} + 2x \cdot y
# \)<br>
# Use chain rule on the second term:<br>
# \(
# = + 6y \cdot \frac{dy}{dx}
# \)<br><br>
# Right side:<br>
# \(
# \frac{d}{dx}[5x] = 5
# \)<br><br>
# Now combine:<br>
# \(
# x^2 \frac{dy}{dx} + 2xy + 6y \frac{dy}{dx} = 5
# \)<br><br>
# Group terms with \( \frac{dy}{dx} \):<br>
# \(
# (x^2 + 6y)\frac{dy}{dx} = 5 - 2xy
# \)<br><br>
# Solve for \( \frac{dy}{dx} \):<br>
# \(
# \frac{dy}{dx} = \frac{5 - 2xy}{x^2 + 6y}
# \)
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="\\( \\frac{5 - 2xy}{x^2 + 6y} \\)",
#     option2="\\( \\frac{5 + 2xy}{x^2 - 6y} \\)",
#     option3="\\( \\frac{2xy - 5}{x^2 + 6y} \\)",
#     option4="None of the above.",
#     correct_answer="\\( \\frac{5 - 2xy}{x^2 + 6y} \\)",
#     topic="Implicit Differentiation",
#     subject="MATH",
#     function_name="implicit_differentiation_quad",
#     variable_names=["In place of x²y coefficient?", "Power of x in x²y?", "In place of 3y² coefficient?", "Power of y in 3y²?", "In place of 5x coefficient?"]
# )


#     Question.objects.create(
#     question_intro='''<b>Find the gradient of the normal to the curve \( x^2 - 4x + 2y^2 = 0 \) at the point \( (0, 1) \)</b>''',
#     question_text='''Differentiate implicitly:<br><br>
# \(
# \\frac{d}{dx}(x^2 - 4x + 2y^2) = 0
# \)<br><br>
# \(
# 2x - 4 + 4y \\frac{dy}{dx} = 0
# \)<br><br>
# Substitute \( x = 0, y = 1 \):<br>
# \(
# 0 - 4 + 4 \\cdot 1 \\cdot \\frac{dy}{dx} = 0
# \)<br>
# \(
# -4 + 4 \\frac{dy}{dx} = 0
# \Rightarrow \\frac{dy}{dx} = 1
# \)<br><br>
# Gradient of the normal = \( -\\frac{1}{1} = -1 \)
# '''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="-1",
#     option2="1",
#     option3="0",
#     option4="Undefined",
#     correct_answer="-1",
#     topic="Implicit Differentiation",
#     subject="MATH",
#     function_name="gradient_of_normal_quadratic",
#     variable_names=["What is the coefficient of x²?", "What is the coefficient of x?", "What is the coefficient of y²?", "x-coordinate?", "y-coordinate?"]
# )

#     Question.objects.create(
#     question_intro='''<b>Evaluate the limit:</b><br><br>
# \[
# \lim_{{x \to \infty}} \frac{{-15x^3 + 4x^2 - 6}}{{6x^3 - x^2 - 4}}
# \]'''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     question_text='''<b>Step 1:</b> Focus on the highest degree terms:<br><br>
# \[
# \frac{{-15x^3}}{{6x^3}} = -\frac{{15}}{{6}} = -2.5
# \]<br><br>

# <b>As x tends to infinity, lower-order terms vanish:</b><br>
# \[
# \lim_{{x \to \infty}} \frac{{-15x^3 + 4x^2 - 6}}{{6x^3 - x^2 - 4}} = \boxed{-2.5}
# \]'''.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="-2.5",
#     option2="2.5",
#     option3="-3",
#     option4="3",
#     correct_answer="-2.5",
#     topic="Limits at Infinity",
#     subject="MATH",
#     function_name="limit_rational_at_infinity",
#     variable_names=["Coefficient of x³ numerator?", "Coefficient of x² numerator?", "Constant numerator?",
#                     "Coefficient of x³ denominator?", "Coefficient of x² denominator?", "Constant denominator?"]
# )

#     Question.objects.create(
#   question_intro="""
#   <b>Two point charges of +3μC and -2μC are separated by a distance of 0.6 m in vacuum.</b><br>
#   Calculate the magnitude of the electrostatic force between them. Take \( k = 9 \times 10^9 \, Nm^2/C^2 \).
#   """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#   question_text="""
#   Use Coulomb’s Law: \( F = \\frac{{k \cdot |q_1 \cdot q_2|}}{{r^2}} \)<br>
#   Plug in \( q_1 = 3\mu C \), \( q_2 = -2\mu C \), and \( r = 0.6\,m \).<br>
#   Compute the magnitude of the electrostatic force.
#   """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#   option1="0.15 N",
#   option2="2.7 N",
#   option3="0.9 N",
#   option4="3.0 N",
#   correct_answer="0.15 N",
#   topic="Electric Force",
#   subject="PHYSICS",
#   function_name="coulombs_law_force_micro",
#   variable_names=["q1 in μC", "q2 in μC", "Distance r in m"]
# )

#     Question.objects.create(
#     question_intro="""
#     <b>Calculate the electric field at a distance of 0.5 m from a point charge of +4μC in vacuum.</b><br>
#     Take \( k = 9 \times 10^9 \, Nm^2/C^2 \).
#     """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     question_text="""
#     Use the formula: \( E = \\frac{{k \cdot q}}{{r^2}} \)<br>
#     Plug in \( q = 4\mu C \), \( r = 0.5\,m \), and compute \( E \).
#     """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="1.44 × 10⁵ N/C",
#     option2="7.2 × 10⁴ N/C",
#     option3="9 × 10⁵ N/C",
#     option4="6.0 × 10⁴ N/C",
#     correct_answer="1.44 × 10⁵ N/C",
#     topic="Electric Field",
#     subject="PHYSICS",
#     function_name="electric_field_from_point_charge",
#     variable_names=["Charge q in μC", "Distance r in m"]
#     )

#     Question.objects.create(
#     question_intro="""
#     <b>A proton is placed in an electric field of strength \( 2 \times 10^3 \, N/C \).</b><br>
#     What is the force experienced by the proton?<br>
#     Use \( q = 1.6 \times 10^{-19} \, C \).
#     """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     question_text="""
#     Use the formula: \( F = qE \)<br>
#     Plug in the charge of a proton and the electric field.
#     """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
#     option1="3.2 × 10⁻¹⁶ N",
#     option2="1.6 × 10⁻¹⁶ N",
#     option3="8.0 × 10⁻¹⁷ N",
#     option4="2.0 × 10⁻¹⁶ N",
#     correct_answer="3.2 × 10⁻¹⁶ N",
#     topic="Electric Force",
#     subject="PHYSICS",
#     function_name="force_on_proton",
#     variable_names=["Electric field E in N/C"]
#     )

    # Question.objects.create(
    # question_intro="""
    # <b>If two equal charges placed 10 cm apart experience a force of 3.6 N,</b><br>
    # What is the magnitude of each charge? Take \( k = 9 \times 10^9 \, Nm^2/C^2 \).
    # """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
    # question_text="""
    # Use rearranged Coulomb’s Law:<br>
    # \( F = \\frac{{k \cdot q^2}}{{r^2}} \Rightarrow q = \\sqrt{{\\frac{{F \cdot r^2}}{{k}}}} \)<br>
    # Plug in \( F = 3.6 \, N \) and \( r = 0.1 \, m \).
    # """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
    # option1="1.0 × 10<sup>-6</sup> C",
    # option2="2.0 × 10<sup>-6</sup> C",
    # option3="3.0 × 10<sup>-6</sup> C",
    # option4="6.0 × 10<sup>-6</sup> C",
    # correct_answer="2.0 × 10<sup>-6</sup> C",
    # topic="Electric Force",
    # subject="PHYSICS",
    # function_name="identical_charge_from_force",
    # variable_names=["Force F in N", "Distance r in m"]
    # )

    # Question.objects.create(
    # question_intro="""
    # <b>If a charge of 5μC is moved from a point of 100V to 60V,</b><br>
    # what is the work done?
    # """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
    # question_text="""
    # Use the formula:<br>
    # \( W = q(V_1 - V_2) \)<br>
    # Plug in \( q = 5 \mu C \), \( V_1 = 100V \), and \( V_2 = 60V \).
    # """.replace('\f', '\\f').replace('\r', '\\r').replace('\t', '\\t').replace('\l', '\\l').replace('\b', '\\b').replace('\a', '\\a'),
    # option1="0.2 J",
    # option2="2.0 × 10<sub>-4</sub> J",
    # option3="0.02 J",
    # option4="0.0002 J",
    # correct_answer="2.0 × 10<sup>-4</sup> J",
    # topic="Electric Potential Energy",
    # subject="PHYSICS",
    # function_name="work_done_by_charge",
    # variable_names=["Charge q in μC", "Initial voltage V₁", "Final voltage V₂"]
    # )


    
#     Question.objects.create(
#     question_intro="Find the inverse of f(x) = (5x − 1)/2 and evaluate f⁻¹(4).",
#     question_text="Solve for x in terms of y and substitute.",
#     option1="1.5",
#     option2="3.2",
#     option3="1.8",
#     option4="2.6",
#     correct_answer="1.8",
#     topic="Inverse Functions",
#     subject="MATH",
#     function_name="inverse_fractional_linear_alt",
#     variable_names=["Numerator a", "Numerator constant b", "Denominator c", "Input x"]
# )
#     Question.objects.create(
#     question_intro="Evaluate the limit as x tends to 0 of tan(3x)/x.",
#     question_text="Apply small-angle trigonometric identity.",
#     option1="1",
#     option2="3",
#     option3="0",
#     option4="undefined",
#     correct_answer="3",
#     topic="Limits",
#     subject="MATH",
#     function_name="limit_tangent_small_angle",
#     variable_names=["Tangent multiplier k", "x value"]
# )
#     Question.objects.create(
#     question_intro="Evaluate the limit as x tends to infinity of (3x³ + 4x² − 6) / (6x² + 5x⁴ − 4).",
#     question_text="Use highest degree rule for limits at infinity.",
#     option1="0",
#     option2="1",
#     option3="∞",
#     option4="undefined",
#     correct_answer="0",
#     topic="Limits",
#     subject="MATH",
#     function_name="limit_highest_power_ratio",
#     variable_names=["Numerator a", "Numerator b", "Numerator c", "Denominator d", "Denominator e", "Denominator f"]
# )

#     Question.objects.create(
#     question_intro="Evaluate the limit as x tends to 0 of sin(2x) / (3x + cos(x)).",
#     question_text="Use substitution and trigonometric limit knowledge.",
#     option1="0",
#     option2="0.5",
#     option3="1",
#     option4="2",
#     correct_answer="0",
#     topic="Limits",
#     subject="MATH",
#     function_name="limit_trig_composite",
#     variable_names=["Sine multiplier a", "x coefficient b", "x value"]
# )

#     Question.objects.create(
#     question_intro="Evaluate the limit as x tends to 2 of (x² − 4) / (x − 2).",
#     question_text="Factor numerator and simplify.",
#     option1="4",
#     option2="2",
#     option3="5",
#     option4="3",
#     correct_answer="4",
#     topic="Limits",
#     subject="MATH",
#     function_name="limit_cancel_factor",
#     variable_names=["x value"]
# )

#     Question.objects.create(
#     question_intro="Evaluate the limit as x tends to infinity of (6x³ − 2x + 1) / (3x³ + 5x − 4).",
#     question_text="Use dominant powers and divide by x³.",
#     option1="2",
#     option2="3",
#     option3="1",
#     option4="1.5",
#     correct_answer="2",
#     topic="Limits",
#     subject="MATH",
#     function_name="limit_rational_infinity",
#     variable_names=["a", "b", "c", "d", "e", "f"]
# )

#     Question.objects.create(
#     question_intro="Evaluate the limit as x tends to 1 of (x³ − 1) / (x − 1).",
#     question_text="Use limit laws and factorization of difference of cubes.",
#     option1="1",
#     option2="3",
#     option3="2",
#     option4="5",
#     correct_answer="3",
#     topic="Limits",
#     subject="MATH",
#     function_name="limit_cube_diff",
#     variable_names=["Point x tends to"]
# )

#     Question.objects.create(
#     question_intro="Find the inverse of f(x) = √(2x − 5) and evaluate f⁻¹(4).",
#     question_text="Inverse of a square root function.",
#     option1="(x² + 5)/2",
#     option2="(x² − 5)/2",
#     option3="(x + 5)/2",
#     option4="(2x² − 5)",
#     correct_answer="(x² + 5)/2",
#     topic="Inverse Functions",
#     subject="MATH",
#     function_name="inverse_root_linear",
#     variable_names=["Coefficient a", "Constant b", "Input x"]
# )

#     Question.objects.create(
#     question_intro="Find the inverse of f(x) = (4x + 1)/3 and evaluate f⁻¹(5).",
#     question_text="Evaluate the inverse of a linear fractional function.",
#     option1="(3x - 1)/4",
#     option2="(5x - 1)/3",
#     option3="(4x + 1)/3",
#     option4="(3x + 1)/4",
#     correct_answer="(3x - 1)/4",
#     topic="Inverse Functions",
#     subject="MATH",
#     function_name="inverse_fractional_linear",
#     variable_names=["Numerator coefficient a", "Numerator constant b", "Denominator c", "x value"]
# )

#     Question.objects.create(
#     question_intro="Find the inverse function of f(x) = 7(x − 3).",
#     question_text="Evaluate f⁻¹(x) if f(x) = 7(x − 3).",
#     option1="x / 7 + 3",
#     option2="x / 3 + 7",
#     option3="x / 10 + 3",
#     option4="(x + 3)/7",
#     correct_answer="x / 7 + 3",
#     topic="Inverse Functions",
#     subject="MATH",
#     function_name="inverse_linear_expression",
#     variable_names=["Coefficient a", "Subtracted constant b", "Input x"]
# )




    query = request.GET.get("q")
    if query:
        questions = questions.filter(question_intro__icontains=query) | questions.filter(topic__icontains=query) | questions.filter(subject__icontains=query)
    
    return render(request, "pq/question_list.html", {"questions": questions})


@login_required(login_url='login')
def change_value(request, question_id):
    room = 9
    sub = Cbtroom.objects.get(id=room)
    if Pins.objects.filter(name=request.user).exists() or request.user.email in sub.allowed:
        question = get_object_or_404(Question, id=question_id)
        result = None
        steps = []
        val = []
        if request.method == "POST":
            values = [float(request.POST.get(var)) for var in question.variable_names]
            func = getattr(functions, question.function_name)
            output = func(*values)
            result = output.get("result")
            steps = output.get("steps")
            val.append(steps)
        return render(request, "pq/change_value.html", {
            "question": question,
            "variables": question.variable_names,
            "result": result,
            "steps": steps,
        })
    else:
        messages.error(request, "Only activated or subscribed users can do that")
        return redirect('buypin')

def delq(request):
    idy = request.GET.get('idy')
    q = Question.objects.get(id=idy)
    q.delete()
    messages.success(request, 'Question deleted successfully')
    return redirect(request.META.get('HTTP_REFERER', '/'))
