

links = {
    'opaltutorials@gmail.com': [{'name':'CVE512','link':'cve512_opal.pdf'},
                                {'name':'GET 213', 'link': 'GET 213 OPAL solution manual.pdf'}],
    'calixotu@gmail.com': [{'name':'MTH111','link':'Mth111 solution material-compressed.pdf'}, 
                           {'name':'GST111 summary','link':'GST summary.pdf'},
                           {'name':'GET 213', 'link': 'GET 213 OPAL solution manual.pdf'}],
    # 3: {'OpenAI': 'www.openai.com', 'GitHub': 'www.github.com'}
}