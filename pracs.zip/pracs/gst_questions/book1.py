
chapter1 = [
    {'question_id': 1, 'question_text': 'Who is believed to be the first person to claim to be a philosopher?', 'options': ['Plato', 'Socrates', 'Pythagoras', 'Aristotle'], 'correct_option': 'Pythagoras'},
    {'question_id': 2, 'question_text': 'What does the term "philosophy" mean in its Greek origins?', 'options': ['The search for truth', 'The love of knowledge', 'The love of wisdom', 'The pursuit of excellence'], 'correct_option': 'The love of wisdom'},
    {'question_id': 3, 'question_text': 'Which of these is considered a cardinal virtue in Plato\'s Republic?', 'options': ['Truth', 'Wisdom', 'Freedom', 'Happiness'], 'correct_option': 'Wisdom'},
    {'question_id': 4, 'question_text': 'According to Aristotle, virtue is defined as a settled disposition of the mind that determines choices by observing what?', 'options': ['The extreme', 'The ideal', 'The mean', 'The absolute'], 'correct_option': 'The mean'},
    {'question_id': 5, 'question_text': 'Lawhead suggests that philosophical conclusions influence what aspect of life?', 'options': ['Political systems', 'Religious beliefs', 'Daily conduct', 'Scientific research'], 'correct_option': 'Daily conduct'},
    {'question_id': 6, 'question_text': 'What is philosophy primarily concerned with, according to the text?', 'options': ['Practical skills', 'Empirical studies', 'Fundamental questions', 'Technological advances'], 'correct_option': 'Fundamental questions'},
    {'question_id': 7, 'question_text': 'Philosophy as a formal discipline requires what key approach?', 'options': ['Personal intuition', 'Spiritual guidance', 'Rational enquiry', 'Social consensus'], 'correct_option': 'Rational enquiry'},
    {'question_id': 8, 'question_text': 'Why do philosophers often ask "why" questions even when presented with evidence?', 'options': ['To reject evidence', 'To entertain ideas', 'To explore deeper meaning', 'To confuse others'], 'correct_option': 'To explore deeper meaning'},
    {'question_id': 9, 'question_text': 'What term describes the view that knowledge is not possible?', 'options': ['Rationalism', 'Empiricism', 'Skepticism', 'Dogmatism'], 'correct_option': 'Skepticism'},
    {'question_id': 10, 'question_text': 'What did Socrates believe about his own wisdom?', 'options': ['It came from divine insight', 'It was superior to others', 'It stemmed from knowing his ignorance', 'It was a result of education'], 'correct_option': 'It stemmed from knowing his ignorance'},
    {'question_id': 11, 'question_text': 'Bertrand Russell argued that definite knowledge belongs to which domain?', 'options': ['Religion', 'Philosophy', 'Science', 'Politics'], 'correct_option': 'Science'},
    {'question_id': 12, 'question_text': 'What school of thought emphasizes the analysis of language in philosophy?', 'options': ['Existentialism', 'Logical positivism', 'Phenomenology', 'Stoicism'], 'correct_option': 'Logical positivism'},
    {'question_id': 13, 'question_text': 'Philosophy is considered a "second-order" discipline because it does what?', 'options': ['Creates new technologies', 'Examines other disciplines', 'Invents new languages', 'Develops empirical methods'], 'correct_option': 'Examines other disciplines'},
    {'question_id': 14, 'question_text': 'Philosophy as a "first-order" discipline primarily deals with what?', 'options': ['Political systems', 'Scientific theories', 'Human existence', 'Economic policies'], 'correct_option': 'Human existence'},
    {'question_id': 15, 'question_text': 'What are the core branches of philosophy?', 'options': ['Metaphysics, Epistemology, Axiology, Logic', 'History, Literature, Science, Art', 'Politics, Economics, Sociology, Psychology', 'Law, Medicine, Engineering, Architecture'], 'correct_option': 'Metaphysics, Epistemology, Axiology, Logic'},
    {'question_id': 16, 'question_text': 'Gary Alan Scot described ancient philosophy as what?', 'options': ['A technical pursuit', 'A way of life', 'An academic exercise', 'A religious ritual'], 'correct_option': 'A way of life'},
    {'question_id': 17, 'question_text': 'Which philosopher is associated with the statement, "The unexamined life is not worth living"?', 'options': ['Aristotle', 'Socrates', 'Plato', 'Descartes'], 'correct_option': 'Socrates'},
    {'question_id': 18, 'question_text': 'Philosophers examine the assumptions and methods of other disciplines to achieve what?', 'options': ['Financial gain', 'Clarity and consistency', 'Political power', 'Artistic expression'], 'correct_option': 'Clarity and consistency'},
    {'question_id': 19, 'question_text': 'Which of the following is a branch of philosophy that analyzes political concepts?', 'options': ['Metaphysics', 'Epistemology', 'Axiology', 'Political philosophy'], 'correct_option': 'Political philosophy'},
    {'question_id': 20, 'question_text': 'According to the text, what role do philosophers play regarding "truths" accepted by other disciplines?', 'options': ['They accept them', 'They question them', 'They ignore them', 'They promote them'], 'correct_option': 'They question them'},
    {'question_id': 21, 'question_text': 'Why do tyrants and charlatans often view philosophers as dangerous?', 'options': ['They control political power', 'They challenge accepted truths', 'They support authoritarianism', 'They advocate violence'], 'correct_option': 'They challenge accepted truths'},
    {'question_id': 22, 'question_text': 'What is the Socratic method primarily characterized by?', 'options': ['Memorization of facts', 'Continuous questioning', 'Emotional appeals', 'Physical demonstrations'], 'correct_option': 'Continuous questioning'},
    {'question_id': 23, 'question_text': 'According to Mautner, philosophy provides a comprehensive view of what?', 'options': ['Political structures', 'Economic systems', 'Reality and man’s place in it', 'Scientific advancements'], 'correct_option': 'Reality and man’s place in it'},
    {'question_id': 24, 'question_text': 'What distinguishes philosophy from other disciplines?', 'options': ['Its empirical methods', 'Its quantitative research', 'Its focus on fundamental questions', 'Its technological applications'], 'correct_option': 'Its focus on fundamental questions'},
    {'question_id': 25, 'question_text': 'Which branch of philosophy deals with the nature of reality?', 'options': ['Epistemology', 'Axiology', 'Logic', 'Metaphysics'], 'correct_option': 'Metaphysics'},
    {'question_id': 26, 'question_text': 'Epistemology is primarily concerned with what?', 'options': ['Ethics', 'Knowledge', 'Politics', 'Aesthetics'], 'correct_option': 'Knowledge'},
    {'question_id': 27, 'question_text': 'Axiology focuses on which of the following areas?', 'options': ['Truth and logic', 'Values and ethics', 'Scientific method', 'Political structures'], 'correct_option': 'Values and ethics'},
    {'question_id': 28, 'question_text': 'Logical positivism emphasizes which type of knowledge?', 'options': ['Intuitive knowledge', 'Empirical knowledge', 'Religious knowledge', 'Speculative knowledge'], 'correct_option': 'Empirical knowledge'},
    {'question_id': 29, 'question_text': 'What role does philosophy play as a second-order discipline?', 'options': ['Conducting experiments', 'Critiquing other disciplines', 'Developing new technologies', 'Promoting political ideologies'], 'correct_option': 'Critiquing other disciplines'},
    {'question_id': 30, 'question_text': 'The analytic movement in philosophy is mainly concerned with what?', 'options': ['Scientific discoveries', 'Language analysis', 'Political theories', 'Moral values'], 'correct_option': 'Language analysis'},
    {'question_id': 31, 'question_text': 'In what way did Bertrand Russell influence modern philosophy?', 'options': ['Promoting mysticism', 'Encouraging political activism', 'Focusing on language and logic', 'Developing existentialism'], 'correct_option': 'Focusing on language and logic'},
    {'question_id': 32, 'question_text': 'Philosophical reasoning often uses which method alongside empirical approaches?', 'options': ['Mathematical proofs', 'Deductive reasoning', 'Statistical analysis', 'Emotional persuasion'], 'correct_option': 'Deductive reasoning'},
    {'question_id': 33, 'question_text': 'Philosophy of science primarily examines what aspect of science?', 'options': ['Technological applications', 'Scientific funding', 'Conceptual foundations', 'Market trends'], 'correct_option': 'Conceptual foundations'},
    {'question_id': 34, 'question_text': 'What is the relationship between philosophy and politics, according to some scholars?', 'options': ['Politics is a subset of philosophy', 'They are unrelated fields', 'Philosophy influences normative issues in politics', 'Politics determines philosophical truths'], 'correct_option': 'Philosophy influences normative issues in politics'},
    {'question_id': 35, 'question_text': 'What did Socrates mean by saying "The unexamined life is not worth living"?', 'options': ['Life should be enjoyed', 'Life requires constant questioning', 'Life is meaningless', 'Life should be easy'], 'correct_option': 'Life requires constant questioning'},
    {'question_id': 36, 'question_text': 'Which of the following methods is unique to philosophical enquiry?', 'options': ['Experimental method', 'Statistical analysis', 'Socratic method', 'Market research'], 'correct_option': 'Socratic method'},
    {'question_id': 37, 'question_text': 'Which philosopher is known for promoting logical positivism?', 'options': ['Socrates', 'Plato', 'Bertrand Russell', 'Aristotle'], 'correct_option': 'Bertrand Russell'},
    {'question_id': 38, 'question_text': 'Philosophical skepticism highlights what about human knowledge?', 'options': ['Its certainty', 'Its limitations', 'Its universality', 'Its infallibility'], 'correct_option': 'Its limitations'},
    {'question_id': 39, 'question_text': 'Which philosopher believed in questioning the assumptions of experts?', 'options': ['Descartes', 'Socrates', 'Nietzsche', 'Kant'], 'correct_option': 'Socrates'},
    {'question_id': 40, 'question_text': 'What distinguishes metaphysics from other branches of philosophy?', 'options': ['It studies language', 'It explores reality beyond experience', 'It focuses on social justice', 'It emphasizes practical ethics'], 'correct_option': 'It explores reality beyond experience'},
    {'question_id': 41, 'question_text': 'How do philosophers contribute to other disciplines?', 'options': ['By developing new formulas', 'By providing technical skills', 'By questioning foundational assumptions', 'By creating financial models'], 'correct_option': 'By questioning foundational assumptions'},
    {'question_id': 42, 'question_text': 'Which approach emphasizes careful reasoning and honest reflection in philosophy?', 'options': ['Empiricism', 'Analytic philosophy', 'Rationalism', 'Speculative philosophy'], 'correct_option': 'Analytic philosophy'},
    {'question_id': 43, 'question_text': 'What is one reason philosophy is relevant in modern times?', 'options': ['It provides technological solutions', 'It solves financial problems', 'It interrogates profound human issues', 'It creates entertainment content'], 'correct_option': 'It interrogates profound human issues'},
    {'question_id': 44, 'question_text': 'What aspect of philosophy makes non-philosophers wary?', 'options': ['Its complexity', 'Its questioning of accepted truths', 'Its reliance on empirical data', 'Its focus on ancient texts'], 'correct_option': 'Its questioning of accepted truths'},
    {'question_id': 45, 'question_text': 'Philosophy’s relationship with science is often characterized by what?', 'options': ['Total separation', 'Overlapping concerns', 'Complete opposition', 'Mutual dependence'], 'correct_option': 'Overlapping concerns'},
    {'question_id': 46, 'question_text': 'Which philosopher argued that philosophy should clarify language?', 'options': ['Aristotle', 'Descartes', 'Russell', 'Nietzsche'], 'correct_option': 'Russell'},
    {'question_id': 47, 'question_text': 'Philosophical analysis can lead to what beneficial outcome?', 'options': ['Increased profits', 'Conceptual clarity', 'Political unity', 'Social media engagement'], 'correct_option': 'Conceptual clarity'},
    {'question_id': 48, 'question_text': 'The analytic tradition in philosophy emerged with a focus on what?', 'options': ['Scientific innovation', 'Language and logic', 'Political activism', 'Historical events'], 'correct_option': 'Language and logic'},
    {'question_id': 49, 'question_text': 'What distinguishes philosophy from empirical sciences?', 'options': ['Use of experiments', 'Focus on normative issues', 'Reliance on data', 'Application of technology'], 'correct_option': 'Focus on normative issues'},
    {'question_id': 50, 'question_text': 'Philosophy’s role in clarifying concepts contributes to which of the following?', 'options': ['Economic growth', 'Technological advancement', 'Better understanding', 'Political stability'], 'correct_option': 'Better understanding'},
    {'question_id': 51, 'question_text': 'What is the original meaning of the term "method" from its Greek root?', 'options': ['Knowledge after experience', 'Way after', 'Logical reasoning', 'Path to wisdom'], 'correct_option': 'Way after'},
    {'question_id': 52, 'question_text': 'Which philosopher is credited with giving "method" a technical meaning?', 'options': ['Plato', 'Descartes', 'Aristotle', 'Socrates'], 'correct_option': 'Aristotle'},
    {'question_id': 53, 'question_text': 'In The Republic, Plato relates dialectics to which discipline?', 'options': ['Ethics', 'Five kinds of mathematics', 'Natural sciences', 'Politics'], 'correct_option': 'Five kinds of mathematics'},
    {'question_id': 54, 'question_text': 'What distinguishes methodology from method in philosophy?', 'options': ['Methodology involves rules and principles', 'Methodology focuses on intuition', 'Methodology is used only in science', 'Methodology is simpler'], 'correct_option': 'Methodology involves rules and principles'},
    {'question_id': 55, 'question_text': 'Which philosopher proposed the "open question method" for conceptual analysis?', 'options': ['Willard Quine', 'Rudolf Carnap', 'G. E. Moore', 'William James'], 'correct_option': 'G. E. Moore'},
    {'question_id': 56, 'question_text': 'A major criticism of conceptual analysis is its reliance on what?', 'options': ['Empirical data', 'Rigid definitions', 'Subjective intuition', 'Thought experiments'], 'correct_option': 'Rigid definitions'},
    {'question_id': 57, 'question_text': 'Intuitive methods are often criticized for lacking what?', 'options': ['Empirical support', 'Logical structure', 'Philosophical relevance', 'Cognitive appeal'], 'correct_option': 'Empirical support'},
    {'question_id': 58, 'question_text': 'What is the primary purpose of thought experiments in philosophy?', 'options': ['Testing empirical claims', 'Determining consequences', 'Analyzing data', 'Conducting surveys'], 'correct_option': 'Determining consequences'},
    {'question_id': 59, 'question_text': 'Cartesian doubt is primarily associated with which philosophical method?', 'options': ['Methodological skepticism', 'Phenomenological method', 'Pragmatic method', 'Transcendental method'], 'correct_option': 'Methodological skepticism'},
    {'question_id': 60, 'question_text': 'Methodological skepticism aims to achieve what?', 'options': ['Absolute certainty', 'General principles', 'Practical utility', 'Creative insight'], 'correct_option': 'Absolute certainty'},
    {'question_id': 61, 'question_text': 'Phenomenological reduction, also known as bracketing, focuses on what?', 'options': ['Empirical testing', 'Subjective perception', 'Logical deduction', 'Moral reasoning'], 'correct_option': 'Subjective perception'},
    {'question_id': 62, 'question_text': 'Which method seeks to balance beliefs through back-and-forth consideration?', 'options': ['Reflective equilibrium', 'Phenomenological method', 'Cartesian doubt', 'Conceptual analysis'], 'correct_option': 'Reflective equilibrium'},
    {'question_id': 63, 'question_text': 'Reflective equilibrium is often connected to which philosophical theory?', 'options': ['Foundationalism', 'Coherentism', 'Skepticism', 'Empiricism'], 'correct_option': 'Coherentism'},
    {'question_id': 64, 'question_text': 'Pragmatic methods evaluate the truth of a theory based on what?', 'options': ['Its logical coherence', 'Its practical consequences', 'Its historical origins', 'Its emotional appeal'], 'correct_option': 'Its practical consequences'},
    {'question_id': 65, 'question_text': 'William James emphasized which aspect when considering an object in pragmatism?', 'options': ['Sensations and reactions', 'Logical structure', 'Historical significance', 'Metaphysical implications'], 'correct_option': 'Sensations and reactions'},
    {'question_id': 66, 'question_text': 'A key criticism of pragmatism concerns what concept?', 'options': ['Cognitive clarity', 'Semantic differences', 'Logical rigor', 'Scientific validity'], 'correct_option': 'Semantic differences'},
    {'question_id': 67, 'question_text': 'Transcendental arguments focus on analyzing what?', 'options': ['Physical experiments', 'Conditions of possibility', 'Moral intuitions', 'Philosophical doctrines'], 'correct_option': 'Conditions of possibility'},
    {'question_id': 68, 'question_text': 'What is a challenge associated with transcendental methods?', 'options': ['Lack of empirical data', 'Assumptions are not obvious', 'Emphasis on emotions', 'Over-reliance on logic'], 'correct_option': 'Assumptions are not obvious'},
    {'question_id': 69, 'question_text': 'Philosophical studies are often confused with what by newcomers?', 'options': ['History', 'Science', 'Practical skills', 'Career training'], 'correct_option': 'Career training'},
    {'question_id': 70, 'question_text': 'What did Socrates mean by "an unexamined life is not worth living"?', 'options': ['Life should be enjoyed', 'Life should be questioned', 'Life is predetermined', 'Life is a mystery'], 'correct_option': 'Life should be questioned'},
    {'question_id': 71, 'question_text': 'Philosophy helps to unbundle the mind from what?', 'options': ['Creativity', 'Bias and prejudice', 'Mathematical errors', 'Physical constraints'], 'correct_option': 'Bias and prejudice'},
    {'question_id': 72, 'question_text': 'Which aspect of philosophy aids in discerning truth and falsehood?', 'options': ['Pragmatic analysis', 'Critical thinking', 'Historical study', 'Creative imagination'], 'correct_option': 'Critical thinking'},
    {'question_id': 73, 'question_text': 'Philosophical studies enhance problem-solving by fostering what?', 'options': ['Creative writing', 'Organized ideas', 'Physical dexterity', 'Emotional intelligence'], 'correct_option': 'Organized ideas'},
    {'question_id': 74, 'question_text': 'One relevance of philosophy in careers includes its ability to enhance what?', 'options': ['Technical skills', 'Analytical thinking', 'Physical endurance', 'Entertainment value'], 'correct_option': 'Analytical thinking'},
    {'question_id': 75, 'question_text': 'Philosophical studies are relevant to every discipline because they enhance what?', 'options': ['Technology', 'Learning experiences', 'Financial profits', 'Public relations'], 'correct_option': 'Learning experiences'},
    {'question_id': 76, 'question_text': 'Philosophy’s intrinsic nature provides tools for what?', 'options': ['Mystification', 'Conceptual clarity', 'Entertainment', 'Market trends'], 'correct_option': 'Conceptual clarity'},
    {'question_id': 77, 'question_text': 'What key capacity does philosophy enhance, making individuals better problem-solvers?', 'options': ['Physical stamina', 'Critical reasoning', 'Memory retention', 'Artistic ability'], 'correct_option': 'Critical reasoning'},
    {'question_id': 78, 'question_text': 'Philosophy aids in career prospects by developing what kind of arguments?', 'options': ['Creative', 'Sound', 'Emotional', 'Historical'], 'correct_option': 'Sound'},
    {'question_id': 79, 'question_text': 'How do philosophical debates contribute to societal progress?', 'options': ['They create financial models', 'They drive intellectual discourse', 'They simplify laws', 'They enforce regulations'], 'correct_option': 'They drive intellectual discourse'},
    {'question_id': 80, 'question_text': 'Which philosophical method is a reaction to Cartesian doubt?', 'options': ['Conceptual analysis', 'Phenomenological method', 'Reflective equilibrium', 'Transcendental method'], 'correct_option': 'Phenomenological method'},
    {'question_id': 81, 'question_text': 'Which method emphasizes suspending judgment about external reality to focus on perception?', 'options': ['Reflective equilibrium', 'Phenomenological reduction', 'Cartesian doubt', 'Conceptual analysis'], 'correct_option': 'Phenomenological reduction'},
    {'question_id': 82, 'question_text': 'A major weakness of phenomenological methods is their focus on what at the expense of practical concerns?', 'options': ['Empirical evidence', 'Theoretical attitude', 'Moral values', 'Logical consistency'], 'correct_option': 'Theoretical attitude'},
    {'question_id': 83, 'question_text': 'Reflective equilibrium requires balancing what elements to reach a stable state?', 'options': ['Feelings and facts', 'Beliefs and intuitions', 'Laws and ethics', 'Observations and theories'], 'correct_option': 'Beliefs and intuitions'},
    {'question_id': 84, 'question_text': 'Which form of philosophical theory does reflective equilibrium oppose?', 'options': ['Empiricism', 'Foundationalism', 'Skepticism', 'Pragmatism'], 'correct_option': 'Foundationalism'},
    {'question_id': 85, 'question_text': 'The pragmatic method evaluates theories based on their what?', 'options': ['Logical structure', 'Utility and consequences', 'Historical context', 'Moral implications'], 'correct_option': 'Utility and consequences'},
    {'question_id': 86, 'question_text': 'In pragmatism, the truth of a theory depends on what factor?', 'options': ['Universal agreement', 'Practical outcomes', 'Metaphysical status', 'Intuitive appeal'], 'correct_option': 'Practical outcomes'},
    {'question_id': 87, 'question_text': 'What is the key issue with the semantic interpretation in pragmatism?', 'options': ['Truth and falsehood are indistinguishable', 'Truth and usefulness may not align', 'It relies too much on intuition', 'It lacks empirical evidence'], 'correct_option': 'Truth and usefulness may not align'},
    {'question_id': 88, 'question_text': 'Transcendental methods analyze phenomena by examining what?', 'options': ['Historical origins', 'Possibility conditions', 'Cultural influences', 'Logical contradictions'], 'correct_option': 'Possibility conditions'},
    {'question_id': 89, 'question_text': 'A key criticism of transcendental arguments is the assumption of what?', 'options': ['Empirical data', 'The external world', 'Universal values', 'Subjective experience'], 'correct_option': 'The external world'},
    {'question_id': 90, 'question_text': 'Which philosophical figure argued that the unexamined life is not worth living?', 'options': ['Aristotle', 'Plato', 'Socrates', 'Descartes'], 'correct_option': 'Socrates'},
    {'question_id': 91, 'question_text': 'Philosophical studies aim to free the mind from what influences?', 'options': ['Creativity', 'Bias and dogmas', 'Knowledge and wisdom', 'Tradition and heritage'], 'correct_option': 'Bias and dogmas'},
    {'question_id': 92, 'question_text': 'The ability to discern truth from falsehood in philosophy primarily develops through what?', 'options': ['Critical reasoning', 'Memory retention', 'Imaginative thinking', 'Sensory perception'], 'correct_option': 'Critical reasoning'},
    {'question_id': 93, 'question_text': 'Philosophy enhances analytical thinking by fostering what process?', 'options': ['Emotional engagement', 'Conceptual clarity', 'Physical experimentation', 'Historical analysis'], 'correct_option': 'Conceptual clarity'},
    {'question_id': 94, 'question_text': 'The relevance of philosophical studies lies in their contribution to what aspect of life?', 'options': ['Scientific discovery', 'Career skills', 'Personal reflection', 'Economic growth'], 'correct_option': 'Personal reflection'},
    {'question_id': 95, 'question_text': 'Which method helps expose pseudo-problems by clarifying issues?', 'options': ['Pragmatic method', 'Reflective equilibrium', 'Phenomenological method', 'Cartesian doubt'], 'correct_option': 'Pragmatic method'},
    {'question_id': 96, 'question_text': 'Which method involves mentally adjusting beliefs to achieve coherence?', 'options': ['Phenomenological reduction', 'Reflective equilibrium', 'Transcendental argument', 'Conceptual analysis'], 'correct_option': 'Reflective equilibrium'},
    {'question_id': 97, 'question_text': 'Philosophical studies are considered valuable because they contribute to what type of progress?', 'options': ['Technological', 'Intellectual', 'Financial', 'Physical'], 'correct_option': 'Intellectual'},
    {'question_id': 98, 'question_text': 'William James associated pragmatic clarity with considering what aspects of an object?', 'options': ['Historical roots', 'Practical effects', 'Moral implications', 'Logical consistency'], 'correct_option': 'Practical effects'},
    {'question_id': 99, 'question_text': 'What is one major critique of reflective equilibrium in guiding philosophical inquiry?', 'options': ['Lack of coherence', 'Vagueness and triviality', 'Excessive reliance on emotion', 'Focus on external reality'], 'correct_option': 'Vagueness and triviality'},
    {'question_id': 100, 'question_text': 'Philosophical studies encourage what kind of mindset toward arguments and worldviews?', 'options': ['Uncritical acceptance', 'Creative skepticism', 'Blind faith', 'Dogmatic belief'], 'correct_option': 'Creative skepticism'}


]

chapter2 = [
    {'question_id': 1, 'question_text': 'What does the term "Metaphysics" etymologically mean?', 
     'options': ['After nature', 'Beyond matter', 'Within nature', 'Prior to existence'], 
     'correct_option': 'After nature'},

    {'question_id': 2, 'question_text': 'Who is credited with coining the term "Metaphysics"?', 
     'options': ['Socrates', 'Andronicus of Rhodes', 'Plato', 'Aristotle'], 
     'correct_option': 'Andronicus of Rhodes'},

    {'question_id': 3, 'question_text': 'What term did Aristotle originally use to refer to Metaphysics?', 
     'options': ['Physics', 'Ontology', 'First Philosophy', 'Natural Philosophy'], 
     'correct_option': 'First Philosophy'},

    {'question_id': 4, 'question_text': 'Which German philosopher raised the question "Why is there something rather than nothing?"', 
     'options': ['Kant', 'Hegel', 'Leibniz', 'Descartes'], 
     'correct_option': 'Leibniz'},

    {'question_id': 5, 'question_text': 'What is Ontology primarily concerned with?', 
     'options': ['Nature of knowledge', 'Physical universe', 'Nature of reality and existence', 'Principles of motion'], 
     'correct_option': 'Nature of reality and existence'},

    {'question_id': 6, 'question_text': 'Which philosopher believed everything is in a constant state of flux?', 
     'options': ['Parmenides', 'Heraclitus', 'Plato', 'Socrates'], 
     'correct_option': 'Heraclitus'},

    {'question_id': 7, 'question_text': 'What did Heraclitus identify as the fundamental substance?', 
     'options': ['Water', 'Earth', 'Fire', 'Air'], 
     'correct_option': 'Fire'},

    {'question_id': 8, 'question_text': 'According to Parmenides, change is considered to be:', 
     'options': ['Inevitable', 'An illusion', 'A divine process', 'A natural law'], 
     'correct_option': 'An illusion'},

    {'question_id': 9, 'question_text': 'Parmenides used the term "Ta eon" to refer to:', 
     'options': ['Non-being', 'Eternal being', 'Physical matter', 'Changing states'], 
     'correct_option': 'Eternal being'},

    {'question_id': 10, 'question_text': 'Aristotle’s theory of act and potency aimed to reconcile the views of:', 
     'options': ['Plato and Socrates', 'Heraclitus and Parmenides', 'Kant and Descartes', 'Leibniz and Hegel'], 
     'correct_option': 'Heraclitus and Parmenides'},

    {'question_id': 11, 'question_text': 'Essence deals with the question of:', 
     'options': ['Why a thing exists', 'What a thing is', 'How a thing functions', 'Where a thing originates'], 
     'correct_option': 'What a thing is'},

    {'question_id': 12, 'question_text': 'In finite beings, St. Thomas Aquinas argues that essence and existence are:', 
     'options': ['Identical', 'Distinct', 'Interchangeable', 'Irrelevant'], 
     'correct_option': 'Distinct'},

    {'question_id': 13, 'question_text': 'The statement "To be or not to be?" highlights the philosophical importance of:', 
     'options': ['Existence', 'Knowledge', 'Virtue', 'Identity'], 
     'correct_option': 'Existence'},

    {'question_id': 14, 'question_text': 'Plato’s allegory of the cave illustrates the distinction between:', 
     'options': ['Essence and existence', 'Appearance and reality', 'Knowledge and belief', 'Truth and opinion'], 
     'correct_option': 'Appearance and reality'},

    {'question_id': 15, 'question_text': 'According to Descartes, what bridges the gap between appearance and reality?', 
     'options': ['Reason', 'Faith', 'A benevolent God', 'Skepticism'], 
     'correct_option': 'A benevolent God'},

    {'question_id': 16, 'question_text': 'In Kantian philosophy, phenomena refer to:', 
     'options': ['Things in themselves', 'Objects as they appear', 'Illusions of the mind', 'Universal truths'], 
     'correct_option': 'Objects as they appear'},

    {'question_id': 17, 'question_text': 'Noumena, in Kant’s philosophy, are best described as:', 
     'options': ['Objects of sense perception', 'Beings of understanding', 'Physical entities', 'Mental constructs'], 
     'correct_option': 'Beings of understanding'},

    {'question_id': 18, 'question_text': 'Hegel’s "Phenomenology of Spirit" aims to reconcile:', 
     'options': ['Being and non-being', 'Essence and existence', 'Phenomena and noumena', 'Good and evil'], 
     'correct_option': 'Phenomena and noumena'},

    {'question_id': 19, 'question_text': 'Which philosopher is associated with the idea that evil is a privation of good?', 
     'options': ['Epicurus', 'St. Augustine', 'Hume', 'Spinoza'], 
     'correct_option': 'St. Augustine'},

    {'question_id': 20, 'question_text': 'Epicurus’ paradox questions the coexistence of God and:', 
     'options': ['Justice', 'Evil', 'Freedom', 'Knowledge'], 
     'correct_option': 'Evil'},
    
    {'question_id': 21, 'question_text': 'Which philosopher introduced the idea of "Forms" as perfect, eternal concepts?', 
     'options': ['Plato', 'Aristotle', 'Socrates', 'Heraclitus'], 
     'correct_option': 'Plato'},

    {'question_id': 22, 'question_text': 'In Plato’s theory, what is the relationship between Forms and physical objects?', 
     'options': ['Forms are copies of physical objects', 'Physical objects are imperfect copies of Forms', 'They are identical', 'They coexist as equals'], 
     'correct_option': 'Physical objects are imperfect copies of Forms'},

    {'question_id': 23, 'question_text': 'Aristotle rejected Plato’s theory of Forms, proposing instead:', 
     'options': ['Substance and accident', 'Essence and existence', 'Matter and form', 'Act and potency'], 
     'correct_option': 'Matter and form'},

    {'question_id': 24, 'question_text': 'Which medieval philosopher famously synthesized Aristotelian metaphysics with Christian theology?', 
     'options': ['St. Augustine', 'St. Thomas Aquinas', 'Boethius', 'Duns Scotus'], 
     'correct_option': 'St. Thomas Aquinas'},

    {'question_id': 25, 'question_text': 'In Aquinas’ view, God’s essence is identical to:', 
     'options': ['His will', 'His existence', 'His attributes', 'The universe'], 
     'correct_option': 'His existence'},

    {'question_id': 26, 'question_text': 'Leibniz’s concept of "pre-established harmony" addresses the interaction between:', 
     'options': ['Soul and body', 'Good and evil', 'God and man', 'Matter and form'], 
     'correct_option': 'Soul and body'},

    {'question_id': 27, 'question_text': 'What did Descartes famously conclude in his Meditations?', 
     'options': ['God exists', 'I think, therefore I am', 'Knowledge is power', 'Truth is relative'], 
     'correct_option': 'I think, therefore I am'},

    {'question_id': 28, 'question_text': 'The "problem of universals" concerns the existence of:', 
     'options': ['Abstract entities', 'Physical laws', 'Moral absolutes', 'Divine beings'], 
     'correct_option': 'Abstract entities'},

    {'question_id': 29, 'question_text': 'Which philosopher’s "monads" are indivisible, immaterial substances?', 
     'options': ['Hegel', 'Kant', 'Leibniz', 'Descartes'], 
     'correct_option': 'Leibniz'},

    {'question_id': 30, 'question_text': 'According to Spinoza, God and Nature are:', 
     'options': ['Separate entities', 'Identical', 'Illusions', 'In opposition'], 
     'correct_option': 'Identical'},

    {'question_id': 31, 'question_text': 'Hume’s skepticism about causality suggests that cause and effect are:', 
     'options': ['Necessary connections', 'Human conventions', 'Illusions', 'Divinely ordained'], 
     'correct_option': 'Human conventions'},

    {'question_id': 32, 'question_text': 'Kant argued that space and time are:', 
     'options': ['Objective realities', 'Mental constructs', 'Physical substances', 'Illusions'], 
     'correct_option': 'Mental constructs'},

    {'question_id': 33, 'question_text': 'Which philosopher introduced the concept of "will to power"?', 
     'options': ['Nietzsche', 'Schopenhauer', 'Hegel', 'Kant'], 
     'correct_option': 'Nietzsche'},

    {'question_id': 34, 'question_text': 'According to Schopenhauer, the fundamental driving force of reality is:', 
     'options': ['Reason', 'Will', 'Desire', 'Emotion'], 
     'correct_option': 'Will'},

    {'question_id': 35, 'question_text': 'For existentialists, the primary concern is:', 
     'options': ['Knowledge', 'Freedom', 'Existence', 'Morality'], 
     'correct_option': 'Existence'},

    {'question_id': 36, 'question_text': 'Sartre’s concept of "bad faith" refers to:', 
     'options': ['Moral corruption', 'Self-deception', 'Religious doubt', 'Philosophical error'], 
     'correct_option': 'Self-deception'},

    {'question_id': 37, 'question_text': 'Who argued that existence precedes essence?', 
     'options': ['Sartre', 'Heidegger', 'Kierkegaard', 'Camus'], 
     'correct_option': 'Sartre'},

    {'question_id': 38, 'question_text': 'The "leap of faith" is associated with which philosopher?', 
     'options': ['Kierkegaard', 'Nietzsche', 'Heidegger', 'Sartre'], 
     'correct_option': 'Kierkegaard'},

    {'question_id': 39, 'question_text': 'Heidegger’s term "Being-towards-death" reflects:', 
     'options': ['Anxiety about death', 'Authentic existence', 'Moral obligation', 'Fear of the unknown'], 
     'correct_option': 'Authentic existence'},

    {'question_id': 40, 'question_text': 'Camus’ idea of the absurd is based on the conflict between:', 
     'options': ['Freedom and responsibility', 'Human desire for meaning and a meaningless universe', 'Life and death', 'Good and evil'], 
     'correct_option': 'Human desire for meaning and a meaningless universe'},

    {'question_id': 41, 'question_text': 'Which myth does Camus use to illustrate the concept of the absurd?', 
     'options': ['Myth of Prometheus', 'Myth of Sisyphus', 'Myth of Icarus', 'Myth of Orpheus'], 
     'correct_option': 'Myth of Sisyphus'},

    {'question_id': 42, 'question_text': 'The term "dualism" in philosophy primarily refers to the separation of:', 
     'options': ['Good and evil', 'Mind and body', 'Reality and illusion', 'Essence and existence'], 
     'correct_option': 'Mind and body'},

    {'question_id': 43, 'question_text': 'Who is considered the father of modern dualism?', 
     'options': ['Plato', 'Aristotle', 'Descartes', 'Leibniz'], 
     'correct_option': 'Descartes'},

    {'question_id': 44, 'question_text': 'Hume’s argument against miracles rests on:', 
     'options': ['Scientific evidence', 'Moral principles', 'Empirical skepticism', 'Religious authority'], 
     'correct_option': 'Empirical skepticism'},

    {'question_id': 45, 'question_text': 'Kant’s "categorical imperative" is a principle of:', 
     'options': ['Moral duty', 'Aesthetic judgment', 'Practical reason', 'Political theory'], 
     'correct_option': 'Moral duty'},

    {'question_id': 46, 'question_text': 'Which philosopher developed the idea of "eternal recurrence"?', 
     'options': ['Nietzsche', 'Hegel', 'Schopenhauer', 'Sartre'], 
     'correct_option': 'Nietzsche'},

    {'question_id': 47, 'question_text': 'The "veil of ignorance" is a thought experiment by:', 
     'options': ['John Rawls', 'Robert Nozick', 'Thomas Hobbes', 'John Locke'], 
     'correct_option': 'John Rawls'},

    {'question_id': 48, 'question_text': 'Which philosopher advocated for a "state of nature"?', 
     'options': ['Hobbes', 'Locke', 'Rousseau', 'Kant'], 
     'correct_option': 'Hobbes'},

    {'question_id': 49, 'question_text': 'Which concept describes human freedom as limited by the necessity of choice?', 
     'options': ['Determinism', 'Free will', 'Existential freedom', 'Moral responsibility'], 
     'correct_option': 'Existential freedom'},

    {'question_id': 50, 'question_text': 'Leibniz’s best of all possible worlds theory aims to justify:', 
     'options': ['Moral relativism', 'Free will', 'God’s goodness despite evil', 'Human suffering'], 
     'correct_option': 'God’s goodness despite evil'},
    
    {'question_id': 51, 'question_text': 'Which philosopher is often considered the originator of the problem of universals in Western philosophy?', 'options': ['Plato', 'Aristotle', 'Descartes', 'Kant'], 'correct_option': 'Plato'},

    {'question_id': 52, 'question_text': 'Which of the following theories suggests that universals exist only in the mind as concepts?', 'options': ['Realism', 'Conceptualism', 'Nominalism', 'Resemblance theory'], 'correct_option': 'Conceptualism'},

    {'question_id': 53, 'question_text': 'According to Aristotle, substances are characterized by which key feature?', 'options': ['Being dependent on accidents', 'Existing independently', 'Changing constantly', 'Having no causal powers'], 'correct_option': 'Existing independently'},

    {'question_id': 54, 'question_text': 'Which philosopher is known for arguing that the mind and body are two distinct substances?', 'options': ['Spinoza', 'Hume', 'Descartes', 'Wittgenstein'], 'correct_option': 'Descartes'},

    {'question_id': 55, 'question_text': 'Which theory posits that mental events are caused by brain events but have no causal influence themselves?', 'options': ['Interactionism', 'Epiphenomenalism', 'Pre-established harmony', 'Parallelism'], 'correct_option': 'Epiphenomenalism'},

    {'question_id': 56, 'question_text': 'Which philosopher is associated with the concept of pre-established harmony in the mind-body problem?', 'options': ['Descartes', 'Leibniz', 'Kant', 'Spinoza'], 'correct_option': 'Leibniz'},

    {'question_id': 57, 'question_text': 'In metaphysics, accidents are best described as:', 'options': ['Essential properties', 'Non-essential qualities', 'Substances themselves', 'Independent existents'], 'correct_option': 'Non-essential qualities'},

    {'question_id': 58, 'question_text': 'Which of these is NOT a characteristic of a substance, according to Aristotle?', 'options': ['Independent existence', 'Ability to admit contrary accidents', 'Composed of other substances', 'Causal powers'], 'correct_option': 'Composed of other substances'},

    {'question_id': 59, 'question_text': 'David Hume’s critique of causality emphasizes which of the following?', 'options': ['Empirical verification of necessary connection', 'Metaphysical necessity', 'Universal laws', 'Mental habit'], 'correct_option': 'Mental habit'},

    {'question_id': 60, 'question_text': 'The philosophical problem of “the one and the many” is closely related to:', 'options': ['Freedom and determinism', 'Universals and particulars', 'Mind and body', 'Substance and accident'], 'correct_option': 'Universals and particulars'},
    {'question_id': 61, 'question_text': 'Which philosopher believed time had no future dimension in African cosmology?', 'options': ['Mbiti', 'Leibniz', 'Augustine', 'Hawking'], 'correct_option': 'Mbiti'},

    {'question_id': 62, 'question_text': 'Which theory suggests that freedom and determinism are mutually implicated constructs?', 'options': ['Existentialism', 'Compatibilism', 'Incompatibilism', 'Soft determinism'], 'correct_option': 'Compatibilism'},

    {'question_id': 63, 'question_text': 'Which philosopher argued that humans are “condemned to be free”?', 'options': ['Sartre', 'Kant', 'Mill', 'Wittgenstein'], 'correct_option': 'Sartre'},

    {'question_id': 64, 'question_text': 'The ontological argument for God’s existence hinges on which concept?', 'options': ['Design', 'Cosmos', 'Necessary existence', 'Morality'], 'correct_option': 'Necessary existence'},

    {'question_id': 65, 'question_text': 'Which philosopher is known for the cosmological argument based on the universe’s order?', 'options': ['Anselm', 'Aquinas', 'Descartes', 'Plato'], 'correct_option': 'Aquinas'},

    {'question_id': 66, 'question_text': 'Stephen Hawking associated the beginning of time with which theory?', 'options': ['Relativity', 'Big Bang', 'Quantum theory', 'String theory'], 'correct_option': 'Big Bang'},

    {'question_id': 67, 'question_text': 'Hume’s skepticism about causality led him to conclude that causation is a result of:', 'options': ['Objective reality', 'Scientific laws', 'Mental habit', 'Natural necessity'], 'correct_option': 'Mental habit'},

    {'question_id': 68, 'question_text': 'The problem of freedom and determinism raises which primary question?', 'options': ['Is morality subjective?', 'Are human actions free or caused?', 'Is knowledge possible?', 'Can mind and body interact?'], 'correct_option': 'Are human actions free or caused?'},

    {'question_id': 69, 'question_text': 'Who argued that metaphysics holds relevance by addressing questions beyond scientific scope?', 'options': ['Rosenberg', 'Hume', 'Wittgenstein', 'Kant'], 'correct_option': 'Rosenberg'},

    {'question_id': 70, 'question_text': 'The principle that every action has a cause is known as:', 'options': ['Causal determinism', 'Universal causation', 'Pre-established harmony', 'Epiphenomenalism'], 'correct_option': 'Universal causation'},

    {'question_id': 71, 'question_text': 'Which philosopher claimed that time’s nature is paradoxical and difficult to define?', 'options': ['Augustine', 'Aristotle', 'Bergson', 'Hume'], 'correct_option': 'Augustine'},
    {'question_id': 72, 'question_text': 'In Aristotle’s view, which of the following can admit contrary accidents over time?', 'options': ['Substances', 'Accidents', 'Concepts', 'Numbers'], 'correct_option': 'Substances'},
    {'question_id': 73, 'question_text': 'According to the mind-brain identity theory, mental states are:', 'options': ['Separate from brain activity', 'Identical to brain processes', 'Purely spiritual', 'Irrelevant to causality'], 'correct_option': 'Identical to brain processes'},
    {'question_id': 74, 'question_text': 'Which argument for God’s existence is based on moral values?', 'options': ['Cosmological', 'Ontological', 'Teleological', 'Moral'], 'correct_option': 'Moral'},
    {'question_id': 75, 'question_text': 'The metaphysical problem of “the infinite” is closely tied to:', 'options': ['Substance and accident', 'Causality', 'Universals and particulars', 'Time and space'], 'correct_option': 'Time and space'},
    {'question_id': 76, 'question_text': 'What is the primary concern of metaphysics in the context of scientific inquiry?', 'options': ['Empirical testing', 'Abstract questions', 'Logical positivism', 'Material observation'], 'correct_option': 'Abstract questions'},
    {'question_id': 77, 'question_text': 'Which philosophical theory denies the independent existence of universals?', 'options': ['Realism', 'Nominalism', 'Conceptualism', 'Dualism'], 'correct_option': 'Nominalism'},
    {'question_id': 78, 'question_text': 'Which philosopher emphasized the existence of God based on “a being than which nothing greater can be conceived”?', 'options': ['Descartes', 'Anselm', 'Aquinas', 'Spinoza'], 'correct_option': 'Anselm'},
    {'question_id': 79, 'question_text': 'Which theory explains mind-body interaction through God’s coordination?', 'options': ['Epiphenomenalism', 'Parallelism', 'Pre-established harmony', 'Interactionism'], 'correct_option': 'Pre-established harmony'},
    {'question_id': 80, 'question_text': 'Which branch of philosophy is concerned with the fundamental nature of reality?', 'options': ['Epistemology', 'Metaphysics', 'Ethics', 'Aesthetics'], 'correct_option': 'Metaphysics'},
    {'question_id': 81, 'question_text': 'What concept describes a substance that remains constant while undergoing changes?', 'options': ['Accident', 'Substance', 'Causality', 'Quantity'], 'correct_option': 'Substance'},
    {'question_id': 82, 'question_text': 'Which philosopher argued that “God’s existence is necessary for the validity of sensory evidence”?', 'options': ['Kant', 'Descartes', 'Calvin', 'Leibniz'], 'correct_option': 'Descartes'},
    {'question_id': 83, 'question_text': 'In metaphysics, accidents are considered:', 'options': ['Independent entities', 'Attributes of substances', 'Causal agents', 'Primary substances'], 'correct_option': 'Attributes of substances'},
    {'question_id': 84, 'question_text': 'Which of the following best defines “quantity” in metaphysics?', 'options': ['A material object', 'A measurement concept', 'An attribute of substance', 'A non-existent property'], 'correct_option': 'An attribute of substance'},
    {'question_id': 85, 'question_text': 'According to Sartre, freedom implies:', 'options': ['Moral responsibility', 'Predetermined choices', 'Escape from causality', 'Complete randomness'], 'correct_option': 'Moral responsibility'},
    {'question_id': 86, 'question_text': 'Which of the following statements aligns with soft determinism?', 'options': ['All actions are caused and unfree', 'Free will and determinism are compatible', 'Determinism negates moral responsibility', 'Freedom requires randomness'], 'correct_option': 'Free will and determinism are compatible'},
    {'question_id': 87, 'question_text': 'Which argument focuses on the design and purpose of the universe to prove God’s existence?', 'options': ['Moral', 'Ontological', 'Teleological', 'Cosmological'], 'correct_option': 'Teleological'},
    {'question_id': 88, 'question_text': 'The mind-body problem questions:', 'options': ['The reality of sensations', 'The relationship between mental and physical states', 'The existence of universal laws', 'The validity of scientific observation'], 'correct_option': 'The relationship between mental and physical states'},
    {'question_id': 89, 'question_text': 'Which philosopher contributed significantly to the philosophy of time with his “Physics”?', 'options': ['Aristotle', 'Bergson', 'Hawking', 'Kant'], 'correct_option': 'Aristotle'},
    {'question_id': 90, 'question_text': 'Who argued for God’s existence based on humans’ intrinsic knowledge of the divine?', 'options': ['Kant', 'Calvin', 'Hume', 'Anselm'], 'correct_option': 'Calvin'},
    {'question_id': 91, 'question_text': 'Which term describes the philosophical study of existence and being?', 'options': ['Metaphysics', 'Epistemology', 'Ontology', 'Phenomenology'], 'correct_option': 'Ontology'},
    {'question_id': 92, 'question_text': 'Which philosopher is known for his critique of metaphysical concepts and emphasis on empiricism?', 'options': ['Hume', 'Aristotle', 'Sartre', 'Leibniz'], 'correct_option': 'Hume'},
    {'question_id': 93, 'question_text': 'Which concept is central to metaphysics and questions the nature of time and change?', 'options': ['Causality', 'Freedom', 'Quantity', 'Continuum'], 'correct_option': 'Continuum'},
    {'question_id': 94, 'question_text': 'Which problem in philosophy addresses the conflict between moral responsibility and causal determinism?', 'options': ['Mind-body problem', 'Freedom and determinism', 'Causality and chance', 'Substance and accident'], 'correct_option': 'Freedom and determinism'},
    {'question_id': 95, 'question_text': 'According to Hume, the idea of a necessary connection in causality comes from:', 'options': ['Scientific evidence', 'Sensory experience', 'Mental activity', 'Divine will'], 'correct_option': 'Mental activity'},
    {'question_id': 96, 'question_text': 'Who is known for emphasizing the significance of metaphysics despite criticism from logical positivists?', 'options': ['Quine', 'Rosenberg', 'Wittgenstein', 'Hawking'], 'correct_option': 'Rosenberg'},
    {'question_id': 97, 'question_text': 'The metaphysical debate on substance focuses primarily on:', 'options': ['Material composition', 'Causal relations', 'Temporal existence', 'Essential nature'], 'correct_option': 'Essential nature'},
    {'question_id': 98, 'question_text': 'Which theory claims that universals exist only as names or labels?', 'options': ['Realism', 'Nominalism', 'Conceptualism', 'Dualism'], 'correct_option': 'Nominalism'},
    {'question_id': 99, 'question_text': 'Which philosopher’s work bridges metaphysics and the philosophy of mathematics?', 'options': ['Quine', 'Descartes', 'Spinoza', 'Mill'], 'correct_option': 'Quine'},
    {'question_id': 100, 'question_text': 'What is a key feature of metaphysics in relation to scientific knowledge?', 'options': ['Practical application', 'Empirical verification', 'Abstract inquiry', 'Experimental data'], 'correct_option': 'Abstract inquiry'}


    # (Continue up to question_id 50 with similar challenging questions on topics like free will, Leibniz’s Theodicy, Plato’s Forms, and more philosophical concepts covered in the text.)
]

chapter3 = [
    {'question_id': 1, 'question_text': 'What is the etymological meaning of epistemology?', 
     'options': ['Theory of reason', 'Theory of ethics', 'Theory of knowledge', 'Theory of reality'], 
     'correct_option': 'Theory of knowledge'},

    {'question_id': 2, 'question_text': 'Epistemology is considered a normative discipline because it aims to:', 
     'options': ['Prescribe ethical behavior', 'Establish criteria for assessing knowledge claims', 'Explore metaphysical truths', 'Analyze emotions'], 
     'correct_option': 'Establish criteria for assessing knowledge claims'},

    {'question_id': 3, 'question_text': 'Which question is central to epistemology?', 
     'options': ['What is reality?', 'Is knowledge possible?', 'What is beauty?', 'Is life meaningful?'], 
     'correct_option': 'Is knowledge possible?'},

    {'question_id': 4, 'question_text': 'Which philosophical position claims that no knowledge is possible under any circumstances?', 
     'options': ['Rationalism', 'Moderate skepticism', 'Empiricism', 'Extreme skepticism'], 
     'correct_option': 'Extreme skepticism'},

    {'question_id': 5, 'question_text': 'Rationalists believe that knowledge is derived from:', 
     'options': ['Sense experience', 'Divine revelation', 'Innate ideas and reason', 'Cultural traditions'], 
     'correct_option': 'Innate ideas and reason'},

    {'question_id': 6, 'question_text': 'Which type of knowledge is a priori?', 
     'options': ['Empirical knowledge', 'Rational knowledge', 'Intuitive knowledge', 'Authoritative knowledge'], 
     'correct_option': 'Rational knowledge'},

    {'question_id': 7, 'question_text': 'Empiricism holds that knowledge is derived from:', 
     'options': ['Reason alone', 'Sense experience', 'Intuition', 'Authority'], 
     'correct_option': 'Sense experience'},

    {'question_id': 8, 'question_text': 'Which philosopher is associated with constructivism?', 
     'options': ['René Descartes', 'John Locke', 'Immanuel Kant', 'David Hume'], 
     'correct_option': 'Immanuel Kant'},

    {'question_id': 9, 'question_text': 'Constructivism combines elements of:', 
     'options': ['Rationalism and skepticism', 'Empiricism and metaphysics', 'Rationalism and empiricism', 'Skepticism and ethics'], 
     'correct_option': 'Rationalism and empiricism'},

    {'question_id': 10, 'question_text': 'Revealed knowledge is primarily based on:', 
     'options': ['Empirical verification', 'Divine disclosure', 'Logical reasoning', 'Scientific authority'], 
     'correct_option': 'Divine disclosure'},

    {'question_id': 11, 'question_text': 'Which type of knowledge is immediate and does not involve reasoning?', 
     'options': ['Intuitive knowledge', 'Rational knowledge', 'Empirical knowledge', 'Authoritative knowledge'], 
     'correct_option': 'Intuitive knowledge'},

    {'question_id': 12, 'question_text': 'The metaphor "The Garden of Eden" in epistemology refers to:', 
     'options': ['A place of ultimate knowledge', 'A stage of naive knowing', 'An advanced stage of critical thinking', 'A philosophical utopia'], 
     'correct_option': 'A stage of naive knowing'},

    {'question_id': 13, 'question_text': 'In the "Anything Goes" stage, individuals believe that:', 
     'options': ['There is only one truth', 'No view is better than another', 'Authority must be obeyed', 'Knowledge is absolute'], 
     'correct_option': 'No view is better than another'},

    {'question_id': 14, 'question_text': 'Critical thinking involves:', 
     'options': ['Blind acceptance of authority', 'Relativism in all matters', 'Evaluating and analyzing arguments', 'Rejecting all beliefs'], 
     'correct_option': 'Evaluating and analyzing arguments'},

    {'question_id': 15, 'question_text': 'Epistemic humility involves:', 
     'options': ['Claiming to know everything', 'Recognizing the limits of one’s knowledge', 'Rejecting critical thinking', 'Ignoring evidence'], 
     'correct_option': 'Recognizing the limits of one’s knowledge'},

    {'question_id': 16, 'question_text': 'Which philosopher argued against innate ideas, claiming the mind is a "tabula rasa"?', 
     'options': ['René Descartes', 'John Locke', 'Immanuel Kant', 'Baruch Spinoza'], 
     'correct_option': 'John Locke'},

    {'question_id': 17, 'question_text': 'Which type of knowledge requires acceptance based on an expert’s authority?', 
     'options': ['Rational knowledge', 'Intuitive knowledge', 'Authoritative knowledge', 'Empirical knowledge'], 
     'correct_option': 'Authoritative knowledge'},

    {'question_id': 18, 'question_text': 'Epistemology helps us distinguish between:', 
     'options': ['Ethics and aesthetics', 'Belief and opinion', 'Knowledge and belief', 'Science and religion'], 
     'correct_option': 'Knowledge and belief'},

    {'question_id': 19, 'question_text': 'The "prudential goal" of epistemology is:', 
     'options': ['Achieving enlightenment', 'Making timely decisions', 'Developing moral virtues', 'Creating art'], 
     'correct_option': 'Making timely decisions'},

    {'question_id': 20, 'question_text': 'Which of these is an example of a posteriori knowledge?', 
     'options': ['Mathematical truths', 'Logical deductions', 'Sensory observations', 'Innate ideas'], 
     'correct_option': 'Sensory observations'},
    
    {'question_id': 21, 'question_text': 'Which epistemological theory emphasizes the role of perception in acquiring knowledge?', 
     'options': ['Empiricism', 'Rationalism', 'Constructivism', 'Pragmatism'], 
     'correct_option': 'Empiricism'},

    {'question_id': 22, 'question_text': 'What is the central problem for epistemology?', 
     'options': ['The problem of evil', 'The problem of knowledge', 'The problem of ethics', 'The problem of metaphysics'], 
     'correct_option': 'The problem of knowledge'},

    {'question_id': 23, 'question_text': 'Which philosopher is most closely associated with the method of radical doubt?', 
     'options': ['John Locke', 'René Descartes', 'David Hume', 'Immanuel Kant'], 
     'correct_option': 'René Descartes'},

    {'question_id': 24, 'question_text': 'What does epistemic relativism argue?', 
     'options': ['Knowledge is fixed and unchanging', 'Knowledge is subjective and varies across cultures', 'There is only one true form of knowledge', 'Knowledge is purely empirical'], 
     'correct_option': 'Knowledge is subjective and varies across cultures'},

    {'question_id': 25, 'question_text': 'Which philosophical approach claims that knowledge arises from the interaction between the mind and sensory experience?', 
     'options': ['Rationalism', 'Empiricism', 'Idealism', 'Phenomenology'], 
     'correct_option': 'Phenomenology'},

    {'question_id': 26, 'question_text': 'What is the "Gettier problem" in epistemology concerned with?', 
     'options': ['The justification of beliefs', 'The nature of knowledge', 'The distinction between true and false beliefs', 'The reliability of sensory data'], 
     'correct_option': 'The nature of knowledge'},

    {'question_id': 27, 'question_text': 'Which of these is a form of propositional knowledge?', 
     'options': ['Knowing how to ride a bike', 'Knowing the capital of France', 'Knowing the taste of chocolate', 'Knowing a person’s name'], 
     'correct_option': 'Knowing the capital of France'},

    {'question_id': 28, 'question_text': 'According to pragmatism, what is the criterion for determining the truth of an idea?', 
     'options': ['Its logical coherence', 'Its empirical verification', 'Its practical consequences', 'Its alignment with tradition'], 
     'correct_option': 'Its practical consequences'},

    {'question_id': 29, 'question_text': 'Which theory of knowledge emphasizes the role of social interaction and community in shaping knowledge?', 
     'options': ['Social epistemology', 'Pragmatism', 'Phenomenology', 'Constructivism'], 
     'correct_option': 'Social epistemology'},

    {'question_id': 30, 'question_text': 'In the context of epistemology, what does the term "justification" refer to?', 
     'options': ['The emotional aspect of belief', 'The reasons or evidence supporting a belief', 'The subjective experience of knowledge', 'The historical context of a belief'], 
     'correct_option': 'The reasons or evidence supporting a belief'},

    {'question_id': 31, 'question_text': 'What is "epistemic virtue"?', 
     'options': ['The ability to doubt everything', 'The possession of accurate sensory organs', 'The qualities of a good knower, such as open-mindedness and intellectual courage', 'The ability to memorize facts quickly'], 
     'correct_option': 'The qualities of a good knower, such as open-mindedness and intellectual courage'},

    {'question_id': 32, 'question_text': 'Which of these is an example of a priori knowledge?', 
     'options': ['The fact that the sun rises in the east', 'The belief that 2 + 2 = 4', 'The experience of pain', 'The knowledge of the weather tomorrow'], 
     'correct_option': 'The belief that 2 + 2 = 4'},

    {'question_id': 33, 'question_text': 'What does epistemic closure refer to in epistemology?', 
     'options': ['The process of closing off all possibilities for acquiring knowledge', 'The idea that if one knows a fact, one must also know other facts related to it', 'The rejection of all beliefs as false', 'The inability to acquire knowledge'], 
     'correct_option': 'The idea that if one knows a fact, one must also know other facts related to it'},

    {'question_id': 34, 'question_text': 'Which philosopher argued that knowledge is justified true belief, a position later challenged by the Gettier problem?', 
     'options': ['David Hume', 'John Locke', 'Plato', 'René Descartes'], 
     'correct_option': 'Plato'},

    {'question_id': 35, 'question_text': 'Which concept refers to the certainty that one knows something?', 
     'options': ['Skepticism', 'Epistemic humility', 'Epistemic certainty', 'Reliabilism'], 
     'correct_option': 'Epistemic certainty'},

    {'question_id': 36, 'question_text': 'What does "internalism" in epistemology argue?', 
     'options': ['Knowledge depends on external factors only', 'Knowledge is justified by internal factors such as the believer’s own evidence or reasoning', 'Knowledge is purely subjective', 'Knowledge is relative to culture'], 
     'correct_option': 'Knowledge is justified by internal factors such as the believer’s own evidence or reasoning'},

    {'question_id': 37, 'question_text': 'Which epistemological position claims that our knowledge of the world is mediated by language and social context?', 
     'options': ['Rationalism', 'Relativism', 'Social epistemology', 'Empiricism'], 
     'correct_option': 'Social epistemology'},

    {'question_id': 38, 'question_text': 'The "coherence theory" of truth asserts that:', 
     'options': ['Truth is whatever aligns with empirical evidence', 'Truth is determined by consensus', 'Truth is the coherence of a set of beliefs', 'Truth is established by authoritative figures'], 
     'correct_option': 'Truth is the coherence of a set of beliefs'},

    {'question_id': 39, 'question_text': 'Which philosopher is associated with the "theory of knowledge as justified true belief"?', 
     'options': ['Immanuel Kant', 'John Locke', 'René Descartes', 'Plato'], 
     'correct_option': 'Plato'},

    {'question_id': 40, 'question_text': 'In the context of epistemology, what does "contextualism" claim?', 
     'options': ['Knowledge is relative to one’s social context', 'The meaning of knowledge depends on its historical context', 'Truth is dependent on the context in which a statement is made', 'Knowledge cannot exist without context'], 
     'correct_option': 'Knowledge is relative to one’s social context'},
    
    {'question_id': 41, 'question_text': 'What is the central existential challenge that human existence faces according to Ozumba?', 
     'options': ['The search for happiness', 'Dealing with environmental challenges', 'The pursuit of knowledge', 'The need for human interaction'], 
     'correct_option': 'The pursuit of knowledge'},

    {'question_id': 42, 'question_text': 'According to Aristotle, what is a natural human desire?', 
     'options': ['The desire for material wealth', 'The desire for pleasure', 'The desire for knowledge', 'The desire for power'], 
     'correct_option': 'The desire for knowledge'},

    {'question_id': 43, 'question_text': 'Why is knowledge considered a non-negotiable condition of human existence?', 
     'options': ['It is essential for happiness', 'It is necessary for survival and understanding the world', 'It leads to social harmony', 'It guarantees success'], 
     'correct_option': 'It is necessary for survival and understanding the world'},

    {'question_id': 44, 'question_text': 'What does epistemology critically examine?', 
     'options': ['The social structures that influence beliefs', 'The scientific methods for discovering truths', 'Our beliefs to differentiate what we really know from what we think we know', 'The historical development of human knowledge'], 
     'correct_option': 'Our beliefs to differentiate what we really know from what we think we know'},

    {'question_id': 45, 'question_text': 'How does epistemology contribute to human decision making?', 
     'options': ['By providing ways to discern the quality of different disciplines', 'By helping us understand the political implications of knowledge', 'By defining clear moral rules for decision making', 'By offering a structure for personal happiness'], 
     'correct_option': 'By providing ways to discern the quality of different disciplines'},

    {'question_id': 46, 'question_text': 'According to Blackburn, why is epistemology crucial for addressing public and political issues?', 
     'options': ['Because it offers solutions to political problems', 'Because it helps determine if certain knowledge claims are reliable and justified', 'Because it dictates the political ideologies to follow', 'Because it eliminates moral issues in decision making'], 
     'correct_option': 'Because it helps determine if certain knowledge claims are reliable and justified'},

    {'question_id': 47, 'question_text': 'What is one key role of epistemology in the education system?', 
     'options': ['To decide which knowledge claims are valid and which are not', 'To promote specific religious views in schools', 'To determine which subjects are the most important', 'To teach people how to memorize information effectively'], 
     'correct_option': 'To decide which knowledge claims are valid and which are not'},

    {'question_id': 48, 'question_text': 'Which of the following is NOT an important aspect of epistemology in human life?', 
     'options': ['Guiding belief formation processes', 'Determining the correct moral actions', 'Fostering intellectual humility', 'Helping individuals in decision making'], 
     'correct_option': 'Determining the correct moral actions'},

    {'question_id': 49, 'question_text': 'What does epistemic humility involve?', 
     'options': ['Believing in your knowledge without doubt', 'Acknowledging the limits of your own knowledge', 'Never changing your beliefs', 'Refusing to listen to other perspectives'], 
     'correct_option': 'Acknowledging the limits of your own knowledge'},

    {'question_id': 50, 'question_text': 'How does epistemology help combat dogmatism?', 
     'options': ['By teaching individuals to always stick to their beliefs', 'By encouraging the constant examination of one’s beliefs', 'By providing a single, universal truth', 'By discouraging critical thinking'], 
     'correct_option': 'By encouraging the constant examination of one’s beliefs'},

    {'question_id': 51, 'question_text': 'What role does epistemology play in intellectual autonomy?', 
     'options': ['It motivates individuals to follow the opinions of experts', 'It encourages dependence on others for intellectual guidance', 'It promotes the self-authorship of one’s beliefs and values', 'It discourages independent thought'], 
     'correct_option': 'It promotes the self-authorship of one’s beliefs and values'},

    {'question_id': 52, 'question_text': 'What is the main consequence of not having epistemic empathy?', 
     'options': ['Inability to form beliefs', 'Failure to understand others’ viewpoints accurately', 'Total agreement with others', 'Doubt about all forms of knowledge'], 
     'correct_option': 'Failure to understand others’ viewpoints accurately'},

    {'question_id': 53, 'question_text': 'According to the text, how does epistemology affect moral decision making?', 
     'options': ['By providing better frameworks for understanding moral choices', 'By eliminating the need for moral reasoning', 'By promoting absolute moral truth', 'By discouraging critical analysis of moral beliefs'], 
     'correct_option': 'By providing better frameworks for understanding moral choices'},

    {'question_id': 54, 'question_text': 'What is one benefit of epistemic empathy in decision making?', 
     'options': ['It allows individuals to impose their own beliefs on others', 'It helps individuals understand and reason from others’ viewpoints', 'It ensures everyone will agree with your conclusions', 'It leads to rejecting alternative perspectives entirely'], 
     'correct_option': 'It helps individuals understand and reason from others’ viewpoints'},

    {'question_id': 55, 'question_text': 'What does intellectual courage encourage individuals to do?', 
     'options': ['Avoid considering opposing viewpoints', 'Face ideas or beliefs that challenge one’s own with fairness', 'Only believe in ideas that are familiar', 'Accept ideas without questioning'], 
     'correct_option': 'Face ideas or beliefs that challenge one’s own with fairness'},

    {'question_id': 56, 'question_text': 'How does epistemology help us fight against absolute skepticism?', 
     'options': ['By proving that no knowledge is possible', 'By providing a basis for belief in certain truths', 'By making us doubt everything we know', 'By showing that all knowledge is subjective'], 
     'correct_option': 'By providing a basis for belief in certain truths'},

    {'question_id': 57, 'question_text': 'What is the role of epistemology in ensuring survival according to the text?', 
     'options': ['It helps us acquire knowledge necessary for survival', 'It eliminates the need for decision making', 'It promotes ignorance about the world', 'It encourages dependence on others for knowledge'], 
     'correct_option': 'It helps us acquire knowledge necessary for survival'},

    {'question_id': 58, 'question_text': 'What is the result of functioning with an inaccurate belief system?', 
     'options': ['It leads to effective decision making', 'It provides reliable guidance for life decisions', 'It may result in unfortunate and disastrous outcomes', 'It ensures success in all endeavors'], 
     'correct_option': 'It may result in unfortunate and disastrous outcomes'}
]

chapter4 = [
    {'question_id': 1, 'question_text': 'What is the main focus of ethics as discussed in the chapter?', 'options': ['Moral responsibility and human conduct', 'The analysis of beauty and art', 'The evaluation of social norms', 'The investigation of cultural practices'], 'correct_option': 'Moral responsibility and human conduct'},
    {'question_id': 2, 'question_text': 'Which branch of philosophy studies values related to human actions and conduct?', 'options': ['Axiology', 'Metaphysics', 'Epistemology', 'Logic'], 'correct_option': 'Axiology'},
    {'question_id': 3, 'question_text': 'According to the chapter, which of the following is NOT a subfield of ethics?', 'options': ['Normative ethics', 'Meta-ethics', 'Applied ethics', 'Aesthetic ethics'], 'correct_option': 'Aesthetic ethics'},
    {'question_id': 4, 'question_text': 'What does the term "ethics" primarily focus on?', 'options': ['The evaluation of human conduct', 'The creation of art', 'The determination of beauty', 'The study of abstract concepts'], 'correct_option': 'The evaluation of human conduct'},
    {'question_id': 5, 'question_text': 'Which of the following best defines "normative ethics"?', 'options': ['Study of moral standards and principles', 'Analysis of moral language', 'Study of moral judgments in real-life situations', 'Philosophical inquiries into the meaning of moral terms'], 'correct_option': 'Study of moral standards and principles'},
    {'question_id': 6, 'question_text': 'Meta-ethics is concerned with which of the following?', 'options': ['The meaning and methodology of moral judgments', 'The determination of right and wrong actions', 'The evaluation of the consequences of actions', 'The creation of moral rules'], 'correct_option': 'The meaning and methodology of moral judgments'},
    {'question_id': 7, 'question_text': 'Which of the following is a key focus of applied ethics?', 'options': ['The application of ethical theories to real-world situations', 'The study of ethical terminology', 'The creation of ethical norms', 'The analysis of beauty in art'], 'correct_option': 'The application of ethical theories to real-world situations'},
    {'question_id': 8, 'question_text': 'Which normative ethical theory is based on the principle of the greatest good for the greatest number of people?', 'options': ['Utilitarianism', 'Deontology', 'Virtue ethics', 'Consequentialism'], 'correct_option': 'Utilitarianism'},
    {'question_id': 9, 'question_text': 'Egoism, a version of consequentialism, holds that individuals should act in a way that promotes what?', 'options': ['Their own best interest', 'The collective interest of society', 'The happiness of the greatest number of people', 'The adherence to moral principles'], 'correct_option': 'Their own best interest'},
    {'question_id': 10, 'question_text': 'What does rule utilitarianism prioritize over act utilitarianism?', 'options': ['Following moral rules that promote the greatest good', 'Maximizing personal happiness', 'Considering the intentions behind actions', 'Evaluating the consequences of each individual action'], 'correct_option': 'Following moral rules that promote the greatest good'},
    {'question_id': 11, 'question_text': 'According to deontology, the rightness or wrongness of an action is determined by what?', 'options': ['The intention behind the action', 'The consequences of the action', 'The moral character of the individual', 'The rule that governs the action'], 'correct_option': 'The intention behind the action'},
    {'question_id': 12, 'question_text': 'Which of the following is a key feature of Kant’s categorical imperative?', 'options': ['Universal moral rules that respect human dignity', 'Maximization of social utility', 'Maximization of personal happiness', 'Promotion of self-interest'], 'correct_option': 'Universal moral rules that respect human dignity'},
    {'question_id': 13, 'question_text': 'Which ethical theory emphasizes the importance of moral virtues in shaping a good person?', 'options': ['Virtue ethics', 'Deontology', 'Utilitarianism', 'Consequentialism'], 'correct_option': 'Virtue ethics'},
    {'question_id': 14, 'question_text': 'In virtue ethics, what is considered the primary concern of moral life?', 'options': ['Developing virtuous character traits', 'Maximizing the greatest happiness for all', 'Following moral rules and principles', 'Evaluating the consequences of actions'], 'correct_option': 'Developing virtuous character traits'},
    {'question_id': 15, 'question_text': 'Which ethical theory is described as being concerned with the consequences of actions in determining moral rightness?', 'options': ['Consequentialism', 'Deontology', 'Virtue ethics', 'Social contract theory'], 'correct_option': 'Consequentialism'},
    {'question_id': 16, 'question_text': 'What does ethical egoism prioritize in decision-making?', 'options': ['Self-interest as the ultimate ethical standard', 'The well-being of the greatest number of people', 'The adherence to universal moral laws', 'The development of moral character'], 'correct_option': 'Self-interest as the ultimate ethical standard'},
    {'question_id': 17, 'question_text': 'What distinguishes deontology from consequentialism?', 'options': ['It focuses on the moral duties of the agent rather than the consequences', 'It evaluates actions based on the greatest good', 'It emphasizes the development of character traits', 'It considers the self-interest of the individual'], 'correct_option': 'It focuses on the moral duties of the agent rather than the consequences'},
    {'question_id': 18, 'question_text': 'Which of the following is a criticism often directed at Kant’s deontological ethics?', 'options': ['It fails to resolve conflicts between competing duties', 'It ignores the importance of virtues', 'It places too much emphasis on consequences', 'It disregards human dignity'], 'correct_option': 'It fails to resolve conflicts between competing duties'},
    {'question_id': 19, 'question_text': 'In virtue ethics, the right action is one that a virtuous person would do in which context?', 'options': ['The context of their habitual behavior', 'The context of legal obligations', 'The context of maximizing happiness', 'The context of following rules'], 'correct_option': 'The context of their habitual behavior'},
    {'question_id': 20, 'question_text': 'According to the chapter, which of the following is the primary question of virtue ethics?', 'options': ['What kind of person should I be?', 'What should I do in a specific situation?', 'What is the greatest good?', 'What duties do I have?'], 'correct_option': 'What kind of person should I be?'},
    {'question_id': 21, 'question_text': 'Which of the following best describes the moral agent in virtue ethics?', 'options': ['One who acts according to moral virtues developed over time', 'One who acts to maximize overall happiness', 'One who follows rules of conduct strictly', 'One who prioritizes self-interest'], 'correct_option': 'One who acts according to moral virtues developed over time'},
    {'question_id': 22, 'question_text': 'Which ethical theory asserts that actions are right if they follow rules validated by the principle of utility?', 'options': ['Rule utilitarianism', 'Deontology', 'Virtue ethics', 'Egoism'], 'correct_option': 'Rule utilitarianism'},
    {'question_id': 23, 'question_text': 'According to the chapter, which of the following theories is concerned with the concept of duty as central to morality?', 'options': ['Deontology', 'Consequentialism', 'Virtue ethics', 'Utilitarianism'], 'correct_option': 'Deontology'},
    {'question_id': 24, 'question_text': 'What does meta-ethics question in terms of moral language?', 'options': ['The meaning of moral terms such as "right", "wrong", and "good"', 'The consequences of specific actions', 'The duties humans have toward each other', 'The social structures that enforce morality'], 'correct_option': 'The meaning of moral terms such as "right", "wrong", and "good"'},
    {'question_id': 25, 'question_text': 'Which ethical theory emphasizes maximizing happiness for the greatest number of people?', 'options': ['Utilitarianism', 'Egoism', 'Virtue ethics', 'Deontology'], 'correct_option': 'Utilitarianism'},
    {'question_id': 26, 'question_text': 'What is the main concern of consequentialist theories?', 'options': ['The consequences of actions', 'The moral character of the agent', 'The adherence to moral duties', 'The virtue of the action itself'], 'correct_option': 'The consequences of actions'},
    {'question_id': 27, 'question_text': 'Which of the following is NOT a component of philosophical ethics discussed in the chapter?', 'options': ['Psychology', 'Normative ethics', 'Meta-ethics', 'Applied ethics'], 'correct_option': 'Psychology'},
    {'question_id': 28, 'question_text': 'Which of the following normative ethical theories focuses on the inherent morality of actions regardless of consequences?', 'options': ['Deontology', 'Consequentialism', 'Virtue ethics', 'Utilitarianism'], 'correct_option': 'Deontology'},
    {'question_id': 29, 'question_text': 'According to the chapter, the study of ethics helps in determining what?', 'options': ['What constitutes right and wrong actions in society', 'The definition of beauty and art', 'The study of aesthetic experiences', 'The creation of legal codes of conduct'], 'correct_option': 'What constitutes right and wrong actions in society'},
    {'question_id': 30, 'question_text': 'What does the chapter say about the relationship between ethics and aesthetics?', 'options': ['Both address human experiences but focus on different aspects', 'Aesthetics is a subset of ethics', 'Ethics always guides aesthetic judgment', 'Aesthetics has no role in ethical reasoning'], 'correct_option': 'Both address human experiences but focus on different aspects'},
    {'question_id': 31, 'question_text': 'What is the Greek origin of the word "aesthetics"?', 'options': ['To perceive', 'To create', 'To understand', 'To express'], 'correct_option': 'To perceive'},
    {'question_id': 32, 'question_text': 'Who introduced the term "aesthetics" in 1735?', 'options': ['Baumgarten', 'Aristotle', 'Plato', 'Immanuel Kant'], 'correct_option': 'Baumgarten'},
    {'question_id': 33, 'question_text': 'Aesthetics is concerned with which of the following?', 'options': ['The perception and nature of beauty', 'Moral responsibility and actions', 'The study of logic and reasoning', 'The evaluation of philosophical arguments'], 'correct_option': 'The perception and nature of beauty'},
    {'question_id': 34, 'question_text': 'Which branch of philosophy is directly concerned with the appreciation and criticism of works of art?', 'options': ['Philosophy of art', 'Aesthetics', 'Ethics', 'Meta-ethics'], 'correct_option': 'Philosophy of art'},
    {'question_id': 35, 'question_text': 'What distinguishes art criticism from the philosophy of art?', 'options': ['Art criticism analyzes and evaluates works of art, while philosophy of art discusses their deeper meaning', 'Art criticism focuses on creating art, while philosophy of art does not', 'Art criticism examines ethics, while philosophy of art examines aesthetics', 'There is no distinction between the two disciplines'], 'correct_option': 'Art criticism analyzes and evaluates works of art, while philosophy of art discusses their deeper meaning'},
    {'question_id': 36, 'question_text': 'According to the chapter, what is the broader sense of the term "art"?', 'options': ['It includes visual arts, dance, drama, and music', 'It only refers to painting and sculpture', 'It refers exclusively to man-made objects', 'It includes only decorative arts'], 'correct_option': 'It includes visual arts, dance, drama, and music'},
    {'question_id': 37, 'question_text': 'Which of the following does aesthetics NOT primarily concern itself with?', 'options': ['Beauty in nature and art', 'The moral implications of art', 'The experience and value of beauty', 'The judgment of what is considered beautiful'], 'correct_option': 'The moral implications of art'},
    {'question_id': 38, 'question_text': 'Which of the following is NOT a question typically addressed by aesthetics?', 'options': ['Can a work of art be said to exist?', 'What are the criteria for distinguishing good art from bad art?', 'How does art relate to truth or morality?', 'How can art be used to enforce social norms?'], 'correct_option': 'How can art be used to enforce social norms?'},
    {'question_id': 39, 'question_text': 'What is the aesthetic attitude according to Stolnitz?', 'options': ['Disinterested and sympathetic attention to any object for its own sake', 'The act of analyzing the moral implications of art', 'Admiration for art only in relation to its social function', 'Critical judgment based on moral values'], 'correct_option': 'Disinterested and sympathetic attention to any object for its own sake'},
    {'question_id': 40, 'question_text': 'What does "aesthetic experience" involve, according to Zumbo?', 'options': ['Entering into an intimate relation with the aesthetic object and focusing on the essence of beauty', 'Critically analyzing the object to determine its moral value', 'Judging the social impact of the object', 'Creating art based on personal emotions'], 'correct_option': 'Entering into an intimate relation with the aesthetic object and focusing on the essence of beauty'},
    {'question_id': 41, 'question_text': 'According to the chapter, which of the following is an important aspect of aesthetic value?', 'options': ['Imitation, subjectivity, and objectivity of beauty', 'The moral value of art', 'The social function of beauty', 'The educational role of aesthetics'], 'correct_option': 'Imitation, subjectivity, and objectivity of beauty'},
    {'question_id': 42, 'question_text': 'What is the core concept of the Imitation Theory of aesthetic value?', 'options': ['Art imitates the forms or prototypes beyond human experience', 'Beauty exists in the mind of the beholder', 'Beauty is an objective feature of the object', 'The pleasure derived from art is its primary value'], 'correct_option': 'Art imitates the forms or prototypes beyond human experience'},
    {'question_id': 43, 'question_text': 'Which philosopher associated with the Imitation Theory believes that art is an imitation of a universal whole?', 'options': ['Aristotle', 'Plato', 'Baumgarten', 'Hospers'], 'correct_option': 'Aristotle'},
    {'question_id': 44, 'question_text': 'Which aesthetic theory holds that beauty lies in the mind of the beholder?', 'options': ['Subjective theory', 'Objective theory', 'Imitation theory', 'Pleasure theory'], 'correct_option': 'Subjective theory'},
    {'question_id': 45, 'question_text': 'According to the Objective Theory, beauty is regarded as?', 'options': ['An objective feature of the object, independent of personal perception', 'A subjective experience that varies with each individual', 'The emotional response evoked by the object', 'Dependent on the context in which the object is viewed'], 'correct_option': 'An objective feature of the object, independent of personal perception'},
    {'question_id': 46, 'question_text': 'The Pleasure Theory of aesthetic value holds that the primary function of an aesthetic object is to produce what?', 'options': ['Pleasure in the beholder', 'A reflection of universal truth', 'Social harmony', 'Moral enlightenment'], 'correct_option': 'Pleasure in the beholder'},
    {'question_id': 47, 'question_text': 'Who is associated with the Instrumentalist Theory of aesthetic value?', 'options': ['John Dewey', 'Plato', 'Aristotle', 'Baumgarten'], 'correct_option': 'John Dewey'},
    {'question_id': 48, 'question_text': 'What does the Instrumentalist Theory of aesthetic value focus on?', 'options': ['The capacity of the aesthetic object to produce an aesthetic experience in the beholder', 'The object’s intrinsic beauty', 'The social function of the art', 'The imitation of forms or prototypes'], 'correct_option': 'The capacity of the aesthetic object to produce an aesthetic experience in the beholder'},
    {'question_id': 49, 'question_text': 'What is the relevance of ethics and aesthetics to human existence?', 'options': ['They guide human conduct and shape how humans experience beauty', 'They provide moral laws for societal behavior', 'They evaluate human emotions and desires', 'They define the role of art in society'], 'correct_option': 'They guide human conduct and shape how humans experience beauty'},
    {'question_id': 50, 'question_text': 'How does ethics function within human society?', 'options': ['As an instrument of social control', 'As a way to appreciate beauty', 'As a method of creating art', 'As a philosophical framework for creativity'], 'correct_option': 'As an instrument of social control'},
    {'question_id': 51, 'question_text': 'Which of the following best explains the importance of axiological thinking in human life?', 'options': ['It guides moral decisions and behaviors in daily life', 'It defines the aesthetic value of art', 'It focuses on the creation of art in society', 'It evaluates the moral consequences of artistic expressions'], 'correct_option': 'It guides moral decisions and behaviors in daily life'},
    {'question_id': 52, 'question_text': 'What role does aesthetics play in enhancing personal happiness?', 'options': ['It contributes to mental health by fostering appreciation for beauty', 'It provides moral guidelines for living a fulfilling life', 'It helps individuals develop artistic skills', 'It teaches individuals to critique works of art effectively'], 'correct_option': 'It contributes to mental health by fostering appreciation for beauty'},
    {'question_id': 53, 'question_text': 'According to the chapter, how does external beauty relate to perfection in nature or human character?', 'options': ['Beauty should be harmonized with perfection, whether in design or character', 'External beauty is the only form of true beauty', 'Perfection is unrelated to beauty in nature or humans', 'Beauty is deceptive and does not relate to human character or nature'], 'correct_option': 'Beauty should be harmonized with perfection, whether in design or character'},
    {'question_id': 54, 'question_text': 'What is one key aspect of human existence discussed in the chapter?', 'options': ['The need for human interaction and social association', 'The creation of moral norms', 'The relationship between ethics and logic', 'The cultivation of artistic talents'], 'correct_option': 'The need for human interaction and social association'},
    {'question_id': 55, 'question_text': 'Which of the following best describes how humans can live a meaningful life according to the chapter?', 'options': ['By developing both ethical and aesthetic values in society', 'By focusing solely on ethical principles', 'By isolating themselves from social influences', 'By creating art and beauty independently'], 'correct_option': 'By developing both ethical and aesthetic values in society'},
    {'question_id': 56, 'question_text': 'The discussion of axiological thinking in the chapter focuses on what?', 'options': ['How beauty and moral values influence human behavior', 'The role of logic in human decision-making', 'The relationship between truth and morality', 'The creation of beauty in art and nature'], 'correct_option': 'How beauty and moral values influence human behavior'}

]

chapter5 = [
    {'question_id': 1, 'question_text': 'What is the primary question that arises when one first encounters the discipline of logic?', 'options': ['What is philosophy?', 'What is logic?', 'What is reasoning?', 'What is formal logic?'], 'correct_option': 'What is logic?'},
    {'question_id': 2, 'question_text': 'According to the text, what is the relationship between philosophy and logic?', 'options': ['Logic is a branch of philosophy', 'Logic is an instrument or tool for philosophy', 'Logic is completely separate from philosophy', 'Logic is a subordinate field of philosophy'], 'correct_option': 'Logic is an instrument or tool for philosophy'},
    {'question_id': 3, 'question_text': 'Which of the following best describes the meaning of the Greek word "logos"?', 'options': ['Word, discourse, reason', 'Beauty, wisdom, knowledge', 'Truth, wisdom, argument', 'Thought, argument, logic'], 'correct_option': 'Word, discourse, reason'},
    {'question_id': 4, 'question_text': 'What does the Greek word "philos" in the term philosophy mean?', 'options': ['Wisdom', 'Love', 'Knowledge', 'Truth'], 'correct_option': 'Love'},
    {'question_id': 5, 'question_text': 'What are the three core areas that philosophy concerns itself with?', 'options': ['Reality, knowledge, values', 'Wisdom, truth, reason', 'Mind, body, soul', 'Freedom, morality, justice'], 'correct_option': 'Reality, knowledge, values'},
    {'question_id': 6, 'question_text': 'Which major branch of philosophy deals with questions of existence and reality?', 'options': ['Epistemology', 'Metaphysics', 'Axiology', 'Ethics'], 'correct_option': 'Metaphysics'},
    {'question_id': 7, 'question_text': 'Which branch of philosophy concerns itself with the nature and scope of knowledge?', 'options': ['Epistemology', 'Metaphysics', 'Axiology', 'Ethics'], 'correct_option': 'Epistemology'},
    {'question_id': 8, 'question_text': 'Which branch of philosophy focuses on values, including moral values and aesthetics?', 'options': ['Epistemology', 'Metaphysics', 'Axiology', 'Ethics'], 'correct_option': 'Axiology'},
    {'question_id': 9, 'question_text': 'How does formal logic relate to arguments?', 'options': ['It studies the form or structure of arguments', 'It studies the content of arguments', 'It aims to argue effectively', 'It critiques the conclusions of arguments'], 'correct_option': 'It studies the form or structure of arguments'},
    {'question_id': 10, 'question_text': 'What is an example of a formal logic proposition?', 'options': ['All men are mortal', 'Jennifer is fallible', 'It is raining', 'All dogs are animals'], 'correct_option': 'All men are mortal'},
    {'question_id': 11, 'question_text': 'What does the study of formal logic focus on, according to the text?', 'options': ['Content of arguments', 'Forms of arguments', 'Emotions in arguments', 'The truth of conclusions'], 'correct_option': 'Forms of arguments'},
    {'question_id': 12, 'question_text': 'Which of the following is NOT a characteristic of formal logic?', 'options': ['Focus on argument content', 'Emphasis on argument structure', 'Use of exact and clear language', 'Objectivity and detachment'], 'correct_option': 'Focus on argument content'},
    {'question_id': 13, 'question_text': 'What is the definition of an argument in logic?', 'options': ['An angry disagreement', 'A rational exercise of adducing reasons for a conclusion', 'A claim made without evidence', 'A contradiction between two statements'], 'correct_option': 'A rational exercise of adducing reasons for a conclusion'},
    {'question_id': 14, 'question_text': 'Which part of an argument provides the reasons or evidence to support the conclusion?', 'options': ['Conclusion', 'Premise', 'Argument', 'Reasoning'], 'correct_option': 'Premise'},
    {'question_id': 15, 'question_text': 'What determines whether an argument is valid in logic?', 'options': ['The conclusion is true', 'The premises are acceptable', 'The conclusion necessarily follows from the premises', 'The argument uses clear language'], 'correct_option': 'The conclusion necessarily follows from the premises'},
    {'question_id': 16, 'question_text': 'When an argument is invalid, what does this mean?', 'options': ['The conclusion is true', 'The premises are incorrect', 'The conclusion does not follow from the premises', 'The premises are irrelevant'], 'correct_option': 'The conclusion does not follow from the premises'},
    {'question_id': 17, 'question_text': 'Which of the following is an example of an invalid argument?', 'options': ['All humans are fallible. Jennifer is human. Therefore, Jennifer is fallible.', 'If it rains, the streets will be wet. It is raining. Therefore, the streets are wet.', 'All whales are mammals. Dolphins are whales. Therefore, dolphins are mammals.', 'All birds can fly. A penguin is a bird. Therefore, a penguin can fly.'], 'correct_option': 'All birds can fly. A penguin is a bird. Therefore, a penguin can fly.'},
    {'question_id': 18, 'question_text': 'Which of the following is NOT a characteristic of informal logic?', 'options': ['Focus on the content and context of arguments', 'Emphasis on everyday reasoning and discussions', 'Study of the structure of formal arguments', 'Analysis of argumentative reasoning in real-world contexts'], 'correct_option': 'Study of the structure of formal arguments'},
    {'question_id': 19, 'question_text': 'What role does formal logic play in philosophy, according to Aristotle?', 'options': ['It serves as a tool or instrument for philosophy', 'It is a branch of philosophy', 'It focuses on the moral consequences of arguments', 'It studies the content of arguments'], 'correct_option': 'It serves as a tool or instrument for philosophy'},
    {'question_id': 20, 'question_text': 'What does the term "Organon" refer to in the context of Aristotle’s works on logic?', 'options': ['Philosophy', 'Instrument or tool', 'Ethics', 'Axiology'], 'correct_option': 'Instrument or tool'},
    {'question_id': 21, 'question_text': 'Which philosopher emphasized inductive logic and called his work "Novum Organum"?', 'options': ['Aristotle', 'Francis Bacon', 'René Descartes', 'John Dewey'], 'correct_option': 'Francis Bacon'},
    {'question_id': 22, 'question_text': 'What is the main focus of formal logic as discussed in the text?', 'options': ['Examining the content of arguments', 'Studying the structure of arguments', 'Determining the emotional tone of arguments', 'Assessing the truth of premises'], 'correct_option': 'Studying the structure of arguments'},
    {'question_id': 23, 'question_text': 'Which of the following is a benefit of studying formal logic?', 'options': ['Encourages emotional reasoning', 'Helps avoid vague and unclear expressions', 'Encourages subjective interpretations', 'Increases emotional attachment to arguments'], 'correct_option': 'Helps avoid vague and unclear expressions'},
    {'question_id': 24, 'question_text': 'What does the term "premise" refer to in logic?', 'options': ['The conclusion of an argument', 'The reason or evidence supporting a conclusion', 'The emotional response elicited by the argument', 'The contradictory element of an argument'], 'correct_option': 'The reason or evidence supporting a conclusion'},
    {'question_id': 25, 'question_text': 'In the structure of a formal argument, what does the conclusion represent?', 'options': ['The reason for the argument', 'The outcome based on the premises', 'The premise that is most debated', 'The irrelevant detail of the argument'], 'correct_option': 'The outcome based on the premises'},
    {'question_id': 26, 'question_text': 'Which of the following is NOT a key characteristic of formal logic?', 'options': ['Focus on exact language', 'Indifference to emotional content', 'Examination of argument structure', 'Evaluation of argument’s content'], 'correct_option': 'Evaluation of argument’s content'},
    {'question_id': 27, 'question_text': 'What does it mean when an argument is said to be "valid" in formal logic?', 'options': ['The argument has a true conclusion', 'The premises are true', 'The conclusion logically follows from the premises', 'The argument is well-structured'], 'correct_option': 'The conclusion logically follows from the premises'},
    {'question_id': 28, 'question_text': 'Which philosopher is known for pioneering deductive logic?', 'options': ['Francis Bacon', 'Aristotle', 'René Descartes', 'John Dewey'], 'correct_option': 'Aristotle'},
    {'question_id': 29, 'question_text': 'How does informal logic differ from formal logic?', 'options': ['It focuses on the structure of arguments', 'It involves the study of content and context', 'It is concerned with deductive reasoning', 'It is used only in formal debates'], 'correct_option': 'It involves the study of content and context'},
    {'question_id': 30, 'question_text': 'Which philosopher coined the term "Novum Organum" for his work on inductive logic?', 'options': ['Immanuel Kant', 'John Stuart Mill', 'Francis Bacon', 'René Descartes'], 'correct_option': 'Francis Bacon'},
    {'question_id': 31, 'question_text': 'Which of the following best describes "sophistry" in contrast to logic?', 'options': ['The use of clever but false arguments to deceive', 'The study of reasoning and inference', 'The creation of valid arguments', 'The search for wisdom through logical reasoning'], 'correct_option': 'The use of clever but false arguments to deceive'},
    {'question_id': 32, 'question_text': 'What is one of the goals of studying formal logic?', 'options': ['To understand emotions in arguments', 'To evaluate the truth of propositions', 'To identify valid and invalid reasoning patterns', 'To critique the content of debates'], 'correct_option': 'To identify valid and invalid reasoning patterns'},
    {'question_id': 33, 'question_text': 'Which of the following represents a key benefit of studying formal logic?', 'options': ['Encourages emotional expression in arguments', 'Improves clarity and precision in reasoning', 'Promotes subjective interpretation of arguments', 'Focuses on the emotional appeal of arguments'], 'correct_option': 'Improves clarity and precision in reasoning'},
    {'question_id': 34, 'question_text': 'How does formal logic contribute to philosophy?', 'options': ['By providing a tool for clear reasoning', 'By studying the emotional aspects of arguments', 'By focusing on moral values', 'By focusing on metaphysical questions'], 'correct_option': 'By providing a tool for clear reasoning'},
    {'question_id': 35, 'question_text': 'What does "logos" translate to in English?', 'options': ['Truth', 'Reason', 'Emotion', 'Argument'], 'correct_option': 'Reason'},
    {'question_id': 36, 'question_text': 'What aspect of language does formal logic primarily focus on?', 'options': ['Content', 'Emotion', 'Structure', 'Aesthetics'], 'correct_option': 'Structure'},
    {'question_id': 37, 'question_text': 'How do arguments in formal logic become useful for inference?', 'options': ['Through the content of the argument', 'Through the clarity of the argument', 'Through the structure or form of the argument', 'Through emotional appeal'], 'correct_option': 'Through the structure or form of the argument'},
    {'question_id': 38, 'question_text': 'What is the primary concern of logic as a discipline?', 'options': ['Moral implications of arguments', 'Form and structure of reasoning', 'Emotional appeal of arguments', 'Content and context of reasoning'], 'correct_option': 'Form and structure of reasoning'},
    {'question_id': 39, 'question_text': 'In formal logic, what does "validity" refer to?', 'options': ['The truth of the premises', 'The emotional appeal of the argument', 'The logical connection between premises and conclusion', 'The content of the premises'], 'correct_option': 'The logical connection between premises and conclusion'},
    {'question_id': 40, 'question_text': 'Which of the following is a key feature of formal logic?', 'options': ['Focus on emotional persuasion', 'Focus on content of arguments', 'Focus on the clarity and structure of reasoning', 'Focus on the conclusion alone'], 'correct_option': 'Focus on the clarity and structure of reasoning'},
    {'question_id': 41, 'question_text': 'What is the difference between a valid argument and an invalid argument?', 'options': ['Validity refers to truth, while invalidity refers to emotion', 'A valid argument has a true conclusion, while an invalid argument does not', 'A valid argument has a logical connection between premises and conclusion', 'Invalid arguments are always illogical'], 'correct_option': 'A valid argument has a logical connection between premises and conclusion'},
    {'question_id': 42, 'question_text': 'How does formal logic contribute to the practice of philosophy?', 'options': ['By providing clarity and objectivity in reasoning', 'By focusing on emotional content', 'By prioritizing metaphysical arguments', 'By discouraging philosophical debate'], 'correct_option': 'By providing clarity and objectivity in reasoning'},
    {'question_id': 43, 'question_text': 'What does Aristotle’s "Organon" emphasize about logic?', 'options': ['Its role as an instrument for philosophy', 'Its focus on inductive reasoning', 'Its focus on moral values', 'Its study of the content of arguments'], 'correct_option': 'Its role as an instrument for philosophy'},
    {'question_id': 44, 'question_text': 'What is the main purpose of logic as discussed in the text?', 'options': ['To uncover hidden truths', 'To argue with passion', 'To clarify reasoning and support valid conclusions', 'To analyze emotions in arguments'], 'correct_option': 'To clarify reasoning and support valid conclusions'},
    {'question_id': 45, 'question_text': 'What does the term "Novum Organum" refer to in the context of logic?', 'options': ['An instrument of deduction', 'A new tool for inductive reasoning', 'A study of human emotions in argument', 'A system of metaphysical inquiry'], 'correct_option': 'A new tool for inductive reasoning'},
    {'question_id': 46, 'question_text': 'Which is an essential feature of formal logic?', 'options': ['Study of content only', 'Study of structure and form of reasoning', 'Focus on emotional appeal in arguments', 'Focus on the truth of premises alone'], 'correct_option': 'Study of structure and form of reasoning'},
    {'question_id': 47, 'question_text': 'What is the ultimate goal of philosophy, according to the chapter?', 'options': ['To study the formal structure of reasoning', 'To seek wisdom through reasoning', 'To engage in arguments based on emotions', 'To analyze the truth of premises alone'], 'correct_option': 'To seek wisdom through reasoning'},
    {'question_id': 48, 'question_text': 'What is the meaning of the Greek term "philosophia"?', 'options': ['Love of reason', 'Love of wisdom', 'Love of truth', 'Love of knowledge'], 'correct_option': 'Love of wisdom'},
    {'question_id': 49, 'question_text': 'Which type of logic focuses on the form or structure of arguments?', 'options': ['Formal logic', 'Informal logic', 'Inductive logic', 'Deductive logic'], 'correct_option': 'Formal logic'},
    {'question_id': 50, 'question_text': 'What is the key purpose of logic in philosophy?', 'options': ['To explain metaphysical concepts', 'To clarify reasoning and inference processes', 'To understand human emotions', 'To evaluate the truth of premises'], 'correct_option': 'To clarify reasoning and inference processes'}
]

chapter6 = [
    {'question_id': 1, 'question_text': 'What is the primary focus of sociopolitical philosophy?', 'options': ['Studying the natural sciences', 'Examining the social and political challenges of human existence', 'Understanding the emotional state of individuals', 'Promoting economic theories'], 'correct_option': 'Examining the social and political challenges of human existence'},
    {'question_id': 2, 'question_text': 'Which philosopher defines political theory as "man’s attempt to consciously understand and solve the problem of his group life and organization"?', 'options': ['Sabine and Thorson', 'A. Appadorai', 'Aristotle', 'Iks J. Nwankwor'], 'correct_option': 'Sabine and Thorson'},
    {'question_id': 3, 'question_text': 'According to the chapter, which concept is NOT a core aspect of sociopolitical philosophy?', 'options': ['Liberty', 'Justice', 'Property', 'Existentialism'], 'correct_option': 'Existentialism'},
    {'question_id': 4, 'question_text': 'What does sociopolitical philosophy aim to "enwisdomize"?', 'options': ['Human emotions', 'Social and political theories and practices', 'Environmental issues', 'Economic systems'], 'correct_option': 'Social and political theories and practices'},
    {'question_id': 5, 'question_text': 'What is the ultimate goal of sociopolitical philosophy, as outlined in the chapter?', 'options': ['To promote economic theories', 'To establish universal truths', 'To achieve the happiness and well-being of society', 'To define the nature of man'], 'correct_option': 'To achieve the happiness and well-being of society'},
    {'question_id': 6, 'question_text': 'Which of the following is considered a major challenge in social existence as described in the chapter?', 'options': ['Managing human emotions', 'Organizing resources and managing ecological hazards', 'Building personal relationships', 'Understanding cultural diversity'], 'correct_option': 'Organizing resources and managing ecological hazards'},
    {'question_id': 7, 'question_text': 'What does the term "polis" refer to in the context of political philosophy?', 'options': ['A political theory', 'A form of government', 'Ancient Greek city-states', 'A type of philosophical logic'], 'correct_option': 'Ancient Greek city-states'},
    {'question_id': 8, 'question_text': 'Which philosopher is quoted as stating that man is a "sociopolitical being" and that social and political philosophy addresses this nature?', 'options': ['Aquinas', 'Aristotle', 'Iks J. Nwankwor', 'A. Appadorai'], 'correct_option': 'Iks J. Nwankwor'},
    {'question_id': 9, 'question_text': 'Which of the following does sociopolitical philosophy NOT primarily concern itself with?', 'options': ['Philosophical wisdom', 'Political events and ideologies', 'Social existence and challenges', 'Scientific inquiry'], 'correct_option': 'Scientific inquiry'},
    {'question_id': 10, 'question_text': 'Which concept is linked with the function of sociopolitical philosophy to evaluate and prescribe the ideal for human flourishing?', 'options': ['Political practice', 'Justice', 'Rhetoric', 'Emotion'], 'correct_option': 'Justice'},
    {'question_id': 11, 'question_text': 'What is the purpose of sociopolitical philosophy in relation to human-environmental conditions?', 'options': ['To establish an ideal economic system', 'To promote global trade', 'To guarantee optimal happiness in social and political contexts', 'To create a perfect social order'], 'correct_option': 'To guarantee optimal happiness in social and political contexts'},
    {'question_id': 12, 'question_text': 'Which philosopher defines politics as the science that deals with the state or political society?', 'options': ['Nwankwor', 'Appadorai', 'Aquinas', 'Aristotle'], 'correct_option': 'Appadorai'},
    {'question_id': 13, 'question_text': 'What is a key challenge that sociopolitical philosophy aims to address in relation to the natural environment?', 'options': ['Technological advancements', 'Ecological hazards', 'Cultural assimilation', 'Genetic modification'], 'correct_option': 'Ecological hazards'},
    {'question_id': 14, 'question_text': 'What does the sociopolitical philosopher aim to mirror through their analysis of social and political existence?', 'options': ['Emotional stability', 'Political power', 'Orderliness in nature and creation', 'Cultural understanding'], 'correct_option': 'Orderliness in nature and creation'},
    {'question_id': 15, 'question_text': 'What is the goal of the sociopolitical philosopher when analyzing political practices?', 'options': ['To criticize and offer practical solutions', 'To promote political ideologies', 'To teach political science', 'To focus on individual freedom'], 'correct_option': 'To criticize and offer practical solutions'},
    {'question_id': 16, 'question_text': 'Which of the following is an essential task for a sociopolitical philosopher?', 'options': ['Creating new political theories', 'Applying wisdom to social and political life', 'Building political systems', 'Encouraging political participation'], 'correct_option': 'Applying wisdom to social and political life'},
    {'question_id': 17, 'question_text': 'In the context of sociopolitical philosophy, what does the concept of "enwisdomization" refer to?', 'options': ['The acquisition of political power', 'The application of wisdom to social and political issues', 'The study of social behavior', 'The implementation of government policies'], 'correct_option': 'The application of wisdom to social and political issues'},
    {'question_id': 18, 'question_text': 'Which concept is NOT central to sociopolitical philosophy according to the text?', 'options': ['Justice', 'Liberty', 'Economic growth', 'Law'], 'correct_option': 'Economic growth'},
    {'question_id': 19, 'question_text': 'Which philosopher is credited with defining politics as the study of government and political society?', 'options': ['Iks J. Nwankwor', 'A. Appadorai', 'Aristotle', 'John Locke'], 'correct_option': 'A. Appadorai'},
    {'question_id': 20, 'question_text': 'What does sociopolitical philosophy aim to create through its analysis of social and political affairs?', 'options': ['Political power', 'Economic wealth', 'Social order and prosperity', 'Philosophical debates'], 'correct_option': 'Social order and prosperity'},
    {'question_id': 21, 'question_text': 'What does the sociopolitical philosopher focus on when studying social and political problems?', 'options': ['Theoretical predictions', 'Empirical data', 'Moral and rational analysis', 'Psychological factors'], 'correct_option': 'Moral and rational analysis'},
    {'question_id': 22, 'question_text': 'Which concept does NOT belong in the domain of sociopolitical philosophy?', 'options': ['The enforcement of legal codes', 'The pursuit of political power', 'The study of civil rights', 'The analysis of political ideologies'], 'correct_option': 'The pursuit of political power'},
    {'question_id': 23, 'question_text': 'Which of the following is NOT an objective of sociopolitical philosophy?', 'options': ['Establishing peace and harmony', 'Promoting human-environmental harmony', 'Criticizing political practices that harm humanity', 'Building technological systems for political management'], 'correct_option': 'Building technological systems for political management'},
    {'question_id': 24, 'question_text': 'What does sociopolitical philosophy seek to understand in relation to historical events?', 'options': ['Political ideologies', 'Economic systems', 'Social dynamics', 'Ontological significance of sociopolitical phenomena'], 'correct_option': 'Ontological significance of sociopolitical phenomena'},
    {'question_id': 25, 'question_text': 'How does sociopolitical philosophy seek to impact human society?', 'options': ['By creating policies for governance', 'By interpreting and improving social order', 'By studying human history', 'By focusing on the economy'], 'correct_option': 'By interpreting and improving social order'},
    {'question_id': 26, 'question_text': 'What is the relationship between sociopolitical philosophy and other disciplines such as economics and sociology?', 'options': ['They are independent', 'They overlap with sociopolitical philosophy on various concerns', 'They are irrelevant', 'They focus solely on social issues'], 'correct_option': 'They overlap with sociopolitical philosophy on various concerns'},
    {'question_id': 27, 'question_text': 'What is the aim of sociopolitical philosophy when analyzing the concept of "justice"?', 'options': ['To define political justice only', 'To understand its moral and societal implications', 'To promote legal justice over social justice', 'To create new systems of justice'], 'correct_option': 'To understand its moral and societal implications'},
    {'question_id': 28, 'question_text': 'What does sociopolitical philosophy ultimately aim to achieve for society?', 'options': ['Economic prosperity', 'Political power', 'A just and harmonious society', 'Technological advancements'], 'correct_option': 'A just and harmonious society'},
    {'question_id': 29, 'question_text': 'Which is a key feature of sociopolitical philosophy according to the chapter?', 'options': ['The philosophical reflection and analysis of sociopolitical events', 'The promotion of national politics', 'The application of scientific research in politics', 'The focus on technological development'], 'correct_option': 'The philosophical reflection and analysis of sociopolitical events'},
    {'question_id': 30, 'question_text': 'What does the sociopolitical philosopher aim to clarify?', 'options': ['Political ideologies', 'Economic models', 'The concepts, ideas, and principles in social and political life', 'The scientific aspects of politics'], 'correct_option': 'The concepts, ideas, and principles in social and political life'},
    
    {'question_id': 31, 'question_text': 'What are the two main dimensions of the scope of a discipline discussed in the text?', 'options': ['Geographical Scope and Content Scope', 'Geographical Scope and Historical Scope', 'Content Scope and Temporal Scope', 'Geographical Scope and Ideological Scope'], 'correct_option': 'Geographical Scope and Content Scope'},
    {'question_id': 32, 'question_text': 'What does the Geographical Scope of sociopolitical philosophy cover?', 'options': ['The study of natural sciences', 'The study of social and political affairs across various disciplines', 'The study of political power and authority', 'The focus on individual political ideologies'], 'correct_option': 'The study of social and political affairs across various disciplines'},
    {'question_id': 33, 'question_text': 'Which of the following disciplines is NOT included in the Geographical Scope of sociopolitical philosophy?', 'options': ['Anthropology', 'Biology', 'Physics', 'Economics'], 'correct_option': 'Physics'},
    {'question_id': 34, 'question_text': 'What does the Content Scope of sociopolitical philosophy focus on?', 'options': ['Philosophical wisdom in everyday life', 'Interpersonal relationships and man’s relationship with his environment', 'Scientific study of politics', 'Political practices of various countries'], 'correct_option': 'Interpersonal relationships and man’s relationship with his environment'},
    {'question_id': 35, 'question_text': 'What are some key topics dealt with under the Content Scope of sociopolitical philosophy?', 'options': ['Mathematics, geometry, and engineering', 'Authority, Freedom, Sovereignty, and Power', 'Literature, art, and culture', 'Physical sciences and environmental studies'], 'correct_option': 'Authority, Freedom, Sovereignty, and Power'},
    {'question_id': 36, 'question_text': 'What is a major distinction between Sociopolitical Philosophy and Political Science according to the text?', 'options': ['Political Science focuses on ideal systems, while Sociopolitical Philosophy focuses on practical governance', 'Political Science uses scientific methods, while Sociopolitical Philosophy uses rational thinking and logic', 'Sociopolitical Philosophy is more empirical than Political Science', 'Sociopolitical Philosophy is concerned with international relations, while Political Science focuses on local politics'], 'correct_option': 'Political Science uses scientific methods, while Sociopolitical Philosophy uses rational thinking and logic'},
    {'question_id': 37, 'question_text': 'What is the result of Sociopolitical Philosophy generally described as?', 'options': ['Empirical and experimental', 'Speculative, contemplative, and reflective', 'Pragmatic and utilitarian', 'Direct and actionable'], 'correct_option': 'Speculative, contemplative, and reflective'},
    {'question_id': 38, 'question_text': 'Which of the following is NOT a primary focus of Political Science as described in the text?', 'options': ['Practical application of theories', 'Practical utility of political systems', 'Theoretical justification of political theories', 'Explanation of political phenomena'], 'correct_option': 'Theoretical justification of political theories'},
    {'question_id': 39, 'question_text': 'How does Sociopolitical Philosophy approach questions about political establishments and systems?', 'options': ['It describes their practical functions', 'It examines their historical context', 'It prescribes ideal solutions and critiques weaknesses', 'It emphasizes their cultural aspects'], 'correct_option': 'It prescribes ideal solutions and critiques weaknesses'},
    {'question_id': 40, 'question_text': 'What is the main focus of Political Science as a discipline?', 'options': ['Idealism and theory-building', 'Historical analysis of political systems', 'Practical study and explanation of political systems', 'Ethical evaluation of political practices'], 'correct_option': 'Practical study and explanation of political systems'},
    {'question_id': 41, 'question_text': 'What kind of questions does Sociopolitical Philosophy typically ask about political systems?', 'options': ['How and what political systems work in practice', 'What ought to be in political systems and institutions', 'What is the efficiency of political systems', 'How political systems impact economic growth'], 'correct_option': 'What ought to be in political systems and institutions'},
    {'question_id': 42, 'question_text': 'In contrast to Sociopolitical Philosophy, what does Political Science focus on regarding political institutions?', 'options': ['The moral justification of political structures', 'The exploration of ideal political systems', 'The practical operations and activities of political institutions', 'The philosophical justification of political activities'], 'correct_option': 'The practical operations and activities of political institutions'},
    {'question_id': 43, 'question_text': 'Which of the following methods is NOT typically used in Sociopolitical Philosophy?', 'options': ['Induction and experimentation', 'Speculation and prescription', 'Criticism and analysis', 'Universalism and globalism'], 'correct_option': 'Induction and experimentation'},
    {'question_id': 44, 'question_text': 'What is the ultimate goal of Sociopolitical Philosophy in relation to political activities?', 'options': ['To critique the failures of political institutions', 'To provide a practical guide to political governance', 'To define the moral and ethical foundations of political practices', 'To justify the authority of political systems'], 'correct_option': 'To define the moral and ethical foundations of political practices'},
    {'question_id': 45, 'question_text': 'How does Political Science typically explain political phenomena?', 'options': ['By offering theoretical predictions', 'By analyzing and explaining real-world political institutions and activities', 'By proposing ideal political systems', 'By focusing on philosophical justifications'], 'correct_option': 'By analyzing and explaining real-world political institutions and activities'},
    {'question_id': 46, 'question_text': 'What makes Sociopolitical Philosophy more prescriptive and normative than Political Science?', 'options': ['It describes political systems', 'It justifies and critiques political practices', 'It develops scientific methods for political analysis', 'It focuses solely on the history of political thought'], 'correct_option': 'It justifies and critiques political practices'},
    {'question_id': 47, 'question_text': 'Which discipline is described as more concerned with the practical application of existing political theories?', 'options': ['Political Science', 'Sociopolitical Philosophy', 'Ethics', 'Economics'], 'correct_option': 'Political Science'},
    {'question_id': 48, 'question_text': 'What is the role of Sociopolitical Philosophy in relation to Political Science, as described in the text?', 'options': ['Sociopolitical Philosophy serves as the foundation for Political Science', 'Sociopolitical Philosophy focuses only on history', 'Sociopolitical Philosophy provides practical political solutions', 'Sociopolitical Philosophy analyzes political systems in detail'], 'correct_option': 'Sociopolitical Philosophy serves as the foundation for Political Science'},
    {'question_id': 49, 'question_text': 'What is a key feature of Sociopolitical Philosophy’s method of investigation?', 'options': ['Empirical observation and experimentation', 'Speculative and critical evaluation of political ideas', 'Observation and analysis of political outcomes', 'Practical application of political theories'], 'correct_option': 'Speculative and critical evaluation of political ideas'},
    {'question_id': 50, 'question_text': 'What distinguishes the scope of Sociopolitical Philosophy from that of Political Science?', 'options': ['Sociopolitical Philosophy is concerned with ideal political systems, while Political Science focuses on real-world political practices', 'Sociopolitical Philosophy exclusively studies political systems in history', 'Sociopolitical Philosophy focuses on empirical data, while Political Science focuses on normative theory', 'Sociopolitical Philosophy deals exclusively with economics, while Political Science covers political theory'], 'correct_option': 'Sociopolitical Philosophy is concerned with ideal political systems, while Political Science focuses on real-world political practices'}
]

chapter7 = [
    {'question_id': 1, 'question_text': 'What is meant by authentic existence as discussed in the chapter?', 'options': ['Living according to societal expectations', 'Being true to oneself in alignment with societal standards', 'Existing without societal influence', 'Living solely for personal gain'], 'correct_option': 'Being true to oneself in alignment with societal standards'},
    {'question_id': 2, 'question_text': 'According to the chapter, how does philosophy contribute to understanding existence?', 'options': ['By accepting facts as they are', 'By critically analyzing concepts and principles', 'By aligning with religious teachings', 'By focusing solely on empirical evidence'], 'correct_option': 'By critically analyzing concepts and principles'},
    {'question_id': 3, 'question_text': 'What does the term "philosophy" primarily signify according to the chapter?', 'options': ['The pursuit of mystical knowledge', 'Love of wisdom and critical thinking', 'The study of religious beliefs', 'A method of controlling society'], 'correct_option': 'Love of wisdom and critical thinking'},
    {'question_id': 4, 'question_text': 'What does the "philosophy of education" explore?', 'options': ['Principles of religion in education', 'Basic concepts and assumptions about education', 'Historical methods of teaching', 'Economic theories related to education'], 'correct_option': 'Basic concepts and assumptions about education'},
    {'question_id': 5, 'question_text': 'What is the general understanding of education among laypeople?', 'options': ['The transmission of abstract knowledge', 'Formal schooling or learning of some sort', 'The study of philosophy and logic', 'Personal development outside societal norms'], 'correct_option': 'Formal schooling or learning of some sort'},
    {'question_id': 6, 'question_text': 'Which philosopher defined education as the "arts of acquisition and utilization of knowledge"?', 'options': ['Scheffler', 'Ijiomah', 'Whitehead', 'Ukeje'], 'correct_option': 'Whitehead'},
    {'question_id': 7, 'question_text': 'How does Ukeje define education?', 'options': ['A process of personal development', 'The transmission of cultural knowledge to advance society', 'The acquisition of technical skills only', 'A purely formal institutional activity'], 'correct_option': 'The transmission of cultural knowledge to advance society'},
    {'question_id': 8, 'question_text': 'What distinguishes formal education from informal education?', 'options': ['Formal education is spontaneous, informal education is planned', 'Formal education is planned and systematic, while informal education is not', 'Both are equally structured', 'Informal education is regulated by law, formal education is not'], 'correct_option': 'Formal education is planned and systematic, while informal education is not'},
    {'question_id': 9, 'question_text': 'According to Frankena, what does education do in society?', 'options': ['Helps individuals avoid societal expectations', 'Preserves and upgrades accumulated knowledge, skills, and attitudes', 'Teaches individuals to reject societal values', 'Focuses only on intellectual development'], 'correct_option': 'Preserves and upgrades accumulated knowledge, skills, and attitudes'},
    {'question_id': 10, 'question_text': 'What is the critique presented by Ijiomah regarding the concept of education?', 'options': ['It is irrelevant and needs to be discarded', 'It is too focused on theoretical knowledge', 'It can be synonymous with mis-education due to its lack of relevance', 'It is too focused on individualism'], 'correct_option': 'It can be synonymous with mis-education due to its lack of relevance'},
    {'question_id': 11, 'question_text': 'What does Ijiomah suggest education often becomes in society?', 'options': ['A process of socializing the younger generation by the older generation', 'A tool for personal development', 'A space for individual exploration', 'A method of escaping societal responsibilities'], 'correct_option': 'A process of socializing the younger generation by the older generation'},
    {'question_id': 12, 'question_text': 'According to the chapter, what is often perceived as mis-education by youth?', 'options': ['The transmission of societal values and cultural heritage', 'The attempt to cultivate individualism and independence', 'The forced imposition of values and beliefs', 'The focus on educational reform'], 'correct_option': 'The forced imposition of values and beliefs'},
    {'question_id': 13, 'question_text': 'What is the potential consequence of viewing education as a tool for transmitting only societal values?', 'options': ['It creates authoritarianism and reduces critical thinking', 'It enhances individual creativity and autonomy', 'It fosters an inclusive and diverse society', 'It encourages independent thinking'], 'correct_option': 'It creates authoritarianism and reduces critical thinking'},
    {'question_id': 14, 'question_text': 'How does the chapter describe the relationship between society and education?', 'options': ['Education functions independently of societal needs', 'Education reflects and perpetuates the values and goals of society', 'Society suppresses individual freedom in education', 'Education is irrelevant to societal development'], 'correct_option': 'Education reflects and perpetuates the values and goals of society'},
    {'question_id': 15, 'question_text': 'What key element does the chapter identify as essential for education to be meaningful?', 'options': ['Strict adherence to tradition', 'The development of desirable dispositions and critical thinking', 'Focus on technical skills alone', 'Elimination of cultural values'], 'correct_option': 'The development of desirable dispositions and critical thinking'},
    {'question_id': 16, 'question_text': 'What is the role of the older generation in education, according to Ijiomah?', 'options': ['To oppose societal norms', 'To transmit desirable values and beliefs to the youth', 'To suppress youth development', 'To prioritize individual success over societal values'], 'correct_option': 'To transmit desirable values and beliefs to the youth'},
    {'question_id': 17, 'question_text': 'According to the chapter, what is the primary aim of education?', 'options': ['To help individuals achieve economic success', 'To help individuals realize their full potential and contribute to society', 'To ensure conformity with societal norms', 'To discourage independent thought'], 'correct_option': 'To help individuals realize their full potential and contribute to society'},
    {'question_id': 18, 'question_text': 'What does the chapter suggest is a crucial component for national development through education?', 'options': ['Political indoctrination', 'Preservation of cultural values and development of individual potential', 'Strict control over educational institutions', 'Focus on individual autonomy'], 'correct_option': 'Preservation of cultural values and development of individual potential'},
    {'question_id': 19, 'question_text': 'How does the chapter address the tension between traditional and formal education?', 'options': ['It argues that both should be disregarded', 'It suggests that traditional education should be prioritized over formal education', 'It emphasizes the need for integration of both types to foster societal continuity', 'It claims that traditional education has no place in modern society'], 'correct_option': 'It emphasizes the need for integration of both types to foster societal continuity'},
    {'question_id': 20, 'question_text': 'What is the significance of values like honesty and integrity in education, according to the chapter?', 'options': ['They hinder societal progress', 'They are irrelevant in the educational process', 'They foster societal cohesion and authentic human existence', 'They promote individualism over societal well-being'], 'correct_option': 'They foster societal cohesion and authentic human existence'},
    {
    'question_id': 21,
    'question_text': 'What does philosophy of education primarily focus on?',
    'options': ['Examining the political systems of education', 'Critically analyzing educational policies and practices', 'Developing educational materials', 'Teaching technical skills to educators'],
    'correct_option': 'Critically analyzing educational policies and practices'
},
{
    'question_id': 22,
    'question_text': 'Which concept does the philosophy of education examine?',
    'options': ['Educational materials', 'Educational systems and methods', 'Political influence on education', 'School infrastructure'],
    'correct_option': 'Educational systems and methods'
},
{
    'question_id': 23,
    'question_text': 'According to Bamiseiye, philosophy of education involves:',
    'options': ['Examining the history of educational systems', 'Critically examining problems and setting goals for education', 'Creating new educational theories', 'Focusing only on academic curricula'],
    'correct_option': 'Critically examining problems and setting goals for education'
},
{
    'question_id': 24,
    'question_text': 'What is the main function of philosophy of education according to Uduigwomen?',
    'options': ['Clarifying concepts and analyzing meanings', 'Creating new teaching methods', 'Designing school curricula', 'Promoting educational reforms'],
    'correct_option': 'Clarifying concepts and analyzing meanings'
},
{
    'question_id': 25,
    'question_text': 'How does philosophy of education impact teachers?',
    'options': ['It focuses solely on classroom management', 'It develops teachers’ intellectual abilities', 'It provides fixed answers to teaching problems', 'It isolates teachers from societal issues'],
    'correct_option': 'It develops teachers’ intellectual abilities'
},
{
    'question_id': 26,
    'question_text': 'What role does philosophy of education play in educational planning?',
    'options': ['It restricts the scope of educational goals', 'It helps in formulating and evaluating educational goals', 'It determines the physical infrastructure of schools', 'It focuses on textbook development'],
    'correct_option': 'It helps in formulating and evaluating educational goals'
},
{
    'question_id': 27,
    'question_text': 'What does philosophical thinking about education aim to do?',
    'options': ['Create political systems', 'Identify and solve educational problems', 'Design teaching techniques', 'Ensure economic growth through education'],
    'correct_option': 'Identify and solve educational problems'
},
{
    'question_id': 28,
    'question_text': 'What does the term "philosophy of education" imply when it is applied to a society?',
    'options': ['The creation of new government policies', 'A systematic approach to understanding educational issues', 'The development of new educational subjects', 'An evaluation of past educational systems'],
    'correct_option': 'A systematic approach to understanding educational issues'
},
{
    'question_id': 29,
    'question_text': 'Why is philosophy of education important for policy makers?',
    'options': ['It ensures that educational reforms focus only on skills', 'It critiques and ensures policies reflect societal values', 'It helps in administrative decision-making', 'It establishes fixed teaching methods'],
    'correct_option': 'It critiques and ensures policies reflect societal values'
},
{
    'question_id': 30,
    'question_text': 'Which philosophical school focuses on the development of personal values and societal engagement?',
    'options': ['Idealism', 'Realism', 'Pragmatism', 'Existentialism'],
    'correct_option': 'Existentialism'
},
{
    'question_id': 31,
    'question_text': 'How does philosophy of education assist educators?',
    'options': ['By providing fixed, uniform policies', 'By helping them develop critical thinking skills', 'By eliminating the need for teacher-student interaction', 'By limiting their curriculum choices'],
    'correct_option': 'By helping them develop critical thinking skills'
},
{
    'question_id': 32,
    'question_text': 'Which philosophical system emphasizes practical solutions to educational issues?',
    'options': ['Idealism', 'Realism', 'Pragmatism', 'Existentialism'],
    'correct_option': 'Pragmatism'
},
{
    'question_id': 33,
    'question_text': 'What does the philosophy of education promote in relation to societal development?',
    'options': ['Isolation from global educational standards', 'Critical engagement with educational goals for social progress', 'Focus on technical education only', 'Denial of traditional educational methods'],
    'correct_option': 'Critical engagement with educational goals for social progress'
},
{
    'question_id': 34,
    'question_text': 'What is a major concern of the philosophy of education?',
    'options': ['Improving the infrastructure of schools', 'Identifying and addressing educational problems', 'Focusing only on academic subjects', 'Promoting one educational system worldwide'],
    'correct_option': 'Identifying and addressing educational problems'
},
{
    'question_id': 35,
    'question_text': 'What does philosophical thinking in education enable individuals to do?',
    'options': ['Follow standard educational practices without questioning', 'Formulate new educational policies without critical analysis', 'Critically evaluate educational systems and practices', 'Focus solely on theoretical knowledge'],
    'correct_option': 'Critically evaluate educational systems and practices'
},
{
    'question_id': 36,
    'question_text': 'Which of the following does philosophy of education directly influence?',
    'options': ['School infrastructure and resources', 'The type of education system adopted by society', 'Only the academic content of education', 'Classroom management techniques'],
    'correct_option': 'The type of education system adopted by society'
},
{
    'question_id': 37,
    'question_text': 'What role does philosophy of education play in relation to the curriculum?',
    'options': ['It determines the exact content of the curriculum', 'It provides a framework for understanding the goals of the curriculum', 'It restricts the scope of the curriculum', 'It defines the subjects that must be taught'],
    'correct_option': 'It provides a framework for understanding the goals of the curriculum'
},
{
    'question_id': 38,
    'question_text': 'How does philosophy of education contribute to national development?',
    'options': ['By promoting vocational training only', 'By creating policies that reflect societal values and goals', 'By focusing on standardized education systems', 'By limiting the development of higher education'],
    'correct_option': 'By creating policies that reflect societal values and goals'
},
{
    'question_id': 39,
    'question_text': 'What is the key to ensuring educational goals align with societal needs?',
    'options': ['Uniform educational policies', 'Philosophical analysis of societal ideologies', 'Economic resources allocated to education', 'Standardized testing systems'],
    'correct_option': 'Philosophical analysis of societal ideologies'
},
{
    'question_id': 40,
    'question_text': 'Which philosophical approach is most concerned with practical results in education?',
    'options': ['Idealism', 'Realism', 'Pragmatism', 'Existentialism'],
    'correct_option': 'Pragmatism'
},
{
    'question_id': 41,
    'question_text': 'What impact does philosophy of education have on teachers’ actions?',
    'options': ['It imposes rigid teaching methods', 'It enables them to critically assess and adapt their methods', 'It focuses only on theoretical knowledge', 'It enforces uniform teaching styles across all schools'],
    'correct_option': 'It enables them to critically assess and adapt their methods'
},
{
    'question_id': 42,
    'question_text': 'What is the primary goal of philosophy of education according to the text?',
    'options': ['To develop new educational technologies', 'To improve educational policies and practices through critical analysis', 'To create universal educational standards', 'To limit the scope of educational reforms'],
    'correct_option': 'To improve educational policies and practices through critical analysis'
},
{
    'question_id': 43,
    'question_text': 'What does philosophical analysis of educational systems help society avoid?',
    'options': ['Revolutionary movements', 'Backwardness in societal development', 'Technological advancements in education', 'Uniform educational practices worldwide'],
    'correct_option': 'Backwardness in societal development'
},
{
    'question_id': 44,
    'question_text': 'What is the role of philosophy of education in understanding educational practice?',
    'options': ['It simplifies educational practices', 'It enables a deeper understanding of educational values and their implications', 'It eliminates the need for educational reforms', 'It limits the scope of educational practices'],
    'correct_option': 'It enables a deeper understanding of educational values and their implications'
},
{
    'question_id': 45,
    'question_text': 'What is a key feature of educational systems shaped by philosophy of education?',
    'options': ['They strictly adhere to outdated practices', 'They critically assess and revise policies to reflect societal needs', 'They prioritize only academic learning', 'They limit the involvement of educators in decision making'],
    'correct_option': 'They critically assess and revise policies to reflect societal needs'
},
    
    {'question_id': 46, 'question_text': 'What is the central belief of idealism regarding the nature of reality?', 'options': ['Reality is physical and material', 'Reality is spiritual and mental', 'Reality is a mixture of both material and spiritual', 'Reality is illusionary'], 'correct_option': 'Reality is spiritual and mental'},
    {'question_id': 47, 'question_text': 'Which of the following subjects are emphasized in the idealist approach to education?', 'options': ['Mathematics, science, and technology', 'History, fine arts, religion, and philosophy', 'Physical education and sports', 'Engineering and technical courses'], 'correct_option': 'History, fine arts, religion, and philosophy'},
    {'question_id': 48, 'question_text': 'In the realist school of thought, how is reality perceived?', 'options': ['As existing independently of the human mind', 'As being subjective and dependent on individual perception', 'As a construct of the human consciousness', 'As an illusion created by sense perception'], 'correct_option': 'As existing independently of the human mind'},
    {'question_id': 49, 'question_text': 'Which philosopher is NOT typically associated with the philosophy of realism?', 'options': ['Plato', 'Aristotle', 'John Locke', 'Francis Bacon'], 'correct_option': 'Plato'},
    {'question_id': 50, 'question_text': 'What is the primary goal of education according to pragmatism?', 'options': ['To pass on fixed knowledge from one generation to the next', 'To prepare learners for change and adaptation', 'To discover universal truths', 'To develop spiritual qualities in students'], 'correct_option': 'To prepare learners for change and adaptation'},
    {'question_id': 51, 'question_text': 'How do pragmatists view the nature of truth?', 'options': ['Truth is absolute and unchanging', 'Truth is what works in a given context', 'Truth is a mental construct', 'Truth is irrelevant to educational practice'], 'correct_option': 'Truth is what works in a given context'},
    {'question_id': 52, 'question_text': 'Which of the following is a major focus in existentialist philosophy of education?', 'options': ['Adjusting individuals to society', 'Helping individuals develop a unique personality', 'Acquiring objective knowledge', 'Learning through structured methods'], 'correct_option': 'Helping individuals develop a unique personality'},
    {'question_id': 53, 'question_text': 'What does existentialism emphasize regarding human existence?', 'options': ['Existence precedes essence', 'Essence precedes existence', 'Humans are defined by their environment', 'Humans are determined by external factors'], 'correct_option': 'Existence precedes essence'},
    {'question_id': 54, 'question_text': 'In existentialist education, how is the learner viewed?', 'options': ['As a passive recipient of knowledge', 'As an individual who must follow societal norms', 'As an active participant in shaping their own destiny', 'As a vessel to be filled with knowledge'], 'correct_option': 'As an active participant in shaping their own destiny'},
    {'question_id': 55, 'question_text': 'Which philosopher is considered a major figure in existentialism?', 'options': ['Jean-Paul Sartre', 'Aristotle', 'Immanuel Kant', 'John Dewey'], 'correct_option': 'Jean-Paul Sartre'},
    {'question_id': 56, 'question_text': 'According to realists, what is the most desirable knowledge?', 'options': ['Knowledge about abstract concepts', 'Knowledge of nature and the physical world', 'Knowledge of the spiritual realm', 'Knowledge based on individual experiences'], 'correct_option': 'Knowledge of nature and the physical world'},
    {'question_id': 57, 'question_text': 'Which educational method is commonly associated with idealism?', 'options': ['The use of objective tests and standardized assessments', 'The Socratic method of questioning and dialogue', 'The memorization of facts and figures', 'The focus on practical application of knowledge'], 'correct_option': 'The Socratic method of questioning and dialogue'},
    {'question_id': 58, 'question_text': 'What is the existentialist view on education and its goals?', 'options': ['To foster conformity to societal expectations', 'To develop spiritual virtues', 'To help individuals achieve self-realization and personal freedom', 'To transfer knowledge across generations'], 'correct_option': 'To help individuals achieve self-realization and personal freedom'},
    {'question_id': 59, 'question_text': 'What is the existentialist view on standardized testing and measurements?', 'options': ['They are essential for assessing individual progress', 'They are necessary to track societal development', 'They limit personal choice and self-direction', 'They provide an accurate representation of an individual’s abilities'], 'correct_option': 'They limit personal choice and self-direction'},
    {'question_id': 60, 'question_text': 'Which educational theory emphasizes the development of reasoning and the understanding of abstract ideas?', 'options': ['Pragmatism', 'Realism', 'Idealism', 'Existentialism'], 'correct_option': 'Idealism'},
    {'question_id': 61, 'question_text': 'What is the primary goal of realist education?', 'options': ['To develop spiritual qualities', 'To facilitate understanding of objective reality', 'To adapt to social expectations', 'To prepare students for higher learning'], 'correct_option': 'To facilitate understanding of objective reality'},
    {'question_id': 62, 'question_text': 'What does pragmatism emphasize in terms of the educational process?', 'options': ['Knowledge as a fixed set of truths', 'Learning through active problem-solving and experience', 'The transmission of cultural values', 'The development of a spiritual self'], 'correct_option': 'Learning through active problem-solving and experience'},
    {'question_id': 63, 'question_text': 'Which of the following is NOT a key feature of idealism in education?', 'options': ['Emphasis on reason and intellectual development', 'Focus on abstract subjects like philosophy and fine arts', 'Focus on practical and vocational subjects', 'Emphasis on spiritual development of the individual'], 'correct_option': 'Focus on practical and vocational subjects'},
    {'question_id': 64, 'question_text': 'How do pragmatists view knowledge?', 'options': ['As an absolute truth that never changes', 'As a tool to solve practical problems and adapt to changing circumstances', 'As something to be memorized and passed down', 'As irrelevant to the individual’s needs'], 'correct_option': 'As a tool to solve practical problems and adapt to changing circumstances'},
    {'question_id': 65, 'question_text': 'What is the central principle of existentialist philosophy?', 'options': ['Reality is objective and independent of human perception', 'The individual must create their own meaning and values in life', 'Knowledge is a set of fixed truths', 'Human existence is defined by societal norms'], 'correct_option': 'The individual must create their own meaning and values in life'},
    {'question_id': 66, 'question_text': 'In which philosophy is the idea that existence precedes essence most central?', 'options': ['Idealism', 'Realism', 'Pragmatism', 'Existentialism'], 'correct_option': 'Existentialism'},
    {'question_id': 67, 'question_text': 'How do existentialists view group values?', 'options': ['As essential for creating harmony in society', 'As a foundation for personal growth', 'As inhibiting personal freedom and choice', 'As necessary for the common good'], 'correct_option': 'As inhibiting personal freedom and choice'}
    

]

chapter8 = [
    {'question_id': 1, 'question_text': 'What is the primary focus of philosophy of science?', 'options': ['To explore the natural world using observation', 'To examine the methods, foundations, and implications of science', 'To develop new scientific theories', 'To study the social impacts of scientific discoveries'], 'correct_option': 'To examine the methods, foundations, and implications of science'},
    {'question_id': 2, 'question_text': 'Which of the following is NOT considered a characteristic of science?', 'options': ['Concreteness', 'Objectivity', 'Universality', 'Subjectivity'], 'correct_option': 'Subjectivity'},
    {'question_id': 3, 'question_text': 'What is the Latin origin of the word "science"?', 'options': ['Scientia', 'Scientia Nova', 'Scientifique', 'Scienta'], 'correct_option': 'Scientia'},
    {'question_id': 4, 'question_text': 'How does science as a body of knowledge differ from other disciplines like religion or art?', 'options': ['It is based on logical, orderly observation and testing of facts', 'It focuses on metaphysical speculation', 'It deals exclusively with abstract ideas', 'It relies on faith and belief systems'], 'correct_option': 'It is based on logical, orderly observation and testing of facts'},
    {'question_id': 5, 'question_text': 'Which step is NOT part of the scientific method?', 'options': ['Observation', 'Hypothesis formulation', 'Belief affirmation', 'Experimentation'], 'correct_option': 'Belief affirmation'},
    {'question_id': 6, 'question_text': 'What role do scientific institutions play in the development of science?', 'options': ['They regulate and promote collaboration among scientists', 'They provide funding for scientific studies', 'They prevent scientific research from occurring', 'They restrict the flow of scientific knowledge'], 'correct_option': 'They regulate and promote collaboration among scientists'},
    {'question_id': 7, 'question_text': 'What does the characteristic of "objectivity" in science refer to?', 'options': ['The influence of personal opinions on scientific conclusions', 'The impartial and verifiable nature of scientific knowledge', 'The importance of subjective experiences in scientific research', 'The process of forming hypotheses based on beliefs'], 'correct_option': 'The impartial and verifiable nature of scientific knowledge'},
    {'question_id': 8, 'question_text': 'Which philosopher proposed that water is the underlying principle of all things?', 'options': ['Heraclitus', 'Thales', 'Democritus', 'Pythagoras'], 'correct_option': 'Thales'},
    {'question_id': 9, 'question_text': 'What is the significance of the idea of "universality" in science?', 'options': ['Scientific knowledge is only relevant in the country of origin', 'Scientific methods and conclusions are open to public scrutiny and can be tested by anyone', 'Scientific findings must be subjective and influenced by personal beliefs', 'Only experts in a particular field can understand scientific methods'], 'correct_option': 'Scientific methods and conclusions are open to public scrutiny and can be tested by anyone'},
    {'question_id': 10, 'question_text': 'What does the aim of "control" in science involve?', 'options': ['Predicting future events', 'Explaining the origins of natural phenomena', 'Manipulating the behavior of objects and phenomena in nature', 'Disproving established theories'], 'correct_option': 'Manipulating the behavior of objects and phenomena in nature'},
    {'question_id': 11, 'question_text': 'Which early Greek philosopher believed that air is the primary substance from which all things originated?', 'options': ['Thales', 'Heraclitus', 'Pythagoras', 'Anaximenes'], 'correct_option': 'Anaximenes'},
    {'question_id': 12, 'question_text': 'What is the main difference between science and philosophy in terms of their historical development?', 'options': ['Science emerged as a separate field in the 18th century, while philosophy focused on abstract ideas', 'Science emerged alongside religion, while philosophy remained separate', 'Science and philosophy have always been the same', 'Science emerged from philosophy, and was once known as natural philosophy'], 'correct_option': 'Science emerged from philosophy, and was once known as natural philosophy'},
    {'question_id': 13, 'question_text': 'How is the field of science classified in terms of its branches?', 'options': ['By the type of research methods used', 'By the objects and phenomena they study', 'By the number of scientists involved', 'By the geographic region of the research'], 'correct_option': 'By the objects and phenomena they study'},
    {'question_id': 14, 'question_text': 'What is the main characteristic of formal sciences?', 'options': ['They deal with measurable and observable phenomena', 'They use calculations to ascertain the validity of conclusions', 'They focus on the behavior of living organisms', 'They study abstract concepts without rules or structure'], 'correct_option': 'They use calculations to ascertain the validity of conclusions'},
    {'question_id': 15, 'question_text': 'Which of the following is NOT an example of empirical science?', 'options': ['Physics', 'Chemistry', 'Mathematics', 'Biology'], 'correct_option': 'Mathematics'},
    {'question_id': 16, 'question_text': 'What is the role of "prediction" in science?', 'options': ['To explain natural phenomena', 'To make informed guesses about future events based on past data', 'To develop new theories', 'To manipulate objects in the environment'], 'correct_option': 'To make informed guesses about future events based on past data'},
    {'question_id': 17, 'question_text': 'What does "development" in science aim to achieve?', 'options': ['To explain events that have already occurred', 'To predict future events with certainty', 'To help in the growth and progress of people and society', 'To limit human understanding of the world'], 'correct_option': 'To help in the growth and progress of people and society'},
    {'question_id': 18, 'question_text': 'Which Greek philosopher believed that fire is the fundamental substance of the universe?', 'options': ['Heraclitus', 'Thales', 'Anaximenes', 'Democritus'], 'correct_option': 'Heraclitus'},
    {'question_id': 19, 'question_text': 'What is a key feature of empirical sciences?', 'options': ['They rely on abstract reasoning', 'They study objects and phenomena that can be observed and tested', 'They focus on understanding the metaphysical world', 'They avoid experimentation'], 'correct_option': 'They study objects and phenomena that can be observed and tested'},
    {'question_id': 20, 'question_text': 'Which of the following is a primary goal of science as a method of acquiring knowledge?', 'options': ['To develop spiritual wisdom', 'To acquire knowledge through a structured and logical process of testing', 'To follow predetermined beliefs', 'To focus on subjective interpretation of data'], 'correct_option': 'To acquire knowledge through a structured and logical process of testing'},
    
    {'question_id': 21, 'question_text': 'What is the main characteristic of the deductive method?', 'options': ['It starts with specific observations and concludes general principles.', 'It moves from general principles to specific conclusions.', 'It involves making predictions based on past experiences.', 'It tests theories through repeated experiments.'], 'correct_option': 'It moves from general principles to specific conclusions.'},
    
    {'question_id': 22, 'question_text': 'Which of the following best describes the inductive method?', 'options': ['Moving from specific observations to broad generalizations.', 'Using general principles to deduce specific outcomes.', 'Focusing on proving the truth of a given theory.', 'Testing theories under controlled conditions.'], 'correct_option': 'Moving from specific observations to broad generalizations.'},
    
    {'question_id': 23, 'question_text': 'What is the nature of conclusions drawn from inductive reasoning?', 'options': ['They are always true if the premises are true.', 'They are always guaranteed to be true.', 'They are always probable, but not certain.', 'They are only valid for the current situation.'], 'correct_option': 'They are always probable, but not certain.'},
    
    {'question_id': 24, 'question_text': 'What is a hypothesis in the scientific method?', 'options': ['A definitive conclusion about a phenomenon.', 'A set of observations made about an event.', 'A proposed explanation that needs testing.', 'A proven scientific theory.'], 'correct_option': 'A proposed explanation that needs testing.'},
    
    {'question_id': 25, 'question_text': 'In scientific experimentation, what is the role of observation?', 'options': ['It involves creating new theories based on old ones.', 'It helps gather data that can lead to conclusions.', 'It is the final step in the scientific method.', 'It requires the scientist to manipulate variables directly.'], 'correct_option': 'It helps gather data that can lead to conclusions.'},
    
    {'question_id': 26, 'question_text': 'What distinguishes scientific theories from hypotheses?', 'options': ['Theories are based on personal beliefs, while hypotheses are factual.', 'Theories are well-supported explanations, while hypotheses are proposed explanations.', 'Hypotheses are tested, while theories are not.', 'Theories are conclusions derived from inductive reasoning, while hypotheses are deductive.'], 'correct_option': 'Theories are well-supported explanations, while hypotheses are proposed explanations.'},
    
    {'question_id': 27, 'question_text': 'What does the philosophy of science primarily investigate?', 'options': ['The historical development of scientific theories.', 'The methods and concepts of science and their validity.', 'The best scientific theories currently available.', 'The relationship between science and religion.'], 'correct_option': 'The methods and concepts of science and their validity.'},
    
    {'question_id': 28, 'question_text': 'What role does philosophy play in the scientific process?', 'options': ['It conducts experiments to verify scientific theories.', 'It critiques the assumptions and logical foundations of science.', 'It provides funding for scientific research.', 'It publishes scientific findings for global distribution.'], 'correct_option': 'It critiques the assumptions and logical foundations of science.'},
    
    {'question_id': 29, 'question_text': 'Which of the following is a key aspect of the philosophy of science?', 'options': ['It focuses only on the practical applications of scientific discoveries.', 'It seeks to provide a clear explanation of what science is and how it works.', 'It avoids making any conclusions about scientific theories.', 'It attempts to prove all scientific claims true.'], 'correct_option': 'It seeks to provide a clear explanation of what science is and how it works.'},
    
    {'question_id': 30, 'question_text': 'What is the difference between scientific realism and anti-realism?', 'options': ['Realism claims that scientific theories are proven true, while anti-realism denies their truth.', 'Realism states that the physical world exists independently of human thought, while anti-realism denies this.', 'Realism focuses on observable phenomena, while anti-realism focuses on unobservable phenomena.', 'Realism insists on the importance of empirical data, while anti-realism rejects scientific methods.'], 'correct_option': 'Realism states that the physical world exists independently of human thought, while anti-realism denies this.'},
    
    {'question_id': 31, 'question_text': 'What is the main concern of objectivity in science?', 'options': ['Ensuring that scientific findings are free from personal bias and external influences.', 'Focusing on the economic benefits of scientific research.', 'Applying ethical considerations to all scientific experiments.', 'Validating the cultural relevance of scientific theories.'], 'correct_option': 'Ensuring that scientific findings are free from personal bias and external influences.'},
    
    {'question_id': 32, 'question_text': 'Which of the following best defines objectivity as "faithfulness to fact"?', 'options': ['Scientific claims are objective if they describe facts without considering external biases.', 'Objectivity is achieved when facts are not verified against evidence.', 'Science is objective only when it includes moral considerations.', 'Scientific claims are objective if they align with personal beliefs.'], 'correct_option': 'Scientific claims are objective if they describe facts without considering external biases.'},
    
    {'question_id': 33, 'question_text': 'What is the value-free ideal of objectivity in science?', 'options': ['Science is objective when it is guided by moral and political values.', 'Science should be free from any moral, political, or personal biases in its methods and outcomes.', 'Objectivity in science is achieved when scientists are personally invested in their theories.', 'Science aims to make its findings consistent with societal norms and values.'], 'correct_option': 'Science should be free from any moral, political, or personal biases in its methods and outcomes.'},
    
    {'question_id': 34, 'question_text': 'What is a concern regarding process objectivity in science?', 'options': ['It focuses on the accuracy of scientific results rather than the methods used.', 'It ignores the role of human values in shaping scientific research.', 'It stresses that scientific methods and processes must be free from bias and external influence.', 'It suggests that scientific results should always align with societal values.'], 'correct_option': 'It stresses that scientific methods and processes must be free from bias and external influence.'},
    
    {'question_id': 35, 'question_text': 'How has science positively impacted communication?', 'options': ['It has improved the speed and accuracy of message delivery through modern technologies.', 'It has made communication more expensive and less accessible.', 'It has reduced the need for formal written communication.', 'It has limited communication to only scientific communities.'], 'correct_option': 'It has improved the speed and accuracy of message delivery through modern technologies.'},
    
    {'question_id': 36, 'question_text': 'What positive impact has science had on agriculture?', 'options': ['It has introduced mechanized farming and increased food production.', 'It has reduced the variety of crops produced worldwide.', 'It has made organic farming obsolete.', 'It has focused on improving farming for large-scale industries only.'], 'correct_option': 'It has introduced mechanized farming and increased food production.'},
    
    {'question_id': 37, 'question_text': 'How has science improved health and medicine?', 'options': ['By developing new technologies that eliminate all diseases.', 'By creating vaccines and medications to prevent and cure diseases.', 'By focusing exclusively on traditional healing methods.', 'By reducing the need for medical practitioners.'], 'correct_option': 'By creating vaccines and medications to prevent and cure diseases.'},
    
    {'question_id': 38, 'question_text': 'What is a negative impact of scientific advancements on society?', 'options': ['Science has eliminated diseases and reduced poverty.', 'Science has contributed to environmental pollution and depletion of natural resources.', 'Science has made education universally accessible.', 'Science has improved the quality of life for all populations.'], 'correct_option': 'Science has contributed to environmental pollution and depletion of natural resources.'},
    
    {'question_id': 39, 'question_text': 'Which of the following is a negative social consequence of scientific progress?', 'options': ['The expansion of global trade and economic equality.', 'The emergence of new ethical dilemmas and loss of traditional values.', 'The increase in medical breakthroughs and life expectancy.', 'The enhancement of transportation and communication networks.'], 'correct_option': 'The emergence of new ethical dilemmas and loss of traditional values.'},
    
    {'question_id': 40, 'question_text': 'How has science impacted transportation?', 'options': ['By making long-distance travel faster and more affordable.', 'By focusing on improving local transportation systems only.', 'By reducing the need for public transportation systems.', 'By limiting transportation innovations to specific geographic regions.'], 'correct_option': 'By making long-distance travel faster and more affordable.'},
    
    {'question_id': 41, 'question_text': 'What impact has scientific progress had on entertainment?', 'options': ['It has made entertainment more accessible to the public.', 'It has limited entertainment to only educational content.', 'It has made all forms of entertainment obsolete.', 'It has only focused on improving entertainment for the elite.'], 'correct_option': 'It has made entertainment more accessible to the public.'},
    
    {'question_id': 42, 'question_text': 'What challenge arises from the rapid pace of scientific development?', 'options': ['Ensuring that the benefits of science are equally distributed across societies.', 'Limiting the number of scientific discoveries to avoid ethical dilemmas.', 'Minimizing the negative effects of scientific progress on the environment.', 'Ensuring that scientific discoveries align with religious teachings.'], 'correct_option': 'Ensuring that the benefits of science are equally distributed across societies.'},
    
    {'question_id': 43, 'question_text': 'What is the main goal of a scientific theory?', 'options': ['To provide a set of observations without making predictions.', 'To describe and explain phenomena based on evidence and testing.', 'To make predictions without any supporting evidence.', 'To prove a particular hypothesis is true.'], 'correct_option': 'To describe and explain phenomena based on evidence and testing.'},
    
    {'question_id': 44, 'question_text': 'What is a primary characteristic of a scientific law?', 'options': ['It is a principle that has been tested and universally accepted.', 'It is a set of untested hypotheses about natural phenomena.', 'It is a theory that explains a wide range of observations.', 'It is a fact that cannot be questioned or revised.'], 'correct_option': 'It is a principle that has been tested and universally accepted.'},
    
    {'question_id': 45, 'question_text': 'What does falsifiability mean in the context of scientific theories?', 'options': ['A theory can be proven true by repeated observations.', 'A theory can be tested and potentially proven false through evidence or experimentation.', 'A theory must be based solely on subjective observations.', 'A theory is only valid if it cannot be disproven.'], 'correct_option': 'A theory can be tested and potentially proven false through evidence or experimentation.'},
    
    {'question_id': 46, 'question_text': 'What is the primary focus of the philosophy of science?', 'options': ['The development of new scientific tools and techniques.', 'The analysis and understanding of scientific methods and practices.', 'The promotion of scientific research funding.', 'The organization of scientific data into meaningful categories.'], 'correct_option': 'The analysis and understanding of scientific methods and practices.'},
    
    {'question_id': 47, 'question_text': 'What does the concept of "scientific progress" primarily refer to?', 'options': ['The accumulation of knowledge through discovery and experimentation.', 'The development of scientific theories without testing.', 'The improvement of ethical standards in research.', 'The financial gain from scientific breakthroughs.'], 'correct_option': 'The accumulation of knowledge through discovery and experimentation.'},
    
    {'question_id': 48, 'question_text': 'Which of the following is a criticism of scientific realism?', 'options': ['It assumes that all scientific theories are proven true.', 'It claims that scientific theories should never be revised.', 'It suggests that all scientific knowledge is subjective and unreliable.', 'It argues that the physical world exists independently of human perception.'], 'correct_option': 'It assumes that all scientific theories are proven true.'},
    
    {'question_id': 49, 'question_text': 'What is an example of a scientific method in practice?', 'options': ['Creating a hypothesis, conducting experiments, and analyzing the results.', 'Collecting data and accepting it without question.', 'Testing ideas through random trial and error.', 'Proposing a theory without gathering supporting evidence.'], 'correct_option': 'Creating a hypothesis, conducting experiments, and analyzing the results.'},
    
    {'question_id': 50, 'question_text': 'What is an example of an ethical issue in scientific research?', 'options': ['Ensuring that experiments are conducted in controlled environments.', 'The use of human or animal subjects in research without proper consent.', 'Releasing results based on preliminary findings.', 'Exploring new scientific techniques without rigorous testing.'], 'correct_option': 'The use of human or animal subjects in research without proper consent.'},
    
    {'question_id': 51, 'question_text': 'How does peer review contribute to the scientific process?', 'options': ['By allowing researchers to share their findings with the public before publishing.', 'By providing an opportunity for other scientists to critique and validate the research methods and conclusions.', 'By offering financial rewards for successful research.', 'By promoting only certain scientific theories over others.'], 'correct_option': 'By providing an opportunity for other scientists to critique and validate the research methods and conclusions.'},
    
    {'question_id': 52, 'question_text': 'What is the role of a control group in an experiment?', 'options': ['To receive the experimental treatment and compare outcomes with the test group.', 'To test the hypothesis under uncontrolled conditions.', 'To provide a baseline for comparison with the experimental group.', 'To randomly choose participants for the study.'], 'correct_option': 'To provide a baseline for comparison with the experimental group.'},
    
    {'question_id': 53, 'question_text': 'What does "replication" mean in the context of scientific experiments?', 'options': ['Repeating experiments in a different environment with different variables.', 'Reproducing experiments to verify results and ensure reliability.', 'Making predictions based on the initial experiment results.', 'Ignoring previous results and starting from scratch.'], 'correct_option': 'Reproducing experiments to verify results and ensure reliability.'},
    
    {'question_id': 54, 'question_text': 'Which of the following is an example of a scientific hypothesis?', 'options': ['If plants are exposed to more sunlight, they will grow taller.', 'Plants should grow taller in bright light.', 'A theory explaining the growth of plants.', 'The sun is necessary for plant growth.'], 'correct_option': 'If plants are exposed to more sunlight, they will grow taller.'},
    
    {'question_id': 55, 'question_text': 'What is the purpose of forming a null hypothesis in scientific research?', 'options': ['To predict the outcome of the experiment.', 'To provide a statement that can be tested and potentially disproven.', 'To confirm the results of the experiment.', 'To eliminate all other hypotheses from consideration.'], 'correct_option': 'To provide a statement that can be tested and potentially disproven.'},
    
    {'question_id': 56, 'question_text': 'What is the significance of the scientific method in research?', 'options': ['It ensures that research is conducted in a biased way to support predetermined outcomes.', 'It provides a structured approach to answering questions through observation, experimentation, and analysis.', 'It eliminates the need for testing hypotheses or theories.', 'It involves guessing and intuition without need for evidence.'], 'correct_option': 'It provides a structured approach to answering questions through observation, experimentation, and analysis.'}


]

chapter9 = [
    {'question_id': 1, 'question_text': 'What is the primary focus of the Milesian school of thought?', 'options': ['Cosmological inquiry', 'Ethical norms', 'Political theories', 'Epistemological foundations'], 'correct_option': 'Cosmological inquiry'},
    {'question_id': 2, 'question_text': 'Who was associated with the concept of the "ideal state" during the Socratic period?', 'options': ['Plato', 'Socrates', 'Aristotle', 'Xenophon'], 'correct_option': 'Plato'},
    {'question_id': 3, 'question_text': 'What does scepticism assert about knowledge?', 'options': ['Nothing can be known', 'Knowledge is always absolute', 'Truth is relative', 'All knowledge is empirical'], 'correct_option': 'Nothing can be known'},
    {'question_id': 4, 'question_text': 'What did the medieval period of philosophy emphasize?', 'options': ['Faith and reason as unity', 'Materialism and empiricism', 'Cosmological explanations', 'Existentialism'], 'correct_option': 'Faith and reason as unity'},
    {'question_id': 5, 'question_text': 'Who is known for developing Scholasticism to its highest point?', 'options': ['St. Augustine', 'Immanuel Kant', 'St. Thomas Aquinas', 'John Locke'], 'correct_option': 'St. Thomas Aquinas'},
    {'question_id': 6, 'question_text': 'Which of the following philosophers were prominent rationalists during the Modern period?', 'options': ['Hobbes, Rousseau, Marx', 'Locke, Berkeley, Hume', 'Descartes, Spinoza, Kant', 'Socrates, Plato, Aristotle'], 'correct_option': 'Descartes, Spinoza, Kant'},
    {'question_id': 7, 'question_text': 'Which of these thinkers is most closely associated with post-modernism?', 'options': ['Bertens', 'Rousseau', 'John Dewey', 'Karl Marx'], 'correct_option': 'Bertens'},
    {'question_id': 8, 'question_text': 'What does post-modernism primarily reject?', 'options': ['The possibility of multiple truths', 'The dominance of rationalism', 'The idea of subjective experience', 'Metaphysical and epistemological frameworks'], 'correct_option': 'Metaphysical and epistemological frameworks'},
    {'question_id': 9, 'question_text': 'What is the main goal of African philosophy?', 'options': ['To investigate African ethics', 'To articulate a unique worldview of the African', 'To follow Western philosophical traditions', 'To critique colonialism'], 'correct_option': 'To articulate a unique worldview of the African'},
    {'question_id': 10, 'question_text': 'Who is considered the founder of phenomenology?', 'options': ['Edmund Husserl', 'Franz Brentano', 'Martin Heidegger', 'Gilbert Ryle'], 'correct_option': 'Edmund Husserl'},
    {'question_id': 11, 'question_text': 'What is the principle of "epoche" in phenomenology?', 'options': ['Describing experiences as they are', 'Avoiding personal prejudices and assumptions', 'Focusing on material reality', 'Explaining the causes of phenomena'], 'correct_option': 'Avoiding personal prejudices and assumptions'},
    {'question_id': 12, 'question_text': 'What does intentionality refer to in phenomenology?', 'options': ['The meaning of consciousness', 'The relationship between objectivity and subjectivity', 'The ability to act without bias', 'The direction of consciousness towards something'], 'correct_option': 'The direction of consciousness towards something'},
    {'question_id': 13, 'question_text': 'What is the central claim of existentialism regarding human existence?', 'options': ['Human nature is predetermined', 'Essence precedes existence', 'Existence precedes essence', 'Human existence is irrelevant'], 'correct_option': 'Existence precedes essence'},
    {'question_id': 14, 'question_text': 'Which philosopher is associated with the existentialist view that "man is whatever he conceives himself to be"?', 'options': ['Jean-Paul Sartre', 'Martin Heidegger', 'Kierkegaard', 'Albert Camus'], 'correct_option': 'Jean-Paul Sartre'},
    {'question_id': 15, 'question_text': 'What is a key feature of pragmatism?', 'options': ['The truth of ideas is determined by their practical consequences', 'Ideas are absolute and unchanging', 'Philosophical truth can be found through logical analysis', 'Metaphysical debates are essential to understanding truth'], 'correct_option': 'The truth of ideas is determined by their practical consequences'},
    
    {'question_id': 16, 'question_text': 'What does logical atomism primarily focus on?', 'options': ['Classical logic of classes', 'Propositions and their logical structure', 'The nature of human perception', 'Ethical implications of logical truths'], 'correct_option': 'Propositions and their logical structure'},
    {'question_id': 17, 'question_text': 'What was Bertrand Russell’s main contribution to logical atomism?', 'options': ['Developing a new type of logic', 'Promoting metaphysical realism', 'Focusing on existential issues', 'Refining the concept of metaphysical dualism'], 'correct_option': 'Developing a new type of logic'},
    {'question_id': 18, 'question_text': 'Which movement rejected traditional metaphysical and religious propositions as meaningless?', 'options': ['Logical positivism', 'Ordinary language philosophy', 'Existentialism', 'Phenomenology'], 'correct_option': 'Logical positivism'},
    {'question_id': 19, 'question_text': 'What is the central idea of ordinary language philosophy?', 'options': ['Philosophical problems arise from misuse of language', 'Philosophy should be based on empirical data', 'Metaphysical theories can be verified through experience', 'Language games should be used to explain ethical principles'], 'correct_option': 'Philosophical problems arise from misuse of language'},
    {'question_id': 20, 'question_text': 'Who is the primary figure associated with ordinary language philosophy?', 'options': ['Ludwig Wittgenstein', 'Karl Popper', 'Edmund Husserl', 'Martin Heidegger'], 'correct_option': 'Ludwig Wittgenstein'},
    {'question_id': 21, 'question_text': 'What does the concept of “language game” in Wittgenstein’s philosophy refer to?', 'options': ['The structured rules of scientific discourse', 'The practical use of language in specific contexts', 'The formal logical analysis of language', 'The emotional aspect of language in philosophy'], 'correct_option': 'The practical use of language in specific contexts'},
    {'question_id': 22, 'question_text': 'Which philosopher emphasized the importance of practical consequences in judging the truth of ideas?', 'options': ['John Dewey', 'Jean-Paul Sartre', 'Karl Marx', 'Immanuel Kant'], 'correct_option': 'John Dewey'},
    {'question_id': 23, 'question_text': 'What is the fundamental claim of pragmatism regarding truth?', 'options': ['Truth is determined by logical consistency', 'Truth is determined by social consensus', 'Truth is judged by its practical effects', 'Truth is an abstract, unchanging entity'], 'correct_option': 'Truth is judged by its practical effects'},
    {'question_id': 24, 'question_text': 'Which of these philosophers is NOT associated with pragmatism?', 'options': ['C. S. Peirce', 'William James', 'John Dewey', 'Martin Heidegger'], 'correct_option': 'Martin Heidegger'},
    {'question_id': 25, 'question_text': 'Which existentialist philosopher is known for the concept of “bad faith” as a form of self-deception?', 'options': ['Jean-Paul Sartre', 'Albert Camus', 'Martin Heidegger', 'Gabriel Marcel'], 'correct_option': 'Jean-Paul Sartre'},
    {'question_id': 26, 'question_text': 'According to existentialism, what is the role of individual choice in defining human existence?', 'options': ['It is irrelevant, as human nature is predetermined', 'It is central, as existence precedes essence', 'It is guided by a universal moral code', 'It is determined by external social forces'], 'correct_option': 'It is central, as existence precedes essence'},
    {'question_id': 27, 'question_text': 'Which philosopher is known for the concept of the “will to power” in existentialism?', 'options': ['Friedrich Nietzsche', 'Jean-Paul Sartre', 'Martin Heidegger', 'Gabriel Marcel'], 'correct_option': 'Friedrich Nietzsche'},
    {'question_id': 28, 'question_text': 'What is the main concern of African philosophy?', 'options': ['To explore the ethical implications of African culture', 'To critique Western philosophical traditions', 'To define the essence of African existence', 'To apply phenomenology to African experiences'], 'correct_option': 'To define the essence of African existence'},
    {'question_id': 29, 'question_text': 'Who are the key figures in African philosophy that influenced the modern movement?', 'options': ['Franz Fanon and Kwame Nkrumah', 'John Dewey and William James', 'Karl Marx and Friedrich Engels', 'Edmund Husserl and Maurice Merleau-Ponty'], 'correct_option': 'Franz Fanon and Kwame Nkrumah'},
    {'question_id': 30, 'question_text': 'Which of these is a central issue in phenomenology?', 'options': ['Conscious experience and its direct investigation', 'The logic of language games', 'The verification of empirical propositions', 'The essence of metaphysical truths'], 'correct_option': 'Conscious experience and its direct investigation'},
    {'question_id': 31, 'question_text': 'In phenomenology, what does the term “intentionality” refer to?', 'options': ['The ability of consciousness to focus on specific objects', 'The subjective nature of philosophical inquiry', 'The search for objective truths in the world', 'The relationship between language and meaning'], 'correct_option': 'The ability of consciousness to focus on specific objects'},
    {'question_id': 32, 'question_text': 'Which of the following is a key concept in Edmund Husserl’s phenomenology?', 'options': ['Epoche', 'Logical atomism', 'Metaphysical realism', 'Social contract'], 'correct_option': 'Epoche'},
    {'question_id': 33, 'question_text': 'Who is considered the founder of the philosophy of logical positivism?', 'options': ['Rudolf Carnap', 'Bertrand Russell', 'Ludwig Wittgenstein', 'John Dewey'], 'correct_option': 'Rudolf Carnap'},
    {'question_id': 34, 'question_text': 'What is the central principle of logical positivism regarding meaningful statements?', 'options': ['A statement is meaningful only if it can be empirically verified', 'A statement must be logically consistent', 'A statement must be metaphysically significant', 'A statement must be morally relevant'], 'correct_option': 'A statement is meaningful only if it can be empirically verified'},
    {'question_id': 35, 'question_text': 'Which philosopher is associated with the "Vienna Circle" and logical positivism?', 'options': ['Moritz Schlick', 'Immanuel Kant', 'Jean-Paul Sartre', 'Friedrich Nietzsche'], 'correct_option': 'Moritz Schlick'},
    {'question_id': 36, 'question_text': 'What does the concept of “subjectivity” in phenomenology mean?', 'options': ['The perspective that the mind shapes reality', 'The pursuit of objective truths in science', 'The belief in universal ethical principles', 'The role of external factors in consciousness'], 'correct_option': 'The perspective that the mind shapes reality'},
    {'question_id': 37, 'question_text': 'In existentialism, what is the significance of human freedom?', 'options': ['It is an illusion that limits human potential', 'It is the foundation of all ethical decisions', 'It means humans are bound by fate', 'It is irrelevant to human existence'], 'correct_option': 'It is the foundation of all ethical decisions'},
    {'question_id': 38, 'question_text': 'What did existentialists believe about the nature of human essence?', 'options': ['Humans are born with a fixed essence', 'Human essence is defined through actions', 'Human essence is the same for everyone', 'Humans have no essence'], 'correct_option': 'Human essence is defined through actions'},
    {'question_id': 39, 'question_text': 'Who argued that philosophy should focus on the practical application of ideas in life?', 'options': ['William James', 'Sartre', 'Husserl', 'Descartes'], 'correct_option': 'William James'},
    {'question_id': 40, 'question_text': 'What was the focus of existentialist thinkers like Albert Camus?', 'options': ['The absurdity of existence and human freedom', 'The logical structure of propositions', 'The ethical norms in society', 'The scientific verification of metaphysical claims'], 'correct_option': 'The absurdity of existence and human freedom'},
    {'question_id': 41, 'question_text': 'What is a key feature of post-modernist thought?', 'options': ['The rejection of universal truths', 'The belief in objective, universal knowledge', 'The emphasis on scientific rationality', 'The focus on religious faith'], 'correct_option': 'The rejection of universal truths'},
    {'question_id': 42, 'question_text': 'Which concept is central to logical atomism?', 'options': ['Propositions as the basic units of logic', 'The verification of empirical statements', 'The critique of metaphysical theories', 'The structure of everyday language'], 'correct_option': 'Propositions as the basic units of logic'},
    {'question_id': 43, 'question_text': 'Which philosopher is closely associated with the concept of “language games”?', 'options': ['Ludwig Wittgenstein', 'Jean-Paul Sartre', 'Karl Marx', 'John Dewey'], 'correct_option': 'Ludwig Wittgenstein'},
    {'question_id': 44, 'question_text': 'In phenomenology, what is meant by “epoche”?', 'options': ['A method of questioning assumptions', 'A focus on subjective experience', 'The ethical reflection on actions', 'The empirical testing of ideas'], 'correct_option': 'A method of questioning assumptions'},
    {'question_id': 45, 'question_text': 'Which of the following is a main feature of pragmatism?', 'options': ['Ideas must be tested by their practical implications', 'Knowledge is determined by sensory perception alone', 'Ethics are irrelevant to philosophical inquiry', 'Truth is defined by religious doctrines'], 'correct_option': 'Ideas must be tested by their practical implications'},
    {'question_id': 46, 'question_text': 'Who is associated with the development of the “will to power” concept?', 'options': ['Friedrich Nietzsche', 'Jean-Paul Sartre', 'Immanuel Kant', 'Karl Marx'], 'correct_option': 'Friedrich Nietzsche'},
    {'question_id': 47, 'question_text': 'What does existentialism assert about the nature of human existence?', 'options': ['It is determined by predetermined essence', 'It is a random event with no inherent meaning', 'It is shaped by human choices and freedom', 'It is strictly defined by social structures'], 'correct_option': 'It is shaped by human choices and freedom'},
    {'question_id': 48, 'question_text': 'What was central to the thought of Jean-Paul Sartre?', 'options': ['The importance of social contracts', 'The concept of bad faith', 'The idea of universal ethical norms', 'The search for metaphysical truth'], 'correct_option': 'The concept of bad faith'},
    {'question_id': 49, 'question_text': 'Which philosopher is credited with popularizing the phrase "existence precedes essence"?', 'options': ['Jean-Paul Sartre', 'Martin Heidegger', 'Simone de Beauvoir', 'Gabriel Marcel'], 'correct_option': 'Jean-Paul Sartre'},
    {'question_id': 50, 'question_text': 'What does post-modernism critique in traditional philosophy?', 'options': ['The idea of universal truths', 'The use of empirical methods', 'The reliance on rationality', 'The belief in subjective experience'], 'correct_option': 'The idea of universal truths'},
    
    {'question_id': 51, 'question_text': 'What does New Humanism primarily emphasize about human beings?', 'options': ['The dignity and value of man', 'The importance of rationality', 'The need for religious adherence', 'The pursuit of material wealth'], 'correct_option': 'The dignity and value of man'},
    {'question_id': 52, 'question_text': 'How did New Humanism differ from medieval asceticism?', 'options': ['It embraces human needs and dignity', 'It advocates complete denial of the body', 'It focuses solely on spiritual matters', 'It is primarily concerned with materialism'], 'correct_option': 'It embraces human needs and dignity'},
    {'question_id': 53, 'question_text': 'What is the relationship between New Humanism and theism?', 'options': ['New Humanism was initially non-theistic but became anti-theistic', 'New Humanism is strictly theistic', 'New Humanism rejects all forms of belief', 'New Humanism accepts all religious viewpoints equally'], 'correct_option': 'New Humanism was initially non-theistic but became anti-theistic'},
    {'question_id': 54, 'question_text': 'What does John H. Randall assert about humanism?', 'options': ['It places faith in human possibilities', 'It denies human potential', 'It is a strictly religious philosophy', 'It rejects all forms of belief in human dignity'], 'correct_option': 'It places faith in human possibilities'},
    {'question_id': 55, 'question_text': 'In the context of New Humanism, what is the significance of the brotherhood of man?', 'options': ['It is understood in relation to the Fatherhood of God', 'It emphasizes a materialistic worldview', 'It rejects religious connections', 'It focuses only on individualism'], 'correct_option': 'It is understood in relation to the Fatherhood of God'},
    {'question_id': 56, 'question_text': 'What is the main argument of structuralism in human cultures?', 'options': ['Phenomena must be understood through interrelations', 'Everything must be understood in isolation', 'Human actions are random and without patterns', 'Cultural systems cannot be studied at all'], 'correct_option': 'Phenomena must be understood through interrelations'},
    {'question_id': 57, 'question_text': 'Who is credited with developing the foundational ideas of structuralism?', 'options': ['Ferdinand de Saussure', 'Karl Marx', 'Jean-Paul Sartre', 'Simone de Beauvoir'], 'correct_option': 'Ferdinand de Saussure'},
    {'question_id': 58, 'question_text': 'What is the concept of binary opposition in structuralism?', 'options': ['Opposites are interrelated and hierarchical', 'Opposites are completely independent', 'Binary opposites do not exist in culture', 'All concepts are unrelated and chaotic'], 'correct_option': 'Opposites are interrelated and hierarchical'},
    {'question_id': 59, 'question_text': 'Who was one of the first scholars to apply Saussure’s ideas to anthropology?', 'options': ['Claude Lévi-Strauss', 'Jean Baudrillard', 'Louis Althusser', 'Jacques Derrida'], 'correct_option': 'Claude Lévi-Strauss'},
    {'question_id': 60, 'question_text': 'Which field saw a widespread adoption of structuralism after Saussure?', 'options': ['Humanities', 'Physics', 'Chemistry', 'Engineering'], 'correct_option': 'Humanities'},
    {'question_id': 61, 'question_text': 'Which intellectual movement critiqued structuralism in the 1960s?', 'options': ['Post-structuralism', 'Pragmatism', 'Humanism', 'Phenomenology'], 'correct_option': 'Post-structuralism'},
    {'question_id': 62, 'question_text': 'Which philosopher is commonly associated with the critique of structuralism and post-structuralism?', 'options': ['Michel Foucault', 'Immanuel Kant', 'David Hume', 'Aristotle'], 'correct_option': 'Michel Foucault'},
    {'question_id': 63, 'question_text': 'What is a key feature of post-structuralism?', 'options': ['Rejection of fixed meanings and structures', 'Advocacy for rigid structures', 'Focus on absolute truths', 'Rejection of all academic analysis'], 'correct_option': 'Rejection of fixed meanings and structures'},
    {'question_id': 64, 'question_text': 'What does post-structuralism argue about interpreting media and the world?', 'options': ['Interpretation must go beyond socially constructed structures', 'Interpretation is always determined by fixed frameworks', 'The world cannot be interpreted at all', 'Only scientific analysis is valid for understanding the world'], 'correct_option': 'Interpretation must go beyond socially constructed structures'},
    {'question_id': 65, 'question_text': 'What critique does post-structuralism offer regarding binary oppositions?', 'options': ['They should not be interpreted as rigid hierarchies', 'They should be strictly maintained', 'They are irrelevant to understanding culture', 'They should be eliminated entirely'], 'correct_option': 'They should not be interpreted as rigid hierarchies'},
    {'question_id': 66, 'question_text': 'Which philosopher’s work is central to the development of deconstruction?', 'options': ['Jacques Derrida', 'Michel Foucault', 'Jean-Paul Sartre', 'Simone de Beauvoir'], 'correct_option': 'Jacques Derrida'},
    {'question_id': 67, 'question_text': 'What does Derrida’s concept of deconstruction challenge?', 'options': ['The quest for totality and absolute truth', 'The rejection of human experience', 'The value of language in philosophy', 'The study of metaphysics'], 'correct_option': 'The quest for totality and absolute truth'},
    {'question_id': 68, 'question_text': 'How does Derrida view language in his deconstructionist approach?', 'options': ['It is fluid and unstable', 'It is purely logical and fixed', 'It is irrelevant to meaning', 'It is separate from culture'], 'correct_option': 'It is fluid and unstable'},
    {'question_id': 69, 'question_text': 'What does Derrida argue about the meaning of words?', 'options': ['It is dependent on contrast with other words', 'It is fixed and unchanging', 'It is absolute and universal', 'It is derived from personal experience alone'], 'correct_option': 'It is dependent on contrast with other words'},
    {'question_id': 70, 'question_text': 'According to Derrida, how does language function in the context of metaphysical oppositions?', 'options': ['It creates a violent hierarchy', 'It is neutral and balanced', 'It eliminates oppositions', 'It does not influence philosophical thinking'], 'correct_option': 'It creates a violent hierarchy'},
    {'question_id': 71, 'question_text': 'What is the main objective of deconstruction according to Derrida?', 'options': ['To expose the contradictions and hierarchies within texts', 'To eliminate all binary oppositions', 'To affirm the importance of presence over absence', 'To develop a universal theory of meaning'], 'correct_option': 'To expose the contradictions and hierarchies within texts'},
    {'question_id': 72, 'question_text': 'In deconstruction, what does Derrida mean by an "aporia"?', 'options': ['A point where the meaning becomes irreducibly complex', 'A clear and simple answer', 'A form of logical contradiction', 'A type of philosophical unity'], 'correct_option': 'A point where the meaning becomes irreducibly complex'},
    {'question_id': 73, 'question_text': 'Which philosopher critiqued the idea of "true forms" and essences in language?', 'options': ['Jacques Derrida', 'Michel Foucault', 'Immanuel Kant', 'Gilles Deleuze'], 'correct_option': 'Jacques Derrida'},
    {'question_id': 74, 'question_text': 'Which term does Derrida use to describe the dominance of one side of a binary opposition over the other?', 'options': ['Logocentrism', 'Phenomenology', 'Existentialism', 'Pragmatism'], 'correct_option': 'Logocentrism'},
    {'question_id': 75, 'question_text': 'How does deconstruction challenge Western philosophy?', 'options': ['It undermines the concept of totality and absolute truth', 'It supports traditional metaphysical ideas', 'It upholds the importance of unity', 'It reinforces the value of hierarchy in thinking'], 'correct_option': 'It undermines the concept of totality and absolute truth'},
    {'question_id': 76, 'question_text': 'What is the primary focus of post-structuralism?', 'options': ['The rejection of fixed, rigid structures of thought', 'The establishment of universal laws', 'The importance of rationalism and scientific logic', 'The reliance on binary oppositions'], 'correct_option': 'The rejection of fixed, rigid structures of thought'},
    {'question_id': 77, 'question_text': 'How does Derrida’s approach differ from traditional philosophical analysis?', 'options': ['It focuses on the fluidity and instability of language', 'It prioritizes rigid and stable meanings', 'It supports classical logic over all else', 'It seeks to eliminate interpretation'], 'correct_option': 'It focuses on the fluidity and instability of language'},
    {'question_id': 78, 'question_text': 'What does Derrida claim about the "metaphysics of presence"?', 'options': ['It is a false assumption in Western philosophy', 'It is an essential truth of language', 'It represents the foundation of all knowledge', 'It is irrelevant to philosophy'], 'correct_option': 'It is a false assumption in Western philosophy'},
    {'question_id': 79, 'question_text': 'What does deconstruction highlight about texts?', 'options': ['Texts contain multiple, contradictory interpretations', 'Texts have a singular, unified meaning', 'Texts are irrelevant to philosophical study', 'Texts should be disregarded for better understanding'], 'correct_option': 'Texts contain multiple, contradictory interpretations'},
    {'question_id': 80, 'question_text': 'What kind of approach does post-structuralism advocate towards cultural phenomena?', 'options': ['It suggests they should be analyzed beyond socially constructed frameworks', 'It suggests they should be rigidly interpreted within set structures', 'It dismisses cultural phenomena as meaningless', 'It emphasizes the importance of the material aspects only'], 'correct_option': 'It suggests they should be analyzed beyond socially constructed frameworks'},
    {'question_id': 81, 'question_text': 'How does structuralism relate to binary opposition?', 'options': ['It views oppositions as interdependent and hierarchical', 'It sees oppositions as irrelevant to meaning-making', 'It rejects all forms of opposition in language', 'It views oppositions as separate but equal'], 'correct_option': 'It views oppositions as interdependent and hierarchical'},
    {'question_id': 82, 'question_text': 'How did post-structuralism evolve from structuralism?', 'options': ['It critiques the fixed structures proposed by structuralism', 'It fully supports the ideas of structuralism', 'It rejects all forms of binary opposition', 'It focuses solely on the language of philosophy'], 'correct_option': 'It critiques the fixed structures proposed by structuralism'},
    {'question_id': 83, 'question_text': 'What does Derrida suggest about the relationship between words in language?', 'options': ['Words gain meaning through their contrast with other words', 'Words have fixed meanings independent of context', 'Words are simply random signs without meaning', 'Words have meaning only in isolation'], 'correct_option': 'Words gain meaning through their contrast with other words'},
    {'question_id': 84, 'question_text': 'How does Derrida’s deconstruction challenge the traditional philosophical notion of identity?', 'options': ['It reveals that identity is unstable and constructed', 'It affirms the fixed nature of identity', 'It supports a rigid, essentialist notion of identity', 'It rejects the concept of identity entirely'], 'correct_option': 'It reveals that identity is unstable and constructed'},
    {'question_id': 85, 'question_text': 'What does Derrida’s theory of deconstruction imply for understanding truth?', 'options': ['Truth is not absolute and is subject to interpretation', 'Truth is fixed and unchanging', 'Truth is derived from universal laws', 'Truth is irrelevant to philosophical inquiry'], 'correct_option': 'Truth is not absolute and is subject to interpretation'},
    {'question_id': 86, 'question_text': 'How does Derrida view the concept of metaphysics?', 'options': ['It is a misguided search for absolute truth', 'It is the foundation of all philosophical knowledge', 'It is irrelevant in contemporary philosophy', 'It is purely theoretical and has no real-world implications'], 'correct_option': 'It is a misguided search for absolute truth'},
    {'question_id': 87, 'question_text': 'What do structuralists believe about the relationship between culture and structure?', 'options': ['Culture can only be understood by its relation to underlying structures', 'Culture is independent of any structures', 'Culture exists solely through individual experience', 'Culture can be understood without reference to structures'], 'correct_option': 'Culture can only be understood by its relation to underlying structures'},
    {'question_id': 88, 'question_text': 'What is the primary objective of post-structuralism in terms of interpretation?', 'options': ['To challenge the idea of fixed meanings and objective interpretations', 'To establish fixed meanings for all phenomena', 'To create a new form of cultural hierarchy', 'To reject the study of social constructs'], 'correct_option': 'To challenge the idea of fixed meanings and objective interpretations'},
    {'question_id': 89, 'question_text': 'What does deconstruction seek to reveal about philosophical texts?', 'options': ['The inherent contradictions and multiple meanings within them', 'The single, true interpretation of the text', 'The importance of adhering to traditional interpretations', 'The irrelevance of texts to philosophical study'], 'correct_option': 'The inherent contradictions and multiple meanings within them'},
    {'question_id': 90, 'question_text': 'What does Derrida mean by the term "logocentrism"?', 'options': ['The privileging of speech over writing', 'The rejection of language in philosophy', 'The equality of all forms of communication', 'The importance of non-verbal communication'], 'correct_option': 'The privileging of speech over writing'},
    {'question_id': 91, 'question_text': 'What does Derrida argue about the relationship between meaning and language?', 'options': ['Meaning is always deferred and never fully present', 'Meaning is fixed and unchanging in language', 'Meaning is determined solely by the speaker', 'Meaning is irrelevant to the analysis of language'], 'correct_option': 'Meaning is always deferred and never fully present'},
    {'question_id': 92, 'question_text': 'What is the significance of binary oppositions in structuralism?', 'options': ['They are fundamental to understanding human culture and language', 'They have no relevance to human culture', 'They represent arbitrary cultural constructs', 'They are irrelevant to understanding meaning'], 'correct_option': 'They are fundamental to understanding human culture and language'},
    {'question_id': 93, 'question_text': 'What is the goal of deconstruction with respect to Western philosophy?', 'options': ['To identify and dismantle false dichotomies and hierarchies', 'To affirm all traditional philosophical categories', 'To reinforce established philosophical truths', 'To promote a fixed interpretation of texts'], 'correct_option': 'To identify and dismantle false dichotomies and hierarchies'},
    {'question_id': 94, 'question_text': 'How does post-structuralism view the concept of knowledge?', 'options': ['It sees knowledge as fluid and socially constructed', 'It views knowledge as an absolute, universal truth', 'It dismisses knowledge as subjective and unreliable', 'It affirms the value of scientific knowledge alone'], 'correct_option': 'It sees knowledge as fluid and socially constructed'},
    {'question_id': 95, 'question_text': 'What is one of the key features of structuralism in analyzing cultural systems?', 'options': ['The focus on understanding cultural phenomena through relational structures', 'The isolation of cultural phenomena from their contexts', 'The rejection of cultural phenomena as meaningful', 'The privileging of individual experiences over cultural structures'], 'correct_option': 'The focus on understanding cultural phenomena through relational structures'},
    {'question_id': 96, 'question_text': 'Which philosopher is associated with the idea of binary oppositions and structuralism?', 'options': ['Claude Lévi-Strauss', 'Jean-Paul Sartre', 'Gilles Deleuze', 'Michel Foucault'], 'correct_option': 'Claude Lévi-Strauss'},
    {'question_id': 97, 'question_text': 'How does post-structuralism relate to traditional concepts of language and meaning?', 'options': ['It challenges fixed meanings and proposes that meaning is always deferred', 'It affirms the existence of fixed meanings', 'It supports the idea of a universally accepted truth', 'It rejects language as a form of meaning'], 'correct_option': 'It challenges fixed meanings and proposes that meaning is always deferred'},
    {'question_id': 98, 'question_text': 'What does Derrida’s concept of "différance" refer to in deconstruction?', 'options': ['The idea that meaning is always deferred and never fully present', 'The fixed meaning of words in texts', 'The importance of speech over writing', 'The unchanging essence of language'], 'correct_option': 'The idea that meaning is always deferred and never fully present'},
    {'question_id': 99, 'question_text': 'In deconstruction, what is the role of the "other"?', 'options': ['It plays a crucial role in the formation of meaning through contrast', 'It is irrelevant to understanding texts', 'It is the primary source of all meaning', 'It should be excluded from philosophical analysis'], 'correct_option': 'It plays a crucial role in the formation of meaning through contrast'},
    {'question_id': 100, 'question_text': 'What does post-structuralism reject about the study of culture?', 'options': ['The belief in stable, universal structures governing culture', 'The rejection of culture as a meaningful concept', 'The study of language as irrelevant to cultural analysis', 'The dismissal of historical contexts'], 'correct_option': 'The belief in stable, universal structures governing culture'}

]

