from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from datetime import timedelta, datetime
from django.db.models import Q, Count
from pracs.models import *
from pracs.assignment import uniuyo1, uniuyo2
from pracs import pins
import random
import math
import time, ast
from pracs import views
from django.http import JsonResponse
from django.core.mail import EmailMessage
from . import book1, book2, book11
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
from xhtml2pdf import pisa
# from pracs.utils import generate_pdf
from django.db import IntegrityError


@login_required(login_url='login')
def cbtb1(request):
    users = Pinbin2.objects.all()
    number = 50
    time = 45
    chapter = int(request.GET.get('chapter'))
    book = request.GET.get('book')
    if book == 'cbtb1':
        chaps = [book1.chapter1,book1.chapter2,book1.chapter3,book1.chapter4,book1.chapter5,
                    book1.chapter6,book1.chapter7,book1.chapter8,book1.chapter9]
        if chapter != 0:
            topic = uniuyo1.chapters[chapter-1]
            topic = topic['title']
            quiz = chaps[chapter-1]
        else:
            topic = 'ALL TOPICS'
            quiz = book1.chapter1+book1.chapter2+book1.chapter3+book1.chapter4+book1.chapter5+book1.chapter6+book1.chapter7+book1.chapter8+book1.chapter9
        context = {'chapter': chapter, 'book': book, 'quiz': quiz, 'number':number, 'time':time, 'topic': topic}
    elif book == 'cbtb2':
        chaps = [book2.chapter1,book2.chapter2,book2.chapter3,book2.chapter4,book2.chapter5,
                    book2.chapter6,book2.chapter7,book2.chapter8,book2.chapter9]
        if chapter != 0:
            topic = uniuyo2.chapters[chapter-1]
            topic = topic['title']
            quiz = chaps[chapter-1]
        else:
            topic = 'ALL TOPICS'
            quiz = book2.chapter1+book2.chapter2+book2.chapter3+book2.chapter4+book2.chapter5+book2.chapter6+book2.chapter7+book2.chapter8+book2.chapter9
        context = {'chapter': chapter, 'book': book, 'quiz': quiz, 'number':number, 'time':time, 'topic': topic}
    elif book == 'cbtb3':
        topic = 'ALL TOPICS'
        quiz = book11.quiz
        context = {'chapter': chapter, 'book': book, 'quiz': quiz, 'number':number, 'time':time, 'topic': topic}
    else:
        context = {}
    return render(request, 'cbt/gstcbt.html', context)

@login_required(login_url='login')
def cbtb2(request):
    qui = str(request.POST.get("quiz"))
    book = str(request.POST.get("book"))
    quiz = eval(qui)
    user_id = request.POST.get('id')
    user = User.objects.get(id=user_id)
    score = request.POST.get('score')
    if book == 'cbtb3':
        lookup = {item['question_id']: item for item in book11.quiz}
        q = [lookup[qid] for qid in quiz if qid in lookup]
        context = {'quiz': q, 'chapter': '','text': '', 'score': score,
                'first_name': user.firstname, 'last_name': user.lastname,'book': quiz}
    else:
        context = {'quiz': quiz, 'chapter': '','text': '', 'score': score,
                'first_name': user.firstname, 'last_name': user.lastname,'book': book}
    return render(request, 'gst/gst_result.html', context)

    # Generate PDF
    # response = HttpResponse(content_type='application/pdf')
    # response['Content-Disposition'] = f'attachment; filename="{user.firstname}_gst_gstquiz_results.pdf"'
    # Create PDF from HTML string
    # pisa_status = pisa.CreatePDF(html_string, dest=response)
    # Check for errors
    # if pisa_status.err:
    #     return messages.error(request, 'Error generating PDF')
    # return response

@login_required(login_url='login')
def db1(request):
    return render(request, 'cbt/gstcbt.html')

@login_required(login_url='login')
def db2(request):
    return render(request, 'cbt/gstcbt.html')



def check_pin(request):
    pp = pins.pins
    if request.method == 'POST':
        pin = int(request.POST.get('pin'))  # Get the pin from the form
        user = request.user  # Get the currently logged-in user
        # Step 1: Check if the pin is in the predefined list
        if pin not in pp:
            return JsonResponse({"success": False, "message": "Invalid PIN"})
        # Step 2: Check if the pin already exists in the Pinbin table
        try:
            existing_entry = Pinbin2.objects.get(name=user)
            if existing_entry.pin == pin:
                return JsonResponse({"success": True, "message": "Quiz time"})
            else:
                return JsonResponse({"success": False, "message": "Invalid PIN"})
        
        except Pinbin2.DoesNotExist:
            # Step 3: Save the user and pin if no entry exists
            try:
                Pinbin2.objects.create(name=user, pin=pin)
                return JsonResponse({"success": True, "message": "Quiz time"})
            except IntegrityError:
                return JsonResponse({"success": False, "message": "Invalid PIN"})

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

def view_qa(request):
    book = int(request.GET.get('book'))
    if book == 1:
        chaps = [book1.chapter1,book1.chapter2,book1.chapter3,book1.chapter4,book1.chapter5,
                    book1.chapter6,book1.chapter7,book1.chapter8,book1.chapter9]
        context = {'data': chaps}
    elif book == 2:
        chaps = [book2.chapter1,book2.chapter2,book2.chapter3,book2.chapter4,book2.chapter5,
                    book2.chapter6,book2.chapter7,book2.chapter8,book2.chapter9]
        context = {'data': chaps}
    else:
        chaps = [book11.chh1,book11.chh2,book11.chh3,book11.chh4,book11.chh5,
                    book11.chh6,book11.chh7,book11.chh8,book11.chh9,book11.chh10,book11.chh11]
        context = {'data': chaps}
    return render(request, 'gst/gst_result2.html', context)
