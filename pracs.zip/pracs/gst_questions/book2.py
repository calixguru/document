

chapter1 = [
    {'question_id': 1, 'question_text': 'What is the etymological meaning of philosophy?', 
     'options': ['Love of knowledge', 'Love of wisdom', 'Search for truth', 'Study of existence'], 
     'correct_option': 'Love of wisdom'},
    
    {'question_id': 2, 'question_text': 'Which philosopher described philosophy as the rational study of moral life?', 
     'options': ['Plato', 'Socrates', 'Heidegger', 'Ayer'], 
     'correct_option': 'Socrates'},
    
    {'question_id': 3, 'question_text': 'According to logical positivists, philosophy focuses on:', 
     'options': ['Moral life', 'Ultimate reality', 'Clarification of language', 'Cultural criticism'], 
     'correct_option': 'Clarification of language'},
    
    {'question_id': 4, 'question_text': 'Philosophy, according to Omoregbe, involves:', 
     'options': ['Scientific experiments', 'Rational search for answers', 'Empirical research', 'Mystical insights'], 
     'correct_option': 'Rational search for answers'},
    
    {'question_id': 5, 'question_text': 'Why is it difficult to define philosophy universally?', 
     'options': ['Lack of interest', 'Different perspectives of thinkers', 'Lack of scientific basis', 'Absence of clear concepts'], 
     'correct_option': 'Different perspectives of thinkers'},
    
    {'question_id': 6, 'question_text': 'Which philosopher believed that philosophy should address “intellectual tensions and maladjustments”?', 
     'options': ['Socrates', 'Randall', 'Plato', 'Feyerabend'], 
     'correct_option': 'Randall'},
    
    {'question_id': 7, 'question_text': 'What distinguishes philosophy from other disciplines according to the chapter?', 
     'options': ['Scientific methods', 'Logical reasoning', 'Supernatural explanations', 'Historical analysis'], 
     'correct_option': 'Logical reasoning'},
    
    {'question_id': 8, 'question_text': 'Post-modernists view philosophy as:', 
     'options': ['A singular truth', 'A multi-voiced discipline', 'Purely metaphysical', 'Only empirical'], 
     'correct_option': 'A multi-voiced discipline'},
    
    {'question_id': 9, 'question_text': 'Which of the following is NOT listed as a characteristic of philosophy?', 
     'options': ['Analytical', 'Non-Absolute', 'Systematic', 'Dogmatic'], 
     'correct_option': 'Dogmatic'},
    
    {'question_id': 10, 'question_text': 'Which of these thinkers argued that philosophy should begin with Jesus Christ?', 
     'options': ['Igwe', 'Will Durant', 'Ozumba', 'Feyerabend'], 
     'correct_option': 'Will Durant'},
    
    {'question_id': 11, 'question_text': 'Which thinker claimed that philosophy involves a "systematic investigation of ultimate reality"?', 
     'options': ['Ozumba', 'Plato', 'Randall', 'Feyerabend'], 
     'correct_option': 'Ozumba'},
    
    {'question_id': 12, 'question_text': 'Titus and Smith view different definitions of philosophy as:', 
     'options': ['Contradictory', 'Supplementary', 'Irrelevant', 'Conflicting'], 
     'correct_option': 'Supplementary'},
    
    {'question_id': 13, 'question_text': 'Philosophy is seen as “anything goes” by which thinker?', 
     'options': ['Feyerabend', 'Ayer', 'Heidegger', 'Omoregbe'], 
     'correct_option': 'Feyerabend'},
    
    {'question_id': 14, 'question_text': 'According to the chapter, knowledge without wisdom is:', 
     'options': ['Valuable', 'Useless', 'Essential', 'Relational'], 
     'correct_option': 'Useless'},
    
    {'question_id': 15, 'question_text': 'Which characteristic of philosophy emphasizes its non-dogmatic nature?', 
     'options': ['Daring', 'Non-Absolute', 'Argumentative', 'Empirical'], 
     'correct_option': 'Non-Absolute'},
    
    {'question_id': 16, 'question_text': 'The definition of philosophy by Randall suggests it is concerned with:', 
     'options': ['Metaphysical questions', 'Cultural criticism', 'Scientific methods', 'Moral judgments'], 
     'correct_option': 'Cultural criticism'},
    
    {'question_id': 17, 'question_text': 'Will Durant highlights philosophy’s role in:', 
     'options': ['Exploring metaphysics', 'Coordinating ends', 'Scientific discovery', 'Language analysis'], 
     'correct_option': 'Coordinating ends'},
    
    {'question_id': 18, 'question_text': 'According to the chapter, philosophy’s nature is described as:', 
     'options': ['Rigid', 'Dynamic', 'Unchanging', 'Uniform'], 
     'correct_option': 'Dynamic'},
    
    {'question_id': 19, 'question_text': 'Which of these characteristics is NOT associated with philosophy in the chapter?', 
     'options': ['Daring', 'Futuristic', 'Empirical', 'Superstitious'], 
     'correct_option': 'Superstitious'},
    
    {'question_id': 20, 'question_text': 'Philosophy as a critical thinking about thinking itself is described as:', 
     'options': ['Metaphysics', 'Analysis', 'Wisdom', 'Systematic articulation'], 
     'correct_option': 'Systematic articulation'},
    
    {'question_id': 21, 'question_text': 'Why do post-modernists view philosophy as interdisciplinary?', 
     'options': ['It focuses on metaphysics', 'It incorporates multiple perspectives', 'It rejects empirical data', 'It emphasizes logic alone'], 
     'correct_option': 'It incorporates multiple perspectives'},
    
    {'question_id': 22, 'question_text': 'Who argued that “philosophy gives us wisdom in a systematized way”?', 
     'options': ['Will Durant', 'Igwe', 'Plato', 'Ayer'], 
     'correct_option': 'Igwe'},
    
    {'question_id': 23, 'question_text': 'The chapter claims that philosophy primarily addresses:', 
     'options': ['Supernatural phenomena', 'Human existence', 'Historical events', 'Technological advancements'], 
     'correct_option': 'Human existence'},
    
    {'question_id': 24, 'question_text': 'Which thinker linked philosophy to moral life and self-examination?', 
     'options': ['Heidegger', 'Plato', 'Socrates', 'Omoregbe'], 
     'correct_option': 'Socrates'},
    
    {'question_id': 25, 'question_text': 'The provisional definition of philosophy in the chapter emphasizes its:', 
     'options': ['Empirical nature', 'Religious focus', 'Critical thinking', 'Artistic creativity'], 
     'correct_option': 'Critical thinking'},
    
    {'question_id': 26, 'question_text': 'What does the chapter suggest about disciplines without philosophy?', 
     'options': ['They are superior', 'They provide wisdom', 'They lack depth', 'They focus on ethics'], 
     'correct_option': 'They lack depth'},
    
    {'question_id': 27, 'question_text': 'The term “philosophia” is derived from which language?', 
     'options': ['Latin', 'Greek', 'Hebrew', 'Sanskrit'], 
     'correct_option': 'Greek'},
    
    {'question_id': 28, 'question_text': 'Which characteristic of philosophy involves questioning established norms?', 
     'options': ['Futuristic', 'Protestive', 'Individualistic', 'Empirical'], 
     'correct_option': 'Protestive'},
    
    {'question_id': 29, 'question_text': 'The nature of philosophy as “critical” means it is focused on:', 
     'options': ['Creativity', 'Systematic critique', 'Emotional reflection', 'Religious beliefs'], 
     'correct_option': 'Systematic critique'},
    
    {'question_id': 30, 'question_text': 'According to the chapter, philosophy seeks answers to questions about:', 
     'options': ['Supernatural forces', 'Practical technology', 'Ultimate meaning', 'Artistic methods'], 
     'correct_option': 'Ultimate meaning'},
    
    {'question_id': 31, 'question_text': 'The thinker who emphasized the “science of being” in philosophy is:', 
     'options': ['Ayer', 'Heidegger', 'Feyerabend', 'Randall'], 
     'correct_option': 'Heidegger'},
    
    {'question_id': 32, 'question_text': 'Which feature of philosophy ensures it is open to ongoing inquiry and revision?', 
     'options': ['Systematic', 'Non-Absolute', 'Empirical', 'Daring'], 
     'correct_option': 'Non-Absolute'},
    
    {'question_id': 33, 'question_text': 'According to the chapter, philosophy is distinct because it aims to provide:', 
     'options': ['Pure data', 'Wisdom', 'Religious beliefs', 'Political theory'], 
     'correct_option': 'Wisdom'},
    
    {'question_id': 34, 'question_text': 'Which term best describes philosophy’s ability to address various disciplines and viewpoints?', 
     'options': ['Empirical', 'Relativistic', 'Systematic', 'Narrow'], 
     'correct_option': 'Relativistic'},
    
    {'question_id': 35, 'question_text': 'The chapter suggests that philosophy aims to resolve which type of problems?', 
     'options': ['Scientific', 'Global', 'Historical', 'Technological'], 
     'correct_option': 'Global'},
    
    {'question_id': 36, 'question_text': 'What aspect of philosophy makes it focused on logical reasoning over supernatural beliefs?', 
     'options': ['Empirical', 'Rational', 'Radical', 'Protestive'], 
     'correct_option': 'Rational'},
    
    {'question_id': 37, 'question_text': 'Which characteristic of philosophy is associated with future-oriented thinking?', 
     'options': ['Analytical', 'Futuristic', 'Critical', 'Objective'], 
     'correct_option': 'Futuristic'},
    
    {'question_id': 38, 'question_text': 'Philosophy’s analytical nature involves:', 
     'options': ['Emotional reflection', 'Breaking down concepts', 'Historical interpretation', 'Mystical thinking'], 
     'correct_option': 'Breaking down concepts'},
    
    {'question_id': 39, 'question_text': 'Which philosopher emphasized that “the unexamined life is not worth living”?', 
     'options': ['Plato', 'Ayer', 'Socrates', 'Randall'], 
     'correct_option': 'Socrates'},
    
    {'question_id': 40, 'question_text': 'How do post-modernists perceive human knowledge?', 
     'options': ['Universal', 'Fragmentary', 'Absolute', 'Narrow'], 
     'correct_option': 'Fragmentary'},
    
    {'question_id': 41, 'question_text': 'The chapter describes philosophy as daring because it:', 
     'options': ['Challenges conventional wisdom', 'Follows strict doctrines', 'Avoids controversy', 'Emphasizes tradition'], 
     'correct_option': 'Challenges conventional wisdom'},
    
    {'question_id': 42, 'question_text': 'Philosophy as wisdom is associated with:', 
     'options': ['Technical skills', 'Correct application of rationality', 'Faith-based practices', 'Historical narratives'], 
     'correct_option': 'Correct application of rationality'},
    
    {'question_id': 43, 'question_text': 'Which thinker believes that every intellectual exercise was called philosophy in ancient times?', 
     'options': ['Igwe', 'Heidegger', 'Feyerabend', 'Randall'], 
     'correct_option': 'Igwe'},
    
    {'question_id': 44, 'question_text': 'Which characteristic highlights philosophy’s focus on individual thought?', 
     'options': ['Objective', 'Systematic', 'Individualistic', 'Empirical'], 
     'correct_option': 'Individualistic'},
    
    {'question_id': 45, 'question_text': 'The term “philosophy” fundamentally signifies a pursuit of:', 
     'options': ['Power', 'Wisdom', 'Wealth', 'Religion'], 
     'correct_option': 'Wisdom'},
    
    {'question_id': 46, 'question_text': 'Which definition of philosophy did Omoregbe offer?', 
     'options': ['A form of art', 'A rational search for reality', 'A tool for analysis', 'A pursuit of ethical practices'], 
     'correct_option': 'A rational search for reality'},
    
    {'question_id': 47, 'question_text': 'Which feature of philosophy allows it to incorporate empirical observations?', 
     'options': ['Empirical', 'Non-Absolute', 'Radical', 'Futuristic'], 
     'correct_option': 'Empirical'},
    
    {'question_id': 48, 'question_text': 'Philosophy as critical thinking about thinking itself is described as:', 
     'options': ['Wisdom', 'Systematic articulation', 'Empirical observation', 'Scientific method'], 
     'correct_option': 'Systematic articulation'},
    
    {'question_id': 49, 'question_text': 'According to Will Durant, philosophy coordinates:', 
     'options': ['Scientific methods', 'Cultural beliefs', 'Ends in the light of experience', 'Faith practices'], 
     'correct_option': 'Ends in the light of experience'},
    
    {'question_id': 50, 'question_text': 'Philosophy’s wisdom is linked to which figure?', 
     'options': ['Socrates', 'Christ', 'Heidegger', 'Plato'], 
     'correct_option': 'Christ'},
    
    {'question_id': 51, 'question_text': 'Which of the following best describes the bold nature of philosophy as mentioned in the passage?', 'options': ['It avoids questioning sensitive topics.', 'It follows strict societal norms.', 'It challenges all ideas, including well-established ones.', 'It prioritizes emotional reasoning over logic.'], 'correct_option': 'It challenges all ideas, including well-established ones.'},  

    {'question_id': 52, 'question_text': 'Why is philosophy described as systematic in the passage?', 'options': ['Because it relies on random processes.', 'Because it follows a well-ordered and logical procedure.', 'Because it ignores rules and conventions.', 'Because it focuses solely on emotions.'], 'correct_option': 'Because it follows a well-ordered and logical procedure.'},  

    {'question_id': 53, 'question_text': 'According to the passage, philosophical analysis primarily aims to:', 'options': ['Introduce ambiguity.', 'Eliminate ambiguity and bring clarity.', 'Support chaotic arguments.', 'Avoid analyzing language.'], 'correct_option': 'Eliminate ambiguity and bring clarity.'},  

    {'question_id': 54, 'question_text': 'What does it mean when the passage states that philosophy is non-absolute?', 'options': ['Philosophy accepts eternal truths.', 'Knowledge is rooted in unchanging experiences.', 'Knowledge and truth are subject to change.', 'Philosophy discourages questioning established facts.'], 'correct_option': 'Knowledge and truth are subject to change.'},  

    {'question_id': 55, 'question_text': 'The term "global" in the context of philosophy means:', 'options': ['Philosophy is limited to local practices.', 'Philosophy’s impact is universal.', 'Philosophy focuses only on regional issues.', 'Philosophy rejects universal truths.'], 'correct_option': 'Philosophy’s impact is universal.'},  

    {'question_id': 56, 'question_text': 'Which of the following best explains why philosophy is critical in nature?', 'options': ['It always agrees with mainstream opinions.', 'It evaluates both merits and demerits of theories.', 'It relies on biased reasoning.', 'It avoids controversial topics.'], 'correct_option': 'It evaluates both merits and demerits of theories.'},  

    {'question_id': 57, 'question_text': 'Philosophy is described as individualistic because:', 'options': ['It prioritizes collective beliefs over individual thought.', 'It focuses on the inner life and subjective experiences.', 'It discourages personal reflection.', 'It emphasizes group conformity.'], 'correct_option': 'It focuses on the inner life and subjective experiences.'},  

    {'question_id': 58, 'question_text': 'The argumentative nature of philosophy means that:', 'options': ['Philosophy avoids disagreements.', 'Philosophy supports systematic reasoning and factual claims.', 'Philosophy relies solely on emotional arguments.', 'Philosophy discourages debates.'], 'correct_option': 'Philosophy supports systematic reasoning and factual claims.'},  

    {'question_id': 59, 'question_text': 'Philosophy’s radical nature is linked to:', 'options': ['Preserving traditional ideas.', 'Encouraging fundamental changes in society.', 'Avoiding changes in societal structures.', 'Opposing creativity and innovation.'], 'correct_option': 'Encouraging fundamental changes in society.'},  

    {'question_id': 60, 'question_text': 'In the passage, what does the term "futuristic" imply about philosophy?', 'options': ['Philosophy focuses only on present experiences.', 'Philosophy considers future experiences to determine truth.', 'Philosophy ignores future implications.', 'Philosophy rejects tentative confirmations.'], 'correct_option': 'Philosophy considers future experiences to determine truth.'},  

    
    {'question_id': 61, 'question_text': 'Why does philosophy reject absolutism according to the passage?', 'options': ['Because absolute truths never exist.', 'Because experience and knowledge are static.', 'Because knowledge is rooted in changing experiences.', 'Because it supports fixed and dogmatic views.'], 'correct_option': 'Because knowledge is rooted in changing experiences.'},  

    {'question_id': 62, 'question_text': 'Which philosophical school is mentioned as rejecting abstract thinking and promoting subjective experiences?', 'options': ['Rationalism', 'Existentialism', 'Idealism', 'Dialectical materialism'], 'correct_option': 'Existentialism'},  

    {'question_id': 63, 'question_text': 'In what way is philosophy described as protestive?', 'options': ['It supports existing ideas.', 'It protests against previous ideas and itself.', 'It avoids challenging traditional views.', 'It maintains a neutral stance on all issues.'], 'correct_option': 'It protests against previous ideas and itself.'},  

    {'question_id': 64, 'question_text': 'What does it mean when the passage states that philosophy is empirical?', 'options': ['It relies on abstract theories.', 'It draws conclusions based on verifiable evidence.', 'It avoids observation and experimentation.', 'It is concerned only with hypothetical reasoning.'], 'correct_option': 'It draws conclusions based on verifiable evidence.'},  

    {'question_id': 65, 'question_text': 'Philosophy’s relativistic nature implies that truth is:', 'options': ['Fixed and eternal.', 'Subject to present experiences.', 'Independent of time and context.', 'Unchanging despite new evidence.'], 'correct_option': 'Subject to present experiences.'},  

    {'question_id': 66, 'question_text': 'Which of the following is a reason why philosophy is considered critical?', 'options': ['It accepts all arguments without scrutiny.', 'It evaluates theories to identify strengths and weaknesses.', 'It disregards logical reasoning.', 'It focuses solely on subjective views.'], 'correct_option': 'It evaluates theories to identify strengths and weaknesses.'},  

    {'question_id': 67, 'question_text': 'The radical approach in philosophy seeks to:', 'options': ['Preserve societal norms.', 'Foster fundamental changes in society.', 'Avoid challenging established structures.', 'Maintain the status quo.'], 'correct_option': 'Foster fundamental changes in society.'},  

    {'question_id': 68, 'question_text': 'What is the relationship between protest and different epochs in philosophy as described in the passage?', 'options': ['Each epoch builds on previous ideas without change.', 'Each epoch protests and reacts against the previous one.', 'Philosophy remains static across epochs.', 'There is no connection between epochs in philosophy.'], 'correct_option': 'Each epoch protests and reacts against the previous one.'},  

    {'question_id': 69, 'question_text': 'Which philosophical stance emphasizes that man’s existence precedes his essence?', 'options': ['Pragmatism', 'Existentialism', 'Idealism', 'Rationalism'], 'correct_option': 'Existentialism'},  

    {'question_id': 70, 'question_text': 'Philosophy’s objective nature ensures that:', 'options': ['It is influenced by personal feelings.', 'It remains impartial and fact-based.', 'It prioritizes emotions over logic.', 'It ignores empirical evidence.'], 'correct_option': 'It remains impartial and fact-based.'},
    
    {'question_id': 71, 'question_text': 'Why is philosophy described as daring?', 'options': ['It avoids controversial topics.', 'It confronts all ideas, even established ones.', 'It accepts all beliefs without questioning.', 'It focuses only on religious matters.'], 'correct_option': 'It confronts all ideas, even established ones.'},  

    {'question_id': 72, 'question_text': 'Which quality of philosophy emphasizes a methodical and organized approach to reasoning?', 'options': ['Empirical', 'Systematic', 'Radical', 'Protestive'], 'correct_option': 'Systematic'},  

    {'question_id': 73, 'question_text': 'According to the passage, logical reasoning in philosophy prevents:', 'options': ['Critical thinking', 'Systematic analysis', 'Fallacies', 'Creative ideas'], 'correct_option': 'Fallacies'},  

    {'question_id': 74, 'question_text': 'What does it mean for philosophy to be analytical?', 'options': ['To accept concepts as they are.', 'To break down concepts for clarity.', 'To avoid scrutiny of ideas.', 'To maintain ambiguity in language.'], 'correct_option': 'To break down concepts for clarity.'},  

    {'question_id': 75, 'question_text': 'Philosophy’s global nature implies that:', 'options': ['Philosophy is limited to local contexts.', 'Philosophical ideas are valid universally.', 'Only certain cultures practice philosophy.', 'Philosophy cannot address global issues.'], 'correct_option': 'Philosophical ideas are valid universally.'},  

    {'question_id': 76, 'question_text': 'What does the passage suggest about knowledge in a non-absolute philosophy?', 'options': ['It is static and final.', 'It is dynamic and subject to change.', 'It is absolute and unchanging.', 'It cannot be challenged.'], 'correct_option': 'It is dynamic and subject to change.'},  

    {'question_id': 77, 'question_text': 'Why does philosophy emphasize individualism, according to the passage?', 'options': ['To focus on societal norms.', 'To highlight subjective experiences.', 'To discourage personal reflection.', 'To promote collective thinking.'], 'correct_option': 'To highlight subjective experiences.'},  

    {'question_id': 78, 'question_text': 'Which aspect of philosophy helps in eliminating ambiguity and clarifying arguments?', 'options': ['Objectivity', 'Empiricism', 'Analysis', 'Protest'], 'correct_option': 'Analysis'},  

    {'question_id': 79, 'question_text': 'In what way is philosophy described as rational?', 'options': ['By accepting all theories equally.', 'By using reason and logic to draw conclusions.', 'By relying on emotions.', 'By avoiding evidence-based reasoning.'], 'correct_option': 'By using reason and logic to draw conclusions.'},  

    {'question_id': 80, 'question_text': 'How does philosophy’s radical nature impact society?', 'options': ['It maintains traditional values.', 'It fosters innovation and change.', 'It avoids social reform.', 'It discourages creativity.'], 'correct_option': 'It fosters innovation and change.'},
    
    {
  'question_id': 81,
  'question_text': 'Which branch of philosophy studies the nature, origin, and limits of human knowledge?',
  'options': ['Metaphysics', 'Epistemology', 'Logic', 'Axiology'],
  'correct_option': 'Epistemology'
},

{
  'question_id': 82,
  'question_text': 'What aspect of metaphysics focuses on the study of existence and relationships between entities?',
  'options': ['Cosmology', 'Ontology', 'Axiology', 'Epistemology'],
  'correct_option': 'Ontology'
},

{
  'question_id': 83,
  'question_text': 'Which philosopher is known for investigating the conditions for the possibility of human knowledge?',
  'options': ['Plato', 'John Locke', 'Immanuel Kant', 'Bertrand Russell'],
  'correct_option': 'Immanuel Kant'
},

{
  'question_id': 84,
  'question_text': 'In logic, a form of reasoning that uses two premises to derive a conclusion is called:',
  'options': ['Deduction', 'Induction', 'Syllogism', 'Inference'],
  'correct_option': 'Syllogism'
},

{
  'question_id': 85,
  'question_text': 'Axiology is primarily concerned with the study of:',
  'options': ['Knowledge and truth', 'Values and valuation', 'Reasoning and logic', 'Political systems'],
  'correct_option': 'Values and valuation'
},

{
  'question_id': 86,
  'question_text': 'Which branch of philosophy evaluates the legitimacy of institutions and systems of governance?',
  'options': ['Ethics', 'Political Philosophy', 'Logic', 'Aesthetics'],
  'correct_option': 'Political Philosophy'
},

{
  'question_id': 87,
  'question_text': 'The study of beauty, taste, and artistic value falls under which sub-branch of axiology?',
  'options': ['Ethics', 'Cosmology', 'Ontology', 'Aesthetics'],
  'correct_option': 'Aesthetics'
},

{
  'question_id': 88,
  'question_text': 'Which branch of philosophy would examine questions about the universe’s origin and laws?',
  'options': ['Epistemology', 'Cosmology', 'Logic', 'Axiology'],
  'correct_option': 'Cosmology'
},

{
  'question_id': 89,
  'question_text': 'Bertrand Russell attempted to justify modern science by relating it to:',
  'options': ['Ethics', 'Sensory experience', 'Political systems', 'Mathematical methods'],
  'correct_option': 'Sensory experience'
},

{
  'question_id': 90,
  'question_text': 'Which of the following is NOT a primary focus of logic?',
  'options': ['Correct reasoning', 'Critical thinking', 'Understanding beauty', 'Avoiding fallacies'],
  'correct_option': 'Understanding beauty'
},
    
{
  'question_id': 91,
  'question_text': 'Which branch of philosophy examines what is good or bad in human behavior?',
  'options': ['Epistemology', 'Ethics', 'Ontology', 'Political Philosophy'],
  'correct_option': 'Ethics'
},

{
  'question_id': 92,
  'question_text': 'Which ancient philosopher is credited with formalizing syllogistic reasoning?',
  'options': ['Plato', 'Socrates', 'Aristotle', 'Pythagoras'],
  'correct_option': 'Aristotle'
},

{
  'question_id': 93,
  'question_text': 'The study of the ultimate nature of reality is the focus of which branch of philosophy?',
  'options': ['Axiology', 'Epistemology', 'Metaphysics', 'Logic'],
  'correct_option': 'Metaphysics'
},

{
  'question_id': 94,
  'question_text': 'What term describes the philosophical study of values, including ethics and aesthetics?',
  'options': ['Logic', 'Axiology', 'Ontology', 'Epistemology'],
  'correct_option': 'Axiology'
},

{
  'question_id': 95,
  'question_text': 'Which branch of philosophy concerns itself with methods of critical thinking about thinking itself?',
  'options': ['Ethics', 'Epistemology', 'Logic', 'Metaphysics'],
  'correct_option': 'Logic'
},

{
  'question_id': 96,
  'question_text': 'John Locke’s primary focus in epistemology was on:',
  'options': ['Sensory experience', 'Human knowledge', 'Moral values', 'Political systems'],
  'correct_option': 'Human knowledge'
},

{
  'question_id': 97,
  'question_text': 'Which aspect of axiology focuses on moral principles and human conduct?',
  'options': ['Cosmology', 'Aesthetics', 'Ethics', 'Logic'],
  'correct_option': 'Ethics'
},

{
  'question_id': 98,
  'question_text': 'Political philosophy evaluates which of the following concepts?',
  'options': ['Beauty and taste', 'Knowledge limits', 'Justice and liberty', 'Existence and reality'],
  'correct_option': 'Justice and liberty'
},

{
  'question_id': 99,
  'question_text': 'Which philosopher is known for exploring how knowledge benefits the knower?',
  'options': ['John Locke', 'Plato', 'Bertrand Russell', 'Immanuel Kant'],
  'correct_option': 'Plato'
},

{
  'question_id': 100,
  'question_text': 'Which branch of philosophy would address the question "Is the universe finite or infinite?"',
  'options': ['Logic', 'Ontology', 'Cosmology', 'Ethics'],
  'correct_option': 'Cosmology'
},


]

chapter2 = [
# Question 1
{
    'question_id': 1,
    'question_text': 'Which philosopher is credited with coining the term "philosophy"?',
    'options': ['Socrates', 'Plato', 'Pythagoras', 'Aristotle'],
    'correct_option': 'Pythagoras'
},

# Question 2
{
    'question_id': 2,
    'question_text': 'What does the Greek word "philosophy" literally mean?',
    'options': ['Love of truth', 'Search for reality', 'Love of wisdom', 'Reflection on life'],
    'correct_option': 'Love of wisdom'
},

# Question 3
{
    'question_id': 3,
    'question_text': 'According to Plato, what is the primary aim of philosophy?',
    'options': ['Acquisition of knowledge', 'Moral reflection', 'Search for reality', 'Logical analysis'],
    'correct_option': 'Acquisition of knowledge'
},

# Question 4
{
    'question_id': 4,
    'question_text': 'Which philosopher defined philosophy as the "articulation of the spirit of the age"?',
    'options': ['Aristotle', 'Socrates', 'Immanuel Kant', 'Heidegger'],
    'correct_option': 'Immanuel Kant'
},

# Question 5
{
    'question_id': 5,
    'question_text': 'What does metaphysics primarily study?',
    'options': ['The structure of language', 'Moral values', 'The nature of reality', 'The history of ideas'],
    'correct_option': 'The nature of reality'
},

# Question 6
{
    'question_id': 6,
    'question_text': 'Which philosopher defined metaphysics as the "science of the supra-sensible"?',
    'options': ['Plato', 'Descartes', 'Aristotle', 'Quinton'],
    'correct_option': 'Plato'
},

# Question 7
{
    'question_id': 7,
    'question_text': 'What is the main task of philosophical analysis?',
    'options': ['Criticism of society', 'Clarification of concepts', 'Formulation of laws', 'Religious inquiry'],
    'correct_option': 'Clarification of concepts'
},

# Question 8
{
    'question_id': 8,
    'question_text': 'Which philosopher defined metaphysics as "the study of nature and ourselves"?',
    'options': ['Kant', 'Descartes', 'Aristotle', 'Heidegger'],
    'correct_option': 'Aristotle'
},

# Question 9
{
    'question_id': 9,
    'question_text': 'What branch of philosophy studies values like beauty and morality?',
    'options': ['Epistemology', 'Axiology', 'Logic', 'Metaphysics'],
    'correct_option': 'Axiology'
},

# Question 10
{
    'question_id': 10,
    'question_text': 'Which of the following is a task of philosophy according to Etuk?',
    'options': ['To provide material wealth', 'To train critical thinking', 'To increase physical strength', 'To control political power'],
    'correct_option': 'To train critical thinking'
},

# Question 11
{
    'question_id': 11,
    'question_text': 'Which philosopher viewed metaphysics as the "knowledge of things beyond sense perception"?',
    'options': ['Heidegger', 'Descartes', 'Plato', 'Quinton'],
    'correct_option': 'Descartes'
},

# Question 12
{
    'question_id': 12,
    'question_text': 'What does philosophical inquiry aim to establish according to the text?',
    'options': ['Religious truths', 'Scientific laws', 'Coherence in thought', 'Political systems'],
    'correct_option': 'Coherence in thought'
},

# Question 13
{
    'question_id': 13,
    'question_text': 'What is the fundamental concern of metaphysics?',
    'options': ['Political power', 'Human behavior', 'Ultimate reality', 'Language structures'],
    'correct_option': 'Ultimate reality'
},

# Question 14
{
    'question_id': 14,
    'question_text': 'Which philosopher saw metaphysics as an inquiry into the "being" of all there is?',
    'options': ['Plato', 'Kant', 'Heidegger', 'Aristotle'],
    'correct_option': 'Heidegger'
},

# Question 15
{
    'question_id': 15,
    'question_text': 'Which of these is NOT a sub-branch of philosophy mentioned in the text?',
    'options': ['Philosophy of science', 'Philosophy of language', 'Philosophy of numbers', 'Philosophy of religion'],
    'correct_option': 'Philosophy of numbers'
},

# Question 16
{
    'question_id': 16,
    'question_text': 'How does philosophy help individuals according to the text?',
    'options': ['By granting wealth', 'By ensuring happiness', 'By promoting critical thought', 'By teaching obedience'],
    'correct_option': 'By promoting critical thought'
},

# Question 17
{
    'question_id': 17,
    'question_text': 'Philosophy aims to integrate knowledge from various disciplines into:',
    'options': ['A political system', 'A coherent worldview', 'A moral doctrine', 'An economic framework'],
    'correct_option': 'A coherent worldview'
},

# Question 18
{
    'question_id': 18,
    'question_text': 'Which of the following tasks of philosophy is related to value and meaning discovery?',
    'options': ['Material success', 'Logical justification', 'Value discovery', 'Physical exercise'],
    'correct_option': 'Value discovery'
},

# Question 19
{
    'question_id': 19,
    'question_text': 'Philosophy’s examination of life aims to:',
    'options': ['Create new religions', 'Understand the cosmos', 'Clarify knowledge claims', 'Formulate physical laws'],
    'correct_option': 'Clarify knowledge claims'
},

# Question 20
{
    'question_id': 20,
    'question_text': 'What is a primary benefit of philosophical thinking as discussed in the text?',
    'options': ['Mastery of physical skills', 'Freedom from prejudices', 'Accumulation of wealth', 'Increased political power'],
    'correct_option': 'Freedom from prejudices'
},
{
    'question_id': 21,
    'question_text': 'Which philosopher is regarded as the father of Metaphysics?',
    'options': ['Parmenides', 'Socrates', 'Aristotle', 'Plato'],
    'correct_option': 'Parmenides'
},
{
    'question_id': 22,
    'question_text': 'Metaphysics primarily deals with:',
    'options': ['The study of knowledge', 'The study of reality and existence', 'The study of ethics', 'The study of logic'],
    'correct_option': 'The study of reality and existence'
},
{
    'question_id': 23,
    'question_text': 'Epistemology investigates questions about:',
    'options': ['Morality', 'Knowledge', 'Beauty', 'Being'],
    'correct_option': 'Knowledge'
},
{
    'question_id': 24,
    'question_text': 'The Greek word "episteme" means:',
    'options': ['Logic', 'Knowledge', 'Truth', 'Wisdom'],
    'correct_option': 'Knowledge'
},
{
    'question_id': 25,
    'question_text': 'Which of these is NOT a branch of epistemology?',
    'options': ['Empiricism', 'Rationalism', 'Existentialism', 'Aesthetics'],
    'correct_option': 'Aesthetics'
},
{
    'question_id': 26,
    'question_text': 'Axiology is primarily concerned with:',
    'options': ['Values', 'Logic', 'Knowledge', 'Existence'],
    'correct_option': 'Values'
},
{
    'question_id': 27,
    'question_text': 'Ethics, a subset of axiology, deals with:',
    'options': ['Beauty', 'Conduct and character', 'Logic', 'Knowledge'],
    'correct_option': 'Conduct and character'
},
{
    'question_id': 28,
    'question_text': 'Which statement best defines aesthetics?',
    'options': ['The study of reality', 'The study of logic', 'The study of beauty', 'The study of morality'],
    'correct_option': 'The study of beauty'
},
{
    'question_id': 29,
    'question_text': 'Intrinsic values are pursued for:',
    'options': ['Material wealth', 'Political power', 'Their own sake', 'External rewards'],
    'correct_option': 'Their own sake'
},
{
    'question_id': 30,
    'question_text': 'Logic is defined as the study of:',
    'options': ['Beauty', 'Correct reasoning', 'Ethics', 'Existence'],
    'correct_option': 'Correct reasoning'
},
{
    'question_id': 31,
    'question_text': 'Which type of logic deals with conclusive inferences?',
    'options': ['Inductive logic', 'Deductive logic', 'Informal logic', 'Aesthetic logic'],
    'correct_option': 'Deductive logic'
},
{
    'question_id': 32,
    'question_text': 'The syllogism is associated with which philosopher?',
    'options': ['Socrates', 'Aristotle', 'Plato', 'Descartes'],
    'correct_option': 'Aristotle'
},
{
    'question_id': 33,
    'question_text': 'Which law of logic states that everything is what it is?',
    'options': ['Law of identity', 'Law of contradiction', 'Law of excluded middle', 'Law of causality'],
    'correct_option': 'Law of identity'
},
{
    'question_id': 34,
    'question_text': 'The phrase "beauty is in the eyes of the beholder" highlights which aspect of aesthetics?',
    'options': ['Objective beauty', 'Subjective beauty', 'Universal truth', 'Intrinsic value'],
    'correct_option': 'Subjective beauty'
},
{
    'question_id': 35,
    'question_text': 'What is a premise in logic?',
    'options': ['A conclusion drawn', 'A belief', 'A statement that supports a conclusion', 'An inference'],
    'correct_option': 'A statement that supports a conclusion'
},
{
    'question_id': 36,
    'question_text': 'Which of the following is NOT a recognized law of logic?',
    'options': ['Law of contradiction', 'Law of causality', 'Law of identity', 'Law of excluded middle'],
    'correct_option': 'Law of causality'
},
{
    'question_id': 37,
    'question_text': 'What does informal logic focus on?',
    'options': ['Conclusive evidence', 'Probable inferences', 'Mathematical proofs', 'Aesthetic values'],
    'correct_option': 'Probable inferences'
},
{
    'question_id': 38,
    'question_text': 'Which philosopher is credited with skepticism about human knowledge?',
    'options': ['Descartes', 'Xenophanes', 'Parmenides', 'Socrates'],
    'correct_option': 'Xenophanes'
},
{
    'question_id': 39,
    'question_text': 'The law of excluded middle states that:',
    'options': ['A statement is either true or false', 'A statement can be true and false', 'A statement is identical to itself', 'A statement implies its opposite'],
    'correct_option': 'A statement is either true or false'
},
{
    'question_id': 40,
    'question_text': 'Which branch of philosophy examines moral principles guiding human action?',
    'options': ['Metaphysics', 'Epistemology', 'Aesthetics', 'Ethics'],
    'correct_option': 'Ethics'
},
{
    'question_id': 41,
    'question_text': 'What is the central issue of the mind-body problem?',
    'options': [
        'The nature of thought',
        'The relationship between mind and body',
        'The existence of God',
        'The meaning of life'
    ],
    'correct_option': 'The relationship between mind and body'
},
{
    'question_id': 42,
    'question_text': 'Which philosopher is most associated with interactionism?',
    'options': [
        'David Hume',
        'Rene Descartes',
        'Benedict Spinoza',
        'Nicholas Malebranche'
    ],
    'correct_option': 'Rene Descartes'
},
{
    'question_id': 43,
    'question_text': 'Epiphenomenalism claims that:',
    'options': [
        'The mind affects the body',
        'The body affects the mind',
        'Mind and body interact equally',
        'Mind and body are identical'
    ],
    'correct_option': 'The body affects the mind'
},
{
    'question_id': 44,
    'question_text': 'According to parallelism, the mind and body:',
    'options': [
        'Causally interact',
        'Are separate but synchronized',
        'Do not exist',
        'Are identical'
    ],
    'correct_option': 'Are separate but synchronized'
},
{
    'question_id': 45,
    'question_text': 'Which theory posits that mind-body interaction is mediated by God?',
    'options': [
        'Interactionism',
        'Epiphenomenalism',
        'Occasionalism',
        'Identity theory'
    ],
    'correct_option': 'Occasionalism'
},
{
    'question_id': 46,
    'question_text': 'Spinoza’s double-aspect theory suggests that:',
    'options': [
        'Mind and body are two substances',
        'Mind and body are two aspects of one substance',
        'Mind and body do not exist',
        'Mind controls body absolutely'
    ],
    'correct_option': 'Mind and body are two aspects of one substance'
},
{
    'question_id': 47,
    'question_text': 'Which philosopher famously stated, “I think, therefore I am”?',
    'options': [
        'Plato',
        'Rene Descartes',
        'David Hume',
        'Benedict Spinoza'
    ],
    'correct_option': 'Rene Descartes'
},
{
    'question_id': 48,
    'question_text': 'The identity theory argues that:',
    'options': [
        'Mind and body are separate',
        'Mind is a by-product of body',
        'Mind and body are identical',
        'Mind does not exist'
    ],
    'correct_option': 'Mind and body are identical'
},
{
    'question_id': 49,
    'question_text': 'David Hume’s view on substance is that it is:',
    'options': [
        'An essential component of reality',
        'A chimera',
        'A necessary entity',
        'Divine in origin'
    ],
    'correct_option': 'A chimera'
},
{
    'question_id': 50,
    'question_text': 'What did Descartes identify as the point of mind-body interaction?',
    'options': [
        'Heart',
        'Liver',
        'Pineal gland',
        'Brainstem'
    ],
    'correct_option': 'Pineal gland'
},
{
    'question_id': 51,
    'question_text': 'According to epiphenomenalism, mental events are:',
    'options': [
        'Independent causes',
        'By-products of physical processes',
        'Primary agents of change',
        'Nonexistent'
    ],
    'correct_option': 'By-products of physical processes'
},
{
    'question_id': 52,
    'question_text': 'Which theory compares mind and body to synchronized clocks?',
    'options': [
        'Epiphenomenalism',
        'Occasionalism',
        'Parallelism',
        'Identity theory'
    ],
    'correct_option': 'Parallelism'
},
{
    'question_id': 53,
    'question_text': 'Which philosopher proposed the pre-established harmony idea?',
    'options': [
        'Rene Descartes',
        'Benedict Spinoza',
        'Gottfried Leibniz',
        'Nicholas Malebranche'
    ],
    'correct_option': 'Gottfried Leibniz'
},
{
    'question_id': 54,
    'question_text': 'The mind-body problem is considered a perennial problem because:',
    'options': [
        'It has no empirical solution',
        'It was solved in antiquity',
        'It is irrelevant today',
        'It pertains only to science'
    ],
    'correct_option': 'It has no empirical solution'
},
{
    'question_id': 55,
    'question_text': 'Descartes described the body as:',
    'options': [
        'An illusion',
        'A material substance',
        'A mental construct',
        'Divine essence'
    ],
    'correct_option': 'A material substance'
},
{
    'question_id': 56,
    'question_text': 'Which theory denies any causal connection between mind and body?',
    'options': [
        'Interactionism',
        'Epiphenomenalism',
        'Parallelism',
        'Identity theory'
    ],
    'correct_option': 'Parallelism'
},
{
    'question_id': 57,
    'question_text': 'What is a major critique of identity theory?',
    'options': [
        'It overemphasizes spirituality',
        'It fails to account for consciousness',
        'It rejects materialism',
        'It supports dualism'
    ],
    'correct_option': 'It fails to account for consciousness'
},
{
    'question_id': 58,
    'question_text': 'Which philosopher considered mind and body as expressions of God?',
    'options': [
        'Plato',
        'Spinoza',
        'Descartes',
        'Kant'
    ],
    'correct_option': 'Spinoza'
},
{
    'question_id': 59,
    'question_text': 'Occasionalism asserts that mind-body interaction is facilitated by:',
    'options': [
        'The brain',
        'God',
        'Nerves',
        'Conscious thought'
    ],
    'correct_option': 'God'
},
{
    'question_id': 60,
    'question_text': 'According to the double-aspect theory, reality is:',
    'options': [
        'Purely physical',
        'Purely mental',
        'A combination of mind and body aspects',
        'Illusory'
    ],
    'correct_option': 'A combination of mind and body aspects'
}
    
]

chapter3 = [
    {'question_id': 1, 'question_text': 'What is the primary distinction Rene Descartes makes between the two aspects of human beings?', 
     'options': ['Mind and soul', 'Mind and body', 'Consciousness and unconsciousness', 'Thought and sensation'], 
     'correct_option': 'Mind and body'},

    {'question_id': 2, 'question_text': 'What does Descartes mean by "res cogitans"?', 
     'options': ['Body or matter', 'Consciousness or thought', 'Extension', 'Sensation'], 
     'correct_option': 'Consciousness or thought'},

    {'question_id': 3, 'question_text': 'According to Irving M. Copi, how is reasoning different from general thinking?', 
     'options': ['Reasoning is random', 'Reasoning is systematic and leads to conclusions', 'Thinking is always logical', 'Thinking never involves conclusions'], 
     'correct_option': 'Reasoning is systematic and leads to conclusions'},

    {'question_id': 4, 'question_text': 'What is a key feature of informal critical thinking?', 
     'options': ['Follows formal rules', 'Relies on common sense and available evidence', 'Always produces valid conclusions', 'Involves scientific methods'], 
     'correct_option': 'Relies on common sense and available evidence'},

    {'question_id': 5, 'question_text': 'What is emphasized in the Australian Council for Educational Research’s definition of critical thinking?', 
     'options': ['Memorization of facts', 'Analysis and evaluation', 'Following strict traditions', 'Personal intuition'], 
     'correct_option': 'Analysis and evaluation'},

    {'question_id': 6, 'question_text': 'Karl Popper’s approach to philosophy focuses on:', 
     'options': ['Problem solving', 'Religious belief', 'Mythological explanations', 'Memorization of data'], 
     'correct_option': 'Problem solving'},

    {'question_id': 7, 'question_text': 'What distinguishes critical thinkers from others, according to the text?', 
     'options': ['Memorizing facts', 'Accepting authoritative knowledge', 'Analyzing evidence and being open-minded', 'Relying on emotions'], 
     'correct_option': 'Analyzing evidence and being open-minded'},

    {'question_id': 8, 'question_text': 'Who were the pre-Socratics known for questioning traditional explanations of the universe?', 
     'options': ['Descartes', 'Plato', 'Pre-Socratics', 'Kant'], 
     'correct_option': 'Pre-Socratics'},

    {'question_id': 9, 'question_text': 'According to Schafferson, education should focus on teaching students:', 
     'options': ['What to think', 'How to think', 'Where to think', 'When to think'], 
     'correct_option': 'How to think'},

    {'question_id': 10, 'question_text': 'Why does the text emphasize teaching “how” to think over “what” to think?', 
     'options': ['To increase memorization', 'To foster critical imagination and discovery', 'To ensure uniform beliefs', 'To simplify education'], 
     'correct_option': 'To foster critical imagination and discovery'},

    {'question_id': 11, 'question_text': 'What is a characteristic of a critical thinker, as highlighted by the text?', 
     'options': ['Conformity to norms', 'Non-authoritarian temperament', 'Avoiding alternative viewpoints', 'Relying on prejudices'], 
     'correct_option': 'Non-authoritarian temperament'},

    {'question_id': 12, 'question_text': 'Which obstacle to critical thinking is caused by group-centered thinking?', 
     'options': ['Egocentricism', 'Socio-centricism', 'Peer pressure', 'Narrow-mindedness'], 
     'correct_option': 'Socio-centricism'},

    {'question_id': 13, 'question_text': 'John Dewey’s “reflective thinking” is closely associated with:', 
     'options': ['Daydreaming', 'Scientific attitude of mind', 'Wishful thinking', 'Random musings'], 
     'correct_option': 'Scientific attitude of mind'},

    {'question_id': 14, 'question_text': 'What step comes first in Karthikeyan’s five-step process of critical thinking?', 
     'options': ['Apply the information', 'Gather your information', 'Formulate your question', 'Explore other points of view'], 
     'correct_option': 'Formulate your question'},

    {'question_id': 15, 'question_text': 'Which philosopher favored deduction over induction in problem-solving?', 
     'options': ['John Dewey', 'Karl Popper', 'Descartes', 'Kant'], 
     'correct_option': 'Karl Popper'},

    {'question_id': 16, 'question_text': 'Logic is primarily concerned with which kind of thinking?', 
     'options': ['Random thinking', 'Daydreaming', 'Reasoning', 'Intuition'], 
     'correct_option': 'Reasoning'},

    {'question_id': 17, 'question_text': 'According to Oke and Amodu, reasoning involves:', 
     'options': ['Making random guesses', 'Presenting reasons to support claims', 'Avoiding conclusions', 'Trusting intuition'], 
     'correct_option': 'Presenting reasons to support claims'},

    {'question_id': 18, 'question_text': 'What is the role of premises in an argument?', 
     'options': ['They are the conclusions', 'They support the conclusion', 'They contradict the claim', 'They are irrelevant'], 
     'correct_option': 'They support the conclusion'},

    {'question_id': 19, 'question_text': 'Which of these is NOT a criterion for good reasoning?', 
     'options': ['Logical validity', 'Well-founded facts', 'Personal intuition', 'Clear expression'], 
     'correct_option': 'Personal intuition'},

    {'question_id': 20, 'question_text': 'Why is it important to regularly evaluate our beliefs critically?', 
     'options': ['To memorize facts', 'To avoid peer pressure', 'To overcome obstacles to critical thinking', 'To strengthen biases'], 
     'correct_option': 'To overcome obstacles to critical thinking'},
    {'question_id': 21, 'question_text': 'What is the primary aim of critical thinking according to the passage?', 
     'options': ['Discovery of truth', 'Resolving disagreements', 'Providing solutions', 'Behavioral motivation'], 
     'correct_option': 'Discovery of truth'},
    
    {'question_id': 22, 'question_text': 'Which of the following is NOT mentioned as an aim of critical thinking?', 
     'options': ['Discovery of truth', 'Behavioral motivation', 'Emotional satisfaction', 'Resolution of disputes'], 
     'correct_option': 'Emotional satisfaction'},
    
    {'question_id': 23, 'question_text': 'Why is the pursuit of truth essential in all disciplines?', 
     'options': ['To gain popularity', 'For financial success', 'To discover knowledge', 'To satisfy curiosity'], 
     'correct_option': 'To discover knowledge'},
    
    {'question_id': 24, 'question_text': 'According to the passage, what motivates the man on the street to seek truth?', 
     'options': ['To challenge authority', 'For personal satisfaction', 'For financial gain', 'To win arguments'], 
     'correct_option': 'For personal satisfaction'},
    
    {'question_id': 25, 'question_text': 'Which is a characteristic of the uncritical approach to truth?', 
     'options': ['Logical reasoning', 'Faith-based acceptance', 'Rigorous questioning', 'Systematic evaluation'], 
     'correct_option': 'Faith-based acceptance'},
    
    {'question_id': 26, 'question_text': 'What is a consequence of uncritical thinking as mentioned in the passage?', 
     'options': ['Innovative solutions', 'Dogmatism', 'Problem-solving', 'Rational debates'], 
     'correct_option': 'Dogmatism'},
    
    {'question_id': 27, 'question_text': 'What does the critical approach to truth primarily rely on?', 
     'options': ['Emotional appeals', 'Logical argumentation', 'Faith and intuition', 'Authority and power'], 
     'correct_option': 'Logical argumentation'},
    
    {'question_id': 28, 'question_text': 'Which tool is NOT mentioned as a part of critical thinking?', 
     'options': ['Language', 'Intuition', 'Logic', 'Argumentation'], 
     'correct_option': 'Intuition'},
    
    {'question_id': 29, 'question_text': 'In solving a logical puzzle, what does the process primarily involve?', 
     'options': ['Accepting given statements', 'Evaluating premises logically', 'Emotional reasoning', 'Avoiding contradictions'], 
     'correct_option': 'Evaluating premises logically'},
    
    {'question_id': 30, 'question_text': 'Why was the census enumerator’s report rejected?', 
     'options': ['Insufficient data', 'Logical inconsistency', 'Lack of evidence', 'Poor presentation'], 
     'correct_option': 'Logical inconsistency'},
    
    {'question_id': 31, 'question_text': 'According to the passage, what is closely related to consistency in logic?', 
     'options': ['Validity', 'Creativity', 'Emotions', 'Faith'], 
     'correct_option': 'Validity'},
    
    {'question_id': 32, 'question_text': 'Which principle does the modus ponens logical form represent?', 
     'options': ['If P then Q; P is true, so Q is true', 'If P then Q; Q is false, so P is false', 'If Q then P; Q is true, so P is true', 'If P and Q, then R'], 
     'correct_option': 'If P then Q; P is true, so Q is true'},
    
    {'question_id': 33, 'question_text': 'What is the role of the judge in legal reasoning, according to the passage?', 
     'options': ['Using emotions', 'Following popular opinion', 'Applying logical principles', 'Ignoring arguments'], 
     'correct_option': 'Applying logical principles'},
    
    {'question_id': 34, 'question_text': 'Which type of reasoning is essential in moral decision-making?', 
     'options': ['Emotional reasoning', 'Critical thinking', 'Instinctive responses', 'Unquestioning faith'], 
     'correct_option': 'Critical thinking'},
    
    {'question_id': 35, 'question_text': 'In moral reasoning, what can resolve conflicting judgments?', 
     'options': ['Majority opinion', 'Appeal to normative standards', 'Strict laws', 'Personal preferences'], 
     'correct_option': 'Appeal to normative standards'},
    
    {'question_id': 36, 'question_text': 'What does the natural law standard emphasize in moral reasoning?', 
     'options': ['Harmonizing with nature', 'Obeying legal rules', 'Personal satisfaction', 'Public opinion'], 
     'correct_option': 'Harmonizing with nature'},
    
    {'question_id': 37, 'question_text': 'Why is logic often not prioritized in professional education according to the passage?', 
     'options': ['Lack of interest', 'Lack of practical utility', 'It is too difficult', 'It is outdated'], 
     'correct_option': 'Lack of practical utility'},
    
    {'question_id': 38, 'question_text': 'How can critical thinking help in problem-solving?', 
     'options': ['Through faith-based actions', 'By systematic analysis', 'By ignoring inconsistencies', 'Through emotional appeal'], 
     'correct_option': 'By systematic analysis'},
    
    {'question_id': 39, 'question_text': 'What does Kahane and Cavender suggest we do with information in speech?', 
     'options': ['Accept it fully', 'Discard it entirely', 'Separate useful from useless', 'Memorize it'], 
     'correct_option': 'Separate useful from useless'},
    
    {'question_id': 40, 'question_text': 'Which field of study is most closely linked with logic as per the passage?', 
     'options': ['History', 'Philosophy', 'Literature', 'Geography'], 
     'correct_option': 'Philosophy'},
    
    {'question_id': 41, 'question_text': 'What distinguishes critical thinking from uncritical thinking?', 
     'options': ['Emotional engagement', 'Logical consistency', 'Faith in authority', 'Personal beliefs'], 
     'correct_option': 'Logical consistency'},

    {'question_id': 42, 'question_text': 'In moral dilemmas, what helps individuals make fair decisions?', 
     'options': ['Emotional responses', 'Legal obligations', 'Appeals to logic', 'Normative standards'], 
     'correct_option': 'Normative standards'},

    {'question_id': 43, 'question_text': 'According to the passage, which is a barrier to critical thinking?', 
     'options': ['Rigid dogmatism', 'Open-mindedness', 'Curiosity', 'Logical inquiry'], 
     'correct_option': 'Rigid dogmatism'},

    {'question_id': 44, 'question_text': 'How does uncritical acceptance of information affect decision-making?', 
     'options': ['Leads to innovation', 'Encourages rational debate', 'Promotes dogmatic beliefs', 'Inspires creativity'], 
     'correct_option': 'Promotes dogmatic beliefs'},

    {'question_id': 45, 'question_text': 'Which field heavily relies on logical consistency in arguments?', 
     'options': ['Art', 'Philosophy', 'Sports', 'Music'], 
     'correct_option': 'Philosophy'},

    {'question_id': 46, 'question_text': 'Why is evaluating premises important in logical reasoning?', 
     'options': ['To confirm emotions', 'To challenge beliefs', 'To ensure conclusions follow logically', 'To avoid questioning assumptions'], 
     'correct_option': 'To ensure conclusions follow logically'},

    {'question_id': 47, 'question_text': 'What drives professionals to value logic in their work?', 
     'options': ['Cultural trends', 'Practical utility', 'Emotional satisfaction', 'Legal requirements'], 
     'correct_option': 'Practical utility'},

    {'question_id': 48, 'question_text': 'Which tool is essential for resolving disputes in critical thinking?', 
     'options': ['Faith', 'Logic', 'Tradition', 'Public opinion'], 
     'correct_option': 'Logic'},

    {'question_id': 49, 'question_text': 'What is the outcome of logical analysis in problem-solving?', 
     'options': ['Faith-based conclusions', 'Random solutions', 'Systematic results', 'Emotional judgments'], 
     'correct_option': 'Systematic results'},

    {'question_id': 50, 'question_text': 'What role does normative standard play in moral reasoning?', 
     'options': ['Justifies personal choices', 'Guides fair decision-making', 'Promotes dogma', 'Suppresses creativity'], 
     'correct_option': 'Guides fair decision-making'},

    {'question_id': 51, 'question_text': 'What is the relationship between consistency and logic?', 
     'options': ['They are independent', 'Consistency enhances logic', 'Logic disregards consistency', 'Consistency hinders logic'], 
     'correct_option': 'Consistency enhances logic'},

    {'question_id': 52, 'question_text': 'Why might people reject critical thinking in favor of dogmatism?', 
     'options': ['It is too logical', 'Fear of uncertainty', 'Need for creativity', 'Desire for control'], 
     'correct_option': 'Fear of uncertainty'},

    {'question_id': 53, 'question_text': 'Which of the following reflects critical thinking in practice?', 
     'options': ['Accepting all premises', 'Challenging assumptions', 'Following orders blindly', 'Relying on intuition'], 
     'correct_option': 'Challenging assumptions'},

    {'question_id': 54, 'question_text': 'What is a key goal of logical argumentation?', 
     'options': ['Emotional relief', 'Discovering truth', 'Winning debates', 'Impressing others'], 
     'correct_option': 'Discovering truth'},

    {'question_id': 55, 'question_text': 'Which form of reasoning is characterized by deriving specific conclusions from general premises?', 
     'options': ['Inductive reasoning', 'Deductive reasoning', 'Analogical reasoning', 'Heuristic reasoning'], 
     'correct_option': 'Deductive reasoning'},
        
    {'question_id': 56, 'question_text': 'What motivates professionals to apply logic in their work according to the passage?', 
     'options': ['Obligation to employers', 'Search for creative ideas', 'Desire for practical outcomes', 'Curiosity about truth'], 
     'correct_option': 'Desire for practical outcomes'},
    
    {'question_id': 57, 'question_text': 'What is the key difference between deductive and inductive reasoning?', 
     'options': ['Deduction moves from general to specific, induction from specific to general', 'Induction is more accurate than deduction', 'Deduction relies on intuition, induction on data', 'Induction is quicker than deduction'], 
     'correct_option': 'Deduction moves from general to specific, induction from specific to general'},
    
    {'question_id': 58, 'question_text': 'Why is logical consistency critical in legal reasoning?', 
     'options': ['To maintain legal traditions', 'To avoid contradictions in judgments', 'To express emotions clearly', 'To encourage creative judgments'], 
     'correct_option': 'To avoid contradictions in judgments'},
    
    {'question_id': 59, 'question_text': 'What aspect of moral reasoning does the natural law approach emphasize?', 
     'options': ['Obedience to laws', 'Harmonizing with human nature', 'Following societal norms', 'Encouraging personal beliefs'], 
     'correct_option': 'Harmonizing with human nature'},
    
    {'question_id': 60, 'question_text': 'In critical thinking, what is the role of argument evaluation?', 
     'options': ['To confirm biases', 'To dismiss opposing views', 'To test for logical soundness', 'To promote consensus'], 
     'correct_option': 'To test for logical soundness'},
    
    {'question_id': 61, 'question_text': 'What distinguishes valid from invalid reasoning in logic?', 
     'options': ['Emotional appeal', 'Consistency with premises', 'Popularity of conclusion', 'Simplicity of argument'], 
     'correct_option': 'Consistency with premises'},
    
    {'question_id': 62, 'question_text': 'Which of the following is a characteristic of a sound argument?', 
     'options': ['Vague premises', 'False premises', 'True premises and valid reasoning', 'Popular opinions'], 
     'correct_option': 'True premises and valid reasoning'},
    
    {'question_id': 63, 'question_text': 'Why is separating useful from useless information important in critical thinking?', 
     'options': ['To reduce workload', 'To focus on essential arguments', 'To simplify logic', 'To align with intuition'], 
     'correct_option': 'To focus on essential arguments'},
    
    {'question_id': 64, 'question_text': 'What is one outcome of adopting a critical thinking approach to life?', 
     'options': ['Rigid adherence to norms', 'Open-minded inquiry', 'Avoiding difficult questions', 'Emotional detachment'], 
     'correct_option': 'Open-minded inquiry'},
    
    {'question_id': 65, 'question_text': 'What does critical thinking demand when evaluating speech content?', 
     'options': ['Unquestioning acceptance', 'Skeptical evaluation', 'Immediate rejection', 'Emotional engagement'], 
     'correct_option': 'Skeptical evaluation'},
    {'question_id': 66, 'question_text': 'Which skill is essential for resolving complex ethical issues?', 
     'options': ['Memory recall', 'Logical reasoning', 'Personal preference', 'Social conformity'], 
     'correct_option': 'Logical reasoning'},
    
    {'question_id': 67, 'question_text': 'How does one ensure a balanced evaluation of different viewpoints?', 
     'options': ['Prioritize personal beliefs', 'Use logical frameworks', 'Ignore opposing views', 'Focus on emotional reactions'], 
     'correct_option': 'Use logical frameworks'},
    
    {'question_id': 68, 'question_text': 'In critical thinking, what is the function of evidence?', 
     'options': ['To prove bias', 'To support conclusions', 'To confuse arguments', 'To avoid debate'], 
     'correct_option': 'To support conclusions'},
    
    {'question_id': 69, 'question_text': 'Why is it important to avoid logical fallacies in arguments?', 
     'options': ['To confuse opponents', 'To strengthen conclusions', 'To speed up discussions', 'To promote creativity'], 
     'correct_option': 'To strengthen conclusions'},
    
    {'question_id': 70, 'question_text': 'Which type of reasoning uses examples to generalize conclusions?', 
     'options': ['Deductive reasoning', 'Inductive reasoning', 'Circular reasoning', 'Analogical reasoning'], 
     'correct_option': 'Inductive reasoning'},
    
    {'question_id': 71, 'question_text': 'Which characteristic defines a critical thinker?', 
     'options': ['Unquestioning loyalty', 'Curious skepticism', 'Rigid obedience', 'Emotional impulsiveness'], 
     'correct_option': 'Curious skepticism'},
    
    {'question_id': 72, 'question_text': 'What is the primary goal of philosophical inquiry?', 
     'options': ['To create art', 'To seek truth', 'To win debates', 'To enforce norms'], 
     'correct_option': 'To seek truth'},
    
    {'question_id': 73, 'question_text': 'How can critical thinking impact public decision-making?', 
     'options': ['Encourages conformity', 'Promotes reasoned policies', 'Avoids accountability', 'Ignores evidence'], 
     'correct_option': 'Promotes reasoned policies'},
    
    {'question_id': 74, 'question_text': 'What role does fairness play in critical thinking?', 
     'options': ['Justifies bias', 'Ensures impartiality', 'Reinforces stereotypes', 'Encourages partiality'], 
     'correct_option': 'Ensures impartiality'},
    
    {'question_id': 75, 'question_text': 'Which approach emphasizes respect for natural rights in ethical reasoning?', 
     'options': ['Utilitarianism', 'Natural law', 'Consequentialism', 'Cultural relativism'], 
     'correct_option': 'Natural law'},
    
    {'question_id': 76, 'question_text': 'Why is skepticism valuable in evaluating claims?', 
     'options': ['To dismiss all information', 'To maintain open-mindedness', 'To avoid discussion', 'To create confusion'], 
     'correct_option': 'To maintain open-mindedness'},
    
    {'question_id': 77, 'question_text': 'What is a consequence of failing to apply critical thinking?', 
     'options': ['Enhanced creativity', 'Uninformed decisions', 'Clearer insights', 'Stronger logic'], 
     'correct_option': 'Uninformed decisions'},
    
    {'question_id': 78, 'question_text': 'What does a valid argument require?', 
     'options': ['False premises', 'Logical consistency', 'Popular support', 'Emotional appeal'], 
     'correct_option': 'Logical consistency'},
    
    {'question_id': 79, 'question_text': 'Why is logical fallacy detection important?', 
     'options': ['To dismiss opponents', 'To strengthen reasoning', 'To simplify arguments', 'To appeal emotionally'], 
     'correct_option': 'To strengthen reasoning'},
    
    {'question_id': 80, 'question_text': 'What outcome does ethical reasoning seek?', 
     'options': ['Personal gain', 'Moral justice', 'Legal obedience', 'Social popularity'], 
     'correct_option': 'Moral justice'}
]


chapter4 = [
    {'question_id': 1, 'question_text': 'What is the fundamental distinction between deduction and induction?', 
     'options': ['Deduction ensures probability, induction ensures certainty', 'Deduction provides certainty, induction provides probability', 'Deduction uses assumptions, induction uses facts', 'Deduction is based on evidence, induction on intuition'], 
     'correct_option': 'Deduction provides certainty, induction provides probability'},

    {'question_id': 2, 'question_text': 'Which statement is true of a deductive argument?', 
     'options': ['The conclusion is only probable', 'The conclusion must follow necessarily', 'The premises are based on observation', 'The premises are always false'], 
     'correct_option': 'The conclusion must follow necessarily'},

    {'question_id': 3, 'question_text': 'In logic, what is a proposition?', 
     'options': ['A sentence with emotional value', 'A question with factual basis', 'A statement with truth value', 'A command with imperative tone'], 
     'correct_option': 'A statement with truth value'},

    {'question_id': 4, 'question_text': 'Which of the following is NOT a proposition?', 
     'options': ['The floor is wet', 'The teacher is in class', 'Are you in Lagos?', 'All birds can fly'], 
     'correct_option': 'Are you in Lagos?'},

    {'question_id': 5, 'question_text': 'What is a key feature of inductive reasoning?', 
     'options': ['Absolute certainty', 'Probable conclusions', 'Direct inference from one premise', 'Logical impossibility'], 
     'correct_option': 'Probable conclusions'},

    {'question_id': 6, 'question_text': 'Which example illustrates a deductive argument?', 
     'options': ['Socrates is a man; all men are mortal; therefore, Socrates is mortal', 'All observed swans are white; therefore, all swans are white', 'Emeka is rich; all Nigerians are rich', 'Joshua is a man; men live longer'], 
     'correct_option': 'Socrates is a man; all men are mortal; therefore, Socrates is mortal'},

    {'question_id': 7, 'question_text': 'An argument where premises offer complete support to the conclusion is known as:', 
     'options': ['Inductive', 'Deductive', 'Assumptive', 'Hypothetical'], 
     'correct_option': 'Deductive'},

    {'question_id': 8, 'question_text': 'What is an immediate inference?', 
     'options': ['Inference requiring evidence', 'Inference drawn from a single premise', 'Inference with assumptions', 'Inference based on multiple premises'], 
     'correct_option': 'Inference drawn from a single premise'},

    {'question_id': 9, 'question_text': 'Which argument type uses a top-down approach?', 
     'options': ['Inductive', 'Deductive', 'Hypothetical', 'Analogical'], 
     'correct_option': 'Deductive'},

    {'question_id': 10, 'question_text': 'What characterizes mediate inference?', 
     'options': ['Conclusion from one premise', 'Use of multiple premises', 'Use of assumptions', 'Based on probability'], 
     'correct_option': 'Use of multiple premises'},

    {'question_id': 11, 'question_text': 'In induction, conclusions are:', 
     'options': ['Certain', 'Probable', 'Impossible', 'Invalid'], 
     'correct_option': 'Probable'},

    {'question_id': 12, 'question_text': 'Which best describes a valid deductive argument?', 
     'options': ['Premises are assumptions', 'Premises guarantee conclusion', 'Premises are observations', 'Premises are irrelevant'], 
     'correct_option': 'Premises guarantee conclusion'},

    {'question_id': 13, 'question_text': 'Why is induction associated with probability?', 
     'options': ['It relies on certainty', 'It uses only universal truths', 'It generalizes from observations', 'It does not involve logic'], 
     'correct_option': 'It generalizes from observations'},

    {'question_id': 14, 'question_text': 'What determines the strength of an inductive argument?', 
     'options': ['Number of premises', 'Logical connection', 'Certainty of conclusion', 'Evidence support'], 
     'correct_option': 'Evidence support'},

    {'question_id': 15, 'question_text': 'In logic, a conclusion follows from:', 
     'options': ['A hypothesis', 'A premise', 'A command', 'An assumption'], 
     'correct_option': 'A premise'},
    
    {'question_id': 16, 'question_text': 'Which of the following is an inductive argument?', 
     'options': ['All men are mortal; Socrates is a man; Socrates is mortal', 'All observed cats are black; therefore, all cats are black', 'All triangles have three sides', 'Water boils at 100 degrees Celsius'], 
     'correct_option': 'All observed cats are black; therefore, all cats are black'},
    
    {'question_id': 17, 'question_text': 'What is a premise in an argument?', 
     'options': ['A rhetorical question', 'A proposition supporting a conclusion', 'A command giving directions', 'A personal opinion'], 
     'correct_option': 'A proposition supporting a conclusion'},

    {'question_id': 18, 'question_text': 'Which of the following is NOT a characteristic of deduction?', 
     'options': ['Moves from general to specific', 'Ensures certainty if premises are true', 'Relies on probability', 'Logical necessity'], 
     'correct_option': 'Relies on probability'},

    {'question_id': 19, 'question_text': 'An argument that infers a general rule from specific observations is:', 
     'options': ['Deductive', 'Inductive', 'Hypothetical', 'Circular'], 
     'correct_option': 'Inductive'},

    {'question_id': 20, 'question_text': 'What kind of inference involves jumping to conclusions without proper support?', 
     'options': ['Deductive', 'Logical', 'Assumptive', 'Inductive'], 
     'correct_option': 'Assumptive'},

    {'question_id': 21, 'question_text': 'A conclusion in logic is:', 
     'options': ['A question being answered', 'A statement inferred from premises', 'A command given in an argument', 'A fact with no basis'], 
     'correct_option': 'A statement inferred from premises'},

    {'question_id': 22, 'question_text': 'What is necessary for a deductive argument to be valid?', 
     'options': ['Premises are true', 'Premises are assumptions', 'Conclusion is assumed', 'Premises and conclusion are related logically'], 
     'correct_option': 'Premises and conclusion are related logically'},

    {'question_id': 23, 'question_text': 'Inductive reasoning typically moves from:', 
     'options': ['General to specific', 'Specific to general', 'Assumptions to facts', 'Certainty to probability'], 
     'correct_option': 'Specific to general'},

    {'question_id': 24, 'question_text': 'Which of these examples demonstrates a mediate inference?', 
     'options': ['All dogs are animals; Max is a dog; therefore, Max is an animal', 'Max is a dog; therefore, Max is an animal', 'All humans are mortal; Socrates is mortal', 'Socrates is a philosopher; therefore, Socrates is wise'], 
     'correct_option': 'All dogs are animals; Max is a dog; therefore, Max is an animal'},

    {'question_id': 25, 'question_text': 'Why can inductive conclusions never guarantee certainty?', 
     'options': ['They are based on assumptions', 'They generalize from specific cases', 'They ignore evidence', 'They follow strict logical rules'], 
     'correct_option': 'They generalize from specific cases'},

    {'question_id': 26, 'question_text': 'In a valid deductive argument, if the premises are true, then:', 
     'options': ['The conclusion is true', 'The conclusion is probable', 'The premises are false', 'The argument is weak'], 
     'correct_option': 'The conclusion is true'},

    {'question_id': 27, 'question_text': 'Which term refers to the logical relationship between premises and conclusion?', 
     'options': ['Inference', 'Hypothesis', 'Assumption', 'Observation'], 
     'correct_option': 'Inference'},

    {'question_id': 28, 'question_text': 'The process of deriving logical conclusions from premises is called:', 
     'options': ['Evaluation', 'Inference', 'Speculation', 'Observation'], 
     'correct_option': 'Inference'},

    {'question_id': 29, 'question_text': 'A strong inductive argument is one in which:', 
     'options': ['The premises provide good support for the conclusion', 'The premises guarantee the conclusion', 'The premises are irrelevant', 'The conclusion follows with certainty'], 
     'correct_option': 'The premises provide good support for the conclusion'},

    {'question_id': 30, 'question_text': 'In logic, what is meant by a truth-functional proposition?', 
     'options': ['A statement whose truth value depends on context', 'A statement that is always true', 'A statement that can be evaluated as true or false', 'A question posed for analysis'], 
     'correct_option': 'A statement that can be evaluated as true or false'},

    {'question_id': 31, 'question_text': 'Which of the following is a feature of immediate inference?', 
     'options': ['It involves a hypothesis', 'It requires a single premise', 'It uses multiple premises', 'It guarantees truth'], 
     'correct_option': 'It requires a single premise'},

    {'question_id': 32, 'question_text': 'In a deductive argument, the relationship between premises and conclusion is one of:', 
     'options': ['Probability', 'Necessity', 'Assumption', 'Observation'], 
     'correct_option': 'Necessity'},

    {'question_id': 33, 'question_text': 'What distinguishes a valid argument from an invalid one?', 
     'options': ['True premises', 'Logical consistency', 'Emotional appeal', 'Number of premises'], 
     'correct_option': 'Logical consistency'},
    
    {'question_id': 34, 'question_text': 'What distinguishes a deductive inference from an inductive inference?', 
     'options': ['Deductive inference ensures certainty, inductive ensures probability', 'Deductive inference uses assumptions, inductive uses facts', 'Deductive inference is always valid, inductive is always invalid', 'Deductive inference follows intuition, inductive follows evidence'], 
     'correct_option': 'Deductive inference ensures certainty, inductive ensures probability'},

    {'question_id': 35, 'question_text': 'According to Coffey, deductive inference is a process of:', 
     'options': ['Deriving probable truths from known facts', 'Advancing from known truths to other necessarily implied truths', 'Making assumptions based on limited data', 'Comparing multiple hypotheses'], 
     'correct_option': 'Advancing from known truths to other necessarily implied truths'},

    {'question_id': 36, 'question_text': 'Which feature of deductive inference ensures logical certainty?', 
     'options': ['Use of statistical data', 'Strict logical structure', 'Dependence on observation', 'Reliance on analogies'], 
     'correct_option': 'Strict logical structure'},

    {'question_id': 37, 'question_text': 'In a categorical syllogism, what is the middle term?', 
     'options': ['The term in both premises but not in the conclusion', 'The subject of the conclusion', 'The predicate of the conclusion', 'The premise with the major term'], 
     'correct_option': 'The term in both premises but not in the conclusion'},

    {'question_id': 38, 'question_text': 'Which of the following is an example of a valid disjunctive syllogism?', 
     'options': ['If p, then q. p. Therefore, q.', 'p or q. Not p. Therefore, q.', 'If p, then q. Not q. Therefore, not p.', 'p and q. Therefore, p.'], 
     'correct_option': 'p or q. Not p. Therefore, q.'},

    {'question_id': 39, 'question_text': 'In a hypothetical syllogism, the conclusion is valid if:', 
     'options': ['The premises share a common middle term', 'The consequent of one premise becomes the antecedent of the next', 'Both premises are true', 'The argument has only one premise'], 
     'correct_option': 'The consequent of one premise becomes the antecedent of the next'},

    {'question_id': 40, 'question_text': 'Which of the following represents a Modus Ponens argument?', 
     'options': ['If p, then q. p. Therefore, q.', 'p or q. Not p. Therefore, q.', 'If p, then q. Not q. Therefore, not p.', 'p and q. Therefore, p.'], 
     'correct_option': 'If p, then q. p. Therefore, q.'},

    {'question_id': 41, 'question_text': 'Modus Tollens allows for which type of inference?', 
     'options': ['Affirming the antecedent', 'Denying the consequent', 'Denying the antecedent', 'Affirming the consequent'], 
     'correct_option': 'Denying the consequent'},

    {'question_id': 42, 'question_text': 'Which of these is an inductive generalization?', 
     'options': ['All humans are mortal. Socrates is human. Therefore, Socrates is mortal.', 'Some observed swans are white. Therefore, all swans are white.', 'If p, then q. q. Therefore, p.', 'p or q. Not p. Therefore, q.'], 
     'correct_option': 'Some observed swans are white. Therefore, all swans are white.'},

    {'question_id': 43, 'question_text': 'In statistical inductive inference, conclusions are drawn based on:', 
     'options': ['Complete certainty', 'Empirical observation', 'Probability from data samples', 'Logical necessity'], 
     'correct_option': 'Probability from data samples'},

    {'question_id': 44, 'question_text': 'Which type of inference relies on establishing causal relationships?', 
     'options': ['Categorical syllogism', 'Disjunctive syllogism', 'Causal inference', 'Modus Tollens'], 
     'correct_option': 'Causal inference'},

    {'question_id': 45, 'question_text': 'An analogical inductive inference compares:', 
     'options': ['Two unrelated arguments', 'Premises and conclusions', 'Two or more things with similar characteristics', 'Logical structures of different arguments'], 
     'correct_option': 'Two or more things with similar characteristics'},

    {'question_id': 46, 'question_text': 'Which syllogism is about definite categories?', 
     'options': ['Hypothetical syllogism', 'Disjunctive syllogism', 'Categorical syllogism', 'Inductive generalization'], 
     'correct_option': 'Categorical syllogism'},

    {'question_id': 47, 'question_text': 'A valid categorical syllogism must have:', 
     'options': ['Three premises', 'A middle term linking premises', 'A disjunction in the premise', 'At least one conditional statement'], 
     'correct_option': 'A middle term linking premises'},

    {'question_id': 48, 'question_text': 'Which inference is based on overlapping conditionals?', 
     'options': ['Modus Ponens', 'Hypothetical syllogism', 'Causal inference', 'Disjunctive syllogism'], 
     'correct_option': 'Hypothetical syllogism'},
    
    {'question_id': 49, 'question_text': 'What is the role of the major premise in a categorical syllogism?', 
     'options': ['Contains the subject term', 'Contains the middle term', 'Contains the major term', 'Contains the minor term'], 
     'correct_option': 'Contains the major term'},

    {'question_id': 50, 'question_text': 'Which of the following is a valid form of Modus Tollens?', 
     'options': ['If p, then q. Not q. Therefore, not p.', 'If p, then q. p. Therefore, q.', 'p or q. Not p. Therefore, q.', 'p and q. Therefore, p.'], 
     'correct_option': 'If p, then q. Not q. Therefore, not p.'},

    {'question_id': 51, 'question_text': 'In a disjunctive syllogism, what allows you to infer the conclusion?', 
     'options': ['Affirmation of the first disjunct', 'Denial of one disjunct', 'Affirmation of both disjuncts', 'Denial of both disjuncts'], 
     'correct_option': 'Denial of one disjunct'},

    {'question_id': 52, 'question_text': 'Which type of inference does not guarantee the truth of its conclusion?', 
     'options': ['Deductive inference', 'Inductive inference', 'Categorical syllogism', 'Hypothetical syllogism'], 
     'correct_option': 'Inductive inference'},

    {'question_id': 53, 'question_text': 'Which of the following best describes a causal inference?', 
     'options': ['Inferring a cause from an observed effect', 'Drawing a conclusion from statistical evidence', 'Making a comparison between two scenarios', 'Inferring the opposite of a disjunction'], 
     'correct_option': 'Inferring a cause from an observed effect'},

    {'question_id': 54, 'question_text': 'Which of the following types of inference can be evaluated as strong or weak?', 
     'options': ['Deductive inference', 'Inductive inference', 'Modus Ponens', 'Categorical syllogism'], 
     'correct_option': 'Inductive inference'},

    {'question_id': 55, 'question_text': 'An analogical inductive argument is strong if:', 
     'options': ['It uses a middle term', 'The comparison is relevant and has many similarities', 'It follows a disjunction', 'It uses statistical data'], 
     'correct_option': 'The comparison is relevant and has many similarities'},

    {'question_id': 56, 'question_text': 'Which of the following is true about a valid deductive argument?', 
     'options': ['The conclusion is always probable', 'The premises provide complete support for the conclusion', 'The conclusion can be false even if the premises are true', 'It relies on general observations'], 
     'correct_option': 'The premises provide complete support for the conclusion'},

    {'question_id': 57, 'question_text': 'Which type of syllogism uses conditional statements?', 
     'options': ['Categorical syllogism', 'Disjunctive syllogism', 'Hypothetical syllogism', 'Analogical inference'], 
     'correct_option': 'Hypothetical syllogism'},

    {'question_id': 58, 'question_text': 'Which inference is most associated with certainty?', 
     'options': ['Inductive generalization', 'Causal inference', 'Deductive inference', 'Analogical inference'], 
     'correct_option': 'Deductive inference'},

    {'question_id': 59, 'question_text': 'The strength of an inductive argument increases with:', 
     'options': ['The logical structure of the premises', 'The number and relevance of examples', 'The use of hypothetical premises', 'The inclusion of a middle term'], 
     'correct_option': 'The number and relevance of examples'},

    {'question_id': 60, 'question_text': 'Which form of reasoning uses generalizations from specific observations?', 
     'options': ['Deductive reasoning', 'Inductive reasoning', 'Modus Ponens', 'Modus Tollens'], 
     'correct_option': 'Inductive reasoning'},

    {'question_id': 61, 'question_text': 'A valid categorical syllogism must have:', 
     'options': ['Three terms appearing exactly twice', 'A negation in one premise', 'Only conditional premises', 'Two terms in each premise'], 
     'correct_option': 'Three terms appearing exactly twice'},

    {'question_id': 62, 'question_text': 'Which example illustrates a statistical inductive inference?', 
     'options': ['If p, then q. p. Therefore, q.', 'Most students in this class passed. Therefore, most students will pass.', 'All cats are mammals. Felix is a cat. Therefore, Felix is a mammal.', 'If the ground is wet, it rained. It rained. Therefore, the ground is wet.'], 
     'correct_option': 'Most students in this class passed. Therefore, most students will pass.'},

    {'question_id': 63, 'question_text': 'The conclusion in Modus Ponens is derived by:', 
     'options': ['Denying the antecedent', 'Affirming the antecedent', 'Denying the consequent', 'Affirming the consequent'], 
     'correct_option': 'Affirming the antecedent'}
     
    # ... more questions up to question_id: 50
]


chapter5 = [
    {'question_id': 1, 'question_text': 'What is the primary difference between a fallacy and sophistry?', 'options': ['Sophistry involves intentional deception, while a fallacy may be unintentional', 'Fallacy is always intentional, sophistry is not', 'Sophistry involves valid reasoning, fallacy does not', 'Fallacy is used for teaching, sophistry is not'], 'correct_option': 'Sophistry involves intentional deception, while a fallacy may be unintentional'},
    {'question_id': 2, 'question_text': 'Which of the following is an example of the fallacy of appeal to force (argumentum ad baculum)?', 'options': ['Threatening harm to influence someone’s choice', 'Arguing based on popular opinion', 'Appealing to a well-known expert', 'Making a false claim and demanding proof'], 'correct_option': 'Threatening harm to influence someone’s choice'},
    {'question_id': 3, 'question_text': 'What is the fallacy of appeal to pity (argumentum ad misericordiam)?', 'options': ['Making an argument based on a threat of harm', 'Using emotional appeal to gain support without rational justification', 'Citing an irrelevant authority to support an argument', 'Assuming that the conclusion is true based on the premise alone'], 'correct_option': 'Using emotional appeal to gain support without rational justification'},
    {'question_id': 4, 'question_text': 'What is a fallacy of relevance?', 'options': ['A fallacy where the premises are not relevant to the conclusion', 'A fallacy that occurs when the premises contradict each other', 'A fallacy where the argument contains contradictory statements', 'A fallacy based on the misuse of language'], 'correct_option': 'A fallacy where the premises are not relevant to the conclusion'},
    {'question_id': 5, 'question_text': 'Which fallacy is committed when someone attempts to gain support for a conclusion by exploiting popular desires?', 'options': ['Appeal to force', 'Appeal to pity', 'Appeal to the people', 'Argument against the person'], 'correct_option': 'Appeal to the people'},
    {'question_id': 6, 'question_text': 'What does the argumentum ad hominem fallacy involve?', 'options': ['Making a personal attack instead of addressing the argument', 'Appealing to the majority to validate a position', 'Drawing a conclusion from irrelevant or unqualified sources', 'Defending a conclusion by misrepresenting the opponent’s argument'], 'correct_option': 'Making a personal attack instead of addressing the argument'},
    {'question_id': 7, 'question_text': 'Which of the following best describes a “tu quoque” fallacy?', 'options': ['Accusing the opponent of hypocrisy', 'Making a personal attack to undermine the argument', 'Arguing based on emotional appeal', 'Using a false dichotomy to limit options'], 'correct_option': 'Accusing the opponent of hypocrisy'},
    {'question_id': 8, 'question_text': 'In which situation does the fallacy of accident occur?', 'options': ['When a general rule is applied to a case it does not apply to', 'When the premises do not support the conclusion', 'When a conclusion is based on emotional appeal', 'When the argument distorts the opponent’s position'], 'correct_option': 'When a general rule is applied to a case it does not apply to'},
    {'question_id': 9, 'question_text': 'What is the fallacy of straw man?', 'options': ['Misrepresenting an argument to make it easier to attack', 'Claiming something is true because it hasn’t been disproven', 'Using a generalization based on an unrepresentative sample', 'Making an emotional appeal to avoid logical reasoning'], 'correct_option': 'Misrepresenting an argument to make it easier to attack'},
    {'question_id': 10, 'question_text': 'What is meant by the fallacy of “missing the point” (ignoratio elenchi)?', 'options': ['Drawing a conclusion that misses the main point of the argument', 'Drawing a conclusion based on irrelevant premises', 'Failing to provide enough evidence for a conclusion', 'Making an argument that lacks sufficient premises'], 'correct_option': 'Drawing a conclusion that misses the main point of the argument'},
    {'question_id': 11, 'question_text': 'Which fallacy occurs when someone appeals to an unqualified authority?', 'options': ['Appeal to ignorance', 'Appeal to unqualified authority', 'Hasty generalization', 'False cause'], 'correct_option': 'Appeal to unqualified authority'},
    {'question_id': 12, 'question_text': 'What is the fallacy of “hasty generalization”?', 'options': ['Making an inductive generalization based on an unrepresentative sample', 'Applying a rule too generally to a specific case', 'Misinterpreting the opponent’s argument to make it easier to attack', 'Making an argument based on emotional appeals'], 'correct_option': 'Making an inductive generalization based on an unrepresentative sample'},
    {'question_id': 13, 'question_text': 'What type of fallacy is committed when someone uses a false cause to explain an event?', 'options': ['Hasty generalization', 'False cause', 'Appeal to pity', 'Argument against the person'], 'correct_option': 'False cause'},
    {'question_id': 14, 'question_text': 'What does the fallacy of “begging the question” involve?', 'options': ['Using a premise that assumes the truth of the conclusion', 'Making a generalization based on an insufficient sample', 'Using a false dichotomy to present two options as the only ones', 'Ignoring important evidence that contradicts the conclusion'], 'correct_option': 'Using a premise that assumes the truth of the conclusion'},
    {'question_id': 15, 'question_text': 'Which fallacy involves asking a question that contains an unwarranted assumption?', 'options': ['Complex question', 'Suppressed evidence', 'False dichotomy', 'Equivocation'], 'correct_option': 'Complex question'},
    {'question_id': 16, 'question_text': 'Which of the following describes a false dichotomy?', 'options': ['Presenting two alternatives as the only options when there are more', 'Claiming that a conclusion is true because no one has disproved it', 'Appealing to authority without proper qualifications', 'Using emotional appeals to sway the audience'], 'correct_option': 'Presenting two alternatives as the only options when there are more'},
    {'question_id': 17, 'question_text': 'What is the fallacy of “suppressed evidence”?', 'options': ['Deliberately withholding information that contradicts the argument', 'Using a misrepresentation of the opponent’s argument', 'Arguing from authority without sufficient expertise', 'Making a generalization based on insufficient evidence'], 'correct_option': 'Deliberately withholding information that contradicts the argument'},
    {'question_id': 18, 'question_text': 'What type of fallacy is committed when a word or phrase has different meanings in an argument?', 'options': ['Amphiboly', 'Equivocation', 'Composition', 'Division'], 'correct_option': 'Equivocation'},
    {'question_id': 19, 'question_text': 'What is the fallacy of amphiboly?', 'options': ['Misinterpreting an ambiguous statement due to poor grammar or punctuation', 'Making an inductive generalization based on an unrepresentative sample', 'Making an argument that relies on emotional appeal rather than logic', 'Arguing that a general rule applies to all specific cases'], 'correct_option': 'Misinterpreting an ambiguous statement due to poor grammar or punctuation'},
    {'question_id': 20, 'question_text': 'Which of the following best describes the fallacy of composition?', 'options': ['Attributing a characteristic of individual parts to the whole', 'Attributing a characteristic of the whole to individual parts', 'Making a conclusion based on insufficient evidence', 'Misrepresenting an argument to make it easier to attack'], 'correct_option': 'Attributing a characteristic of individual parts to the whole'},
    {'question_id': 21, 'question_text': 'Which fallacy involves transferring characteristics of the whole group to an individual member?', 'options': ['Fallacy of composition', 'Fallacy of division', 'False dichotomy', 'Appeal to unqualified authority'], 'correct_option': 'Fallacy of division'},
    {'question_id': 22, 'question_text': 'What does a fallacy of false cause imply?', 'options': ['Claiming a cause-and-effect relationship that does not exist', 'Claiming something is true because no one has disproved it', 'Presenting two alternatives as the only options', 'Assuming a general rule applies to specific cases'], 'correct_option': 'Claiming a cause-and-effect relationship that does not exist'},
    {'question_id': 23, 'question_text': 'Which fallacy occurs when a general rule is applied incorrectly to a specific situation?', 'options': ['Fallacy of accident', 'False dichotomy', 'Hasty generalization', 'Appeal to authority'], 'correct_option': 'Fallacy of accident'},
    {'question_id': 24, 'question_text': 'Which of the following is an example of the fallacy of appeal to ignorance?', 'options': ['Arguing that something is true because it hasn’t been disproven', 'Claiming that something is true based on majority opinion', 'Appealing to authority without adequate evidence', 'Making a generalization based on insufficient evidence'], 'correct_option': 'Arguing that something is true because it hasn’t been disproven'},
    {'question_id': 25, 'question_text': 'Which fallacy is committed when a statement is made with an unwarranted assumption embedded within a question?', 'options': ['Complex question', 'Equivocation', 'Suppressed evidence', 'False cause'], 'correct_option': 'Complex question'},
    {'question_id': 26, 'question_text': 'What does the fallacy of equivocation involve?', 'options': ['Using the same word in different senses within an argument', 'Drawing a conclusion based on an irrelevant emotional appeal', 'Using ambiguous grammar to confuse the argument', 'Exploiting the ignorance of the audience to support an argument'], 'correct_option': 'Using the same word in different senses within an argument'},
    {'question_id': 27, 'question_text': 'Which fallacy occurs when an argument is based on the abuse of an authority figure?', 'options': ['Appeal to unqualified authority', 'False cause', 'Straw man', 'Hasty generalization'], 'correct_option': 'Appeal to unqualified authority'},
    {'question_id': 28, 'question_text': 'Which fallacy occurs when an argument assumes the truth of its conclusion in the premises?', 'options': ['Begging the question', 'False cause', 'Appeal to ignorance', 'False dichotomy'], 'correct_option': 'Begging the question'},
    {'question_id': 29, 'question_text': 'Which type of fallacy involves making an argument by exploiting the emotions or biases of the audience?', 'options': ['Appeal to the people', 'Appeal to force', 'Hasty generalization', 'False cause'], 'correct_option': 'Appeal to the people'},
    {'question_id': 30, 'question_text': 'What is an example of the fallacy of appeal to force?', 'options': ['Threatening someone with harm if they do not agree with you', 'Claiming that an argument is true because it is popular', 'Making a generalization based on biased evidence', 'Using an expert opinion in a field outside their expertise'], 'correct_option': 'Threatening someone with harm if they do not agree with you'},
    {'question_id': 31, 'question_text': 'Which of the following is an example of the fallacy of appeal to authority?', 'options': ['Citing an expert who lacks relevant qualifications', 'Using a generalization based on insufficient evidence', 'Claiming that an argument is true because no one has disproven it', 'Attacking the person making the argument instead of the argument itself'], 'correct_option': 'Citing an expert who lacks relevant qualifications'},
    {'question_id': 32, 'question_text': 'What does the fallacy of “appeal to the people” involve?', 'options': ['Arguing that something is true because many people believe it', 'Attacking the character of the person making the argument', 'Claiming that something is true because it hasn’t been disproven', 'Presenting two alternatives as the only options'], 'correct_option': 'Arguing that something is true because many people believe it'},
    {'question_id': 33, 'question_text': 'What is the fallacy of “argument against the person” (ad hominem)?', 'options': ['Attacking the character of the person making the argument instead of the argument itself', 'Drawing a conclusion based on a false dichotomy', 'Claiming that something is true because it hasn’t been disproven', 'Appealing to an authority figure without relevant expertise'], 'correct_option': 'Attacking the character of the person making the argument instead of the argument itself'},
    {'question_id': 34, 'question_text': 'What is the fallacy of “false cause” (post hoc ergo propter hoc)?', 'options': ['Assuming that because one event follows another, the first caused the second', 'Making an inductive generalization based on an unrepresentative sample', 'Applying a general rule too broadly to a specific case', 'Drawing a conclusion based on a misunderstanding of the opponent’s argument'], 'correct_option': 'Assuming that because one event follows another, the first caused the second'},
    {'question_id': 35, 'question_text': 'Which of the following is a characteristic of the fallacy of composition?', 'options': ['Attributing a characteristic of individual parts to the whole', 'Attributing a characteristic of the whole to individual parts', 'Making an argument based on an irrelevant emotional appeal', 'Claiming something is true because no one has disproven it'], 'correct_option': 'Attributing a characteristic of individual parts to the whole'},
    {'question_id': 36, 'question_text': 'What is the fallacy of “division”?', 'options': ['Attributing a characteristic of the whole group to an individual member', 'Using a misrepresentation of the opponent’s argument', 'Making an argument based on emotional appeal', 'Claiming that something is true because it hasn’t been disproven'], 'correct_option': 'Attributing a characteristic of the whole group to an individual member'},
    {'question_id': 37, 'question_text': 'Which fallacy involves assuming that the truth of the conclusion has already been proven in the premises?', 'options': ['Begging the question', 'False cause', 'Straw man', 'Appeal to pity'], 'correct_option': 'Begging the question'},
    {'question_id': 38, 'question_text': 'What is the fallacy of “hasty generalization”?', 'options': ['Making an inductive generalization based on insufficient evidence', 'Applying a general rule to a specific case where it does not apply', 'Attacking the person instead of addressing the argument', 'Using a personal attack to undermine the opponent’s credibility'], 'correct_option': 'Making an inductive generalization based on insufficient evidence'},
    {'question_id': 39, 'question_text': 'Which fallacy occurs when someone uses irrelevant emotional appeals instead of rational arguments?', 'options': ['Appeal to emotion', 'False cause', 'Straw man', 'Ad hominem'], 'correct_option': 'Appeal to emotion'},
    {'question_id': 40, 'question_text': 'Which fallacy involves presenting a distorted version of the opponent’s argument to make it easier to attack?', 'options': ['Straw man', 'False dichotomy', 'Appeal to force', 'Hasty generalization'], 'correct_option': 'Straw man'},
    {'question_id': 41, 'question_text': 'What is the “argument from ignorance” fallacy?', 'options': ['Arguing that something is true because it has not been proven false', 'Claiming something is true because an expert says so', 'Making a conclusion based on a hasty generalization', 'Claiming that an argument is valid because it is widely accepted'], 'correct_option': 'Arguing that something is true because it has not been proven false'},
    {'question_id': 42, 'question_text': 'What type of fallacy occurs when someone attacks a person’s character rather than the argument itself?', 'options': ['Ad hominem', 'Appeal to ignorance', 'Straw man', 'False cause'], 'correct_option': 'Ad hominem'},
    {'question_id': 43, 'question_text': 'Which of the following is an example of the fallacy of appeal to tradition?', 'options': ['Arguing that something is right because it has been done for a long time', 'Claiming that something is true because no one has disproven it', 'Using an irrelevant appeal to authority', 'Making an emotional appeal to gain support'], 'correct_option': 'Arguing that something is right because it has been done for a long time'},
    {'question_id': 44, 'question_text': 'What is the fallacy of false dilemma?', 'options': ['Presenting only two alternatives when more options are available', 'Claiming something is true because it has not been disproven', 'Making a generalization based on insufficient evidence', 'Using emotional appeal to manipulate the audience'], 'correct_option': 'Presenting only two alternatives when more options are available'},
    {'question_id': 45, 'question_text': 'Which fallacy occurs when a conclusion is drawn based on an insufficient sample size?', 'options': ['Hasty generalization', 'Appeal to force', 'False dichotomy', 'Straw man'], 'correct_option': 'Hasty generalization'},
    {'question_id': 46, 'question_text': 'What does the fallacy of “argument from authority” involve?', 'options': ['Arguing that something is true because an authority figure says so', 'Arguing that something is true because it has not been disproven', 'Making a conclusion based on an emotional appeal', 'Claiming something is true because it is popular'], 'correct_option': 'Arguing that something is true because an authority figure says so'},
    {'question_id': 47, 'question_text': 'Which fallacy occurs when someone claims that a conclusion is true because it has not been proven false?', 'options': ['Argument from ignorance', 'Hasty generalization', 'Ad hominem', 'False cause'], 'correct_option': 'Argument from ignorance'},
    {'question_id': 48, 'question_text': 'What is the fallacy of “equivocation”?', 'options': ['Using a word with different meanings in the same argument', 'Misrepresenting someone’s argument to make it easier to attack', 'Arguing based on an irrelevant emotional appeal', 'Making a conclusion based on insufficient evidence'], 'correct_option': 'Using a word with different meanings in the same argument'},
    {'question_id': 49, 'question_text': 'Which of the following is a characteristic of the fallacy of “ad populum”?', 'options': ['Arguing that something is true because many people believe it', 'Claiming something is true because an expert says so', 'Using an emotional appeal to persuade someone', 'Making a conclusion based on a false dichotomy'], 'correct_option': 'Arguing that something is true because many people believe it'},
    {'question_id': 50, 'question_text': 'Which of the following is an example of the fallacy of appeal to force?', 'options': ['Threatening someone with harm to force agreement', 'Claiming that something is true because it is a long-standing tradition', 'Attacking someone’s character instead of their argument', 'Drawing a conclusion based on insufficient evidence'], 'correct_option': 'Threatening someone with harm to force agreement'},
    {'question_id': 51, 'question_text': 'Which of the following is an example of a fallacy of relevance?', 'options': ['Using an irrelevant emotional appeal to gain support', 'Making a conclusion based on an insufficient sample size', 'Claiming something is true because an authority figure says so', 'Making an argument based on faulty logic'], 'correct_option': 'Using an irrelevant emotional appeal to gain support'},
    {'question_id': 52, 'question_text': 'What is the fallacy of “suppressed evidence”?', 'options': ['Deliberately leaving out evidence that contradicts the argument', 'Claiming something is true because it hasn’t been disproven', 'Drawing a conclusion from an insufficient sample size', 'Using an ambiguous word to confuse the argument'], 'correct_option': 'Deliberately leaving out evidence that contradicts the argument'},
    {'question_id': 53, 'question_text': 'What does the fallacy of “false dichotomy” involve?', 'options': ['Presenting only two options when more options are available', 'Claiming that a conclusion is true because it is popular', 'Attacking someone’s character instead of the argument', 'Using emotional appeals to gain support'], 'correct_option': 'Presenting only two options when more options are available'},
    {'question_id': 54, 'question_text': 'What is the fallacy of “slippery slope”?', 'options': ['Arguing that one small step will inevitably lead to a chain of negative events', 'Claiming that something is true because an authority figure says so', 'Using an emotional appeal to manipulate the audience', 'Drawing a conclusion based on a misunderstanding of the argument'], 'correct_option': 'Arguing that one small step will inevitably lead to a chain of negative events'},
    {'question_id': 55, 'question_text': 'Which fallacy involves attacking the form of the argument rather than the content of the argument?', 'options': ['Appeal to the person', 'False cause', 'Straw man', 'Begging the question'], 'correct_option': 'Appeal to the person'}
]

chapter6 = [
    {'question_id': 1, 'question_text': 'According to James Christian, what is the main aim of philosophy?', 'options': ['To explore human experiences and find new insights', 'To develop mathematical and symbolic concepts', 'To reject all forms of traditional wisdom', 'To focus on absolute truths without contradictions'], 'correct_option': 'To explore human experiences and find new insights'},
    {'question_id': 2, 'question_text': 'What does Bertrand Russell argue about the moral role of philosophers?', 'options': ['Philosophers should use their skills for unbiased search for truth', 'Philosophers should prioritize their personal beliefs over objective truth', 'Philosophers should accept ideas from authoritative figures without questioning', 'Philosophers should focus solely on abstract logic and ignore practical applications'], 'correct_option': 'Philosophers should use their skills for unbiased search for truth'},
    {'question_id': 3, 'question_text': 'What does William Halverson assert about the central aim of philosophers?', 'options': ['To construct a unified picture of reality', 'To focus only on individual experiences without considering broader implications', 'To reject all known knowledge and start from scratch', 'To seek absolute wisdom through mystical practices'], 'correct_option': 'To construct a unified picture of reality'},
    {'question_id': 4, 'question_text': 'Which of the following is a key characteristic of philosophy, as discussed in the text?', 'options': ['The ability to ask and re-ask questions until meaningful answers are found', 'The focus on developing fixed and unchanging truths', 'The exploration of external physical phenomena only', 'The belief that certain truths are unchangeable regardless of context'], 'correct_option': 'The ability to ask and re-ask questions until meaningful answers are found'},
    {'question_id': 5, 'question_text': 'What is the role of philosophy in human conduct?', 'options': ['To analyze, evaluate, and determine the rightness or wrongness of human actions', 'To support only one moral viewpoint', 'To encourage subjective interpretations of ethical issues', 'To focus only on abstract theoretical knowledge'], 'correct_option': 'To analyze, evaluate, and determine the rightness or wrongness of human actions'},
    {'question_id': 6, 'question_text': 'Which of the following philosophers is associated with the concept of "constructing a picture of the whole of reality"?', 'options': ['William Halverson', 'Bertrand Russell', 'Socrates', 'Epicurus'], 'correct_option': 'William Halverson'},
    {'question_id': 7, 'question_text': 'What is the main concern of axiology in philosophy?', 'options': ['The study of value and its impact on human conduct', 'The analysis of logical arguments', 'The exploration of metaphysical realities', 'The development of mathematical principles'], 'correct_option': 'The study of value and its impact on human conduct'},
    {'question_id': 8, 'question_text': 'Which branch of philosophy is concerned with human actions and conduct?', 'options': ['Ethics', 'Aesthetics', 'Epistemology', 'Metaphysics'], 'correct_option': 'Ethics'},
    {'question_id': 9, 'question_text': 'What is meant by values being "relative"?', 'options': ['Values are uniquely located in specific cultures and may not apply universally', 'Values are absolute and apply universally to all individuals', 'Values exist independently of the knower or experiencer', 'Values are purely subjective and have no real-world consequences'], 'correct_option': 'Values are uniquely located in specific cultures and may not apply universally'},
    {'question_id': 10, 'question_text': 'What does the term "intrinsic value" refer to?', 'options': ['Value that something has for its own sake', 'Value that something has because it leads to something else', 'Value that exists only within a specific culture', 'Value that is subjective and depends on personal preferences'], 'correct_option': 'Value that something has for its own sake'},
    {'question_id': 11, 'question_text': 'Which of the following values is considered universal?', 'options': ['The need for truth and knowledge', 'Personal wealth accumulation', 'Cultural preferences in entertainment', 'Religious practices specific to one community'], 'correct_option': 'The need for truth and knowledge'},
    {'question_id': 12, 'question_text': 'What does the text say about the relationship between values and conflict?', 'options': ['Conflicting values are a source of disagreement and potential conflict', 'Values rarely cause conflict in human relationships', 'Conflicting values are always resolvable without moral considerations', 'Values are always absolute and therefore prevent conflict'], 'correct_option': 'Conflicting values are a source of disagreement and potential conflict'},
    {'question_id': 13, 'question_text': 'According to Esikot, what is necessary for the sustainable development of society?', 'options': ['Cognizance of the place and role of values in human life', 'The rejection of all moral values', 'Imposing a single set of values on all cultures', 'Ignoring conflicting values to maintain harmony'], 'correct_option': 'Cognizance of the place and role of values in human life'},
    {'question_id': 14, 'question_text': 'What does "aesthetic value" refer to?', 'options': ['The value associated with beauty and art', 'The value related to moral actions', 'The value of scientific knowledge', 'The value of logical reasoning'], 'correct_option': 'The value associated with beauty and art'},
    {'question_id': 15, 'question_text': 'What does "extrinsic value" refer to?', 'options': ['Value that something has because it leads to something else', 'Value that something has for its own sake', 'Value that is based on personal preference', 'Value that is based on emotional attachment'], 'correct_option': 'Value that something has because it leads to something else'},
    {'question_id': 16, 'question_text': 'Which philosopher is known for the idea that philosophy is a method of constructing a unified view of reality?', 'options': ['William Halverson', 'Immanuel Kant', 'Confucius', 'Aristotle'], 'correct_option': 'William Halverson'},
    {'question_id': 17, 'question_text': 'What is the main focus of moral philosophy or ethics?', 'options': ['To analyze the rightness or wrongness of human actions', 'To study the aesthetic qualities of art and beauty', 'To explore the metaphysical nature of reality', 'To engage in the study of logical reasoning alone'], 'correct_option': 'To analyze the rightness or wrongness of human actions'},
    {'question_id': 18, 'question_text': 'What does the concept of "objective values" imply?', 'options': ['Values exist independently of the self or knower', 'Values are purely subjective and personal', 'Values change based on culture and environment', 'Values are not influenced by human actions or decisions'], 'correct_option': 'Values exist independently of the self or knower'},
    {'question_id': 19, 'question_text': 'Which of the following is considered a "moral value"?', 'options': ['Cooperation and justice', 'Beauty in art', 'Scientific curiosity', 'Material wealth'], 'correct_option': 'Cooperation and justice'},
    {'question_id': 20, 'question_text': 'What does the term "cultural values" refer to?', 'options': ['Values that are shaped by the specific traditions and beliefs of a culture', 'Values that are universal and applicable to all societies', 'Values that are only relevant to individual preferences', 'Values that are determined by religious authorities'], 'correct_option': 'Values that are shaped by the specific traditions and beliefs of a culture'},
    {'question_id': 21, 'question_text': 'Which philosopher is known for the development of ethical theory based on duty and moral law?', 'options': ['Immanuel Kant', 'John Stuart Mill', 'Friedrich Nietzsche', 'Jean-Paul Sartre'], 'correct_option': 'Immanuel Kant'},
    {'question_id': 22, 'question_text': 'According to the text, what is a key characteristic of values that are "subjective"?', 'options': ['They depend on an individual’s sensory and mental states', 'They are universally applicable to all people', 'They are determined by objective, external standards', 'They are imposed by cultural or societal rules'], 'correct_option': 'They depend on an individual’s sensory and mental states'},
    {'question_id': 23, 'question_text': 'What does the concept of "absolute values" imply?', 'options': ['Values that are universally true for all people, regardless of context', 'Values that are flexible and dependent on circumstances', 'Values that change based on cultural or individual beliefs', 'Values that are completely subjective and relative'], 'correct_option': 'Values that are universally true for all people, regardless of context'},
    {'question_id': 24, 'question_text': 'What is the significance of values in human conduct?', 'options': ['Values guide moral and ethical decision-making in human life', 'Values are irrelevant to human behavior', 'Values are only important in abstract philosophical debates', 'Values serve to maintain social order without influencing individual actions'], 'correct_option': 'Values guide moral and ethical decision-making in human life'},
    {'question_id': 25, 'question_text': 'Which of the following best describes the relationship between ethics and aesthetics?', 'options': ['Ethics concerns the rightness or wrongness of actions, while aesthetics concerns beauty and art', 'Ethics and aesthetics are the same and cannot be separated', 'Ethics is concerned with the logical reasoning of actions, while aesthetics focuses on moral virtues', 'Ethics and aesthetics are unrelated branches of philosophy'], 'correct_option': 'Ethics concerns the rightness or wrongness of actions, while aesthetics concerns beauty and art'},
    {'question_id': 26, 'question_text': 'According to Esikot, which three levels of issues does ethics focus on?', 'options': ['Normative, meta-ethical, and strategic', 'Normative, epistemological, and existential', 'Pragmatic, metaphysical, and logical', 'Political, practical, and metaphysical'], 'correct_option': 'Normative, meta-ethical, and strategic'},
    {'question_id': 27, 'question_text': 'What distinguishes normative philosophy from theoretical philosophy?', 'options': ['Normative philosophy is concerned with values, while theoretical philosophy is concerned with abstract concepts', 'Normative philosophy is purely concerned with logic, while theoretical philosophy focuses on social issues', 'Theoretical philosophy focuses on actions, while normative philosophy discusses ideas only', 'Normative philosophy ignores values, focusing instead on metaphysical questions'], 'correct_option': 'Normative philosophy is concerned with values, while theoretical philosophy is concerned with abstract concepts'},
    {'question_id': 28, 'question_text': 'Which of the following is the main concern of ethics?', 'options': ['Determining the rightness or wrongness of human conduct', 'Exploring metaphysical truths', 'Establishing mathematical proofs', 'Clarifying abstract concepts without practical application'], 'correct_option': 'Determining the rightness or wrongness of human conduct'},
    {'question_id': 29, 'question_text': 'What does Aristotle caution about when addressing moral issues in his book "The Nicomachean Ethics"?', 'options': ['We should not expect precision in moral answers', 'Morality is absolute and unchanging', 'Ethical principles can always be calculated precisely', 'The pursuit of virtue requires a specific, fixed method'], 'correct_option': 'We should not expect precision in moral answers'},
    {'question_id': 30, 'question_text': 'What is considered morally neutral in ethics?', 'options': ['Activities that lack moral relevance, like mechanical or natural events', 'Actions that involve moral reasoning', 'Any action performed with the intent to harm others', 'Decisions based on abstract philosophical theories'], 'correct_option': 'Activities that lack moral relevance, like mechanical or natural events'},
    {'question_id': 31, 'question_text': 'What are actions considered conduct in ethics?', 'options': ['Deliberate actions that individuals are morally accountable for', 'Accidental actions that have no moral consequences', 'Natural occurrences that are beyond human control', 'Acts done without conscious intent or awareness'], 'correct_option': 'Deliberate actions that individuals are morally accountable for'},
    {'question_id': 32, 'question_text': 'What does moral philosophy aim to determine about human conduct?', 'options': ['What is right or wrong, good or evil', 'What actions are deemed irrelevant to moral judgment', 'How to avoid conflict between individual desires', 'How to create universal laws governing human actions'], 'correct_option': 'What is right or wrong, good or evil'},
    {'question_id': 33, 'question_text': 'What distinguishes consequentialist theories from other moral theories?', 'options': ['They focus on the consequences of actions to determine their rightness', 'They prioritize duty and law over consequences', 'They assert that moral actions are defined by cultural traditions', 'They emphasize abstract reasoning over practical consequences'], 'correct_option': 'They focus on the consequences of actions to determine their rightness'},
    {'question_id': 34, 'question_text': 'What is the central idea of Ethical Egoism?', 'options': ['Self-interest is the sole moral standard for determining right actions', 'Self-sacrifice for others is the highest moral good', 'Moral actions should benefit the collective good', 'Actions should always follow a universal moral law'], 'correct_option': 'Self-interest is the sole moral standard for determining right actions'},
    {'question_id': 35, 'question_text': 'What is the difference between a self-interested person and a selfish person, according to the text?', 'options': ['A self-interested person may perform acts for others, while a selfish person acts only for personal gain', 'Both are equally focused only on personal satisfaction', 'A selfish person is altruistic, while a self-interested person is only focused on their own happiness', 'Self-interest always leads to selfishness in action'], 'correct_option': 'A self-interested person may perform acts for others, while a selfish person acts only for personal gain'},
    {'question_id': 36, 'question_text': 'What criticism does John Rawls have of utilitarianism?', 'options': ['It sacrifices the interests of individuals for the benefit of others', 'It does not account for the consequences of actions', 'It ignores the greater good in favor of individual happiness', 'It focuses too much on short-term pleasure'], 'correct_option': 'It sacrifices the interests of individuals for the benefit of others'},
    {'question_id': 37, 'question_text': 'What is the central idea of Utilitarianism?', 'options': ['Actions are right if they produce the greatest happiness for the greatest number', 'Actions are right if they are consistent with universal moral laws', 'Actions are right if they benefit the self-interests of individuals', 'Actions are right if they align with religious teachings'], 'correct_option': 'Actions are right if they produce the greatest happiness for the greatest number'},
    {'question_id': 38, 'question_text': 'What is the "hedonic calculus" in Utilitarianism?', 'options': ['A method to calculate the pleasure and pain resulting from actions', 'A set of moral rules to follow in all situations', 'A way to measure how much good an action produces based on moral duty', 'A philosophical argument against selfishness'], 'correct_option': 'A method to calculate the pleasure and pain resulting from actions'},
    {'question_id': 39, 'question_text': 'What does Rule Utilitarianism focus on?', 'options': ['The consequences of following general rules that lead to the greatest good', 'The immediate consequences of individual actions', 'The rights of individuals over the collective good', 'The intentions behind individual actions rather than their outcomes'], 'correct_option': 'The consequences of following general rules that lead to the greatest good'},
    {'question_id': 40, 'question_text': 'What does Formalism in ethics emphasize?', 'options': ['The intrinsic rightness or wrongness of actions, regardless of consequences', 'The immediate outcomes of actions as the only measure of morality', 'The importance of self-interest in guiding moral actions', 'The subjective interpretation of ethical principles by individuals'], 'correct_option': 'The intrinsic rightness or wrongness of actions, regardless of consequences'},
    {'question_id': 41, 'question_text': 'What is the Golden Rule in ethics?', 'options': ['Treat others as you would like to be treated', 'Always prioritize personal happiness over others', 'Act in ways that maximize individual pleasure', 'Follow laws and rules without question'], 'correct_option': 'Treat others as you would like to be treated'},
    {'question_id': 42, 'question_text': 'What problem does the Golden Rule encounter, according to the text?', 'options': ['It allows people who mistreat themselves to treat others the same way', 'It forces people to sacrifice their happiness for others', 'It requires all individuals to follow the same actions regardless of context', 'It encourages selfishness by prioritizing personal needs over others'], 'correct_option': 'It allows people who mistreat themselves to treat others the same way'},
    {'question_id': 43, 'question_text': 'What is the focus of Deontological Theories in ethics?', 'options': ['Duty, right, law, and obligation as indicators of right and wrong conduct', 'The consequences of actions', 'Maximizing happiness for the greatest number', 'The rejection of moral laws and duties in favor of individual choice'], 'correct_option': 'Duty, right, law, and obligation as indicators of right and wrong conduct'},
    {'question_id': 44, 'question_text': 'What does Immanuel Kant argue about the nature of moral actions?', 'options': ['Moral actions are determined by duty, not consequences', 'Moral actions should always aim to maximize happiness', 'Moral actions depend on personal preferences and inclinations', 'Moral actions are determined by the outcome for society'], 'correct_option': 'Moral actions are determined by duty, not consequences'},
    {'question_id': 45, 'question_text': 'What is the "categorical imperative" in Kantian ethics?', 'options': ['A universal moral law that commands actions without exceptions', 'A principle that focuses on the consequences of actions', 'A rule that prioritizes self-interest over duty', 'A moral law that is subjective and based on individual desires'], 'correct_option': 'A universal moral law that commands actions without exceptions'},
    {'question_id': 46, 'question_text': 'What does Kant mean by "acting from a sense of duty"?', 'options': ['Performing actions in obedience to a moral law, regardless of personal desires', 'Acting in ways that promote personal happiness and pleasure', 'Following rules because they lead to the greatest good for society', 'Choosing actions based on the consequences they bring to others'], 'correct_option': 'Performing actions in obedience to a moral law, regardless of personal desires'},
    {'question_id': 47, 'question_text': 'What is the concept of "universalizability" in Kantian ethics?', 'options': ['Moral actions must be applicable to everyone in similar situations', 'Moral actions must promote personal happiness', 'Moral actions must be designed to maximize overall good', 'Moral actions must be determined by individual preferences'], 'correct_option': 'Moral actions must be applicable to everyone in similar situations'},
    {'question_id': 48, 'question_text': 'What does Kant say about humanity in moral actions?', 'options': ['Humanity must always be treated as an end, not merely as a means to an end', 'Humanity must be treated as a means to achieve personal goals', 'Humanity should be subordinated to the happiness of others', 'Humanity is irrelevant to moral judgment and actions'], 'correct_option': 'Humanity must always be treated as an end, not merely as a means to an end'},
    {'question_id': 49, 'question_text': 'What distinguishes deontological theories from consequentialist theories?', 'options': ['Deontological theories focus on the inherent rightness or wrongness of actions, regardless of consequences', 'Deontological theories prioritize the consequences of actions over intrinsic value', 'Deontological theories focus on individual happiness', 'Deontological theories stress the importance of following universal laws to maximize collective good'], 'correct_option': 'Deontological theories focus on the inherent rightness or wrongness of actions, regardless of consequences'},
    {'question_id': 50, 'question_text': 'What is the main concern of moral philosophers when evaluating conduct?', 'options': ['To determine the ultimate moral principles that guide human actions', 'To focus on personal satisfaction and fulfillment', 'To assess the consequences of actions on individuals only', 'To prioritize the interests of society over individual rights'], 'correct_option': 'To determine the ultimate moral principles that guide human actions'}

]

chapter7 = [
    {'question_id': 1, 'question_text': 'What is the primary role of philosophy in character moulding?', 'options': ['It helps individuals reflect on their beliefs and actions', 'It provides a fixed set of moral guidelines', 'It prioritizes emotional development over rational thought', 'It focuses only on theoretical knowledge without practical application'], 'correct_option': 'It helps individuals reflect on their beliefs and actions'},
    {'question_id': 2, 'question_text': 'According to Socrates, why is the examined life important?', 'options': ['It allows individuals to reflect on their beliefs and actions', 'It helps individuals achieve happiness and pleasure', 'It ensures social conformity', 'It leads to religious enlightenment'], 'correct_option': 'It allows individuals to reflect on their beliefs and actions'},
    {'question_id': 3, 'question_text': 'What is the connection between philosophy and character development?', 'options': ['Philosophy encourages critical thinking and ethical reflection that shapes character', 'Philosophy creates a moral code for society to follow', 'Philosophy teaches people to follow tradition without question', 'Philosophy emphasizes personal achievement over communal well-being'], 'correct_option': 'Philosophy encourages critical thinking and ethical reflection that shapes character'},
    {'question_id': 4, 'question_text': 'What did Aristotle believe about the development of virtue?', 'options': ['Virtue is developed through habit and education', 'Virtue is a gift given at birth', 'Virtue is determined by societal norms', 'Virtue is learned only through abstract reasoning'], 'correct_option': 'Virtue is developed through habit and education'},
    {'question_id': 5, 'question_text': 'According to Aristotle, which of the following virtues is essential for flourishing?', 'options': ['Courage, temperance, and justice', 'Ambition, intelligence, and charm', 'Happiness, wealth, and power', 'Self-control, pride, and greed'], 'correct_option': 'Courage, temperance, and justice'},
    {'question_id': 6, 'question_text': 'How does philosophy help individuals make ethical decisions?', 'options': ['By promoting critical examination of motives and conduct', 'By offering rigid rules to follow', 'By focusing on individual desires over collective well-being', 'By disregarding moral questions as irrelevant'], 'correct_option': 'By promoting critical examination of motives and conduct'},
    {'question_id': 7, 'question_text': 'What does the term "character" primarily refer to?', 'options': ['The mental and moral qualities that define a person', 'A person’s wealth and social status', 'An individual’s academic achievements', 'The physical traits of a person'], 'correct_option': 'The mental and moral qualities that define a person'},
    {'question_id': 8, 'question_text': 'Which of the following is NOT a trait that constitutes human character?', 'options': ['Dishonesty', 'Integrity', 'Courage', 'Empathy'], 'correct_option': 'Dishonesty'},
    {'question_id': 9, 'question_text': 'What role does resilience play in character development?', 'options': ['It showcases strength in adversity and helps individuals recover from difficulties', 'It prevents individuals from experiencing failure', 'It emphasizes the avoidance of challenges', 'It allows individuals to suppress emotions'], 'correct_option': 'It showcases strength in adversity and helps individuals recover from difficulties'},
    {'question_id': 10, 'question_text': 'How does nature influence the development of character?', 'options': ['Through genetic predispositions that shape temperament and personality traits', 'By determining a person’s moral values', 'By dictating the social norms of a culture', 'By eliminating the need for personal effort in character building'], 'correct_option': 'Through genetic predispositions that shape temperament and personality traits'},
    {'question_id': 11, 'question_text': 'What is the role of nurture in character development?', 'options': ['It involves environmental influences like upbringing, education, and culture', 'It completely overrides any influence of nature', 'It determines moral values in a vacuum, without any external influence', 'It focuses on the physical traits of a person rather than mental or ethical qualities'], 'correct_option': 'It involves environmental influences like upbringing, education, and culture'},
    {'question_id': 12, 'question_text': 'What is one way that supportive parenting affects character development?', 'options': ['It fosters the growth of positive character traits', 'It leads to a lack of personal responsibility', 'It encourages selfish behavior', 'It promotes emotional suppression'], 'correct_option': 'It fosters the growth of positive character traits'},
    {'question_id': 13, 'question_text': 'What is the meaning of "philosophy" in its original Greek form?', 'options': ['The love of wisdom', 'The study of human nature', 'The quest for power', 'The search for material success'], 'correct_option': 'The love of wisdom'},
    {'question_id': 14, 'question_text': 'What does the branch of metaphysics in philosophy primarily deal with?', 'options': ['The nature of reality and existence', 'The study of moral values and ethical systems', 'The analysis of valid reasoning', 'The exploration of beauty and art'], 'correct_option': 'The nature of reality and existence'},
    {'question_id': 15, 'question_text': 'What does epistemology explore?', 'options': ['The nature of knowledge and how it is acquired', 'The principles of correct reasoning', 'The essence of beauty and art', 'The moral implications of actions'], 'correct_option': 'The nature of knowledge and how it is acquired'},
    {'question_id': 16, 'question_text': 'Which branch of philosophy examines right and wrong, good and bad?', 'options': ['Ethics', 'Aesthetics', 'Metaphysics', 'Logic'], 'correct_option': 'Ethics'},
    {'question_id': 17, 'question_text': 'What is the focus of logic as a branch of philosophy?', 'options': ['Good reasoning and valid arguments', 'The emotional responses to actions', 'The development of societal values', 'The exploration of religious beliefs'], 'correct_option': 'Good reasoning and valid arguments'},
    {'question_id': 18, 'question_text': 'How does philosophy contribute to societal progress?', 'options': ['By promoting critical thinking and ethical reflection that can influence social norms', 'By providing fixed rules for everyone to follow', 'By encouraging blind obedience to authority', 'By discouraging questioning of traditional beliefs'], 'correct_option': 'By promoting critical thinking and ethical reflection that can influence social norms'},
    {'question_id': 19, 'question_text': 'What role does philosophy play in addressing social and moral issues?', 'options': ['It encourages deep reflection on values, ethics, and societal impacts', 'It promotes a single, unchanging moral code for all societies', 'It seeks to eliminate all social conflicts', 'It focuses exclusively on scientific and technological problems'], 'correct_option': 'It encourages deep reflection on values, ethics, and societal impacts'},
    {'question_id': 20, 'question_text': 'What is the Socratic Method known for?', 'options': ['Focusing on dialogue and critical thinking through questioning', 'Offering a set of predetermined answers', 'Prioritizing religious teachings over reason', 'Promoting authoritarian structures in learning'], 'correct_option': 'Focusing on dialogue and critical thinking through questioning'},
    {'question_id': 21, 'question_text': 'What is the central idea behind Aristotle’s concept of virtue?', 'options': ['Virtue is developed through practice and education', 'Virtue is an innate quality that cannot be changed', 'Virtue is irrelevant to human happiness', 'Virtue is only useful for those in positions of power'], 'correct_option': 'Virtue is developed through practice and education'},
    {'question_id': 22, 'question_text': 'According to the text, what is philosophy’s contribution to practical life?', 'options': ['It helps individuals confront life’s challenges through ethical reflection and critical thinking', 'It offers solutions to all personal problems without effort', 'It provides direct answers to scientific questions', 'It avoids addressing real-life issues in favor of abstract theory'], 'correct_option': 'It helps individuals confront life’s challenges through ethical reflection and critical thinking'},
    {'question_id': 23, 'question_text': 'Which virtue is emphasized by philosophy as necessary for personal and societal flourishing?', 'options': ['Courage', 'Greed', 'Ambition', 'Envy'], 'correct_option': 'Courage'},
    {'question_id': 24, 'question_text': 'What does the term "critical thinking" imply in the context of philosophy?', 'options': ['The ability to question and reflect deeply on beliefs and assumptions', 'The ability to memorize facts and follow instructions', 'The ability to quickly answer questions without reflection', 'The ability to agree with societal norms without questioning them'], 'correct_option': 'The ability to question and reflect deeply on beliefs and assumptions'},
    {'question_id': 25, 'question_text': 'How does philosophy influence the development of societal norms?', 'options': ['Through reflection on ethical principles like empathy, integrity, and respect', 'By enforcing laws without regard to individual beliefs', 'By eliminating the need for personal ethics', 'By prioritizing personal gain over communal well-being'], 'correct_option': 'Through reflection on ethical principles like empathy, integrity, and respect'},
    {'question_id': 26, 'question_text': 'What does "nurture" refer to in the context of character development?', 'options': ['The environmental influences like upbringing, culture, and education', 'The natural, inborn traits that shape an individual', 'The passive acceptance of external forces', 'The random, unchangeable aspect of personality'], 'correct_option': 'The environmental influences like upbringing, culture, and education'},
    {'question_id': 27, 'question_text': 'How does philosophy address the issue of knowledge?', 'options': ['It questions the nature, acquisition, and limits of knowledge', 'It assumes knowledge is fixed and unchangeable', 'It ignores knowledge in favor of abstract reasoning', 'It solely focuses on scientific facts without considering ethics'], 'correct_option': 'It questions the nature, acquisition, and limits of knowledge'},
    {'question_id': 28, 'question_text': 'What is the philosophical approach to understanding "beauty" and "art"?', 'options': ['Aesthetics, which explores how we perceive and value beauty', 'Ethics, which focuses on the moral implications of art', 'Metaphysics, which defines the essence of beauty', 'Epistemology, which questions the knowledge of art'], 'correct_option': 'Aesthetics, which explores how we perceive and value beauty'},
    {'question_id': 29, 'question_text': 'What does the philosophical term "self-reflection" encourage?', 'options': ['The examination of one’s thoughts, actions, and motives', 'The focus on external achievements and status', 'The avoidance of emotional experiences', 'The unquestioning acceptance of societal rules'], 'correct_option': 'The examination of one’s thoughts, actions, and motives'},
    {'question_id': 30, 'question_text': 'How does philosophy contribute to innovation?', 'options': ['By encouraging critical thinking and ethical inquiry in areas like science and technology', 'By offering fixed solutions to modern problems', 'By focusing exclusively on abstract, unrelated issues', 'By avoiding discussions on contemporary issues'], 'correct_option': 'By encouraging critical thinking and ethical inquiry in areas like science and technology'},
    {'question_id': 31, 'question_text': 'How does Aristotle view the relationship between education and character development?', 'options': ['Education should cultivate both the mind and the heart', 'Education is solely for the acquisition of knowledge', 'Education should focus on social skills only', 'Education is irrelevant to character development'], 'correct_option': 'Education should cultivate both the mind and the heart'},
    {'question_id': 32, 'question_text': 'What does Aristotle mean by "Moral virtues are a product of habit"?', 'options': ['Virtues are learned through repeated actions and practices', 'Virtues are innate qualities that cannot be learned', 'Virtues are determined by societal expectations', 'Virtues are fixed traits that do not change'], 'correct_option': 'Virtues are learned through repeated actions and practices'},
    {'question_id': 33, 'question_text': 'According to the text, how do schools contribute to character development?', 'options': ['By emphasizing social and emotional learning to build empathy and responsibility', 'By focusing on academic achievement alone', 'By prioritizing athletic skills over moral education', 'By offering financial incentives for good behavior'], 'correct_option': 'By emphasizing social and emotional learning to build empathy and responsibility'},
    {'question_id': 34, 'question_text': 'What is the role of mentorship in character moulding?', 'options': ['Mentors guide, support, and encourage positive behaviors and attitudes', 'Mentors enforce rigid rules without room for personal growth', 'Mentors focus on academic excellence exclusively', 'Mentors discourage self-reflection in favor of compliance'], 'correct_option': 'Mentors guide, support, and encourage positive behaviors and attitudes'},
    {'question_id': 35, 'question_text': 'What is meant by the "collective consciousness" in Emile Durkheim’s philosophy?', 'options': ['It refers to shared social norms that shape individual behavior', 'It is a concept that promotes individual autonomy over societal rules', 'It is a concept focusing solely on emotional responses', 'It is a form of societal selfishness that ignores collective welfare'], 'correct_option': 'It refers to shared social norms that shape individual behavior'},
    {'question_id': 36, 'question_text': 'How do personal experiences and challenges influence character development?', 'options': ['They shape qualities like resilience, empathy, and perseverance', 'They create emotional numbness and detachment from others', 'They lead to personal regression and avoidance of growth', 'They have no significant impact on character development'], 'correct_option': 'They shape qualities like resilience, empathy, and perseverance'},
    {'question_id': 37, 'question_text': 'What does Kahlil Gibran mean by "Your pain is the breaking of the shell that encloses your understanding"?', 'options': ['Personal struggles can lead to self-discovery and growth', 'Pain is always negative and leads to weakness', 'Pain should be avoided as it does not contribute to development', 'Pain is a sign of moral failure'], 'correct_option': 'Personal struggles can lead to self-discovery and growth'},
    {'question_id': 38, 'question_text': 'How does Confucian philosophy view the relationship between individual character and society?', 'options': ['Individual character improvement is essential for societal well-being', 'Society is irrelevant to individual character development', 'Society imposes fixed moral values on individuals', 'Individual character is independent of social harmony'], 'correct_option': 'Individual character improvement is essential for societal well-being'},
    {'question_id': 39, 'question_text': 'What does Confucius mean by "To cultivate oneself is to cultivate the state"?', 'options': ['The development of individual virtue contributes to the greater good of society', 'The state should impose moral values on individuals', 'The state should be governed by absolute rulers, not individuals', 'Individual cultivation is irrelevant to state governance'], 'correct_option': 'The development of individual virtue contributes to the greater good of society'},
    {'question_id': 40, 'question_text': 'What is the key idea of Immanuel Kant’s deontological ethics?', 'options': ['Moral actions must be performed out of duty, not merely in accordance with duty', 'Morality depends on the consequences of actions', 'Moral actions are guided solely by social norms', 'Ethics are situational and not based on universal principles'], 'correct_option': 'Moral actions must be performed out of duty, not merely in accordance with duty'},
    {'question_id': 41, 'question_text': 'What is Nietzsche’s view on traditional morality?', 'options': ['He challenges traditional morality and advocates for the creation of personal values', 'He strongly supports conventional moral standards', 'He believes that traditional morals should be universally accepted', 'He advocates for complete moral relativism without any guidelines'], 'correct_option': 'He challenges traditional morality and advocates for the creation of personal values'},
    {'question_id': 42, 'question_text': 'How does Nietzsche define the "will to power"?', 'options': ['It is a driving force for self-overcoming and personal transformation', 'It is a desire for social approval and conformity', 'It represents the pursuit of wealth and status', 'It refers to dominating others for personal gain'], 'correct_option': 'It is a driving force for self-overcoming and personal transformation'},
    {'question_id': 43, 'question_text': 'How does John Dewey’s pragmatism view education?', 'options': ['Education should focus on reflective, experiential learning for character development', 'Education should be purely theoretical and academic', 'Education should avoid personal reflection and focus only on facts', 'Education should emphasize rote memorization over experiential learning'], 'correct_option': 'Education should focus on reflective, experiential learning for character development'},
    {'question_id': 44, 'question_text': 'What does Dewey mean by "We do not learn from experience... we learn from reflecting on experience"?', 'options': ['Reflection on experience is essential for learning and personal growth', 'Experience alone provides sufficient learning', 'Reflection is unnecessary as knowledge comes from external sources', 'Experience is irrelevant to learning if not accompanied by formal education'], 'correct_option': 'Reflection on experience is essential for learning and personal growth'},
    {'question_id': 45, 'question_text': 'How does Aristotle’s virtue ethics approach character development?', 'options': ['Virtue is cultivated through habitual practice and the pursuit of balance', 'Virtue is determined by societal norms without personal involvement', 'Virtue is solely about intellectual reasoning without practical application', 'Virtue is an innate quality and cannot be developed'], 'correct_option': 'Virtue is cultivated through habitual practice and the pursuit of balance'},
    {'question_id': 46, 'question_text': 'What is the ultimate goal of character development according to Aristotle?', 'options': ['Human flourishing or happiness achieved through the balance of virtues', 'Achieving personal power and domination', 'Conforming to societal standards without question', 'Acquiring wealth and status'], 'correct_option': 'Human flourishing or happiness achieved through the balance of virtues'},
    {'question_id': 47, 'question_text': 'What is the relationship between philosophy and character moulding?', 'options': ['Philosophy provides frameworks and ethical principles for shaping individual character', 'Philosophy focuses only on abstract theories with no real-world application', 'Philosophy discourages personal responsibility in favor of passive existence', 'Philosophy promotes moral relativism and rejects universal ethical standards'], 'correct_option': 'Philosophy provides frameworks and ethical principles for shaping individual character'},
    {'question_id': 48, 'question_text': 'How does utilitarianism influence character development?', 'options': ['Character development should align with promoting the greatest happiness for the greatest number', 'Character development is irrelevant to the consequences of actions', 'Character development should focus on personal satisfaction without regard for others', 'Character development involves strict adherence to rules without considering outcomes'], 'correct_option': 'Character development should align with promoting the greatest happiness for the greatest number'},
    {'question_id': 49, 'question_text': 'What is the central idea of Kant’s universal law principle?', 'options': ['We should act according to maxims that can be universally applied as moral laws', 'Moral actions are based on the social context and individual preferences', 'We should follow societal rules without questioning their moral validity', 'Moral actions depend solely on their immediate consequences'], 'correct_option': 'We should act according to maxims that can be universally applied as moral laws'},
    {'question_id': 50, 'question_text': 'How does Kantian ethics guide character development?', 'options': ['By emphasizing duty, respect for others, and moral laws that apply universally', 'By focusing on personal desires and individual freedom without regard for others', 'By prioritizing the consequences of actions over intentions', 'By asserting that morality is subjective and context-dependent'], 'correct_option': 'By emphasizing duty, respect for others, and moral laws that apply universally'},
    {'question_id': 51, 'question_text': 'How does Aristotle view the role of habits in developing moral virtues?', 'options': ['Virtues are developed through repeated actions and habits', 'Virtues are given by birth and cannot be developed', 'Virtues are irrelevant to character development', 'Virtues are influenced only by external forces like culture and society'], 'correct_option': 'Virtues are developed through repeated actions and habits'},
    {'question_id': 52, 'question_text': 'What does Aristotle mean by "the golden mean"?', 'options': ['Virtue lies between deficiency and excess, finding balance in behavior', 'Virtue is found in total abstinence from pleasure', 'Virtue is only attained through wealth and status', 'Virtue is a result of strict obedience to authority'], 'correct_option': 'Virtue lies between deficiency and excess, finding balance in behavior'},
    {'question_id': 53, 'question_text': 'How does philosophy encourage self-reflection in character development?', 'options': ['It provides tools to critically examine one’s thoughts, actions, and motivations', 'It dismisses personal reflection in favor of societal norms', 'It focuses only on theoretical ideas without practical application', 'It discourages questioning of established moral frameworks'], 'correct_option': 'It provides tools to critically examine one’s thoughts, actions, and motivations'},
    {'question_id': 54, 'question_text': 'What is the significance of emotions in moral behavior, according to Jonathan Haidt?', 'options': ['Emotions play a crucial role in moral judgments, often preceding rational thought', 'Emotions are irrelevant to moral decisions, which are purely rational', 'Emotions distort moral reasoning and should be suppressed', 'Emotions should be the sole basis for moral behavior'], 'correct_option': 'Emotions play a crucial role in moral judgments, often preceding rational thought'},
    {'question_id': 55, 'question_text': 'How do social norms contribute to character formation?', 'options': ['They shape individual behavior by defining acceptable actions and attitudes', 'They have no impact on individual character development', 'They discourage personal responsibility and autonomy', 'They solely focus on material success without moral consideration'], 'correct_option': 'They shape individual behavior by defining acceptable actions and attitudes'},
    {'question_id': 56, 'question_text': 'How does the existentialist perspective influence character development?', 'options': ['It emphasizes personal responsibility and agency in shaping one’s character', 'It denies the role of personal choice and focuses on destiny', 'It argues that character is solely determined by external forces', 'It focuses only on intellectual development without considering emotions'], 'correct_option': 'It emphasizes personal responsibility and agency in shaping one’s character'},
    {'question_id': 57, 'question_text': 'What is the role of societal values in character development?', 'options': ['They provide a framework for understanding moral behavior and guide character formation', 'They restrict personal growth and limit individual freedom', 'They focus solely on material wealth and social status', 'They have no significant impact on individual development'], 'correct_option': 'They provide a framework for understanding moral behavior and guide character formation'},
    {'question_id': 58, 'question_text': 'How does character development contribute to societal well-being?', 'options': ['It leads to responsible and ethical behavior that benefits society as a whole', 'It focuses only on individual gain without regard for others', 'It encourages rebellion against societal norms', 'It has no impact on the larger society'], 'correct_option': 'It leads to responsible and ethical behavior that benefits society as a whole'},
    {'question_id': 59, 'question_text': 'What does Mill’s greatest happiness principle suggest about moral decisions?', 'options': ['Moral decisions should promote the greatest happiness for the greatest number', 'Moral decisions should prioritize individual pleasure over societal well-being', 'Moral decisions should be based solely on duty, regardless of consequences', 'Moral decisions should be based on tradition and authority'], 'correct_option': 'Moral decisions should promote the greatest happiness for the greatest number'},
    {'question_id': 60, 'question_text': 'What is the main idea behind existentialism in relation to character development?', 'options': ['Individuals shape their nature through choices and actions, emphasizing personal responsibility', 'Character is shaped solely by genetic inheritance and external forces', 'Character is fixed and cannot be altered by personal decisions', 'Character development is irrelevant to existential thought'], 'correct_option': 'Individuals shape their nature through choices and actions, emphasizing personal responsibility'}


]


chapter8 = [
    {'question_id': 1, 'question_text': 'What is the common aim of both philosophy and religion?', 'options': ['To seek absolute truth about reality', 'To create rituals for worship', 'To provide a code of conduct', 'To promote dogma and unquestionable beliefs'], 'correct_option': 'To seek absolute truth about reality'},
    {'question_id': 2, 'question_text': 'How does philosophy differ from religion in acquiring knowledge?', 'options': ['Philosophy depends on revelation, religion on reason', 'Philosophy uses reason, religion depends on faith', 'Philosophy follows dogma, religion avoids questioning', 'Philosophy accepts truths without rational analysis'], 'correct_option': 'Philosophy uses reason, religion depends on faith'},
    {'question_id': 3, 'question_text': 'What is the dogmatic approach in religion?', 'options': ['Knowledge gained through reason and analysis', 'Knowledge based on faith and revealed truths', 'Knowledge based on scientific inquiry', 'Knowledge gained through personal experience'], 'correct_option': 'Knowledge based on faith and revealed truths'},
    {'question_id': 4, 'question_text': 'How does philosophy approach belief systems?', 'options': ['By accepting all beliefs as true', 'By accepting beliefs on faith without analysis', 'By critically evaluating and analyzing beliefs', 'By promoting a fixed set of beliefs'], 'correct_option': 'By critically evaluating and analyzing beliefs'},
    {'question_id': 5, 'question_text': 'Which of the following best describes philosophy’s main concern?', 'options': ['Ataining rational understanding of reality', 'Promoting a specific religion or ideology', 'Establishing moral codes for society', 'Performing religious rituals'], 'correct_option': 'Ataining rational understanding of reality'},
    {'question_id': 6, 'question_text': 'What is the core difference between philosophy and religion regarding their beliefs and practices?', 'options': ['Religion is speculative, philosophy is rational', 'Religion is focused on worship and morality, philosophy is about rational inquiry', 'Religion deals only with the mind, philosophy with emotions', 'Philosophy practices rituals, religion seeks understanding'], 'correct_option': 'Religion is focused on worship and morality, philosophy is about rational inquiry'},
    {'question_id': 7, 'question_text': 'What does philosophy aim to do with religious ideas?', 'options': ['Philosophy promotes religious belief', 'Philosophy criticizes all religious beliefs', 'Philosophy explains and makes religious ideas intelligible', 'Philosophy rejects religion completely'], 'correct_option': 'Philosophy explains and makes religious ideas intelligible'},
    {'question_id': 8, 'question_text': 'What role does faith play in religion, according to the text?', 'options': ['Faith is secondary to reason', 'Faith is unquestionable and absolute', 'Faith is used to guide rational inquiry', 'Faith is not emphasized in religion'], 'correct_option': 'Faith is unquestionable and absolute'},
    {'question_id': 9, 'question_text': 'What is the main philosophical argument against religious absolutism?', 'options': ['Faith is not important', 'Religions are all equally true', 'Every religion is a product of a particular culture and thus cannot claim to be the only true religion', 'Philosophy and religion cannot coexist'], 'correct_option': 'Every religion is a product of a particular culture and thus cannot claim to be the only true religion'},
    {'question_id': 10, 'question_text': 'According to the text, what mindset leads to religious conflict?', 'options': ['Complementary existence', 'Negative, exclusivist, and disjunctive mindset', 'Rational inquiry', 'Universal understanding of religious truths'], 'correct_option': 'Negative, exclusivist, and disjunctive mindset'},
    {'question_id': 11, 'question_text': 'Which concept describes the idea that different religions can coexist peacefully?', 'options': ['Exclusivism', 'Complementary existence', 'Religious absolutism', 'Secularism'], 'correct_option': 'Complementary existence'},
    {'question_id': 12, 'question_text': 'What does the Hegelian concept of dialectics promote?', 'options': ['Conflict of opposites as the foundation of truth', 'Complementary existence', 'Religious absolutism', 'Unquestionable dogmas'], 'correct_option': 'Conflict of opposites as the foundation of truth'},
    {'question_id': 13, 'question_text': 'Why is religion considered a force of unity?', 'options': ['It binds people in relation to God and each other', 'It imposes dogmatic rules without exception', 'It demands submission to a single ideology', 'It creates division between different belief systems'], 'correct_option': 'It binds people in relation to God and each other'},
    {'question_id': 14, 'question_text': 'What does philosophical inquiry aim to do in the context of religious conflict?', 'options': ['Promote the exclusivity of religions', 'Offer a critical examination of the root causes of conflict', 'Impose a single religious belief on all', 'Reject all forms of religious belief'], 'correct_option': 'Offer a critical examination of the root causes of conflict'},
    {'question_id': 15, 'question_text': 'What is the role of education in religious conflict resolution?', 'options': ['To impose the truth of one religion', 'To educate about other religions for better understanding and respect', 'To reject all religions as irrational', 'To teach only the superiority of one religion'], 'correct_option': 'To educate about other religions for better understanding and respect'},
    {'question_id': 16, 'question_text': 'How does philosophy contribute to resolving religious violence?', 'options': ['By encouraging violence to defend one’s beliefs', 'By promoting dialogue and critical thinking', 'By denying the existence of God', 'By promoting dogmatic absolutism'], 'correct_option': 'By promoting dialogue and critical thinking'},
    {'question_id': 17, 'question_text': 'What is one danger of blind assumptions in religion?', 'options': ['They lead to open-mindedness', 'They promote peace and coexistence', 'They can result in violence and conflict', 'They encourage critical thinking'], 'correct_option': 'They can result in violence and conflict'},
    {'question_id': 18, 'question_text': 'What does the philosophy of complementarity suggest for religious coexistence?', 'options': ['Religions should try to dominate others', 'Religions should seek harmony through mutual respect', 'Religions should reject each other completely', 'Religions should force others to convert'], 'correct_option': 'Religions should seek harmony through mutual respect'},
    {'question_id': 19, 'question_text': 'How does the exclusivist mindset affect religious harmony?', 'options': ['It fosters cooperation and mutual respect', 'It leads to understanding and peaceful coexistence', 'It creates division and conflict', 'It promotes open dialogue'], 'correct_option': 'It creates division and conflict'},
    {'question_id': 20, 'question_text': 'What does philosophy reveal about the nature of true religion?', 'options': ['It leads to conflict and division', 'It should foster peace, unity, and understanding', 'It supports violence to defend beliefs', 'It focuses on rituals and ceremonies'], 'correct_option': 'It should foster peace, unity, and understanding'},
    {'question_id': 21, 'question_text': 'Which of the following is true according to the text regarding religious violence?', 'options': ['Violence is often justified by religious dogmas', 'Religious violence is a necessary part of faith', 'Religious violence results from ignorance and misunderstanding', 'Religious violence is endorsed by all religions'], 'correct_option': 'Religious violence results from ignorance and misunderstanding'},
    {'question_id': 22, 'question_text': 'What does the text suggest about resolving religious conflicts?', 'options': ['Religious conflict cannot be resolved', 'Religious conflict is resolved through violence', 'Philosophy can help resolve conflicts through critical thought and dialogue', 'Religious conflict is a natural outcome of differing beliefs'], 'correct_option': 'Philosophy can help resolve conflicts through critical thought and dialogue'},
    {'question_id': 23, 'question_text': 'What is the philosophical view on the role of religion in society?', 'options': ['Religion should dominate all other spheres of life', 'Religion is a force for unity, not division', 'Religion should be kept separate from all aspects of life', 'Religion should create conflicts for dominance'], 'correct_option': 'Religion is a force for unity, not division'},
    {'question_id': 24, 'question_text': 'What does the text argue about the nature of religious absolutism?', 'options': ['It is necessary for peace and unity', 'It prevents conflict by defining clear boundaries', 'It leads to a rejection of other cultures and religions', 'It promotes complementary existence between different religions'], 'correct_option': 'It leads to a rejection of other cultures and religions'},
    {'question_id': 25, 'question_text': 'How does philosophy view the existence of different religions?', 'options': ['As incompatible and exclusive', 'As complementary and worthy of respect', 'As unimportant to human experience', 'As irrelevant to the quest for truth'], 'correct_option': 'As complementary and worthy of respect'},
    {'question_id': 26, 'question_text': 'What does the text suggest as a solution to religious conflict in society?', 'options': ['Forced conversion', 'Promotion of a single religion', 'Mutual respect and understanding through education and dialogue', 'Complete separation of religion and state'], 'correct_option': 'Mutual respect and understanding through education and dialogue'},
    {'question_id': 27, 'question_text': 'How does the concept of "complementary existence" contribute to religious peace?', 'options': ['By promoting religious dominance', 'By fostering conflict between different beliefs', 'By encouraging respect and cooperation among different religions', 'By encouraging a single dominant religious worldview'], 'correct_option': 'By encouraging respect and cooperation among different religions'},
    {'question_id': 28, 'question_text': 'What is one characteristic of a philosophical approach to religious belief?', 'options': ['Faith without questioning', 'Critical evaluation of ideas', 'Unquestionable adherence to religious dogma', 'Ritual-based practices'], 'correct_option': 'Critical evaluation of ideas'},
    {'question_id': 29, 'question_text': 'What does the philosophy of religion attempt to explain?', 'options': ['The superiority of one religion over others', 'The underlying truths in all religions', 'The historical accuracy of religious texts', 'The religious rituals and ceremonies'], 'correct_option': 'The underlying truths in all religions'},
    {'question_id': 30, 'question_text': 'What is the primary focus of religious philosophy?', 'options': ['To establish the dominance of one religion', 'To rationally explore and explain religious beliefs', 'To create religious practices', 'To deny the existence of God'], 'correct_option': 'To rationally explore and explain religious beliefs'},
    {'question_id': 31, 'question_text': 'What is the etymological meaning of the word "philosophy"?', 'options': ['Love of wisdom', 'Search for knowledge', 'Science of life', 'Study of existence'], 'correct_option': 'Love of wisdom'},
    {'question_id': 32, 'question_text': 'How does Josef Pieper describe the engagement with philosophy?', 'options': ['Reflecting on the totality of human existence', 'Studying specific aspects of the universe', 'Critiquing religious beliefs', 'Focusing on individual experiences alone'], 'correct_option': 'Reflecting on the totality of human existence'},
    {'question_id': 33, 'question_text': 'Which branch of philosophy specifically examines religion?', 'options': ['Philosophy of Religion', 'Metaphysics', 'Ethics', 'Epistemology'], 'correct_option': 'Philosophy of Religion'},
    {'question_id': 34, 'question_text': 'What does the term "wisdom" signify in philosophy?', 'options': ['Ability to solve life’s difficult problems through rational answers', 'Knowledge of the supernatural', 'Memorization of religious texts', 'Understanding only material reality'], 'correct_option': 'Ability to solve life’s difficult problems through rational answers'},
    {'question_id': 35, 'question_text': 'According to Udoidem, what does philosophy represent?', 'options': ['The irresistible desire for the universal principles of things', 'A reflection of cultural traditions', 'The study of human emotions', 'An academic subject with no practical application'], 'correct_option': 'The irresistible desire for the universal principles of things'},
    {'question_id': 36, 'question_text': 'What does philosophy attempt to achieve in its inquiry?', 'options': ['A comprehensive, systematic, critical, and rational exploration of reality', 'To interpret religious experiences', 'To disprove the existence of deities', 'To reflect on personal emotional experiences'], 'correct_option': 'A comprehensive, systematic, critical, and rational exploration of reality'},
    {'question_id': 37, 'question_text': 'How do philosophers approach problems in society?', 'options': ['Through critical thinking, argumentation, and reasoning', 'By memorizing doctrines', 'By following societal conventions', 'By following intuitive, non-reflective methods'], 'correct_option': 'Through critical thinking, argumentation, and reasoning'},
    {'question_id': 38, 'question_text': 'What aspect of society is often overlooked by critics of philosophy?', 'options': ['Its practical relevance', 'The importance of religious studies', 'The political implications', 'Its connection to popular culture'], 'correct_option': 'Its practical relevance'},
    {'question_id': 39, 'question_text': 'What is the primary purpose of philosophy according to its etymology?', 'options': ['To guide society towards rational living and truth', 'To explore the supernatural realm', 'To accumulate historical knowledge', 'To challenge scientific advancements'], 'correct_option': 'To guide society towards rational living and truth'},
    {'question_id': 40, 'question_text': 'What does religion etymologically refer to?', 'options': ['A relationship that binds humans to the divine', 'A system of ethical principles', 'A code of conduct for political life', 'A set of social rituals'], 'correct_option': 'A relationship that binds humans to the divine'},
    {'question_id': 41, 'question_text': 'According to Durkheim, what is religion?', 'options': ['A unified system of beliefs and practices relative to sacred things', 'A personal set of beliefs without collective importance', 'A form of social control based solely on legal authority', 'A way of separating the sacred from the profane'], 'correct_option': 'A unified system of beliefs and practices relative to sacred things'},
    {'question_id': 42, 'question_text': 'What does religion provide in terms of worldview?', 'options': ['A framework to understand reality and the meaning of existence', 'A collection of unchangeable dogmas', 'A scientific approach to understanding the world', 'A focus on personal material gain'], 'correct_option': 'A framework to understand reality and the meaning of existence'},
    {'question_id': 43, 'question_text': 'What is the relationship between religion and culture?', 'options': ['Religion is deeply intertwined with the culture in which it exists', 'Religion has no relationship with culture', 'Religion shapes culture, but is independent of it', 'Religion exists only in isolated communities, unaffected by culture'], 'correct_option': 'Religion is deeply intertwined with the culture in which it exists'},
    {'question_id': 44, 'question_text': 'What does Omoregbe assert about religious beliefs?', 'options': ['They are deeply tied to a particular cultural context', 'They are universally the same across cultures', 'They are based solely on science and logic', 'They are irrelevant to moral guidance'], 'correct_option': 'They are deeply tied to a particular cultural context'},
    {'question_id': 45, 'question_text': 'What role does religion play in providing a sense of purpose?', 'options': ['It offers answers to existential questions about the origin and destiny of life', 'It encourages a focus on personal wealth', 'It prioritizes intellectual knowledge over spiritual beliefs', 'It promotes a secular worldview devoid of spiritual answers'], 'correct_option': 'It offers answers to existential questions about the origin and destiny of life'},
    {'question_id': 46, 'question_text': 'What is the moral function of religion?', 'options': ['To teach and encourage ethical principles and moral living', 'To reinforce social hierarchies and power structures', 'To promote scientific inquiry', 'To advocate for complete moral relativism'], 'correct_option': 'To teach and encourage ethical principles and moral living'},
    {'question_id': 47, 'question_text': 'How does religion contribute to community building?', 'options': ['By providing spaces for communal worship, prayer, and support', 'By promoting individualism and isolation', 'By encouraging competition over cooperation', 'By restricting participation based on strict doctrinal beliefs'], 'correct_option': 'By providing spaces for communal worship, prayer, and support'},
    {'question_id': 48, 'question_text': 'What spiritual function does religion fulfill?', 'options': ['It connects humans with the divine and provides spiritual guidance', 'It focuses only on material success', 'It rejects all forms of supernatural beliefs', 'It emphasizes individual independence without spiritual connection'], 'correct_option': 'It connects humans with the divine and provides spiritual guidance'},
    {'question_id': 49, 'question_text': 'How does religion help individuals cope with adversity?', 'options': ['By offering comfort, hope, and spiritual resilience', 'By promoting complete detachment from emotional struggles', 'By denying the existence of suffering in life', 'By encouraging materialism as a solution to adversity'], 'correct_option': 'By offering comfort, hope, and spiritual resilience'},
    {'question_id': 50, 'question_text': 'What is a key philosophical question regarding the relationship between philosophy and religion?', 'options': ['How can they mutually benefit and influence each other?', 'Should religion dominate philosophy in all areas?', 'Is philosophy more important than religious faith?', 'Can philosophy be entirely separate from religious views?'], 'correct_option': 'How can they mutually benefit and influence each other?'},
    {'question_id': 51, 'question_text': 'What has historically caused tensions between philosophy and religion?', 'options': ['Philosophers challenging religious beliefs and divine wisdom', 'Philosophy advocating for greater reliance on religious faith', 'Religions pushing for the abandonment of philosophy', 'Philosophers and religious leaders collaborating too closely'], 'correct_option': 'Philosophers challenging religious beliefs and divine wisdom'},
    {'question_id': 52, 'question_text': 'In what way can philosophy enrich religion?', 'options': ['By providing critical thinking and rational inquiry that deepens religious understanding', 'By promoting the abandonment of religious traditions', 'By reducing the importance of divine wisdom', 'By focusing only on abstract metaphysical issues'], 'correct_option': 'By providing critical thinking and rational inquiry that deepens religious understanding'},
    {'question_id': 53, 'question_text': 'Which element of philosophy helps to understand religious practices?', 'options': ['Critical and reflective thinking', 'Religious dogma', 'Revelation alone', 'Cultural traditions'], 'correct_option': 'Critical and reflective thinking'},
    {'question_id': 54, 'question_text': 'What does the concept of "sacred" refer to in religion?', 'options': ['Things that are set apart and forbidden, often revered as holy', 'Things that are simply historical artifacts', 'Anything that is considered mundane and unimportant', 'Only physical objects used in rituals'], 'correct_option': 'Things that are set apart and forbidden, often revered as holy'},
    {'question_id': 55, 'question_text': 'How can philosophy contribute to resolving conflicts arising from religion?', 'options': ['By promoting rational dialogue and critical reflection', 'By enforcing religious conformity', 'By rejecting all religious beliefs', 'By limiting religious freedom'], 'correct_option': 'By promoting rational dialogue and critical reflection'},
    {'question_id': 56, 'question_text': 'What is the primary aim of philosophy in relation to human co-existence?', 'options': ['To foster rational discourse that enhances mutual understanding and cooperation', 'To establish rigid social structures', 'To promote individualism over collective well-being', 'To dictate religious beliefs to all individuals'], 'correct_option': 'To foster rational discourse that enhances mutual understanding and cooperation'}
]


chapter9 = [
    {'question_id': 1, 'question_text': 'What is the primary misconception about philosophy in the 21st century?', 'options': ['It is irrelevant to society', 'It is only concerned with abstract realities', 'It focuses on material goods', 'It promotes scientific values'], 'correct_option': 'It is irrelevant to society'},
    {'question_id': 2, 'question_text': 'Who coined the term "philosophy" and what did it mean?', 'options': ['Socrates, the study of wisdom', 'Plato, the love of wisdom', 'Pythagoras, the love of wisdom', 'Aristotle, the study of reason'], 'correct_option': 'Pythagoras, the love of wisdom'},
    {'question_id': 3, 'question_text': 'How does philosophy contribute to human society?', 'options': ['By producing material goods', 'By enhancing intellectual and social development', 'By focusing on religious teachings', 'By limiting the pursuit of knowledge'], 'correct_option': 'By enhancing intellectual and social development'},
    {'question_id': 4, 'question_text': 'What is the core value of philosophy according to Uduigwomen?', 'options': ['It makes life worth living', 'It produces material wealth', 'It supports dogmatism', 'It focuses on faith alone'], 'correct_option': 'It makes life worth living'},
    {'question_id': 5, 'question_text': 'What does a philosopher seek according to the definition of Pythagoras?', 'options': ['Wisdom through constant effort', 'Material success', 'Abstract knowledge', 'A set of fixed truths'], 'correct_option': 'Wisdom through constant effort'},
    {'question_id': 6, 'question_text': 'How does philosophy differ from religion?', 'options': ['Religion uses reason, philosophy does not', 'Philosophy is based on faith, religion on reason', 'Philosophy uses reason, religion uses faith', 'Both are concerned with the supernatural'], 'correct_option': 'Philosophy uses reason, religion uses faith'},
    {'question_id': 7, 'question_text': 'Which of the following best describes the method of philosophy?', 'options': ['Speculation without evidence', 'Critical inquiry and rational reflection', 'Blind acceptance of truth', 'Focus on material production'], 'correct_option': 'Critical inquiry and rational reflection'},
    {'question_id': 8, 'question_text': 'What is one characteristic of a philosopher as described in the text?', 'options': ['A person who knows all answers', 'A person who loves wisdom and seeks knowledge', 'A person who blindly follows societal beliefs', 'A person who avoids questioning'], 'correct_option': 'A person who loves wisdom and seeks knowledge'},
    {'question_id': 9, 'question_text': 'What does philosophy aim to do when it critiques ideas?', 'options': ['Provide immediate answers', 'Critically evaluate and improve ideas', 'Support popular beliefs', 'Promote personal beliefs'], 'correct_option': 'Critically evaluate and improve ideas'},
    {'question_id': 10, 'question_text': 'Which term best unites the methods used in philosophy?', 'options': ['Rationality and criticality', 'Dogmatism and routine', 'Speculation and faith', 'Authority and obedience'], 'correct_option': 'Rationality and criticality'},
    {'question_id': 11, 'question_text': 'How does philosophy contribute to freedom from dogmatism?', 'options': ['By blindly following tradition', 'By questioning societal and cultural beliefs', 'By accepting religious dogma', 'By focusing on unchanging truths'], 'correct_option': 'By questioning societal and cultural beliefs'},
    {'question_id': 12, 'question_text': 'Which of the following philosophers was known for his criticism of dogmatism?', 'options': ['Aristotle', 'Socrates', 'John Locke', 'Karl Popper'], 'correct_option': 'Socrates'},
    {'question_id': 13, 'question_text': 'Which value of philosophy allows individuals to stand out in society?', 'options': ['Intellectual independence', 'Conformity to societal norms', 'Material success', 'Religious devotion'], 'correct_option': 'Intellectual independence'},
    {'question_id': 14, 'question_text': 'How did early Greek philosophers influence political awareness?', 'options': ['By establishing a monarchy', 'By developing democratic principles', 'By avoiding political engagement', 'By promoting authoritarian rule'], 'correct_option': 'By developing democratic principles'},
    {'question_id': 15, 'question_text': 'What role does philosophy play in political participation?', 'options': ['It promotes authoritarianism', 'It fosters political consciousness and awareness', 'It discourages political involvement', 'It focuses solely on economic issues'], 'correct_option': 'It fosters political consciousness and awareness'},
    {'question_id': 16, 'question_text': 'How does philosophy contribute to religious neutrality?', 'options': ['By supporting all religious views equally', 'By using reason rather than faith in religious matters', 'By promoting religious dogma', 'By defending specific religious doctrines'], 'correct_option': 'By using reason rather than faith in religious matters'},
    {'question_id': 17, 'question_text': 'What does philosophy help to critically analyze in relation to religion?', 'options': ['Religious dogma and rituals', 'Scientific theories', 'Political policies', 'Cultural practices'], 'correct_option': 'Religious dogma and rituals'},
    {'question_id': 18, 'question_text': 'What is a key social value that philosophy promotes?', 'options': ['Narrow-mindedness', 'Intellectual independence', 'Religious extremism', 'Conformity'], 'correct_option': 'Intellectual independence'},
    {'question_id': 19, 'question_text': 'How does philosophy contribute to a better understanding of religion?', 'options': ['By endorsing specific religious practices', 'By critically analyzing religious beliefs', 'By promoting religious conformity', 'By avoiding religious issues'], 'correct_option': 'By critically analyzing religious beliefs'},
    {'question_id': 20, 'question_text': 'What is one of the dangers that philosophy helps people avoid?', 'options': ['Open-mindedness', 'Narrow-mindedness', 'Religious tolerance', 'Cultural diversity'], 'correct_option': 'Narrow-mindedness'},
    {'question_id': 21, 'question_text': 'What is the role of philosophy in relation to science?', 'options': ['It critiques scientific methods', 'It ignores scientific developments', 'It supports the material aspects of science', 'It is foundational to scientific inquiry'], 'correct_option': 'It is foundational to scientific inquiry'},
    {'question_id': 22, 'question_text': 'Who were some of the early philosopher-scientists?', 'options': ['Plato and Aristotle', 'Newton and Kepler', 'Socrates and Descartes', 'Einstein and Popper'], 'correct_option': 'Newton and Kepler'},
    {'question_id': 23, 'question_text': 'What does the term "Queen of the Sciences" refer to?', 'options': ['Philosophy', 'Mathematics', 'Biology', 'Physics'], 'correct_option': 'Philosophy'},
    {'question_id': 24, 'question_text': 'What is one contribution of philosophy to scientific inquiry?', 'options': ['Providing direct scientific experiments', 'Critically examining scientific assumptions', 'Replacing scientific methods', 'Limiting scientific exploration'], 'correct_option': 'Critically examining scientific assumptions'},
    {'question_id': 25, 'question_text': 'What did early philosophers, such as Aristotle, contribute to various disciplines?', 'options': ['Solely focusing on ethics', 'Contributing to fields like biology, physics, and astronomy', 'Rejecting scientific inquiry', 'Limiting their work to logic'], 'correct_option': 'Contributing to fields like biology, physics, and astronomy'},
    {'question_id': 26, 'question_text': 'Which philosopher-scientist was known for his work on the laws of motion and gravity?', 'options': ['Aristotle', 'Galileo', 'Newton', 'Bohr'], 'correct_option': 'Newton'},
    {'question_id': 27, 'question_text': 'What is one way science has impacted human society?', 'options': ['By limiting technological development', 'By improving agriculture, health, and infrastructure', 'By focusing on abstract knowledge', 'By rejecting philosophy'], 'correct_option': 'By improving agriculture, health, and infrastructure'},
    {'question_id': 28, 'question_text': 'What is the relationship between philosophy and modern science?', 'options': ['Science grew out of philosophy and is still rooted in it', 'Philosophy is irrelevant to science', 'Science rejects all philosophical methods', 'Philosophy and science are completely separate'], 'correct_option': 'Science grew out of philosophy and is still rooted in it'},
    {'question_id': 29, 'question_text': 'Which philosopher is often called the father of modern science?', 'options': ['Descartes', 'Aristotle', 'Francis Bacon', 'Kant'], 'correct_option': 'Francis Bacon'},
    {'question_id': 30, 'question_text': 'What role does philosophy play in scientific ethics?', 'options': ['It has no role', 'It guides moral decisions in scientific research', 'It limits scientific experimentation', 'It solely supports technological advancement'], 'correct_option': 'It guides moral decisions in scientific research'},
    {'question_id': 31, 'question_text': 'Which of the following best describes scientific values?', 'options': ['They focus only on empirical evidence', 'They are rooted in rational inquiry and critical thinking', 'They avoid philosophy', 'They ignore the social implications of research'], 'correct_option': 'They are rooted in rational inquiry and critical thinking'},
    {'question_id': 32, 'question_text': 'What was the impact of Socrates on the development of Western philosophy?', 'options': ['He focused only on politics', 'He introduced the Socratic method of questioning', 'He rejected the use of reason', 'He was a supporter of religious dogma'], 'correct_option': 'He introduced the Socratic method of questioning'},
    {'question_id': 33, 'question_text': 'How does philosophy influence scientific progress?', 'options': ['By providing a foundation for scientific methods and inquiry', 'By rejecting technological advances', 'By isolating scientific fields from human experience', 'By preventing scientific exploration'], 'correct_option': 'By providing a foundation for scientific methods and inquiry'},
    {'question_id': 34, 'question_text': 'What is one significant impact of philosophy on social values?', 'options': ['It promotes blind acceptance of tradition', 'It encourages critical reflection and independence of thought', 'It rejects new ideas', 'It focuses on material success'], 'correct_option': 'It encourages critical reflection and independence of thought'},
    {'question_id': 35, 'question_text': 'Which philosopher was known for his ideas about the mind and knowledge, contributing significantly to modern science?', 'options': ['Rene Descartes', 'Immanuel Kant', 'John Locke', 'David Hume'], 'correct_option': 'Rene Descartes'},
    {'question_id': 36, 'question_text': 'How does philosophy contribute to the development of scientific knowledge?', 'options': ['By directly producing scientific data', 'By questioning assumptions and encouraging deeper inquiry', 'By focusing on practical experiments', 'By rejecting scientific theories'], 'correct_option': 'By questioning assumptions and encouraging deeper inquiry'},
    {'question_id': 37, 'question_text': 'What did Copernicus and Galileo contribute to science?', 'options': ['The development of logical reasoning', 'Revolutionizing our understanding of the universe', 'Consolidating religious dogma', 'Rejecting scientific inquiry'], 'correct_option': 'Revolutionizing our understanding of the universe'},
    {'question_id': 38, 'question_text': 'What role does philosophy play in the ethics of scientific advancements?', 'options': ['It has no role', 'It helps scientists consider the moral implications of their work', 'It limits scientific progress', 'It rejects the ethical considerations'], 'correct_option': 'It helps scientists consider the moral implications of their work'},
    {'question_id': 39, 'question_text': 'Which philosopher questioned the nature of knowledge and the mind, significantly shaping the philosophy of science?', 'options': ['David Hume', 'René Descartes', 'Karl Popper', 'John Locke'], 'correct_option': 'René Descartes'},
    {'question_id': 40, 'question_text': 'What is the impact of philosophy on political awareness?', 'options': ['It avoids political discussions', 'It encourages reflection on political values and social structures', 'It promotes authoritarian rule', 'It focuses only on individualism'], 'correct_option': 'It encourages reflection on political values and social structures'},
    {'question_id': 41, 'question_text': 'How did philosophers such as Plato and Aristotle contribute to politics?', 'options': ['By promoting democracy and ethics in governance', 'By focusing only on metaphysics', 'By rejecting government systems', 'By supporting religious dominance'], 'correct_option': 'By promoting democracy and ethics in governance'},
    {'question_id': 42, 'question_text': 'Which philosophical value helps individuals avoid bias or narrow perspectives?', 'options': ['Dogmatism', 'Critical reflection', 'Faith in tradition', 'Materialism'], 'correct_option': 'Critical reflection'},
    {'question_id': 43, 'question_text': 'What role did Aristotle’s philosophy play in shaping modern science?', 'options': ['It rejected scientific experimentation', 'It laid the groundwork for many scientific disciplines', 'It focused solely on logic', 'It ignored natural phenomena'], 'correct_option': 'It laid the groundwork for many scientific disciplines'},
    {'question_id': 44, 'question_text': 'What does philosophy encourage when faced with unchallenged beliefs?', 'options': ['Conformity', 'Critical questioning and re-evaluation', 'Blind faith', 'Rejection of reason'], 'correct_option': 'Critical questioning and re-evaluation'},
    {'question_id': 45, 'question_text': 'What is one contribution of philosophy to social values?', 'options': ['Promoting collective social belief without questioning', 'Encouraging critical thinking and independent reasoning', 'Avoiding critical evaluation of societal norms', 'Focusing solely on individual success'], 'correct_option': 'Encouraging critical thinking and independent reasoning'},
    {'question_id': 46, 'question_text': 'What is the connection between science and philosophy regarding methods?', 'options': ['Philosophy develops methods that are independent of science', 'Science uses philosophical principles to guide research methods', 'Philosophy rejects scientific inquiry', 'Science and philosophy do not share any methods'], 'correct_option': 'Science uses philosophical principles to guide research methods'},
    {'question_id': 47, 'question_text': 'What did Plato and Aristotle contribute to the development of scientific inquiry?', 'options': ['They rejected empirical methods', 'They laid the foundations for logic and empirical investigation', 'They avoided critical thinking', 'They solely focused on metaphysics'], 'correct_option': 'They laid the foundations for logic and empirical investigation'},
    {'question_id': 48, 'question_text': 'What is one key feature of scientific inquiry shaped by philosophy?', 'options': ['Empirical data collection', 'The use of critical reasoning and questioning', 'Complete reliance on tradition', 'Focus on material gains'], 'correct_option': 'The use of critical reasoning and questioning'},
    {'question_id': 49, 'question_text': 'How did philosophers such as Copernicus and Galileo change our understanding of the universe?', 'options': ['They supported religious teachings', 'They questioned and redefined the earth’s position in the universe', 'They rejected scientific methods', 'They focused on abstract speculation'], 'correct_option': 'They questioned and redefined the earth’s position in the universe'},
    {'question_id': 50, 'question_text': 'How does philosophy support scientific progress?', 'options': ['By developing technological tools', 'By challenging assumptions and encouraging deeper questions', 'By solely focusing on practical applications', 'By rejecting scientific methods'], 'correct_option': 'By challenging assumptions and encouraging deeper questions'},
    {'question_id': 51, 'question_text': 'How does philosophy influence the outcomes of science?', 'options': ['By inventing technological tools', 'By framing questions and providing logical reasoning', 'By focusing on empirical data only', 'By avoiding critical analysis'], 'correct_option': 'By framing questions and providing logical reasoning'},
    {'question_id': 52, 'question_text': 'What is the primary focus of philosophy in relation to science?', 'options': ['Understanding the methods and assumptions of science', 'Providing scientific facts', 'Rejecting scientific theories', 'Focusing only on abstract ideas'], 'correct_option': 'Understanding the methods and assumptions of science'},
    {'question_id': 53, 'question_text': 'What does philosophy examine when it studies the methods of science?', 'options': ['The ethics of scientific research', 'The consistency of scientific procedures', 'The results of experiments', 'The technology used in experiments'], 'correct_option': 'The consistency of scientific procedures'},
    {'question_id': 54, 'question_text': 'How does philosophy assist science in examining assumptions about reality?', 'options': ['By questioning the validity of scientific data', 'By clarifying and analyzing the assumptions behind scientific theories', 'By rejecting scientific findings', 'By promoting religious beliefs over scientific facts'], 'correct_option': 'By clarifying and analyzing the assumptions behind scientific theories'},
    {'question_id': 55, 'question_text': 'What is conceptual analysis in philosophy as applied to science?', 'options': ['The study of scientific laws', 'The attempt to define concepts in a way that makes them scientifically studyable', 'The process of developing new technologies', 'The exploration of supernatural phenomena'], 'correct_option': 'The attempt to define concepts in a way that makes them scientifically studyable'},
    {'question_id': 56, 'question_text': 'What does conceptual and ideational synthesis in philosophy aim to achieve?', 'options': ['To create new scientific methods', 'To merge the findings of different scientific disciplines into one unified view of reality', 'To focus on one specific scientific field', 'To create scientific tools for research'], 'correct_option': 'To merge the findings of different scientific disciplines into one unified view of reality'},
    {'question_id': 57, 'question_text': 'How does philosophy contribute to the curiosity of scientists?', 'options': ['By discouraging independent thought', 'By promoting superstition', 'By encouraging curiosity about nature, beliefs, and actions', 'By focusing only on material success'], 'correct_option': 'By encouraging curiosity about nature, beliefs, and actions'},
    {'question_id': 58, 'question_text': 'What is the role of dialectics in scientific inquiry as promoted by philosophy?', 'options': ['To avoid asking difficult questions', 'To engage in logical reasoning through dialogue and questioning', 'To follow established scientific methods without deviation', 'To focus on trial and error'], 'correct_option': 'To engage in logical reasoning through dialogue and questioning'},
    {'question_id': 59, 'question_text': 'What distinguishes scientific curiosity from superstition, according to the text?', 'options': ['Science is based on unproven myths', 'Science uses trial and error exclusively', 'Science relies on curiosity and logical reasoning, while superstition relies on unverified myths', 'Science avoids critical questions'], 'correct_option': 'Science relies on curiosity and logical reasoning, while superstition relies on unverified myths'},
    {'question_id': 60, 'question_text': 'How does philosophy contribute to explaining scientific theories?', 'options': ['By explaining why things happen, not just how', 'By dismissing scientific facts', 'By providing only practical solutions', 'By ignoring the cause behind events'], 'correct_option': 'By explaining why things happen, not just how'},
    {'question_id': 61, 'question_text': 'What is the relationship between science and philosophy in explaining the physical world?', 'options': ['Science explains how things occur, and philosophy explains why things occur', 'Science explains everything, and philosophy is irrelevant', 'Philosophy ignores scientific facts', 'Philosophy rejects empirical data'], 'correct_option': 'Science explains how things occur, and philosophy explains why things occur'},
    {'question_id': 62, 'question_text': 'What is objectivity in the context of philosophy and science?', 'options': ['Science is subjective, philosophy is not', 'Philosophy is concerned with personal beliefs, science with facts', 'Science deals with objective facts, while philosophy explains general principles behind those facts', 'Both science and philosophy are subjective'], 'correct_option': 'Science deals with objective facts, while philosophy explains general principles behind those facts'},
    {'question_id': 63, 'question_text': 'What is the value of philosophy in the judgment and evaluation of scientific theories?', 'options': ['Philosophy evaluates the criteria of acceptability used by scientists in judging theories', 'Philosophy rejects scientific theories', 'Philosophy provides specific scientific data', 'Philosophy ignores scientific claims'], 'correct_option': 'Philosophy evaluates the criteria of acceptability used by scientists in judging theories'},
    {'question_id': 64, 'question_text': 'What is the role of philosophy as a "watchdog" over other disciplines, including science?', 'options': ['It disregards scientific findings', 'It evaluates the claims and methods used in other disciplines to ensure logical consistency', 'It only focuses on social matters', 'It rejects the scientific method entirely'], 'correct_option': 'It evaluates the claims and methods used in other disciplines to ensure logical consistency'},
    {'question_id': 65, 'question_text': 'According to Ishaya, what is the most important role of philosophy in scientific research?', 'options': ['To provide scientific data directly', 'To critique the scientific method and theories', 'To reject all scientific findings', 'To focus on the technological aspects of science'], 'correct_option': 'To critique the scientific method and theories'},
    {'question_id': 66, 'question_text': 'What does philosophy aim to achieve by analyzing the methods of science?', 'options': ['To prove that science is wrong', 'To assess whether scientific methods are consistent and logical', 'To replace science with metaphysical ideas', 'To avoid scientific experimentation'], 'correct_option': 'To assess whether scientific methods are consistent and logical'},
    {'question_id': 67, 'question_text': 'How does philosophy help scientists avoid reliance on superstition?', 'options': ['By promoting unverified myths', 'By encouraging critical thinking and curiosity based on facts', 'By rejecting empirical data', 'By focusing on religious beliefs'], 'correct_option': 'By encouraging critical thinking and curiosity based on facts'},
    {'question_id': 68, 'question_text': 'What is the value of curiosity in science, as emphasized by philosophy?', 'options': ['Curiosity drives blind belief', 'Curiosity helps scientists explore the unknown and refine scientific theories', 'Curiosity should be avoided in scientific research', 'Curiosity leads to unreliable results'], 'correct_option': 'Curiosity helps scientists explore the unknown and refine scientific theories'},
    {'question_id': 69, 'question_text': 'What does philosophy contribute to the explanation of scientific phenomena?', 'options': ['It only explains abstract ideas', 'It focuses on providing reasons for why phenomena occur', 'It avoids offering explanations for scientific events', 'It provides only materialistic explanations'], 'correct_option': 'It focuses on providing reasons for why phenomena occur'},
    {'question_id': 70, 'question_text': 'What is the importance of judgment and evaluation in the relationship between philosophy and science?', 'options': ['Philosophy judges the success of experiments', 'Philosophy evaluates the logical principles behind scientific theories and methods', 'Philosophy rejects scientific claims without evaluation', 'Philosophy determines the scientific results'], 'correct_option': 'Philosophy evaluates the logical principles behind scientific theories and methods'},
    {'question_id': 71, 'question_text': 'How does philosophy contribute to scientific progress?', 'options': ['By providing direct experimental data', 'By questioning the assumptions and methods of science', 'By rejecting scientific ideas', 'By focusing solely on technology'], 'correct_option': 'By questioning the assumptions and methods of science'},
    {'question_id': 72, 'question_text': 'What does the concept of "objectivity" mean in the context of philosophy and science?', 'options': ['Science deals with subjective beliefs, while philosophy is objective', 'Philosophy provides objective facts, while science is subjective', 'Science deals with objective facts, and philosophy explains the general principles behind them', 'Science and philosophy are both subjective'], 'correct_option': 'Science deals with objective facts, and philosophy explains the general principles behind them'},
    {'question_id': 73, 'question_text': 'What is one of the main distinctions between how science and philosophy explain phenomena?', 'options': ['Science focuses on why, while philosophy explains how', 'Philosophy provides reasons for why things happen, while science explains how they happen', 'Science provides moral guidance, while philosophy does not', 'Science only deals with facts, while philosophy avoids facts'], 'correct_option': 'Philosophy provides reasons for why things happen, while science explains how they happen'},
    {'question_id': 74, 'question_text': 'What does philosophy contribute to the formation of scientific theories?', 'options': ['It directly formulates scientific theories', 'It helps frame the questions and sets the groundwork for theoretical debates', 'It rejects scientific theories altogether', 'It only concerns itself with experimental data'], 'correct_option': 'It helps frame the questions and sets the groundwork for theoretical debates'},
    {'question_id': 75, 'question_text': 'How does philosophy evaluate the claims of science?', 'options': ['By offering no critique', 'By ensuring that scientific claims adhere to logical principles and ethical standards', 'By directly conducting experiments', 'By rejecting all scientific findings'], 'correct_option': 'By ensuring that scientific claims adhere to logical principles and ethical standards'},
    {'question_id': 76, 'question_text': 'How does philosophy play a role in the advancement of society?', 'options': ['By ignoring social institutions', 'By influencing institutions like religion, family, economy, and state', 'By focusing solely on academic subjects', 'By rejecting cultural norms'], 'correct_option': 'By influencing institutions like religion, family, economy, and state'},
    {'question_id': 77, 'question_text': 'According to Epicurus, when should people study philosophy?', 'options': ['At an old age only', 'Only when faced with a crisis', 'Always, no matter how young or old', 'Only during childhood'], 'correct_option': 'Always, no matter how young or old'},
    {'question_id': 78, 'question_text': 'What does philosophy aim to secure in society?', 'options': ['Material wealth', 'The health of the soul and society', 'Superficial progress', 'Technological advancement'], 'correct_option': 'The health of the soul and society'},
    {'question_id': 79, 'question_text': 'What is one of the ways philosophy helps science?', 'options': ['By questioning the logical foundations of scientific inquiry', 'By rejecting all scientific data', 'By focusing on technological tools', 'By ignoring empirical research'], 'correct_option': 'By questioning the logical foundations of scientific inquiry'}

]


