
from reportlab.platypus import Paragraph, Table, TableStyle, Spacer, PageBreak, Frame, flowables
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
import math
from reportlab.graphics.shapes import Drawing, Line, Circle, String
from reportlab.graphics import renderPDF


# Assumed 'styles' dictionary from user context is available here.

def get_question_1_elements(styles):
    q1_elements = []

    # --- Data for Question 1 ---
    s_data = [2.5, 5.0, 10.0, 20.0, 30.0, 40.0]
    x_data = [24.7, 23.5, 21.2, 16.0, 10.7, 5.3]
    x_prime_data = [25.7, 25.2, 22.4, 16.9, 11.2, 5.5]

    # --- Solution Content ---
    q1_elements.append(PageBreak())
    q1_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 1", styles["Heading"]))
    q1_elements.append(Spacer(1, 12))

    # A. Display the Data Table
    table_data = [
        ['s(cm)', '2.5', '5.0', '10.0', '20.0', '30.0', '40.0'],
        ['X(cm)', '24.7', '23.5', '21.2', '16.0', '10.7', '5.3'],
        ["X'(cm)", '25.7', '25.2', '22.4', '16.9', '11.2', '5.5']
    ]
    table_style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.grey),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0,0), (-1,0), 12),
        ('BACKGROUND', (0,1), (-1,-1), colors.beige),
        ('GRID', (0,0), (-1,-1), 1, colors.black),
    ])
    data_table = Table(table_data, colWidths=[1.5*cm] + [1.8*cm]*6)
    data_table.setStyle(table_style)
    q1_elements.append(Paragraph("Table 1: Experimental Readings for s, X, and X'", styles["Body"]))
    q1_elements.append(data_table)
    q1_elements.append(Spacer(1, 24))

    # B. The Graph of s against X and s against X' (ReportLab Drawing)
    q1_elements.append(Paragraph("Graph of s against X and s against X' (same axes)", styles["Body"]))

    # We use a custom Flowable to draw on the canvas directly
    class GraphFlowable(flowables.Flowable):
        def __init__(self, width, height, s_vals, x_vals, xp_vals):
            super().__init__()
            self.width = width
            self.height = height
            self.s_vals = s_vals
            self.x_vals = x_vals
            self.xp_vals = xp_vals

            # simple multipliers to stretch values to fit the graph neatly
            self.mx = 10     # X and X' horizontal spacing
            self.my = 6      # s vertical stretching

            self.margin = 40

        def draw(self):
            c = self.canv
            c.saveState()

            # axes
            c.line(self.margin, self.margin, self.width - self.margin, self.margin)  # X-axis
            c.line(self.margin, self.margin, self.margin, self.height - self.margin) # s-axis

            # labels
            c.setFont("Helvetica", 8)
            c.drawString(self.width/2 - 10, self.margin - 25, "X / X' (cm)")
            c.drawString(self.margin - 30, self.height/2, "s (cm)")

            # ---- Plot s vs X (BLUE) ----
            c.setStrokeColor(colors.blue)
            c.setFillColor(colors.blue)
            for i in range(len(self.s_vals)):
                x = self.margin + self.x_vals[i] * self.mx
                y = self.margin + self.s_vals[i] * self.my
                c.circle(x, y, 2, fill=1)
                if i > 0:
                    x_prev = self.margin + self.x_vals[i-1] * self.mx
                    y_prev = self.margin + self.s_vals[i-1] * self.my
                    c.line(x_prev, y_prev, x, y)

            # ---- Plot s vs X′ (RED) ----
            c.setStrokeColor(colors.red)
            c.setFillColor(colors.red)
            for i in range(len(self.s_vals)):
                x = self.margin + self.xp_vals[i] * self.mx
                y = self.margin + self.s_vals[i] * self.my
                c.circle(x, y, 2, fill=1)
                if i > 0:
                    x_prev = self.margin + self.xp_vals[i-1] * self.mx
                    y_prev = self.margin + self.s_vals[i-1] * self.my
                    c.line(x_prev, y_prev, x, y)

            # ---- Legend ----
            c.setStrokeColor(colors.blue)
            c.line(self.width - 120, self.height - 35, self.width - 90, self.height - 35)
            c.drawString(self.width - 85, self.height - 38, "s vs X")

            c.setStrokeColor(colors.red)
            c.line(self.width - 120, self.height - 50, self.width - 90, self.height - 50)
            c.drawString(self.width - 85, self.height - 53, "s vs X'")

            c.restoreState()

    # Append the graph flowable (Width 500 points, Height 350 points)
    q1_elements.append(GraphFlowable(500, 350, s_data, x_data, x_prime_data))
    q1_elements.append(Spacer(1, 24))


    # C. Solution Answers
    q1_elements.append(Paragraph("<b>B. Solution:</b>", styles["Body"]))
    
    q1_elements.append(Paragraph("<i>i. The point of intersection of the two graphs:</i>", styles["Body"]))
    q1_elements.append(Paragraph("The lines visually intersect near the data points for s=2.5 cm and s=5.0 cm. A linear interpolation/extrapolation or visual inspection of the plotted graph determines the exact intersection point.", styles["Body"]))
    q1_elements.append(Paragraph("Approximate Intersection Point: <b>s ≈ 4.1 cm, X ≈ X' ≈ 24.1 cm</b>.", styles["Body"]))
    q1_elements.append(Spacer(1, 12))
    
    q1_elements.append(Paragraph("<i>ii. The values of s when X = 0 and X' = 0:</i>", styles["Body"]))
    q1_elements.append(Paragraph("This is the Y-intercept (s-intercept) when X is on the X-axis (X=0). This requires extrapolating the blue line to X=0. Visually, the s-intercept for both lines appears to be just above s=40.0 cm.", styles["Body"]))
    q1_elements.append(Paragraph("Approximate value of s for X=0: <b>s ≈ 46.5 cm</b>.", styles["Body"]))
    q1_elements.append(Paragraph("Approximate value of s for X'=0: <b>s ≈ 48.0 cm</b>.", styles["Body"]))

    return q1_elements

# Example usage within your main script flow:
# q1_elements = get_question_1_elements(styles)
# elements.extend(q1_elements)


from reportlab.platypus import Paragraph, Spacer, Table, TableStyle, PageBreak, flowables
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_2_elements(styles):
    q2_elements = []

    # --- Solution Content ---
    q2_elements.append(PageBreak())
    q2_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 2", styles["Heading"]))
    q2_elements.append(Spacer(1, 12))

    q2_elements.append(Paragraph("<b>Question 2: Volume and Error Analysis</b>", styles["Body"]))
    q2_elements.append(Paragraph("Given measurements for a rod:", styles["Body"]))
    q2_elements.append(Paragraph("Radius (r) = 1.02 ± 0.01 cm", styles["Body"]))
    q2_elements.append(Paragraph("Length (h) = 6.1 ± 0.1 cm", styles["Body"]))
    q2_elements.append(Spacer(1, 12))

    # A. Determine the maximum error in volume (ΔV)
    q2_elements.append(Paragraph("<b>(a) Maximum Error in Volume (ΔV)</b>", styles["Body"]))
    q2_elements.append(Paragraph(
        "The volume of a cylinder is V = π r² h. The maximum error is calculated using partial differentials.",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "ΔV = |∂V/∂r| Δr + |∂V/∂h| Δh = |2 π r h| Δr + |π r²| Δh",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "Substituting the nominal values (r = 1.02 cm, h = 6.1 cm) and maximum errors (Δr = 0.01 cm, Δh = 0.1 cm):",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "ΔV ≈ |2 π (1.02)(6.1)| (0.01) + |π (1.02)²| (0.1)",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "ΔV ≈ 0.12444 π + 0.10404 π ≈ 0.22848 π cm³",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "ΔV ≈ 0.72 cm³",
        styles["Body"]
    ))
    q2_elements.append(Spacer(1, 12))

    # B. Calculate the volume and indicate the order of accuracy
    q2_elements.append(Paragraph("<b>(b) Volume of the Rod and Order of Accuracy</b>", styles["Body"]))
    q2_elements.append(Paragraph(
        "The nominal volume is calculated using the formula V = π r² h:",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "V = π (1.02 cm)² (6.1 cm)",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "V ≈ 19.97 cm³",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "The final volume is expressed as V ± ΔV ≈ 19.97 ± 0.72 cm³.",
        styles["Body"]
    ))
    q2_elements.append(Paragraph(
        "The maximum error propagation method used results in error terms (like Δr and Δh) raised to the power of 1. Therefore, the order of accuracy is <b>1</b>.",
        styles["Body"]
    ))
    q2_elements.append(Spacer(1, 24))


    return q2_elements

# Example usage within your main script flow:
# q2_elements = get_question_2_elements(styles)
# elements.extend(q2_elements)

from reportlab.platypus import Paragraph, Spacer, Table, TableStyle, PageBreak, flowables
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_3_elements(styles):
    q3_elements = []

    # --- Data for Question 3 ---
    h_data = [7.0, 18.0, 25.0, 45.0, 61.0, 84.0]
    t_data = [36.0, 35.6, 35.1, 34.3, 33.1, 31.6]

    # --- Solution Content ---
    q3_elements.append(PageBreak())
    q3_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 3", styles["Heading"]))
    q3_elements.append(Spacer(1, 12))

    q3_elements.append(Paragraph("<b>Question 3: T² and h relationship</b>", styles["Body"]))
    
    # A. Make a table of T² and h, where T = t/10
    q3_elements.append(Paragraph("<b>(a) Table of T² and h (T = t/10)</b>", styles["Body"]))

    T_data = [round(x / 10, 3) for x in t_data]
    T2_data = [round(x**2, 3) for x in T_data]

    table_data = [
        ['h (cm)', '7.0', '18.0', '25.0', '45.0', '61.0', '84.0'],
        ['t (s)', '36.0', '35.6', '35.1', '34.3', '33.1', '31.6'],
        ['T (s)', *[str(x) for x in T_data]],
        ['T² (s²)', *[str(x) for x in T2_data]]
    ]
    table_style = TableStyle([
        ('BACKGROUND', (0,0), (-1,1), colors.grey),
        ('TEXTCOLOR', (0,0), (-1,1), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 1, colors.black),
        ('BACKGROUND', (0,2), (-1,-1), colors.beige),
    ])
    data_table = Table(table_data, colWidths=[1.5*cm] + [1.8*cm]*6)
    data_table.setStyle(table_style)
    q3_elements.append(data_table)
    q3_elements.append(Spacer(1, 24))

    # B. Plot a graph of T² against h (T² on Y-axis, h on X-axis)
    q3_elements.append(Paragraph("<b>(b) Graph of T² against h</b>", styles["Body"]))

    class GraphFlowable(flowables.Flowable):
        def __init__(self, width, height, h_vals, T2_vals):
            flowables.Flowable.__init__(self)
            self.width = width
            self.height = height
            self.h_vals = h_vals
            self.T2_vals = T2_vals
            
            # Simple axis ranges (no scaling stress)
            self.h_min, self.h_max = min(h_vals), max(h_vals)
            self.T2_min, self.T2_max = min(T2_vals), max(T2_vals)

            self.margin = 50  # Graph margin

        def draw(self):
            canvas = self.canv
            canvas.saveState()
            canvas.setFont('Helvetica', 8)

            draw_w = self.width - 2 * self.margin
            draw_h = self.height - 2 * self.margin

            # --- Mapping function (kept simple) ---
            def map_point(h, T2):
                x_coord = self.margin + (h - self.h_min) / (self.h_max - self.h_min) * draw_w
                y_coord = self.margin + (T2 - self.T2_min) / (self.T2_max - self.T2_min) * draw_h
                return x_coord, y_coord

            # --- Draw axes ---
            canvas.line(self.margin, self.margin, self.width - self.margin, self.margin)  # X-axis
            canvas.line(self.margin, self.margin, self.margin, self.height - self.margin) # Y-axis

            # --- Axis labels ---
            canvas.drawString(self.width/2 - 10, self.margin/2, "h (cm)")
            canvas.rotate(90)
            canvas.drawString(self.height/2, -self.margin/2 - 10, "T² (s²)")
            canvas.rotate(-90)

            # --- Draw points + straight lines ---
            canvas.setStrokeColor(colors.blue)
            canvas.setFillColor(colors.blue)

            for i in range(len(self.h_vals)):
                x, y = map_point(self.h_vals[i], self.T2_vals[i])

                # dot
                canvas.circle(x, y, 2, fill=1)

                # straight line between each successive pair
                if i > 0:
                    x_prev, y_prev = map_point(self.h_vals[i-1], self.T2_vals[i-1])
                    canvas.line(x_prev, y_prev, x, y)

            canvas.restoreState()


    q3_elements.append(GraphFlowable(500, 350, h_data, T2_data))
    q3_elements.append(Spacer(1, 24))
    
    # C. Determine the intercept on the T² axis and the slope of the graph
    q3_elements.append(Paragraph("<b>(c) Intercept and Slope Determination</b>", styles["Body"]))
    q3_elements.append(Paragraph(
        "By analyzing the trend line on the graph (which shows an approximately linear, negative slope):",
        styles["Body"]
    ))
    q3_elements.append(Paragraph(
        "<i>Slope (m):</i> Calculated by finding the change in T² divided by the change in h (ΔT² / Δh) between two points on the line of best fit (e.g., first and last points).",
        styles["Body"]
    ))
    q3_elements.append(Paragraph(
        "m = (11.234 - 12.96) / (84.0 - 7.0) = -1.726 / 77.0 ≈ -0.0224 s²/cm",
        styles["Body"]
    ))
    q3_elements.append(Paragraph(
        "<i>T²-intercept (c):</i> The value of T² when h = 0 (extrapolating the line). Using T² = m h + c, we can find c.",
        styles["Body"]
    ))
    q3_elements.append(Paragraph(
        "c = T² - m h ≈ 12.96 - (-0.0224 × 7.0) ≈ 12.96 + 0.1568 ≈ 13.12 s²",
        styles["Body"]
    ))
    q3_elements.append(Spacer(1, 12))

    # D. Write down the linear relationship between T² and h
    q3_elements.append(Paragraph("<b>(d) Linear Relationship</b>", styles["Body"]))
    q3_elements.append(Paragraph(
        "The linear relationship in the form y = m x + c is:",
        styles["Body"]
    ))
    q3_elements.append(Paragraph(
        "T² = -0.0224 h + 13.12",
        styles["Body"]
    ))

    return q3_elements


# Example usage within your main script flow:
# q3_elements = get_question_3_elements(styles)
# elements.extend(q3_elements)
from reportlab.platypus import Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_4_elements(styles):
    q4_elements = []

    # --- Solution Content ---
    q4_elements.append(PageBreak())
    q4_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 4", styles["Heading"]))
    q4_elements.append(Spacer(1, 12))

    q4_elements.append(Paragraph("<b>Question 4: Terms in Simple Harmonic Motion (SHM)</b>", styles["Body"]))
    q4_elements.append(Paragraph("Discussion and mathematical representation of key terms:", styles["Body"]))
    q4_elements.append(Spacer(1, 12))

    # A. Amplitude
    q4_elements.append(Paragraph("<b>(a) Amplitude (A)</b>", styles["Body"]))
    q4_elements.append(Paragraph(
        "<b>Description:</b> The maximum displacement or distance of a point on the wave or vibrating body from its equilibrium position (rest position). It is a measure of the intensity of the oscillation.",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "<b>Mathematical Representation:</b> In the general equation for SHM displacement x(t) = A cos(ω t + φ), the symbol A represents the amplitude.",
        styles["Body"]
    ))
    q4_elements.append(Spacer(1, 12))

    # B. Period
    q4_elements.append(Paragraph("<b>(b) Period (T)</b>", styles["Body"]))
    q4_elements.append(Paragraph(
        "<b>Description:</b> The time duration required for one complete cycle of oscillation or vibration. It is measured in seconds (s).",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "<b>Mathematical Representation:</b> It is inversely related to frequency (f) and related to angular frequency (ω) by:",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "T = 1 / f = 2π / ω",
        styles["Body"]
    ))
    q4_elements.append(Spacer(1, 12))

    # C. Frequency
    q4_elements.append(Paragraph("<b>(c) Frequency (f or ν)</b>", styles["Body"]))
    q4_elements.append(Paragraph(
        "<b>Description:</b> The number of complete oscillations or cycles that occur per unit of time. It is measured in Hertz (Hz), where 1 Hz = 1 s⁻¹.",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "<b>Mathematical Representation:</b> It is the inverse of the period T:",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "f = 1 / T",
        styles["Body"]
    ))
    q4_elements.append(Spacer(1, 12))

    # D. Angular Frequency
    q4_elements.append(Paragraph("<b>(d) Angular Frequency (ω)</b>", styles["Body"]))
    q4_elements.append(Paragraph(
        "<b>Description:</b> A measure of the rotational speed or oscillation rate expressed in radians per second (rad/s). It describes how quickly the phase of the oscillation is changing.",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "<b>Mathematical Representation:</b> It is related to frequency (f) and period (T) by:",
        styles["Body"]
    ))
    q4_elements.append(Paragraph(
        "ω = 2π f = 2π / T",
        styles["Body"]
    ))
    q4_elements.append(Spacer(1, 24))

    return q4_elements


# Example usage within your main script flow:
# q4_elements = get_question_4_elements(styles)
# elements.extend(q4_elements)


from reportlab.platypus import Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_5_elements(styles):
    q5_elements = []

    # --- Solution Content ---
    q5_elements.append(PageBreak())
    q5_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 5", styles["Heading"]))
    q5_elements.append(Spacer(1, 12))

    q5_elements.append(Paragraph("<b>Question 5: Distance in Simple Harmonic Motion (SHM)</b>", styles["Body"]))
    q5_elements.append(Paragraph("Given values for a mass in SHM:", styles["Body"]))
    q5_elements.append(Paragraph("Amplitude (A) = 2.0 cm", styles["Body"]))
    q5_elements.append(Paragraph("Period (T) = 1.0 s", styles["Body"]))
    q5_elements.append(Paragraph("Time elapsed (t) = 0.4 s", styles["Body"]))
    q5_elements.append(Spacer(1, 12))

    q5_elements.append(Paragraph("<b>Solution Steps:</b>", styles["Body"]))

    # Step 1: Use the equation of motion
    q5_elements.append(Paragraph("Step 1: Define the displacement equation", styles["Body"]))
    q5_elements.append(Paragraph(
        "The displacement x(t) from the center of oscillation for an object starting at equilibrium (center) is given by:",
        styles["Body"]
    ))
    q5_elements.append(Paragraph(
        "x(t) = A × sin(ω t)",
        styles["Body"]
    ))
    q5_elements.append(Spacer(1, 12))

    # Step 2: Calculate angular frequency
    q5_elements.append(Paragraph("Step 2: Calculate angular frequency (ω)", styles["Body"]))
    q5_elements.append(Paragraph(
        "Angular frequency is related to the period by:",
        styles["Body"]
    ))
    q5_elements.append(Paragraph(
        "ω = 2π / T",
        styles["Body"]
    ))
    q5_elements.append(Paragraph(
        "ω = 2π / 1.0 s ≈ 2π rad/s",
        styles["Body"]
    ))
    q5_elements.append(Spacer(1, 12))

    # Step 3: Calculate the displacement at t = 0.4s
    q5_elements.append(Paragraph("Step 3: Calculate the displacement at t = 0.4 s", styles["Body"]))
    q5_elements.append(Paragraph(
        "Substitute the values into the displacement equation:",
        styles["Body"]
    ))
    q5_elements.append(Paragraph(
        "x(0.4) = 2.0 cm × sin(2π rad/s × 0.4 s)",
        styles["Body"]
    ))
    q5_elements.append(Paragraph(
        "x(0.4) = 2.0 cm × sin(0.8 π rad)",
        styles["Body"]
    ))
    q5_elements.append(Paragraph(
        "x(0.4) ≈ 2.0 cm × 0.951 ≈ 1.90 cm",
        styles["Body"]
    ))
    q5_elements.append(Spacer(1, 12))

    # Answer
    q5_elements.append(Paragraph("<b>Answer:</b>", styles["Body"]))
    q5_elements.append(Paragraph(
        "The distance moved from the center of oscillation in 0.4 s is approximately <b>1.90 cm</b>.",
        styles["Body"]
    ))
    q5_elements.append(Spacer(1, 24))

    return q5_elements


# Example usage within your main script flow:
# q5_elements = get_question_5_elements(styles)
# elements.extend(q5_elements)


from reportlab.platypus import Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_6a_elements(styles):
    q6_elements = []

    # --- Solution Content ---
    q6_elements.append(PageBreak())
    q6_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 6A", styles["Heading"]))
    q6_elements.append(Spacer(1, 12))

    q6_elements.append(Paragraph("<b>Question 6A: Center of Gravity of a Non-Uniform Rod</b>", styles["Body"]))
    q6_elements.append(Paragraph("Given values for balancing a non-uniform rod:", styles["Body"]))
    q6_elements.append(Paragraph("Rod Length (L) = 1.0 m", styles["Body"]))
    q6_elements.append(Paragraph("Applied Force (F) = 2.0 N (at one end, 0.5 m from midpoint/pivot)", styles["Body"]))
    q6_elements.append(Paragraph("Weight of Rod (W) = 10 N", styles["Body"]))
    q6_elements.append(Spacer(1, 12))

    q6_elements.append(Paragraph("<b>Solution Steps:</b>", styles["Body"]))

    # Step 1: Apply the principle of moments
    q6_elements.append(Paragraph("Step 1: Apply the principle of moments", styles["Body"]))
    q6_elements.append(Paragraph(
        "For the rod to be in equilibrium (balanced on the knife edge at the midpoint), "
        "the sum of clockwise moments must equal the sum of anti-clockwise moments about the pivot point.",
        styles["Body"]
    ))
    q6_elements.append(Paragraph(
        "Let x be the distance of the center of gravity (CG) from the pivot point.",
        styles["Body"]
    ))
    q6_elements.append(Paragraph(
        "F × d_F = W × x",
        styles["Body"]
    ))
    q6_elements.append(Spacer(1, 12))

    # Step 2: Calculate the position of the center of gravity
    q6_elements.append(Paragraph("Step 2: Calculate the position of the center of gravity", styles["Body"]))
    q6_elements.append(Paragraph(
        "We know F = 2.0 N, d_F = 0.5 m (half the rod length), and W = 10 N.",
        styles["Body"]
    ))
    q6_elements.append(Paragraph(
        "2.0 N × 0.5 m = 10 N × x",
        styles["Body"]
    ))
    q6_elements.append(Paragraph(
        "1.0 N·m = 10 N × x",
        styles["Body"]
    ))
    q6_elements.append(Paragraph(
        "x = 1.0 N·m / 10 N",
        styles["Body"]
    ))
    q6_elements.append(Paragraph(
        "x = 0.1 m",
        styles["Body"]
    ))
    q6_elements.append(Spacer(1, 12))

    # Answer
    q6_elements.append(Paragraph("<b>Answer:</b>", styles["Body"]))
    q6_elements.append(Paragraph(
        "The position of the rod's center of gravity is <b>0.1 m</b> (or 10 cm) from the midpoint of the rod, "
        "located on the opposite side to where the downward force of 2.0 N was applied.",
        styles["Body"]
    ))
    q6_elements.append(Spacer(1, 24))

    return q6_elements


# Example usage within your main script flow:
# q6_elements = get_question_6a_elements(styles)
# elements.extend(q6_elements)


from reportlab.platypus import Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_6b_elements(styles):
    q6b_elements = []

    # --- Solution Content ---
    q6b_elements.append(PageBreak())
    q6b_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 6B", styles["Heading"]))
    q6b_elements.append(Spacer(1, 12))

    q6b_elements.append(Paragraph("<b>Question 6B: Transforming an equation to a straight line equation</b>", styles["Body"]))
    q6b_elements.append(Paragraph("The given equation is for the period of a pendulum:", styles["Body"]))
    q6b_elements.append(Paragraph(
        "T = 2π √(l / g)",
        styles["Body"]
    ))
    q6b_elements.append(Paragraph(
        "We need to transform this into the standard linear equation form y = mx + c, identifying y, x, m, and c.",
        styles["Body"]
    ))
    q6b_elements.append(Spacer(1, 12))

    q6b_elements.append(Paragraph("<b>Solution Steps:</b>", styles["Body"]))

    # Step 1: Square both sides
    q6b_elements.append(Paragraph("Step 1: Prepare the equation for linearization (square both sides)", styles["Body"]))
    q6b_elements.append(Paragraph(
        "To remove the square root, we square both sides:",
        styles["Body"]
    ))
    q6b_elements.append(Paragraph(
        "T² = (2π √(l / g))²",
        styles["Body"]
    ))
    q6b_elements.append(Paragraph(
        "T² = (4 π² / g) × l",
        styles["Body"]
    ))
    q6b_elements.append(Spacer(1, 12))

    # Step 2: Linear form
    q6b_elements.append(Paragraph("Step 2: Rearrange into the standard linear form y = mx + c", styles["Body"]))
    q6b_elements.append(Paragraph(
        "The equation now matches y = mx + c:",
        styles["Body"]
    ))
    q6b_elements.append(Paragraph(
        "T² = (4 π² / g) × l + 0",
        styles["Body"]
    ))
    q6b_elements.append(Spacer(1, 12))

    # Step 3: Identify components
    q6b_elements.append(Paragraph("Step 3: Identify the linear components", styles["Body"]))
    q6b_elements.append(Paragraph(
        "Comparing to y = mx + c:",
        styles["Body"]
    ))
    q6b_elements.append(Paragraph("<b>y:</b> The quantity plotted on the vertical axis (y-axis) is T² (Period squared).", styles["Body"]))
    q6b_elements.append(Paragraph("<b>x:</b> The quantity plotted on the horizontal axis (x-axis) is l (length of pendulum).", styles["Body"]))
    q6b_elements.append(Paragraph("<b>m:</b> The slope (gradient) of the straight line is 4π² / g (where g is acceleration due to gravity).", styles["Body"]))
    q6b_elements.append(Paragraph("<b>c:</b> The y-intercept (value of y when x = 0) is 0.", styles["Body"]))

    q6b_elements.append(Spacer(1, 24))

    return q6b_elements


# Example usage within your main script flow:
# q6b_elements = get_question_6b_elements(styles)
# elements.extend(q6b_elements)



from reportlab.platypus import Paragraph, Spacer, Table, TableStyle, PageBreak, flowables
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_7_elements(styles):
    q7_elements = []

    # --- Data for Question 7 ---
    F_data = [341.0, 320.0, 288.0, 256.0, 232.0]
    l_raw_data = [
        [25.0, 24.5, 24.5],
        [26.3, 27.0, 26.0],
        [30.0, 30.0, 30.0],
        [33.2, 31.6, 33.0],
        [34.1, 34.1, 34.1]
    ]
    
    # Calculations
    l_mean_data = [round(sum(row) / len(row), 2) for row in l_raw_data]
    inv_F_data = [round(1 / f, 5) for f in F_data]

    # --- Solution Content ---
    q7_elements.append(PageBreak())
    q7_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 7", styles["Heading"]))
    q7_elements.append(Spacer(1, 12))

    q7_elements.append(Paragraph("<b>Question 7: Cooling Experiment Data Analysis (Velocity of Sound)</b>", styles["Body"]))
    q7_elements.append(Paragraph(f"Room temperature = 30°C (303 K)", styles["Body"]))
    q7_elements.append(Spacer(1, 12))

    # A. Table of 1/f and Mean l
    q7_elements.append(Paragraph("<b>(a) Data Table including 1/f and Mean l</b>", styles["Body"]))
    
    table_data = [
        ['F (Hz)', *[str(x) for x in F_data]],
        ['1/F (s)', *[str(x) for x in inv_F_data]],
        ['Mean l (cm)', *[str(x) for x in l_mean_data]]
    ]
    table_style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.grey),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 1, colors.black),
        ('BACKGROUND', (0,1), (-1,-1), colors.beige),
    ])
    data_table = Table(table_data, colWidths=[1.8*cm] + [2.2*cm]*5)
    data_table.setStyle(table_style)
    q7_elements.append(data_table)
    q7_elements.append(Spacer(1, 24))

    # B. Plot a graph of l against 1/f
    q7_elements.append(Paragraph("<b>(b) Graph of l against 1/f (l on Y-axis, 1/f on X-axis)</b>", styles["Body"]))

    class GraphFlowable(flowables.Flowable):
        def __init__(self, width, height, inv_F_vals, l_vals):
            flowables.Flowable.__init__(self)
            self.width = width
            self.height = height
            self.inv_F_vals = inv_F_vals
            self.l_vals = l_vals
            
            # Simple fixed ranges
            self.inv_F_min, self.inv_F_max = 0.0028, 0.0044
            self.l_min, self.l_max = 24.0, 35.0
            self.margin = 50

        def draw(self):
            canvas = self.canv
            canvas.saveState()
            canvas.setFont('Helvetica', 8)

            draw_w = self.width - 2 * self.margin
            draw_h = self.height - 2 * self.margin
            
            # Map values → canvas
            def map_point(val_inv_f, val_l):
                x_coord = self.margin + (val_inv_f - self.inv_F_min) / (self.inv_F_max - self.inv_F_min) * draw_w
                y_coord = self.margin + (val_l - self.l_min) / (self.l_max - self.l_min) * draw_h
                return x_coord, y_coord

            # Axes
            canvas.line(self.margin, self.margin, self.width - self.margin, self.margin)   # X-axis (1/F)
            canvas.line(self.margin, self.margin, self.margin, self.height - self.margin) # Y-axis (l)

            # Labels
            canvas.drawString(self.width/2, self.margin/2, "1/F (s)")
            canvas.rotate(90)
            canvas.drawString(self.height/2, -self.margin/2 - 10, "l (cm)")
            canvas.rotate(-90)

            # Line Graph (Blue)
            canvas.setStrokeColor(colors.blue)
            canvas.setFillColor(colors.blue)

            for i in range(len(self.inv_F_vals)):
                x, y = map_point(self.inv_F_vals[i], self.l_vals[i])
                canvas.circle(x, y, 2, fill=1)

                if i > 0:
                    x_prev, y_prev = map_point(self.inv_F_vals[i-1], self.l_vals[i-1])
                    canvas.line(x_prev, y_prev, x, y)

            canvas.restoreState()



    q7_elements.append(GraphFlowable(500, 350, inv_F_data, l_mean_data))
    q7_elements.append(Spacer(1, 24))
    
    # C. Deduce the velocity of sound from your graph (Slope = V/2)
    q7_elements.append(Paragraph("<b>(c) Deduce the velocity of sound (V) from the graph</b>", styles["Body"]))
    q7_elements.append(Paragraph(
        "The relationship is linear: l = V/(2F) - e, which can be written as l = (V/2) × (1/F) - e. "
        "This is in the form y = mx + c.", styles["Body"]))
    q7_elements.append(Paragraph(
        "The slope (m) of the graph of l vs 1/F gives m = V/2.", styles["Body"]))
    q7_elements.append(Paragraph(
        "Slope calculation (using first and last points of line of best fit, approx 6800 cm/s):", styles["Body"]))
    q7_elements.append(Paragraph(
        "m ≈ (34.1 - 24.67) / (0.00431 - 0.00293) = 9.43 cm / 0.00138 s ≈ 6833 cm/s", styles["Body"]))
    q7_elements.append(Paragraph(
        "Velocity V = 2 × m = 2 × 68.33 m/s", styles["Body"]))
    q7_elements.append(Paragraph(
        "V ≈ 136.66 m/s (Note: This result seems low for speed of sound, indicative of simplified data/graph interpretation).", styles["Body"]))
    q7_elements.append(Spacer(1, 12))

    # D. End correction
    q7_elements.append(Paragraph("<b>(d) Deduce end correction (e) from the graph</b>", styles["Body"]))
    q7_elements.append(Paragraph(
        "The equation is l = m(1/F) - e. The intercept (c) is negative (-e). Extrapolating the line of best fit back to the y-axis (1/F = 0) gives the intercept.", styles["Body"]))
    q7_elements.append(Paragraph(
        "Using point-slope form: e = -c = -(l - m(1/F)).", styles["Body"]))
    q7_elements.append(Paragraph(
        "e ≈ -(24.67 cm - 6833 cm/s × 0.00293 s)", styles["Body"]))
    q7_elements.append(Paragraph(
        "e ≈ -(24.67 cm - 20.04 cm)", styles["Body"]))
    q7_elements.append(Paragraph(
        "e ≈ 4.63 cm (The end correction value is approximately 4.63 cm).", styles["Body"]))
    q7_elements.append(Spacer(1, 12))

    # E. Velocity from temperature
    q7_elements.append(Paragraph("<b>(e) Calculate the velocity of sound using the temperature equation</b>", styles["Body"]))
    q7_elements.append(Paragraph(
        "The formula is v = v0 × √(1 + θ / 273), where θ is the room temperature in Celsius (30°C) "
        "and v0 is the speed of sound at 0°C (approx 331 m/s).", styles["Body"]))
    q7_elements.append(Paragraph(
        "v = 331 m/s × √(1 + 30 / 273)", styles["Body"]))
    q7_elements.append(Paragraph(
        "v = 331 m/s × √1.10989", styles["Body"]))
    q7_elements.append(Paragraph(
        "v ≈ 331 m/s × 1.0535 ≈ 348.6 m/s", styles["Body"]))
    q7_elements.append(Spacer(1, 12))

    # F. Compare results
    q7_elements.append(Paragraph("<b>(f) Compare the results</b>", styles["Body"]))
    q7_elements.append(Paragraph(
        "The velocity calculated from the graph (V ≈ 136.66 m/s) is significantly lower than the theoretically expected velocity "
        "of sound at 30°C (V ≈ 348.6 m/s). This large discrepancy suggests potential experimental errors, unusual apparatus design, "
        "or data that does not perfectly represent standard physics values.", styles["Body"]))


    return q7_elements

# Example usage within your main script flow:
# q7_elements = get_question_7_elements(styles)
# elements.extend(q7_elements)



from reportlab.platypus import Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_8_elements(styles):
    q8_elements = []

    # --- Solution Content ---
    q8_elements.append(PageBreak())
    q8_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 8", styles["Heading"]))
    q8_elements.append(Spacer(1, 12))

    q8_elements.append(Paragraph("<b>Question 8: Density Calculation and Order of Accuracy</b>", styles["Body"]))
    q8_elements.append(Paragraph("Given dimensions and mass of a metallic plate:", styles["Body"]))
    q8_elements.append(Paragraph("Length (L) = 15.6 ± 0.1 cm", styles["Body"]))
    q8_elements.append(Paragraph("Width (W) = 5.51 ± 0.02 cm", styles["Body"]))
    q8_elements.append(Paragraph("Thickness (T) = 0.84 ± 0.01 cm", styles["Body"]))
    q8_elements.append(Paragraph("Mass (M) = 12.512 ± 0.002 g", styles["Body"]))
    q8_elements.append(Spacer(1, 12))

    q8_elements.append(Paragraph("<b>Solution Steps:</b>", styles["Body"]))

    # Step 1: Calculate Nominal Volume
    q8_elements.append(Paragraph("#### Step 1: Calculate the nominal volume (V)", styles["Body"]))
    q8_elements.append(Paragraph("V = L × W × T", styles["Body"]))
    q8_elements.append(Paragraph("V = 15.6 cm × 5.51 cm × 0.84 cm", styles["Body"]))
    q8_elements.append(Paragraph("V ≈ 72.31 cm³", styles["Body"]))
    q8_elements.append(Spacer(1, 12))

    # Step 2: Calculate Nominal Density
    q8_elements.append(Paragraph("#### Step 2: Calculate the nominal density (ρ)", styles["Body"]))
    q8_elements.append(Paragraph("ρ = M / V", styles["Body"]))
    q8_elements.append(Paragraph("ρ = 12.512 g / 72.31 cm³", styles["Body"]))
    q8_elements.append(Paragraph("ρ ≈ 0.173 g/cm³", styles["Body"]))
    q8_elements.append(Spacer(1, 12))

    # Step 3: Calculate Maximum Error in Volume
    q8_elements.append(Paragraph("#### Step 3: Calculate the maximum error in volume (ΔV)", styles["Body"]))
    q8_elements.append(Paragraph("The fractional error in a product is the sum of fractional errors:", styles["Body"]))
    q8_elements.append(Paragraph("ΔV / V = ΔL / L + ΔW / W + ΔT / T", styles["Body"]))
    q8_elements.append(Paragraph("ΔV / V = 0.1 / 15.6 + 0.02 / 5.51 + 0.01 / 0.84", styles["Body"]))
    q8_elements.append(Paragraph("ΔV / V ≈ 0.00641 + 0.00363 + 0.0119 ≈ 0.02194", styles["Body"]))
    q8_elements.append(Paragraph("ΔV = 0.02194 × V ≈ 0.02194 × 72.31 cm³", styles["Body"]))
    q8_elements.append(Paragraph("ΔV ≈ 1.59 cm³", styles["Body"]))
    q8_elements.append(Spacer(1, 12))

    # Step 4: Calculate Maximum Error in Density
    q8_elements.append(Paragraph("#### Step 4: Calculate the maximum error in density (Δρ)", styles["Body"]))
    q8_elements.append(Paragraph("The fractional error in a quotient is the sum of fractional errors:", styles["Body"]))
    q8_elements.append(Paragraph("Δρ / ρ = ΔM / M + ΔV / V", styles["Body"]))
    q8_elements.append(Paragraph("Δρ / ρ ≈ 0.00016 + 0.02194 ≈ 0.0221", styles["Body"]))
    q8_elements.append(Paragraph("Δρ = 0.0221 × 0.173 g/cm³ ≈ 0.00383 g/cm³", styles["Body"]))
    q8_elements.append(Spacer(1, 12))

    # Step 5: Format Answer and Order of Accuracy
    q8_elements.append(Paragraph("#### Step 5: Final Result and Order of Accuracy", styles["Body"]))
    q8_elements.append(Paragraph("Rounding appropriately: ρ ± Δρ ≈ 0.173 ± 0.004 g/cm³", styles["Body"]))
    q8_elements.append(Paragraph(
        "The density of the plate is approximately <b>0.173 g/cm³</b>. "
        "The calculation treats errors as first-order differentials, so the order of accuracy is <b>1</b>.",
        styles["Body"]
    ))

    return q8_elements


# Example usage within your main script flow:
# q8_elements = get_question_8_elements(styles)
# elements.extend(q8_elements)


from reportlab.platypus import Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
import math

# Assumed 'styles' dictionary from user context is available here.

def get_question_9_elements(styles):
    q9_elements = []

    # --- Solution Content ---
    q9_elements.append(PageBreak())
    q9_elements.append(Paragraph("PHY 117 ASSIGNMENT - QUESTION 9", styles["Heading"]))
    q9_elements.append(Spacer(1, 12))

    q9_elements.append(Paragraph("<b>Question 9: Balancing a Uniform Meter Rule using the Principle of Moments</b>", styles["Body"]))
    q9_elements.append(Paragraph("Given values:", styles["Body"]))
    q9_elements.append(Paragraph("Weight of uniform meter rule (W_R) = 1.0 N (acts at 0.50 m mark)", styles["Body"]))
    q9_elements.append(Paragraph("Pivot position = 0.40 m mark", styles["Body"]))
    q9_elements.append(Paragraph("Weight 1 (W_1) = 2.0 N (hung at 0.15 m mark)", styles["Body"]))
    q9_elements.append(Paragraph("Weight 2 (W_2) = 2.0 N (position to be determined, x)", styles["Body"]))
    q9_elements.append(Spacer(1, 12))

    q9_elements.append(Paragraph("<b>Solution Steps:</b>", styles["Body"]))

    # Step 1: Calculate distances from the pivot
    q9_elements.append(Paragraph("#### Step 1: Calculate distances from the pivot (0.40 m mark)", styles["Body"]))
    q9_elements.append(Paragraph("Distance of W_1 (at 0.15 m): d1 = 0.40 m - 0.15 m = 0.25 m (Anti-clockwise moment)", styles["Body"]))
    q9_elements.append(Paragraph("Distance of W_R (at 0.50 m): dR = 0.50 m - 0.40 m = 0.10 m (Clockwise moment)", styles["Body"]))
    q9_elements.append(Paragraph("Distance of W_2 (at position x): d2 = |x - 0.40 m|. Since W1 and WR are on opposite sides, W2 must be on the Clockwise side to balance.", styles["Body"]))
    q9_elements.append(Spacer(1, 12))

    # Step 2: Apply the principle of moments
    q9_elements.append(Paragraph("#### Step 2: Apply the principle of moments", styles["Body"]))
    q9_elements.append(Paragraph("Sum of Anti-Clockwise Moments = Sum of Clockwise Moments", styles["Body"]))
    q9_elements.append(Paragraph("W1 * d1 = W_R * dR + W2 * d2", styles["Body"]))
    q9_elements.append(Spacer(1, 12))

    # Step 3: Solve for the unknown distance d2
    q9_elements.append(Paragraph("#### Step 3: Solve for the required distance d2", styles["Body"]))
    q9_elements.append(Paragraph("2.0 N * 0.25 m = 1.0 N * 0.10 m + 2.0 N * d2", styles["Body"]))
    q9_elements.append(Paragraph("0.50 Nm = 0.10 Nm + 2.0 N * d2", styles["Body"]))
    q9_elements.append(Paragraph("0.40 Nm = 2.0 N * d2", styles["Body"]))
    q9_elements.append(Paragraph("d2 = 0.40 Nm / 2.0 N", styles["Body"]))
    q9_elements.append(Paragraph("d2 = 0.20 m", styles["Body"]))
    q9_elements.append(Spacer(1, 12))

    # Step 4: Determine the mark on the meter rule
    q9_elements.append(Paragraph("#### Step 4: Determine the position mark on the meter rule", styles["Body"]))
    q9_elements.append(Paragraph("Since this weight is on the Clockwise side, its position x = 0.40 m + 0.20 m = 0.60 m", styles["Body"]))
    q9_elements.append(Spacer(1, 12))

    # Answer
    q9_elements.append(Paragraph("#### <b>Answer:</b>", styles["Body"]))
    q9_elements.append(Paragraph("The second 2.0 N weight must be placed at the <b>0.60 m mark</b> (or 60 cm mark) to balance the meter rule.", styles["Body"]))
    q9_elements.append(Spacer(1, 24))

    return q9_elements


# Example usage within your main script flow:
# q9_elements = get_question_9_elements(styles)
# elements.extend(q9_elements)

