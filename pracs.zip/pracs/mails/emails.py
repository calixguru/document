
mails = [
    # {
    #     "id": 2,
    #     "email_header": "Welcome to Kalix Guru",
    #     "email_body": "Thank you for joining Kalix Guru. We are excited to have you on board."
    # },
    {
    "id": 1,
    "email_header": "🎄 Merry Christmas from Calixguru".upper(),
    "email_body": "As the year winds down, we want to say a heartfelt thank you for being part of the Calixguru community. May this Christmas bring you peace, joy, and renewed hope. We’re excited to keep learning, growing, and achieving great things together in the coming year. Enjoy the season and stay inspired. We the Calixguru team love and appreciate you so much"
    }

]



