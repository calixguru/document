
import datetime
import base64
from django.shortcuts import render, redirect
from django.core.files.storage import default_storage
from django.conf import settings
from django.http import JsonResponse
from .models import Pins
from django.shortcuts import render, redirect
from django.contrib import messages

from .decorators import monthly
# from openai import OpenAI # Make sure to install the OpenAI library if you haven't
web = 'https://platform.openai.com/docs/guides/vision#limitations'

# Configure your API key here
# client = OpenAI(api_key='sk-proj-BNsRxOhdtMZ8LVGTLPPcPCczUCl4wFd3zU6NX-'
#                         '0q3P7DuG2QlXMY1wwV0l5QazgZUnFzXC3NJ4T3BlbkFJhmaS6db23'
#                         'doOIP9us6dA7JHvbuSH51a-xQ0YlBbv6lq0yJ7bzTNYq7bB6Foz__'
#                         'vUyfc1j9VFQA')

# In-memory session tracking usage count


def get_daily_usage_count(request):
    today = datetime.date.today().isoformat()
    usage_data = request.session.get('usage_data', {})
    if usage_data.get('date') == today:
        return usage_data.get('count', 0)
    else:
        request.session['usage_data'] = {'date': today, 'count': 0}
        return 0


def increment_daily_usage_count(request):
    today = datetime.date.today().isoformat()
    usage_data = request.session.get('usage_data', {})
    if usage_data.get('date') == today:
        usage_data['count'] += 1
    else:
        usage_data = {'date': today, 'count': 0}
    request.session['usage_data'] = usage_data


def upload_image(request):
    topics = ['Mathematics', 'English']
    if get_daily_usage_count(request) >= 5:
        return render(request, 'ai/limit.html')

    if request.method == 'POST' and request.FILES['image']:
        topic = request.POST.get('topic')
        if topic in topics:
            try:
                check = Pins.objects.get(pin=request.user.id)
                if check.duration == 'monthly':
                    image = request.FILES['image']
                    path = default_storage.save(f"uploads/{image.name}", image)
                    file_path = f"{settings.MEDIA_ROOT}/{path}"
                    # Convert image to base64 for API upload
                    with open(file_path, "rb") as image_file:
                        image_data = base64.b64encode(image_file.read()).decode('utf-8')

                    # Call OpenAI API
                    # response = client.chat.completions.create(
                    #     model="gpt-4o-mini",
                    #     messages=[
                    #         {
                    #             "role": "user",
                    #             "content": [
                    #                 {
                    #                     "type": "text",
                    #                     "text": f'''Please help me with this {topic} question in the image
                    #             giving me the answer in just body tag of a template in mathjax form.
                    #             I need just the contents of the body tag, nothing else''',
                    #                 },
                    #                 {
                    #                     "type": "image_url",
                    #                     "image_url": {
                    #                         "url": f"data:image/jpeg;base64,{image_data}"
                    #                     },
                    #                 },
                    #             ],
                    #         }
                    #     ],
                    # )

                    # Process the response and render solution
                    # if response.get('choices'):
                    #     increment_daily_usage_count(request)
                        # solution = response['choices'][0]['message']['content']
                    solution = r'''Hmm'''
                    increment_daily_usage_count(request)
                    lim = 5 - get_daily_usage_count(request)
                    return render(request, 'ai/solution.html', {'solution': solution, 'topic': topic,
                                                                'image_url': path, 'lim': lim})
                else:
                    messages.error(request, "Only monthly subscribers can use that")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
            except:
                messages.error(request, "You have to be subcribed")
                return redirect('buypin')
        else:
            messages.error(request, "Please select a topic")
            return redirect(request.META.get('HTTP_REFERER', '/'))
    return render(request, 'ai/upload.html', {'topics': topics})


def reset_usage(request):
    request.session.pop('usage_data', None)
    return JsonResponse({"status": "reset"})





