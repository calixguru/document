import datetime
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from django.http import FileResponse

pin = [

    [3895963, 4910197, 7978167, 4911626, 5059949, 4560631, 6267414, 7733612, 2493748, 3879608, 4059120, 4169654, 2189656, 9301504, 6049061, 2965736, 9366514, 7273458, 6934386, 1767966, 5083353, 8324829, 8644312, 2879770, 5802371, 6794368, 2205428, 5833707, 1754607, 7943863, 5473315, 6731553, 9641027, 5759603, 9603394, 6153426, 7520083, 3366332, 7517211, 7804741, 6308318, 8976462, 8083023, 1021316, 8111700, 2724953, 5289559, 1695069, 9610331, 6708817, 5873941, 1612137, 9901467, 4419313, 8069883, 9895552, 8081474, 5854419, 5521799, 7959349, 9307617, 1168305, 1111305, 2120141, 8912221, 2503535, 1869783, 7744335, 7719445, 4008124, 9867586, 5252252, 6909125, 9863212, 5030964, 8126236, 4970809, 8389345, 9503259, 5124841, 5920563, 7007044, 7688588, 2605219, 1877851, 8864717, 1447578, 5018556, 8787711, 7184302, 1929294, 2365226, 6996049, 8858715, 7543774, 2154201, 2462086, 8005424, 1085892, 1459317],
    
    [4794315, 8886721, 8218437, 2534480, 7269913, 1195624, 8727253, 2428982, 7845459, 8907567, 3712631, 6657691, 1468639, 4858469, 8865396, 7925247, 6486916, 9430952, 2009770, 6251966, 8667570, 7262511, 2668770, 9929077, 3370969, 9072872, 9320522, 8847913, 4800607, 6524527, 2133059, 2906042, 1761145, 1814733, 4673616, 8480177, 2151943, 5197936, 7666454, 4559900, 7943410, 9829320, 2397108, 7574892, 1373127, 8011953, 9986832, 9231284, 1354993, 6583297, 5726820, 9218502, 7440081, 7256937, 1592435, 5011566, 7079169, 9392541, 8756438, 5288155, 9969752, 2429460, 4550087, 5385544, 7774759, 3412069, 1090625, 1261101, 4511182, 5459025, 8399570, 4840819, 3952037, 2854500, 7638753, 5890433, 5973611, 7037219, 9731108, 3379018, 2116847, 3145723, 3431186, 4321376, 3577729, 4447677, 7892521, 9653880, 5147008, 9219546, 7713704, 7696287, 7869611, 1438735, 1788322, 8033559, 2427734, 8476517, 6014958, 2053355],
    
    [8843195, 5933138, 8322203, 9686580, 7124648, 1697203, 9294815, 9497972, 6831063, 4729158, 3897598, 2263879, 7751510, 1851494, 7612502, 1453742, 7798322, 2766999, 6552163, 4246521, 3966749, 4627566, 4837917, 1152789, 2249552, 7380363, 8391139, 1507780, 5522444, 4729297, 6845317, 2547075, 8324050, 8528339, 3131402, 1306703, 7059583, 3829134, 1071483, 9860185, 9991484, 2586779, 3200213, 5243588, 1269914, 8246284, 8691238, 1341840, 3080428, 6687019, 8656782, 3552592, 8411754, 4147071, 3227572, 7135885, 8659168, 3562713, 4542939, 2463775, 8311546, 5927624, 3486770, 8869225, 6706361, 9271785, 4610184, 7276470, 1382535, 4819058, 7465669, 1942595, 5994712, 7630682, 7900505, 9690653, 6235716, 4984021, 5178052, 5030773, 8652240, 6447999, 2448495, 7380418, 2573703, 3913223, 9245103, 2173905, 7889629, 5235642, 7547065, 8834786, 6302229, 1114886, 1643401, 2375655, 2636780, 7519520, 1672361, 1048348],
    
    [6543185, 8402222, 4880361, 3679431, 6678115, 2714608, 3237154, 3059101, 1811716, 1167201, 3428914, 8276195, 1332910, 2040176, 8293534, 2652419, 2575389, 4964971, 9206578, 4330386, 5987368, 1110017, 3973972, 4390533, 3011697, 6578044, 1566520, 1522287, 3739028, 3625026, 5153508, 7942064, 7374230, 9551918, 6685999, 3604075, 1899232, 6457314, 5856378, 9759006, 1068915, 7002614, 8233486, 6705526, 5895270, 9331771, 2501463, 2232378, 7458454, 5309068, 3613993, 6396585, 1328979, 3454128, 4392347, 4896524, 5100210, 7951358, 4553060, 3908349, 6724529, 9688552, 9144361, 3490950, 1865788, 5589993, 4926148, 2382720, 3651770, 6514434, 4302071, 5803453, 7980777, 8079030, 7250207, 7514212, 6394956, 2874299, 3170414, 6228361, 4412727, 4201734, 5136891, 7797246, 5366545, 7289622, 6093154, 8435777, 1449783, 8386216, 1373250, 3402104, 6218695, 1545889, 9306953, 6510971, 9227224, 5737041, 2332648, 4244683],
    
    [1477756, 4800590, 3376854, 7838271, 2223294, 6315587, 3806217, 7708445, 3233352, 7073430, 3085831, 4147829, 5736022, 9099793, 9820743, 6595620, 3659240, 4063735, 5364237, 8032342, 5841226, 1910954, 6307185, 7211891, 5279902, 2006843, 9749524, 5736818, 6601852, 3548108, 8742662, 4024251, 6456914, 3337717, 7394782, 8699224, 8634819, 7561598, 2597038, 9751670, 7209282, 7638996, 1261982, 2041806, 1505283, 7324027, 9822636, 3281984, 6714079, 3222175, 6737066, 2735375, 2975030, 6542415, 4955003, 9260962, 8631728, 1768074, 1975241, 2177862, 4719399, 3950801, 4165875, 7651530, 3606975, 1766312, 5408132, 4920395, 2653382, 4931492, 5966246, 2649275, 8072424, 8366536, 5742907, 1387816, 4331775, 4699864, 5101270, 8276734, 7061016, 3042948, 2664084, 3512709, 3238878, 1631701, 5074715, 9615728, 3382108, 4472717, 4896460, 5811798, 3990368, 1854648, 5675103, 8863333, 4821049, 3187881, 9297152, 4991636],
    
    [8336646, 8229319, 6074596, 4878020, 8502317, 8879407, 9441541, 4203934, 2646555, 2059482, 6154093, 2621408, 4780964, 7819309, 6974173, 9896526, 7328857, 6592874, 1744391, 9630951, 6074930, 2902200, 2575895, 8433186, 5332179, 2898609, 2610387, 6215129, 2886601, 4653905, 9485811, 2571809, 7133335, 6451454, 1040732, 6730874, 7532452, 9079256, 2172221, 6641634, 3963629, 6470819, 6282735, 6964542, 7560344, 3951302, 2899553, 9210007, 3063348, 1510062, 7673283, 2086100, 8681999, 7580347, 6189430, 9919307, 3692738, 7352821, 7685395, 7639574, 4045240, 5150853, 8927588, 6546246, 6278899, 3185997, 8153479, 5075391, 2887506, 6153304, 6680277, 4933892, 7159741, 8082227, 9164551, 1525632, 3783893, 6276685, 4441433, 1228957, 4060459, 6184721, 6980889, 5038759, 7959353, 8564877, 8741875, 8032844, 2299396, 2808176, 4579938, 1406941, 7832353, 7869090, 5775246, 6211978, 6577170, 8614872, 3901991, 8137519],
    
    [2689362, 5319512, 7076246, 9418779, 9084272, 5400249, 4253225, 2991376, 8708696, 6296947, 3093009, 7843046, 8208909, 3788688, 2598494, 6818169, 5369791, 1097673, 7833446, 6069739, 3974249, 7013924, 6943738, 7585910, 7806146, 1280234, 8716575, 1562799, 5388815, 1469570, 3176334, 1340824, 8002387, 6617933, 6629819, 1221066, 2118869, 9498224, 4925928, 4427850, 8304415, 6160955, 6793840, 1608378, 5114256, 1006908, 1742720, 9430321, 6203751, 3492037, 3525812, 2006084, 4418688, 6120297, 4043697, 2082778, 1430456, 8449544, 6723149, 1558247, 1466347, 2018834, 1217766, 2568015, 7837991, 9195323, 4417271, 2036524, 9215897, 1464569, 4470289, 9915302, 8692412, 6038393, 7430783, 7024004, 5165027, 8792963, 3074586, 6390478, 9261103, 5535464, 7473608, 3804303, 7432913, 3990301, 2765028, 7038657, 1211996, 8163633, 7508500, 4360672, 1509392, 8730799, 2059461, 7540953, 6286952, 4150394, 7742370, 8716774],
    
    [8816209, 5453017, 2428598, 9459715, 5130141, 2022001, 9132986, 4179043, 1146988, 9536336, 9323903, 2510751, 8431149, 3508743, 5781373, 8328147, 4128133, 2412598, 6545303, 7894711, 7920026, 8855006, 6055952, 2844361, 9854396, 9401560, 8524275, 2323182, 4118451, 4407145, 3174160, 8367131, 4751575, 2350593, 8610819, 6416018, 5688211, 4877034, 8981533, 8347325, 1190754, 7227714, 2977010, 9155858, 7859252, 1713644, 2345892, 7602682, 2543659, 3277758, 9163042, 3118571, 8361366, 1560562, 6224045, 9070908, 6571575, 5589162, 1642482, 4257509, 6570289, 3338427, 8619661, 9298373, 9293203, 5273331, 9110054, 6073213, 3543297, 6060072, 3607108, 6465319, 5353137, 8527198, 8206532, 3113921, 1346144, 7614163, 4360014, 1578061, 5640828, 2490996, 2738790, 7214575, 1909852, 7636577, 6698435, 9376355, 5806527, 1716881, 2651448, 9987099, 5813252, 5774439, 3379907, 2872020, 8683418, 3999673, 4193751, 5523291],
    
    [1376588, 4024485, 6404867, 1613136, 7231979, 2772982, 4680009, 3061763, 2927089, 7815949, 8021580, 5377592, 3401036, 7817584, 3594313, 9268215, 7405392, 4923536, 3096660, 8830316, 4476665, 1328839, 7391822, 8300633, 7563892, 5645061, 7964606, 3477083, 1060575, 8482496, 5882652, 5317495, 4473330, 9638500, 1964583, 2089444, 8217265, 7381010, 5685393, 7438088, 1028024, 4349273, 9865306, 6658708, 9030908, 9390982, 8977873, 7899313, 8812648, 8117709, 1335858, 5401756, 7276007, 3102014, 1730092, 9675409, 4172760, 8326941, 9996245, 7646630, 1102038, 9344945, 8865298, 7617116, 7072081, 5103044, 7412517, 6788293, 7054456, 9683405, 2665665, 7501311, 1639239, 8907828, 4023081, 9117556, 1930924, 5592176, 9228455, 5538018, 6075543, 2438931, 9990376, 2496920, 7144756, 8029004, 6563669, 1035825, 8172330, 3232857, 7889424, 4773775, 5183932, 2831792, 6945063, 6516778, 3341932, 5163417, 9942259, 7681333],
    
    [6665319, 9054197, 8933088, 3892861, 9829438, 8009869, 2773882, 5101586, 2769098, 5876179, 3718240, 2298388, 6662596, 5762121, 3724864, 9424925, 2076474, 1611975, 5959068, 3059318, 9987234, 5231324, 7493882, 5125806, 7203773, 9848003, 2656098, 8199128, 1259324, 7155653, 5265131, 7669580, 5950861, 5548391, 9264143, 7522435, 7972382, 8607962, 5452703, 5157229, 6699701, 5258821, 7519973, 4964426, 3302510, 2744722, 9071237, 2349469, 9457544, 4685180, 9409531, 3352843, 8961566, 1970904, 2282595, 3398714, 9850091, 7260571, 2177873, 6071303, 3489338, 5784987, 7547388, 2893394, 2051706, 3382902, 1675523, 5008561, 1324293, 8962301, 3831617, 4265312, 6430187, 1681298, 1459023, 9762142, 4754959, 7974390, 5284756, 3183555, 5118607, 9854148, 4201774, 8923580, 6705772, 8823822, 2041293, 3523907, 6540418, 4686618, 7126560, 9484672, 8612680, 5662485, 3112753, 8313048, 6627301, 4550506, 4222326, 2131261],
]

pins = []

for i in pin:
    for v in i:
        pins.append(v)

list1 = [706599, 486936, 904266, 273795, 126167, 157522, 172788, 824620, 157263, 878734, 631661, 471718, 631545, 843979, 446913, 450802, 270190, 123548, 300221, 782311, 580818, 192292, 558455, 269609, 372824, 923716, 333047, 496237, 824484, 152758, 442313, 854397, 156265, 721651, 676835, 842757, 443235, 964508, 178107, 781382, 657422, 479471, 382793, 708419, 799559, 719118, 453709, 289678, 874925, 805335]
list2 = [282139, 659054, 165280, 859148, 719936, 427085, 934069, 921943, 906661, 648333, 780175, 520277, 881233, 355287, 930070, 257122, 718287, 154649, 299770, 900508, 413816, 480770, 287398, 885622, 916650, 601468, 144334, 657654, 557394, 679760, 705900, 549671, 891271, 501586, 712167, 826834, 624963, 106972, 652724, 942826, 492073, 476948, 957600, 845786, 432608, 449236, 245413, 214169, 337516, 913468]
list3 = [942744, 418368, 923302, 482724, 599851, 271304, 276426, 192243, 188860, 115916, 493628, 229266, 344614, 629229, 600639, 230219, 701750, 850721, 973600, 894942, 388509, 254214, 746712, 203941, 609821, 981546, 615642, 946893, 903652, 297347, 830455, 786755, 319580, 798898, 602454, 512773, 387632, 743418, 689221, 489846, 163044, 983877, 946048, 528486, 910524, 888767, 569249, 439002, 501018, 550312]
list4 = [136972, 804628, 207826, 510902, 789056, 507704, 855150, 334596, 376310, 433704, 763632, 226913, 161941, 256646, 944673, 745114, 363240, 587340, 406659, 498901, 468421, 365430, 280835, 704353, 542254, 109379, 225177, 161887, 990280, 957649, 238842, 459867, 415511, 694303, 870346, 958811, 216436, 301565, 750354, 376159, 139829, 648046, 796530, 211731, 198597, 295206, 620486, 364559, 456034, 497113]
list5 = [340336, 496035, 965567, 985413, 749184, 537346, 894461, 225941, 261846, 677030, 346169, 816211, 708205, 267486, 368265, 321099, 102019, 779345, 171881, 216996, 718283, 984533, 376213, 428905, 106240, 755281, 555650, 453311, 220203, 917875, 683484, 696543, 814320, 486969, 783686, 513285, 169107, 237235, 106333, 766650, 760550, 831467, 214205, 328815, 158680, 214731, 675560, 184311, 994648, 548493]
list6 = [541494, 481754, 217562, 611447, 839432, 600209, 678697, 732082, 188368, 462515, 391773, 341476, 461113, 107168, 385678, 791493, 245131, 597851, 908187, 313768, 738336, 474395, 452574, 501633, 460027, 597477, 253191, 272607, 572995, 597877, 484944, 874096, 894373, 868044, 243857, 454387, 434421, 712689, 363376, 676312, 141262, 621173, 635834, 373890, 834347, 267690, 607543, 523140, 290663, 872757]
list7 = [405172, 457876, 168285, 873036, 146891, 966097, 272676, 402864, 416749, 317637, 341213, 973544, 437386, 592877, 388376, 543579, 304552, 815818, 215904, 312960, 547824, 503982, 861105, 183518, 390519, 583691, 803291, 354745, 687263, 632863, 399812, 141717, 284345, 271688, 674174, 465408, 811426, 949374, 899685, 773159, 391304, 985610, 607788, 443105, 892053, 184083, 406062, 115258, 349764, 970251]
list8 = [151826, 720012, 670639, 650968, 569320, 154768, 252176, 539692, 265952, 461429, 168031, 642030, 489975, 100626, 998394, 272922, 908295, 226382, 561662, 191778, 168491, 702558, 748508, 466375, 247250, 324647, 916290, 794458, 463021, 187684, 481391, 131550, 849320, 515243, 543420, 301104, 813549, 648410, 217007, 622888, 372956, 228674, 486216, 311287, 874812, 302043, 763011, 983429, 751647, 657243]
list9 = [813840, 383541, 165245, 684128, 709451, 977870, 610001, 619325, 369001, 568746, 995380, 135125, 908421, 546009, 859651, 956131, 702776, 842843, 470818, 373217, 811707, 483191, 876116, 100902, 395047, 937362, 939375, 421812, 782991, 606199, 745180, 774083, 869645, 956826, 202322, 670420, 133416, 304453, 208685, 321283, 836066, 783209, 767937, 736648, 314303, 552887, 873257, 606665, 252664, 662594]
list10 = [890010, 612377, 379616, 533051, 530437, 340950, 672348, 278820, 361894, 343189, 549994, 934131, 179111, 559421, 683927, 627198, 141348, 986904, 175946, 182956, 499514, 190180, 854463, 712783, 287034, 824748, 166336, 566287, 350995, 642113, 707284, 864175, 409207, 149161, 647490, 399478, 928575, 169834, 546107, 954928, 300465, 657861, 490526, 245668, 245752, 265483, 121443, 758775, 265721, 481520]
list11 = [848969, 326220, 438103, 743061, 157864, 547325, 731833, 415534, 708121, 322107, 854972, 106148, 867920, 379668, 887342, 843083, 949036, 413378, 937535, 913062, 625631, 974723, 985993, 457383, 363203, 210818, 203531, 342395, 213181, 463625, 789826, 843156, 685213, 254718, 453775, 122637, 207219, 674025, 343743, 879071, 582971, 833250, 292186, 419206, 131369, 818547, 943193, 791043, 508721, 374040]
list12 = [212388, 339364, 450421, 779961, 783434, 292708, 856127, 479414, 963910, 845611, 399643, 218866, 395255, 435532, 824669, 844556, 942356, 543151, 431010, 422360, 377721, 232551, 184940, 713402, 671497, 242998, 541421, 578312, 968943, 721062, 764494, 881202, 460536, 561324, 789658, 702054, 292256, 748926, 883219, 842596, 546240, 411199, 205653, 696173, 435598, 511683, 466174, 316630, 995252, 617297]
list13 = [589245, 999908, 598122, 785901, 895663, 452870, 101757, 899859, 749325, 274299, 247544, 126688, 902685, 287297, 843946, 176779, 967211, 870333, 118135, 446774, 432532, 193135, 246532, 694489, 316016, 557905, 758414, 893338, 950214, 487888, 607631, 434669, 742120, 730644, 315244, 403774, 729170, 631223, 462582, 908407, 712749, 985215, 152971, 405747, 663763, 193806, 410463, 797286, 284054, 525397]
list14 = [258590, 737507, 207816, 211692, 573932, 756533, 676298, 214606, 302000, 532470, 837324, 190293, 175227, 809221, 588091, 539260, 973547, 540101, 334607, 270700, 710115, 773699, 399797, 730051, 770265, 219557, 665027, 640650, 440904, 123130, 762994, 523068, 690703, 846867, 697561, 847992, 998886, 720155, 171477, 239906, 641648, 931270, 842764, 345837, 448492, 736463, 452042, 986998, 939831, 656060]
list15 = [841351, 558089, 145983, 223714, 695805, 527912, 778107, 322372, 507459, 611955, 952032, 930118, 166262, 690618, 646314, 419322, 956939, 120974, 357770, 679722, 309350, 658812, 674771, 178794, 641112, 773897, 308127, 801722, 655945, 606676, 212107, 386955, 860205, 977031, 128065, 488945, 394086, 587679, 857464, 622513, 289646, 586195, 338361, 173977, 537195, 641271, 370373, 125540, 446926, 201218]
list16 = [390297, 250211, 263613, 209973, 979568, 981739, 971489, 640846, 855570, 498708, 107125, 857426, 811362, 282111, 605216, 846010, 319680, 128116, 869759, 260197, 587250, 121977, 410622, 648019, 545089, 365621, 130913, 186613, 137276, 965372, 814886, 249956, 103995, 369421, 753280, 852534, 136936, 912288, 298280, 489493, 184719, 647541, 504538, 105140, 972693, 338178, 687649, 620945, 887340, 246107]
list17 = [832997, 472244, 420520, 199608, 109385, 414708, 392562, 878684, 554541, 248671, 862538, 938529, 118809, 585695, 689063, 625236, 163021, 470378, 994716, 820990, 597679, 530333, 296403, 373335, 975862, 760672, 354698, 731975, 810502, 357120, 188528, 711351, 782932, 155655, 199512, 998277, 926450, 271670, 747591, 654659, 785703, 619967, 678336, 590063, 758599, 532374, 833432, 184438, 754004, 548438]
list18 = [158299, 676258, 322100, 412683, 652584, 974414, 581907, 284727, 584855, 465073, 228544, 587739, 472143, 452315, 868258, 173917, 861610, 828099, 788410, 240293, 182538, 196601, 592296, 236219, 379660, 530432, 137248, 552091, 349027, 101836, 650197, 280241, 309383, 208589, 172236, 995160, 200047, 525972, 195820, 304923, 356839, 150471, 684596, 995235, 379644, 576095, 605736, 126400, 379134, 766000]
list19 = [348605, 479265, 791270, 947693, 572548, 794941, 483475, 271937, 380228, 975772, 213525, 804210, 930783, 131101, 816874, 674740, 831701, 221833, 726384, 596304, 216843, 710967, 870135, 497577, 180414, 195369, 301594, 801570, 865027, 280657, 305817, 584652, 216749, 798319, 911521, 381479, 804328, 251732, 987681, 256471, 805076, 641850, 819959, 651565, 548893, 813699, 896411, 401045, 535926, 229987]
list20 = [821869, 367589, 249198, 348785, 943054, 110148, 521851, 396210, 818493, 449130, 473889, 841685, 426998, 360455, 389507, 150785, 643979, 104843, 969426, 526477, 833837, 887466, 942573, 607465, 981526, 753367, 394353, 529489, 701136, 468942, 223096, 776722, 953424, 991873, 155123, 496115, 924561, 674567, 483534, 781322, 879443, 762955, 172673, 265475, 912519, 654548, 617927, 706287, 104727, 229361]


sets = [list1, list2, list3, list4, list5, 
        list6, list7, list8, list9, list10, 
        list11, list12, list13, list14, list15, 
        list16, list17, list18, list19, list20 ]

class CoverBorders:
    @staticmethod
    def draw_cover_border0(canvas, doc):
        # No border at all (blank style)
        pass
    # ---- Decorative Border ----
    def draw_cover_border(canvas, doc):
        width, height = A4
        # Outer thick rectangle
        canvas.setStrokeColor(colors.HexColor("#2c3e50"))
        canvas.setLineWidth(6)
        canvas.rect(35, 35, width - 70, height - 70)
        # Inner thin gold rectangle
        canvas.setStrokeColor(colors.HexColor("#b8860b"))
        canvas.setLineWidth(2)
        canvas.rect(50, 50, width - 100, height - 100)
        # Floral-like corner ornaments (simple arcs + circles)
        canvas.setFillColor(colors.HexColor("#2c3e50"))
        for (x, y) in [(50, 50), (width - 50, 50), (50, height - 50), (width - 50, height - 50)]:
            canvas.circle(x, y, 10, stroke=1, fill=1)


    # 1. Classic double border (bold outer + thin inner)
    def draw_cover_border1(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setLineWidth(6)
        canvas.rect(35, 35, width - 70, height - 70)

        canvas.setLineWidth(2)
        canvas.rect(50, 50, width - 100, height - 100)


    # 2. Dashed border with corner dots
    def draw_cover_border2(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setDash(6, 4)
        canvas.setLineWidth(2)
        canvas.rect(40, 40, width - 80, height - 80)

        canvas.setDash()  # reset
        for (x, y) in [(40, 40), (width - 40, 40), (40, height - 40), (width - 40, height - 40)]:
            canvas.circle(x, y, 8, fill=1)


    # 3. Triple line frame
    def draw_cover_border3(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        for offset, lw in [(35, 5), (50, 2), (65, 1)]:
            canvas.setLineWidth(lw)
            canvas.rect(offset, offset, width - 2 * offset, height - 2 * offset)


    # 4. Ornamental corner arcs
    def draw_cover_border4(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setLineWidth(3)
        canvas.rect(40, 40, width - 80, height - 80)

        # quarter arcs at corners
        arc_size = 40
        for (x, y) in [(40, 40), (width - 80, 40), (40, height - 80), (width - 80, height - 80)]:
            canvas.arc(x, y, x + arc_size, y + arc_size, startAng=0, extent=90)


    # 5. Inner dotted border + outer solid
    def draw_cover_border5(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Outer
        canvas.setLineWidth(4)
        canvas.rect(35, 35, width - 70, height - 70)

        # Inner dotted
        canvas.setDash(1, 4)
        canvas.setLineWidth(1.5)
        canvas.rect(55, 55, width - 110, height - 110)
        canvas.setDash()


    # 6. Bold top & bottom, thin left & right
    def draw_cover_border6(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setLineWidth(6)
        canvas.line(35, 35, width - 35, 35)
        canvas.line(35, height - 35, width - 35, height - 35)

        canvas.setLineWidth(2)
        canvas.line(35, 35, 35, height - 35)
        canvas.line(width - 35, 35, width - 35, height - 35)


    # 7. Diamond-like corners
    def draw_cover_border7(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setLineWidth(3)
        canvas.rect(50, 50, width - 100, height - 100)

        # small diamond shapes at corners
        for (x, y) in [(50, 50), (width - 50, 50), (50, height - 50), (width - 50, height - 50)]:
            canvas.line(x - 10, y, x, y + 10)
            canvas.line(x, y + 10, x + 10, y)
            canvas.line(x + 10, y, x, y - 10)
            canvas.line(x, y - 10, x - 10, y)


    # 8. Double dashed border
    def draw_cover_border8(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setDash(5, 3)
        canvas.setLineWidth(2)
        canvas.rect(40, 40, width - 80, height - 80)

        canvas.setDash(2, 4)
        canvas.setLineWidth(1)
        canvas.rect(55, 55, width - 110, height - 110)
        canvas.setDash()


    # 9. Bold outer + corner-filled circles
    def draw_cover_border9(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        canvas.setLineWidth(5)
        canvas.rect(40, 40, width - 80, height - 80)

        for (x, y) in [(40, 40), (width - 40, 40), (40, height - 40), (width - 40, height - 40)]:
            canvas.circle(x, y, 12, fill=1)


    # 10. Alternating thick-thin lines (modern academic look)
    def draw_cover_border10(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        offsets = [35, 45, 55, 65]
        line_widths = [5, 1, 3, 0.5]

        for off, lw in zip(offsets, line_widths):
            canvas.setLineWidth(lw)
            canvas.rect(off, off, width - 2 * off, height - 2 * off)

    # 11. Minimalist academic border with header line + link
    def draw_cover_border11(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Simple rectangle
        canvas.setLineWidth(2)
        canvas.rect(50, 50, width - 100, height - 100)

        # Top horizontal bar
        canvas.setLineWidth(5)
        canvas.line(50, height - 100, width - 50, height - 100)

        # Clickable link
        canvas.setFont("Helvetica-Bold", 10)
        canvas.setFillColor(colors.blue)
        # link_text = "Visit Calixguru"
        # canvas.drawCentredString(width / 2, 70, link_text)
        # canvas.linkURL("https://calixguru.com", (width/2 - 60, 60, width/2 + 60, 80))


    # 12. Vertical lines + footer link
    def draw_cover_border12(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Two bold verticals
        canvas.setLineWidth(4)
        canvas.line(80, 50, 80, height - 50)
        canvas.line(width - 80, 50, width - 80, height - 50)

        # Footer link
        canvas.setFont("Times-Roman", 10)
        canvas.setFillColor(colors.blue)
        # link_text = "More Resources Here"
        # canvas.drawCentredString(width / 2, 45, link_text)
        # canvas.linkURL("https://example.com/resources", (width/2 - 70, 35, width/2 + 70, 55))


    # 13. Modern split border (top+left thick, right+bottom thin) + link
    def draw_cover_border13(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Thick top & left
        canvas.setLineWidth(6)
        canvas.line(50, height - 50, width - 50, height - 50)
        canvas.line(50, 50, 50, height - 50)

        # Thin right & bottom
        canvas.setLineWidth(2)
        canvas.line(width - 50, 50, width - 50, height - 50)
        canvas.line(50, 50, width - 50, 50)

        # Link in bottom right corner
        canvas.setFont("Courier-Bold", 9)
        canvas.setFillColor(colors.blue)
        # link_text = "Download More PDFs"
        # canvas.drawRightString(width - 60, 35, link_text)
        # canvas.linkURL("https://calixguru.com/pdfs", (width - 140, 25, width - 40, 45))


    # 14. Wavy style border (zig-zag imitation) + link
    def draw_cover_border14(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        step = 20
        canvas.setLineWidth(1.5)

        # Top zig-zag
        for x in range(50, int(width - 50), step):
            canvas.line(x, height - 50, x + step/2, height - 40)
            canvas.line(x + step/2, height - 40, x + step, height - 50)

        # Bottom zig-zag
        for x in range(50, int(width - 50), step):
            canvas.line(x, 50, x + step/2, 60)
            canvas.line(x + step/2, 60, x + step, 50)

        # Left & right verticals
        canvas.setLineWidth(2)
        canvas.line(50, 50, 50, height - 50)
        canvas.line(width - 50, 50, width - 50, height - 50)

        # Center link
        canvas.setFont("Helvetica", 10)
        canvas.setFillColor(colors.blue)
        # link_text = "Access Library"
        # canvas.drawCentredString(width/2, 35, link_text)
        # canvas.linkURL("https://example.com/library", (width/2 - 60, 25, width/2 + 60, 45))


    # 15. Circle-framed border + centered link
    def draw_cover_border15(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Outer rectangle
        canvas.setLineWidth(3)
        canvas.rect(45, 45, width - 90, height - 90)

        # Corner circles
        for (x, y) in [(45, 45), (width - 45, 45), (45, height - 45), (width - 45, height - 45)]:
            canvas.circle(x, y, 15)

        # Link below title area
        canvas.setFont("Helvetica-Oblique", 11)
        canvas.setFillColor(colors.blue)
        # link_text = "Visit Student Portal"
        # canvas.drawCentredString(width/2, height - 120, link_text)
        # canvas.linkURL("https://student.uniuyo.edu", (width/2 - 70, height - 130, width/2 + 70, height - 110))


    # 16. Double frame with dotted inner border
    def draw_cover_border16(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Outer solid border
        canvas.setLineWidth(3)
        canvas.rect(40, 40, width - 80, height - 80)

        # Inner dotted border
        canvas.setDash(4, 2)
        canvas.setLineWidth(1.2)
        canvas.rect(60, 60, width - 120, height - 120)
        canvas.setDash()  # reset


    # 17. Embroidered diamond corners
    def draw_cover_border17(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Outer border
        canvas.setLineWidth(2.5)
        canvas.rect(50, 50, width - 100, height - 100)

        # Diamond corners
        size = 25
        for (x, y) in [(50, 50), (width - 50, 50), (50, height - 50), (width - 50, height - 50)]:
            canvas.line(x - size, y, x, y + size)
            canvas.line(x, y + size, x + size, y)
            canvas.line(x + size, y, x, y - size)
            canvas.line(x, y - size, x - size, y)


    # 18. Elegant wave embroidery
    def draw_cover_border18(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)
        step = 25

        # Wavy top & bottom
        for x in range(50, int(width - 50), step):
            canvas.arc(x, height - 65, x + step, height - 35, 0, 180)
            canvas.arc(x, 35, x + step, 65, 180, 360)

        # Left & right
        for y in range(50, int(height - 50), step):
            canvas.arc(35, y, 65, y + step, 90, 270)
            canvas.arc(width - 65, y, width - 35, y + step, -90, 90)


    # 19. Stitched embroidery border
    def draw_cover_border19(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)
        canvas.setLineWidth(1.3)
        canvas.setDash(1, 3)  # stitched effect

        canvas.rect(45, 45, width - 90, height - 90)
        canvas.setDash()  # reset


    # 20. Triple frame elegance
    def draw_cover_border20(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        for i, lw in enumerate([4, 2, 1]):
            offset = 40 + (i * 15)
            canvas.setLineWidth(lw)
            canvas.rect(offset, offset, width - 2 * offset, height - 2 * offset)


    # 21. Curved corner embroidery
    def draw_cover_border21(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Outer rectangle
        canvas.setLineWidth(2)
        canvas.rect(50, 50, width - 100, height - 100)

        # Curved embroidery arcs in corners
        radius = 40
        for (x, y) in [(50, 50), (width - 50, 50), (50, height - 50), (width - 50, height - 50)]:
            canvas.arc(x - radius, y - radius, x + radius, y + radius, 0, 360)


    # 22. Side embroidery with floral touch
    def draw_cover_border22(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Vertical double bars
        canvas.setLineWidth(3)
        canvas.line(80, 40, 80, height - 40)
        canvas.line(width - 80, 40, width - 80, height - 40)

        # Small circles (flowers) along them
        for y in range(80, int(height - 80), 50):
            canvas.circle(80, y, 7)
            canvas.circle(width - 80, y, 7)


    # 23. Geometric embroidery
    def draw_cover_border23(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Square inside rectangle
        canvas.setLineWidth(2)
        canvas.rect(50, 50, width - 100, height - 100)

        # Diagonal patterns
        step = 40
        for x in range(50, int(width - 50), step):
            canvas.line(x, 50, x + step, 90)
            canvas.line(x, height - 50, x + step, height - 90)


    # 24. Ornamental dotted arc embroidery
    def draw_cover_border24(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Outer frame
        canvas.setLineWidth(2)
        canvas.rect(60, 60, width - 120, height - 120)

        # Decorative dotted arcs in corners
        canvas.setDash(2, 2)
        r = 30
        for (x, y) in [(60, 60), (width - 60, 60), (60, height - 60), (width - 60, height - 60)]:
            canvas.arc(x - r, y - r, x + r, y + r, 0, 360)
        canvas.setDash()


    # 25. Royal embroidered frame (double + zigzag inside)
    def draw_cover_border25(canvas, doc):
        width, height = A4
        canvas.setStrokeColor(colors.black)

        # Double solid frame
        canvas.setLineWidth(3)
        canvas.rect(40, 40, width - 80, height - 80)
        canvas.setLineWidth(1.5)
        canvas.rect(60, 60, width - 120, height - 120)

        # Zigzag embroidery along top
        step = 20
        for x in range(60, int(width - 60), step):
            canvas.line(x, height - 60, x + step/2, height - 50)
            canvas.line(x + step/2, height - 50, x + step, height - 60)


# import re

# def split_room_payment(input_str):
#     match = re.match(r'([a-zA-Z_]+)(\d+)', input_str)
#     if match:
#         text_part = match.group(1)
#         return f"{text_part}"
#     else:
#         return "Invalid input format"
# def split_room_payment2(input_str):
#     match = re.match(r'([a-zA-Z_]+)(\d+)', input_str)
#     if match:
#         number_part = int(match.group(2))
#         return f"{number_part}"
#     else:
#         return "Invalid input format"
    
# print(split_room_payment('downloads22'))

