quests22 = [
    {
  "question": "If f(x) = 2x<sup>3</sup> - 3x<sup>2</sup> - 36x + 20, at what point is there a local minimum?",
  "opt1": "(3, -61)",
  "opt2": "(2, -54)",
  "opt3": "(–3, 89)",
  "opt4": "(1, -17)",
  "correct": 1
},
{
    "question": "At what point does the function f(x) = -3x<sup>2</sup> have a maximum?",
    "opt1": "(1, -3)",
    "opt2": "(0, 0)",
    "opt3": "(-1, -3)",
    "opt4": "(2, -12)",
    "correct": 2
  },
  {
    "question": "The displacement of a particle projected vertically upward is given by s(t) = (t + 1)<sup>3</sup> - 8t<sup>2</sup> - 1. Find the velocity and acceleration at time t = 4 seconds.",
    "opt1": "(4, 15)",
    "opt2": "(10, 12)",
    "opt3": "(11, 14)",
    "opt4": "(9, 10)",
    "correct": 3
  },
  {
    "question": "The velocity of a moving body is given as v(t) = –4t<sup>2</sup> m/s. Find when the acceleration is maximum.",
    "opt1": "1",
    "opt2": "5",
    "opt3": "2",
    "opt4": "NOTA",
    "correct": 4
  },
  {
    "question": "The velocity of a moving body is given as v(t) = 4t<sup>3</sup> + 3t<sup>2</sup> – 60. Find when the acceleration is minimum.",
    "opt1": "t = 1",
    "opt2": "t = –<sup>1</sup>&frasl;<sub>4</sub>",
    "opt3": "t = –1",
    "opt4": "t = <sup>1</sup>&frasl;<sub>4</sub>",
    "correct": 2
  }

    ]

quests21 = [
  {
    "question": "What are norms and values classified as in a cultural system?",
    "opt1": "Components of material culture",
    "opt2": "Foundations of social control",
    "opt3": "Offshoots of non-material culture",
    "opt4": "Basic societal laws",
    "correct": 3
  },
  {
    "question": "Which of the following is an effect of lack of norms and values enforcement?",
    "opt1": "Improved governance",
    "opt2": "Moral decadence",
    "opt3": "Academic success",
    "opt4": "Economic independence",
    "correct": 2
  },
  {
    "question": "According to Osalusi & Ajayi, which of the following is a benefit of integrating norms and values in schools?",
    "opt1": "Corruption increase",
    "opt2": "Rise in dishonesty",
    "opt3": "Respect for elders",
    "opt4": "Violent behavior",
    "correct": 3
  },
  {
    "question": "Which of these is a social vice resulting from moral decline in Nigeria?",
    "opt1": "Hard work",
    "opt2": "Patriotism",
    "opt3": "Greed",
    "opt4": "Truthfulness",
    "correct": 3
  },
  {
    "question": "Which democratic core value is emphasized in Nigeria?",
    "opt1": "Totalitarian control",
    "opt2": "Suppression of dissent",
    "opt3": "Respect for rights and differences",
    "opt4": "Authoritarianism",
    "correct": 3
  },
  {
    "question": "What are mores in the context of Nigerian norms?",
    "opt1": "Optional customs",
    "opt2": "“Must do” societal expectations",
    "opt3": "Modern regulations",
    "opt4": "Informal greetings",
    "correct": 2
  },
  {
    "question": "Which of the following is a feature of folkways?",
    "opt1": "Harsh punishments apply",
    "opt2": "Legally binding norms",
    "opt3": "Violation often overlooked",
    "opt4": "Requires formal enforcement",
    "correct": 3
  },
  {
    "question": "What is an example of folkways in Nigerian culture?",
    "opt1": "Voting in elections",
    "opt2": "Marriage legislation",
    "opt3": "Prostrating to elders",
    "opt4": "Military service",
    "correct": 3
  },
  {
    "question": "Which of these best defines 'values'?",
    "opt1": "Rules of conduct",
    "opt2": "Political policies",
    "opt3": "Institutionalized ideals guiding behavior",
    "opt4": "Legal punishments",
    "correct": 3
  },
  {
    "question": "According to Enu & Esu (2011), which is a core Nigerian value?",
    "opt1": "Indiscipline",
    "opt2": "Corruption",
    "opt3": "Self-discipline",
    "opt4": "Cheating",
    "correct": 3
  },
  {
    "question": "What is 'communal life' in Nigerian society?",
    "opt1": "Emphasis on individualism",
    "opt2": "Pride in solitude",
    "opt3": "Interpersonal bonds beyond kinship",
    "opt4": "City migration trend",
    "correct": 3
  },
  {
    "question": "Which of these promotes family values in Nigeria?",
    "opt1": "Divorce and single life",
    "opt2": "Respect and mutuality within families",
    "opt3": "Living in isolation",
    "opt4": "Avoiding marriage",
    "correct": 2
  },
  {
    "question": "Which principle supports the 'Value of Hard Work'?",
    "opt1": "Wealth comes from luck",
    "opt2": "Wealth is inherited",
    "opt3": "Wealth comes from hard work",
    "opt4": "Wealth should be avoided",
    "correct": 3
  },
  {
    "question": "Why were elders respected in traditional Nigeria?",
    "opt1": "They were the wealthiest",
    "opt2": "They controlled the army",
    "opt3": "They were sources of wisdom",
    "opt4": "They imposed taxes",
    "correct": 3
  },
  {
    "question": "What is the relationship between religion and morality in Nigeria?",
    "opt1": "They are unrelated",
    "opt2": "They are inseparable",
    "opt3": "Religion discourages morality",
    "opt4": "Morality replaces religion",
    "correct": 2
  },
  {
    "question": "What does the 'Value of Honesty' emphasize?",
    "opt1": "Manipulation and secrecy",
    "opt2": "Open and direct behavior",
    "opt3": "Being clever and evasive",
    "opt4": "Avoiding sensitive matters",
    "correct": 2
  },
  {
    "question": "According to the text, cooperation implies:",
    "opt1": "Absolute independence",
    "opt2": "Total obedience",
    "opt3": "Mutual teamwork and tolerance",
    "opt4": "Strict self-reliance",
    "correct": 3
  },
  {
    "question": "What is patriotism as described in the text?",
    "opt1": "Hatred for other countries",
    "opt2": "Devotion to national interest",
    "opt3": "Total rejection of leadership",
    "opt4": "Criticism of traditions",
    "correct": 2
  },
  {
    "question": "Which institution is not listed as a custodian of national values?",
    "opt1": "Family",
    "opt2": "Teachers",
    "opt3": "Schools",
    "opt4": "Business markets",
    "correct": 4
  },
  {
    "question": "What happens when a person fails to conform to national values?",
    "opt1": "They are rewarded",
    "opt2": "They receive positive sanctions",
    "opt3": "They may face social sanctions",
    "opt4": "They become respected elders",
    "correct": 3
  },

  {
    "question": "What is the major function of norms in society?",
    "opt1": "To promote freedom",
    "opt2": "To cause conflict",
    "opt3": "To regulate behavior",
    "opt4": "To create laws",
    "correct": 1
  },
  {
    "question": "What happens in the absence of moral values in a society?",
    "opt1": "Social harmony",
    "opt2": "Religious revival",
    "opt3": "Moral decay",
    "opt4": "Rapid development",
    "correct": 1
  },
  {
    "question": "Which group is primarily responsible for socializing values into children?",
    "opt1": "The media",
    "opt2": "The military",
    "opt3": "The family",
    "opt4": "The government",
    "correct": 4
  },
  {
    "question": "What distinguishes 'mores' from 'folkways'?",
    "opt1": "Folkways are criminal offenses",
    "opt2": "Mores have stronger sanctions",
    "opt3": "Folkways are legally binding",
    "opt4": "Mores are not enforced",
    "correct": 3
  },
  {
    "question": "Which value is associated with national integrity in Nigeria?",
    "opt1": "Corruption",
    "opt2": "Fraudulence",
    "opt3": "Honesty",
    "opt4": "Laziness",
    "correct": 4
  },
  {
    "question": "Which of these is a consequence of violating mores in Nigeria?",
    "opt1": "Encouragement",
    "opt2": "Legal punishment",
    "opt3": "No reaction",
    "opt4": "Public reward",
    "correct": 3
  },
  {
    "question": "According to the text, what best defines ‘national values’?",
    "opt1": "Global opinions",
    "opt2": "Colonial traditions",
    "opt3": "Principles guiding citizens’ behavior",
    "opt4": "Foreign policies",
    "correct": 2
  },
  {
    "question": "What does Lipman advocate for in school curricula?",
    "opt1": "Moral values and honesty",
    "opt2": "Science and technology only",
    "opt3": "Athletics and arts",
    "opt4": "Globalization",
    "correct": 2
  },
  {
    "question": "Which behavior is NOT considered a Nigerian moral value?",
    "opt1": "Loyalty",
    "opt2": "Self-discipline",
    "opt3": "Indiscipline",
    "opt4": "Truthfulness",
    "correct": 4
  },
  {
    "question": "Which institution enforces national values through legislation?",
    "opt1": "Government",
    "opt2": "Church",
    "opt3": "Market",
    "opt4": "Community elders",
    "correct": 3
  },
  {
    "question": "Which of these defines 'folkways'?",
    "opt1": "Conventional behaviors",
    "opt2": "Severe legal rules",
    "opt3": "Religious taboos",
    "opt4": "Presidential orders",
    "correct": 2
  },
  {
    "question": "What does the phrase 'I am because we are' imply?",
    "opt1": "Rugged individualism",
    "opt2": "Survival of the fittest",
    "opt3": "Spiritual elevation",
    "opt4": "Communal interdependence",
    "correct": 1
  },
  {
    "question": "What is the relationship between norms and laws?",
    "opt1": "Norms violate laws",
    "opt2": "Laws are created from folkways",
    "opt3": "Laws are unrelated to norms",
    "opt4": "Laws are formalized norms",
    "correct": 1
  },
  {
    "question": "What is the importance of respect for elders in Nigerian culture?",
    "opt1": "To maintain economic power",
    "opt2": "To uphold authority",
    "opt3": "To fear punishment",
    "opt4": "To honor wisdom",
    "correct": 2
  },
  {
    "question": "How does the media support national values?",
    "opt1": "By avoiding politics",
    "opt2": "By transmitting value-based content",
    "opt3": "By spreading rumors",
    "opt4": "By entertaining only",
    "correct": 4
  },
  {
    "question": "Which action reflects the value of self-discipline?",
    "opt1": "Quarreling often",
    "opt2": "Resisting temptations",
    "opt3": "Skipping work",
    "opt4": "Telling lies",
    "correct": 3
  },
  {
    "question": "Who are described as role models for teaching values in schools?",
    "opt1": "Classmates",
    "opt2": "Celebrities",
    "opt3": "Janitors",
    "opt4": "Teachers",
    "correct": 3
  },
  {
    "question": "Why is tolerance emphasized in Nigeria?",
    "opt1": "To encourage rebellion",
    "opt2": "To divide the people",
    "opt3": "To enhance unity",
    "opt4": "To promote individualism",
    "correct": 4
  },
  {
    "question": "What do positive sanctions promote?",
    "opt1": "Crime",
    "opt2": "Obedience",
    "opt3": "Deviance",
    "opt4": "Rejection",
    "correct": 1
  },
  {
    "question": "Which value fosters unity and support among citizens?",
    "opt1": "Indifference",
    "opt2": "Patriotism",
    "opt3": "Rebellion",
    "opt4": "Violence",
    "correct": 4
  }
]

quests20 = [
  {
    "question": "Which of the following is the main site for anaerobic respiration in human cells?",
    "opt1": "Mitochondria",
    "opt2": "Cytoplasm",
    "opt3": "Nucleus",
    "opt4": "Golgi body",
    "correct": 2
  },
  {
    "question": "During aerobic respiration, how many molecules of ATP are produced from one glucose molecule?",
    "opt1": "2",
    "opt2": "18",
    "opt3": "32",
    "opt4": "36",
    "correct": 4
  },
  {
    "question": "Which of the following is NOT an end-product of aerobic respiration?",
    "opt1": "Carbon dioxide",
    "opt2": "Water",
    "opt3": "ATP",
    "opt4": "Lactic acid",
    "correct": 4
  },
  {
    "question": "Which part of the nephron is primarily responsible for selective reabsorption?",
    "opt1": "Bowman's capsule",
    "opt2": "Proximal convoluted tubule",
    "opt3": "Loop of Henle",
    "opt4": "Collecting duct",
    "correct": 2
  },
  {
    "question": "Which nitrogenous waste is least toxic and requires the most energy to produce?",
    "opt1": "Ammonia",
    "opt2": "Urea",
    "opt3": "Uric acid",
    "opt4": "Creatinine",
    "correct": 3
  },
  {
    "question": "Which of the following is an example of holozoic nutrition?",
    "opt1": "Amoeba engulfing bacteria",
    "opt2": "Fungi secreting enzymes onto food",
    "opt3": "Tapeworm absorbing host nutrients",
    "opt4": "Green algae performing photosynthesis",
    "correct": 1
  },
  {
    "question": "Which hormone is primarily responsible for stimulating cell elongation during growth?",
    "opt1": "Gibberellin",
    "opt2": "Cytokinin",
    "opt3": "Auxin",
    "opt4": "Abscisic acid",
    "correct": 3
  },
  {
    "question": "The process of programmed cell death is called:",
    "opt1": "Necrosis",
    "opt2": "Apoptosis",
    "opt3": "Cell lysis",
    "opt4": "Cell differentiation",
    "correct": 2
  },
  {
    "question": "Which structure is most adapted for excretion in insects?",
    "opt1": "Nephridia",
    "opt2": "Malpighian tubules",
    "opt3": "Kidneys",
    "opt4": "Contractile vacuole",
    "correct": 2
  },
  {
    "question": "Which plant hormone is responsible for breaking seed dormancy?",
    "opt1": "Auxin",
    "opt2": "Abscisic acid",
    "opt3": "Gibberellin",
    "opt4": "Ethylene",
    "correct": 3
  },
  {
    "question": "Which of the following animals shows physiological adaptation to desert life?",
    "opt1": "Camel storing water in its hump",
    "opt2": "Kangaroo rat producing concentrated urine",
    "opt3": "Lizard basking in the sun",
    "opt4": "Elephant flapping ears to cool down",
    "correct": 2
  },
  {
    "question": "What is the major function of root nodules in legumes?",
    "opt1": "Storage of food",
    "opt2": "Absorption of water",
    "opt3": "Nitrogen fixation",
    "opt4": "Transport of minerals",
    "correct": 3
  },
  {
    "question": "In ruminants, the stomach chamber where microbial fermentation primarily occurs is the:",
    "opt1": "Reticulum",
    "opt2": "Rumen",
    "opt3": "Omasum",
    "opt4": "Abomasum",
    "correct": 2
  },
  {
    "question": "Which of the following is a major characteristic of determinate growth?",
    "opt1": "Growth throughout life",
    "opt2": "Growth only during embryonic stages",
    "opt3": "Growth stops after a certain stage",
    "opt4": "Growth only in meristematic tissues",
    "correct": 3
  },
  {
    "question": "Which of the following is a structural adaptation in aquatic animals?",
    "opt1": "Large ears for heat loss",
    "opt2": "Streamlined body shape",
    "opt3": "Thick fur for insulation",
    "opt4": "Production of urea",
    "correct": 2
  },
  {
    "question": "What enzyme initiates starch digestion in humans?",
    "opt1": "Pepsin",
    "opt2": "Maltase",
    "opt3": "Salivary amylase",
    "opt4": "Trypsin",
    "correct": 3
  },
  {
    "question": "Which of the following best describes obligate aerobes?",
    "opt1": "Can survive only without oxygen",
    "opt2": "Can survive with or without oxygen",
    "opt3": "Require oxygen for survival",
    "opt4": "Die in presence of oxygen",
    "correct": 3
  },
  {
    "question": "Which organ in humans is most involved in detoxification of metabolic waste?",
    "opt1": "Kidney",
    "opt2": "Liver",
    "opt3": "Skin",
    "opt4": "Intestine",
    "correct": 2
  },
  {
    "question": "Which respiratory pigment is found in human blood?",
    "opt1": "Chlorocruorin",
    "opt2": "Hemocyanin",
    "opt3": "Haemoglobin",
    "opt4": "Myoglobin",
    "correct": 3
  },
  {
    "question": "During anaerobic respiration in muscles, the end product is:",
    "opt1": "Carbon dioxide",
    "opt2": "Lactic acid",
    "opt3": "Alcohol",
    "opt4": "Water",
    "correct": 2
  },
  {
    "question": "Which of the following is an excretory product in plants?",
    "opt1": "Glycogen",
    "opt2": "Starch",
    "opt3": "Resin",
    "opt4": "Sucrose",
    "correct": 3
  },
  {
    "question": "Which enzyme converts glucose to pyruvate in glycolysis?",
    "opt1": "Lactase",
    "opt2": "Hexokinase",
    "opt3": "Amylase",
    "opt4": "Glucokinase",
    "correct": 2
  },
  {
    "question": "In which part of the mitochondrion does the Krebs cycle occur?",
    "opt1": "Outer membrane",
    "opt2": "Intermembrane space",
    "opt3": "Matrix",
    "opt4": "Cristae",
    "correct": 3
  },
  {
    "question": "Which of the following is a chemosynthetic autotroph?",
    "opt1": "Green algae",
    "opt2": "Sulfur bacteria",
    "opt3": "Mushroom",
    "opt4": "Blue-green algae",
    "correct": 2
  },
  {
    "question": "The hormone responsible for regulating water reabsorption in kidneys is:",
    "opt1": "Aldosterone",
    "opt2": "Adrenaline",
    "opt3": "ADH",
    "opt4": "Insulin",
    "correct": 3
  },
  {
    "question": "Which of the following shows parasitic nutrition?",
    "opt1": "Mistletoe",
    "opt2": "Mushroom",
    "opt3": "Mango tree",
    "opt4": "Rhizopus",
    "correct": 1
  },
  {
    "question": "Which of the following is the most direct measure of metabolic rate?",
    "opt1": "Body temperature",
    "opt2": "Blood pressure",
    "opt3": "Oxygen consumption",
    "opt4": "Heart rate",
    "correct": 3
  },
  {
    "question": "What adaptation helps fish to maintain buoyancy?",
    "opt1": "Swim bladder",
    "opt2": "Operculum",
    "opt3": "Lateral line",
    "opt4": "Gills",
    "correct": 1
  },
  {
    "question": "The release of enzymes by digestive glands is regulated mainly by:",
    "opt1": "Nerve signals and hormones",
    "opt2": "Digestive pressure",
    "opt3": "Osmosis",
    "opt4": "Excretion",
    "correct": 1
  },
  {
    "question": "Which of the following processes releases the most energy per glucose molecule?",
    "opt1": "Anaerobic glycolysis",
    "opt2": "Alcoholic fermentation",
    "opt3": "Aerobic respiration",
    "opt4": "Lactic acid fermentation",
    "correct": 3
  }
]

quests19 = [
  {
    "question": "Which of the following pairs are functional isomers?",
    "opt1": "CH<sub>3</sub>CH<sub>2</sub>OH and CH<sub>3</sub>OCH<sub>3</sub>",
    "opt2": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>3</sub> and CH<sub>3</sub>CH(CH<sub>3</sub>)",
    "opt3": "CH<sub>3</sub>CH=CH<sub>2</sub> and CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>",
    "opt4": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>3</sub> and CH<sub>2</sub>=CHCH<sub>3</sub>",
    "correct": 1
  },
  {
    "question": "Geometrical isomerism arises due to:",
    "opt1": "Presence of a chiral carbon",
    "opt2": "Restricted rotation around a double bond",
    "opt3": "Free rotation of single bonds",
    "opt4": "Molecular asymmetry",
    "correct": 2
  },
  {
    "question": "Which type of isomerism is shown by but-2-ene?",
    "opt1": "Tautomerism",
    "opt2": "Functional isomerism",
    "opt3": "Geometrical isomerism",
    "opt4": "Optical isomerism",
    "correct": 3
  },
  {
    "question": "Which of these is an example of a nucleophile?",
    "opt1": "BF<sub>3</sub>",
    "opt2": "NO<sub>2</sub><sup>+</sup>",
    "opt3": "NH<sub>3</sub>",
    "opt4": "H<sup>+</sup>",
    "correct": 3
  },
  {
    "question": "Which of these is a typical electrophile?",
    "opt1": "Cl<sup>-</sup>",
    "opt2": "CH<sub>3</sub>OH",
    "opt3": "NH<sub>3</sub>",
    "opt4": "Br<sup>+</sup>",
    "correct": 4
  },
  {
    "question": "Bond cleavage in homolysis leads to the formation of:",
    "opt1": "Two cations",
    "opt2": "One cation and one anion",
    "opt3": "Two free radicals",
    "opt4": "Two anions",
    "correct": 3
  },
  {
    "question": "Which type of bond cleavage occurs in the presence of UV light?",
    "opt1": "Heterolytic cleavage",
    "opt2": "Homolytic cleavage",
    "opt3": "Ionic cleavage",
    "opt4": "Polar cleavage",
    "correct": 2
  },
  {
    "question": "Heterolytic bond cleavage results in:",
    "opt1": "Equal sharing of electrons",
    "opt2": "Formation of radicals",
    "opt3": "One atom taking both bonding electrons",
    "opt4": "None of the above",
    "correct": 3
  },
  {
    "question": "Which of the following is not a type of organic reaction?",
    "opt1": "Addition",
    "opt2": "Condensation",
    "opt3": "Dispersion",
    "opt4": "Substitution",
    "correct": 3
  },
  {
    "question": "Elimination reactions usually produce:",
    "opt1": "Alcohols",
    "opt2": "Double bonds",
    "opt3": "Amines",
    "opt4": "Esters",
    "correct": 2
  },
  {
    "question": "Which reaction involves the replacement of one atom or group by another?",
    "opt1": "Substitution",
    "opt2": "Addition",
    "opt3": "Elimination",
    "opt4": "Rearrangement",
    "correct": 1
  },
  {
    "question": "The mechanism SN1 is characterized by:",
    "opt1": "Concerted mechanism",
    "opt2": "Carbocation intermediate",
    "opt3": "Free radical intermediate",
    "opt4": "Syn addition",
    "correct": 2
  },
  {
    "question": "In an SN2 mechanism, the nucleophile attacks:",
    "opt1": "After leaving group departs",
    "opt2": "From the same side",
    "opt3": "Simultaneously as leaving group departs",
    "opt4": "Only if there’s resonance",
    "correct": 3
  },
  {
    "question": "What is the product of electrophilic addition to an alkene?",
    "opt1": "Aromatic ring",
    "opt2": "Alcohol",
    "opt3": "Alkane",
    "opt4": "Substituted alkane",
    "correct": 4
  },
  {
    "question": "Which of the following can stabilize a carbocation?",
    "opt1": "Electron withdrawing groups",
    "opt2": "Alkyl groups",
    "opt3": "Arenes",
    "opt4": "Nonpolar solvents",
    "correct": 2
  },
  {
    "question": "Which is the fastest in SN1 reactions?",
    "opt1": "CH<sub>3</sub>Cl",
    "opt2": "(CH<sub>3</sub>)<sub>2</sub>CHCl",
    "opt3": "CCl<sub>4</sub>",
    "opt4": "(CH<sub>3</sub>)<sub>3</sub>CCl",
    "correct": 4
  },
  {
    "question": "Which class of organic reagent is most likely to accept a pair of electrons?",
    "opt1": "Electrophiles",
    "opt2": "Nucleophiles",
    "opt3": "Free radicals",
    "opt4": "Carbanions",
    "correct": 1
  },
  {
    "question": "Which bond cleavage mechanism leads to a carbocation?",
    "opt1": "Homolytic",
    "opt2": "Heterolytic",
    "opt3": "SN2",
    "opt4": "Free radical chain",
    "correct": 2
  },
  {
    "question": "Which is a rearrangement reaction?",
    "opt1": "Hydrogenation",
    "opt2": "Friedel-Crafts acylation",
    "opt3": "Wolff rearrangement",
    "opt4": "Dehydration",
    "correct": 3
  },
  {
    "question": "Tautomerism is a special case of:",
    "opt1": "Resonance",
    "opt2": "Dynamic isomerism",
    "opt3": "Stereoisomerism",
    "opt4": "Geometrical isomerism",
    "correct": 2
  }
]

quests18 = [
  {
    "question": "What is the main feature of apprenticeship according to Bandura?",
    "opt1": "A system of classroom-based learning only",
    "opt2": "A method of acquiring complex skills under guidance",
    "opt3": "A government policy on skill acquisition",
    "opt4": "A social practice of playing games",
    "correct": 2
  },
  {
    "question": "Which scholar defined apprenticeship as mastery through interaction with domain experts?",
    "opt1": "Hall",
    "opt2": "Wenger",
    "opt3": "Seely Brown and Duguid",
    "opt4": "Scott",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a key element of apprenticeship?",
    "opt1": "Structured learning experience",
    "opt2": "Mentorship and guidance",
    "opt3": "On-the-job training",
    "opt4": "Autonomous learning without supervision",
    "correct": 4
  },
  {
    "question": "Which Nigerian ethnic group emphasizes creativity and innovation in apprenticeship?",
    "opt1": "Igbo",
    "opt2": "Yoruba",
    "opt3": "Efik",
    "opt4": "Hausa",
    "correct": 2
  },
  {
    "question": "Which ethnic group emphasizes self-reliance and entrepreneurship in apprenticeship?",
    "opt1": "Hausa",
    "opt2": "Ibibio",
    "opt3": "Igbo",
    "opt4": "Yoruba",
    "correct": 3
  },
  {
    "question": "Which sector has modern apprenticeship expanded into?",
    "opt1": "Traditional farming only",
    "opt2": "Manual labor only",
    "opt3": "Technology, healthcare, and finance",
    "opt4": "Art and folklore only",
    "correct": 3
  },
  {
    "question": "What historical law introduced national apprenticeship training in 1563?",
    "opt1": "Colonial Training Act",
    "opt2": "Statute of Artificers",
    "opt3": "Master-Apprentice Law",
    "opt4": "Trade Skills Ordinance",
    "correct": 2
  },
  {
    "question": "What is one major characteristic of apprenticeship in Nigeria?",
    "opt1": "Learning through textbooks",
    "opt2": "Learning without supervision",
    "opt3": "Mentorship and cultural transmission",
    "opt4": "Reliance on internet resources",
    "correct": 3
  },
  {
    "question": "In Nigeria, apprentices often graduate to become:",
    "opt1": "Teachers in schools",
    "opt2": "Entrepreneurs",
    "opt3": "Civil servants",
    "opt4": "Lawyers",
    "correct": 2
  },
  {
    "question": "Which group traditionally used apprenticeship for crafts like leatherwork and blacksmithing?",
    "opt1": "Yoruba",
    "opt2": "Hausa-Fulani",
    "opt3": "Igbo",
    "opt4": "Tiv",
    "correct": 2
  },
  {
    "question": "Which challenge affects apprenticeship due to societal beliefs?",
    "opt1": "High salary demands",
    "opt2": "Short training duration",
    "opt3": "Perceived prestige of formal education",
    "opt4": "Lack of equipment",
    "correct": 3
  },
  {
    "question": "What causes a decline in apprenticeship in rural areas?",
    "opt1": "Formal education policy",
    "opt2": "Urban migration",
    "opt3": "Poor roads",
    "opt4": "Increased farming activities",
    "correct": 2
  },
  {
    "question": "What do apprentices receive as they gain skill?",
    "opt1": "Dismissal",
    "opt2": "Punishment",
    "opt3": "Progressive wages",
    "opt4": "Housing",
    "correct": 3
  },
  {
    "question": "Which component ensures apprentices learn from mentors at the job site?",
    "opt1": "Formal classroom learning",
    "opt2": "On-the-job training",
    "opt3": "Social media coaching",
    "opt4": "Online webinars",
    "correct": 2
  },
  {
    "question": "Which type of apprenticeship existed within a legislative framework in medieval times?",
    "opt1": "Informal apprenticeship",
    "opt2": "Time-served apprenticeship",
    "opt3": "Self-education",
    "opt4": "Government internship",
    "correct": 2
  },
  {
    "question": "In guild-based apprenticeship, what was emphasized?",
    "opt1": "Mass employment",
    "opt2": "Time-bound training only",
    "opt3": "Cultural socialization and quality control",
    "opt4": "Random skill acquisition",
    "correct": 3
  },
  {
    "question": "Which organization regulated standard-based apprenticeship in the past?",
    "opt1": "Guilds",
    "opt2": "Colonial masters",
    "opt3": "Kings",
    "opt4": "Local chiefs",
    "correct": 1
  },
  {
    "question": "What is one effect of modern consumer behavior on guilds?",
    "opt1": "Boosted sales",
    "opt2": "Decline due to quality preference drop",
    "opt3": "Increased apprenticeships",
    "opt4": "More strict training",
    "correct": 2
  },
  {
    "question": "What replaced time-served apprenticeship in the 1990s?",
    "opt1": "Traditional learning",
    "opt2": "National Traineeships",
    "opt3": "Modern Apprenticeships",
    "opt4": "Guild-based internship",
    "correct": 3
  },
  {
    "question": "What qualification did Modern Apprenticeships aim for?",
    "opt1": "PhD",
    "opt2": "WAEC",
    "opt3": "NVQ Level 3",
    "opt4": "SSCE",
    "correct": 3
  },
  {
    "question": "Which sector does NOT typically use apprenticeship?",
    "opt1": "Construction",
    "opt2": "Agriculture",
    "opt3": "Fashion and media",
    "opt4": "Judiciary",
    "correct": 4
  },
  {
    "question": "Which of the following is an education-related apprenticeship?",
    "opt1": "Electrical servicing",
    "opt2": "Supporting teaching and learning",
    "opt3": "Sales management",
    "opt4": "Civil engineering",
    "correct": 2
  },
  {
    "question": "What kind of industry apprenticeship involves animals and farming?",
    "opt1": "Construction",
    "opt2": "Business management",
    "opt3": "Agricultural",
    "opt4": "Media",
    "correct": 3
  },
  {
    "question": "Which of the following is a challenge in Nigerian apprenticeship?",
    "opt1": "Excess funding",
    "opt2": "Strict regulations",
    "opt3": "Lack of standardization",
    "opt4": "Increased employment",
    "correct": 3
  },
  {
    "question": "Which act limited the number of apprentices a master could have to three?",
    "opt1": "National Policy Act",
    "opt2": "Statute of Artificers",
    "opt3": "Craftsmen Order",
    "opt4": "Skill Promotion Act",
    "correct": 2
  },
  {
    "question": "In Nigeria, how do apprentices usually begin their journey?",
    "opt1": "With formal university admission",
    "opt2": "By buying equipment",
    "opt3": "Under a skilled mentor",
    "opt4": "Via government posting",
    "correct": 3
  },
  {
    "question": "What is a benefit of apprenticeship to the economy?",
    "opt1": "Discourages innovation",
    "opt2": "Promotes idleness",
    "opt3": "Supports economic growth",
    "opt4": "Reduces employment",
    "correct": 3
  },
  {
    "question": "What kind of learning does apprenticeship promote?",
    "opt1": "Passive learning",
    "opt2": "Experiential learning",
    "opt3": "Digital gaming",
    "opt4": "Solo learning",
    "correct": 2
  },
  {
    "question": "Which institution often provides related instruction in apprenticeships?",
    "opt1": "Banks",
    "opt2": "Community colleges",
    "opt3": "Hospitals",
    "opt4": "Police academies",
    "correct": 2
  },
  {
    "question": "What is a cultural benefit of apprenticeship in Nigeria?",
    "opt1": "Language loss",
    "opt2": "Heritage preservation",
    "opt3": "Fashion trends",
    "opt4": "Food variety",
    "correct": 2
  }
]

quests14 = [
{
"question": "Which of the following compounds belongs to the same homologous series as CH<sub>4</sub>?",
"opt1": "CH<sub>3</sub>OH",
"opt2": "C<sub>2</sub>H<sub>6</sub>",
"opt3": "C<sub>2</sub>H<sub>5</sub>Cl",
"opt4": "CH<sub>2</sub>O",
"correct": 2
},
{
"question": "A homologous series is best described as a group of compounds that:",
"opt1": "Have identical molecular masses",
"opt2": "Differ by a CH<sub>2</sub> unit and have similar chemical properties",
"opt3": "Contain the same number of carbon atoms",
"opt4": "Have varying functional groups",
"correct": 2
},
{
"question": "Which of the following is the correct general formula for alkenes?",
"opt1": "C<sub>n</sub>H<sub>2n</sub>",
"opt2": "C<sub>n</sub>H<sub>2n+2</sub>",
"opt3": "C<sub>n</sub>H<sub>2n-2</sub>",
"opt4": "C<sub>n</sub>H<sub>n</sub>",
"correct": 1
},
{
"question": "The functional group present in alcohols is:",
"opt1": "-COOH",
"opt2": "-OH",
"opt3": "-NH<sub>2</sub>",
"opt4": "-CHO",
"correct": 2
},
{
"question": "Which compound contains the carbonyl functional group?",
"opt1": "CH<sub>3</sub>CH<sub>2</sub>OH",
"opt2": "CH<sub>3</sub>COOH",
"opt3": "CH<sub>3</sub>CHO",
"opt4": "CH<sub>4</sub>",
"correct": 3
},
{
"question": "Which of these is NOT a functional group in organic chemistry?",
"opt1": "Alkene",
"opt2": "Amide",
"opt3": "Ether",
"opt4": "Isotope",
"correct": 4
},
{
"question": "The ability of carbon to form long chains and rings is referred to as:",
"opt1": "Isomerism",
"opt2": "Catenation",
"opt3": "Hybridization",
"opt4": "Resonance",
"correct": 2
},
{
"question": "Carbon forms strong covalent bonds with other carbon atoms due to its:",
"opt1": "Large atomic radius",
"opt2": "Ability to donate electrons",
"opt3": "Small size and tetravalency",
"opt4": "High electronegativity",
"correct": 3
},
{
"question": "Which of the following is NOT a reason for the unique nature of carbon?",
"opt1": "It forms stable multiple bonds",
"opt2": "It exhibits catenation",
"opt3": "It forms ionic bonds readily",
"opt4": "It is tetravalent",
"correct": 3
},
{
"question": "Which of the following allotropes of carbon is the hardest?",
"opt1": "Graphite",
"opt2": "Fullerene",
"opt3": "Carbon black",
"opt4": "Diamond",
"correct": 4
},
{
"question": "Graphite conducts electricity because:",
"opt1": "It is soluble in water",
"opt2": "Its carbon atoms are loosely packed",
"opt3": "It contains delocalized electrons between layers",
"opt4": "It has ionic bonds",
"correct": 3
},
{
"question": "Which statement is true about allotropes of carbon?",
"opt1": "They have different atomic numbers",
"opt2": "They differ in chemical composition",
"opt3": "They consist of carbon but differ in arrangement",
"opt4": "They are isotopes of carbon",
"correct": 3
},
{
"question": "The spherical molecule C<sub>60</sub> is known as:",
"opt1": "Graphene",
"opt2": "Diamond",
"opt3": "Fullerene",
"opt4": "Charcoal",
"correct": 3
},
{
"question": "Which physical property is most influenced by molecular mass in organic compounds?",
"opt1": "Reactivity",
"opt2": "Boiling point",
"opt3": "pH",
"opt4": "Color",
"correct": 2
},
{
"question": "The presence of -OH group in alcohols affects their:",
"opt1": "Density",
"opt2": "Odor",
"opt3": "Boiling point due to hydrogen bonding",
"opt4": "Color",
"correct": 3
},
{
"question": "Which factor does NOT significantly affect the physical properties of organic compounds?",
"opt1": "Functional group",
"opt2": "Molar mass",
"opt3": "Number of carbon atoms",
"opt4": "Atomic number of carbon",
"correct": 4
},
{
"question": "Isomers are compounds that:",
"opt1": "Have the same chemical properties but different physical states",
"opt2": "Have the same molecular formula but different structures",
"opt3": "Have different molecular formulas but same boiling point",
"opt4": "React only under specific temperatures",
"correct": 2
},
{
"question": "An increase in branching in an organic molecule tends to:",
"opt1": "Increase its boiling point",
"opt2": "Have no effect on boiling point",
"opt3": "Decrease its boiling point",
"opt4": "Cause polymerization",
"correct": 3
},
{
"question": "The presence of a polar functional group like -COOH will:",
"opt1": "Lower solubility in water",
"opt2": "Raise the compound's melting point",
"opt3": "Increase hydrogen bonding and water solubility",
"opt4": "Have no effect",
"correct": 3
},
{
"question": "Which homologous series has the functional group -COOH?",
"opt1": "Alcohols",
"opt2": "Aldehydes",
"opt3": "Carboxylic acids",
"opt4": "Ketones",
"correct": 3
},
{
"question": "Which of the following best explains the lower boiling point of ethers compared to alcohols?",
"opt1": "Smaller molar masses",
"opt2": "Absence of hydrogen bonding",
"opt3": "Stronger dipole-dipole forces",
"opt4": "Increased polarity",
"correct": 2
},
{
"question": "Which of the following is an example of a ketone?",
"opt1": "CH<sub>3</sub>CH<sub>2</sub>OH",
"opt2": "CH<sub>3</sub>COCH<sub>3</sub>",
"opt3": "CH<sub>3</sub>CHO",
"opt4": "HCOOH",
"correct": 2
},
{
"question": "Which of these factors influences volatility in organic compounds?",
"opt1": "Functional group polarity and molecular size",
"opt2": "Color and taste",
"opt3": "Presence of nitrogen only",
"opt4": "Radiation levels",
"correct": 1
},
{
"question": "Which is the correct IUPAC name for CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>OH?",
"opt1": "Ethanol",
"opt2": "Methanol",
"opt3": "Propanol",
"opt4": "Butanol",
"correct": 3
},
{
"question": "The general formula of carboxylic acids is:",
"opt1": "C<sub>n</sub>H<sub>2n+1</sub>OH",
"opt2": "C<sub>n</sub>H<sub>2n+1</sub>COOH",
"opt3": "C<sub>n</sub>H<sub>2n+2</sub>",
"opt4": "C<sub>n</sub>H<sub>2n</sub>",
"correct": 2
}
]


quests = [
  {
    "question": "Mathematically, area expansivity β is",
    "opt1": "β = 2α",
    "opt2": "β = α²",
    "opt3": "β = α³",
    "opt4": "β = 3α",
    "correct": 1
  },
  {
    "question": "Thermal stress has the same unit as",
    "opt1": "Young modulus",
    "opt2": "Compressive",
    "opt3": "Extension",
    "opt4": "Tensile strain",
    "correct": 1
  },
  {
    "question": "Cubic expansivity is three times....",
    "opt1": "Linear expansivity",
    "opt2": "Area expansivity",
    "opt3": "Volume expansivity",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "If the linear expansivity of a material is 0.00015 °C⁻¹, what is the area expansivity of that material?",
    "opt1": "0.0003 °C⁻¹",
    "opt2": "0.0036 °C⁻¹",
    "opt3": "0.00045 °C⁻¹",
    "opt4": "0.00034 °C⁻¹",
    "correct": 1
  },
  {
    "question": "The fractional increase in volume per unit rise of temperature is referred to as",
    "opt1": "Volume expansivity",
    "opt2": "Area expansivity",
    "opt3": "Linear expansivity",
    "opt4": "Pressure expansivity",
    "correct": 1
  },
  {
    "question": "The proportionality constant in Hooke's law is called",
    "opt1": "Force constant",
    "opt2": "Strain",
    "opt3": "Stress",
    "opt4": "Extension",
    "correct": 1
  },
  {
    "question": "___________denotes the resulting effect of applied force on a body.",
    "opt1": "Tensile stress",
    "opt2": "Tensile strain",
    "opt3": "Elasticity",
    "opt4": "Extension",
    "correct": 2
  },
  {
    "question": "Which of the following is incorrect?",
    "opt1": "Pressure decreases with depth of liquid",
    "opt2": "Pressure in different liquids at the same depth varies directly with density.",
    "opt3": "Pressure at any point in a liquid acts equally in all directions.",
    "opt4": "Pressure at any point at the same depth within the same liquid is the same.",
    "correct": 1
  },
  {
    "question": "A mercury thread has 10 cm and 22 cm at ice and steam points. Find its temperature when the mercury thread is 19 cm long.",
    "opt1": "75.0°C",
    "opt2": "46.2°C",
    "opt3": "53.3°C",
    "opt4": "61.5°C",
    "correct": 1
  },
  {
    "question": "A wire has a force constant of 100 N/m. When stretched by the application of a certain force, it produces an extension of 20 cm. Calculate the work done in stretching the wire.",
    "opt1": "0.9 J",
    "opt2": "12 J",
    "opt3": "6 J",
    "opt4": "2 J",
    "correct": 4
  },
  {
    "question": "The three ways in which heat can be transferred are .......",
    "opt1": "Conduction, convection, radiation",
    "opt2": "Electrical, mechanical, chemical",
    "opt3": "Fire, light, gas",
    "opt4": "Stirrer, glass rod, heater",
    "correct": 1
  },
  {
    "question": "A block of copper of mass 0.6 kg at an initial temperature of 80°C is placed in water. When thermal equilibrium is attained, the temperature of the mixture is 40°C. How much heat is lost by the copper block? (Specific heat capacity of copper = 400 J/kg·K)",
    "opt1": "8400 J",
    "opt2": "3360 J",
    "opt3": "9600 J",
    "opt4": "5040 J",
    "correct": 3
  },
  {
    "question": "In the determination of specific heat capacity by electrical method, one of these apparatus is used to lag the aluminium (solid) to reduce heat loss to the surrounding",
    "opt1": "Felt",
    "opt2": "Glass rod",
    "opt3": "Thermometer",
    "opt4": "Heater",
    "correct": 1
  },
  {
    "question": "The quantity of heat required to raise the temperature of a body by 1 kelvin is",
    "opt1": "Heat capacity",
    "opt2": "Specific heat capacity",
    "opt3": "Black body",
    "opt4": "Evaporation",
    "correct": 1
  },
  {
    "question": "The S.I. unit of mass is",
    "opt1": "kg",
    "opt2": "J",
    "opt3": "J/kg",
    "opt4": "J/kg·K",
    "correct": 1
  },
  {
    "question": "Newton's 3rd law refers to action and reaction forces. These forces always occur in pairs and...",
    "opt1": "act on same object",
    "opt2": "act at right angles",
    "opt3": "never act on same object",
    "opt4": "move a body",
    "correct": 3
  },
  {
    "question": "Mass and weight...",
    "opt1": "both have same units",
    "opt2": "both measure inertia",
    "opt3": "both have different units",
    "opt4": "represent gravity",
    "correct": 3
  },
  {
    "question": "Which branch of physics deals with motion of bodies with reference to force?",
    "opt1": "Mechanics",
    "opt2": "Electromagnetism",
    "opt3": "Dynamics",
    "opt4": "Motion",
    "correct": 3
  },
  {
    "question": "Who initiated the study of dynamics?",
    "opt1": "Newton",
    "opt2": "Faraday",
    "opt3": "Galileo",
    "opt4": "Boyle",
    "correct": 3
  },
  {
    "question": "If a body of mass 4 kg moves with a velocity of 12 m/s in 6 seconds, what is its acceleration?",
    "opt1": "2 m/s²",
    "opt2": "4 m/s²",
    "opt3": "6 m/s²",
    "opt4": "10 m/s²",
    "correct": 1
  },
  {
    "question": "For a cone in unstable equilibrium, the center of gravity is _______ if displaced by a small force.",
    "opt1": "lowered",
    "opt2": "increased",
    "opt3": "varied",
    "opt4": "unchanged",
    "correct": 2
  },
  {
    "question": "Which of the following is responsible for acceleration in rotational motion?",
    "opt1": "Torque",
    "opt2": "Force",
    "opt3": "Work",
    "opt4": "Speed",
    "correct": 1
  },
  {
    "question": "The angular position of a rotating wheel is given by θ = 2 + 4t² + t³. What is the angular velocity at t = 3 s?",
    "opt1": "43 rad/s",
    "opt2": "51 rad/s",
    "opt3": "65 rad/s",
    "opt4": "75 rad/s",
    "correct": 2
  },
  {
    "question": "An example of torque on a body is when a football is being kicked...",
    "opt1": "obliquely",
    "opt2": "linearly",
    "opt3": "forcefully",
    "opt4": "vertically",
    "correct": 1
  },
  {
    "question": "A force F = -3i + 2j acts at a point x = 2 m, y = 6 m. What is the torque about the origin?",
    "opt1": "+18 Nm",
    "opt2": "+22 Nm",
    "opt3": "+10 Nm",
    "opt4": "-30 Nm",
    "correct": 2
  },
  {
    "question": "What is the dimension of the coefficient of attenuation?",
    "opt1": "Dimensionless",
    "opt2": "ML⁻³",
    "opt3": "ML⁻²T⁻¹",
    "opt4": "MLT",
    "correct": 1
  },
  {
    "question": "What is the dimension of impulse of a force?",
    "opt1": "MLT⁻1",
    "opt2": "MLT⁻²",
    "opt3": "MLT",
    "opt4": "ML⁻¹T⁻¹",
    "correct": 2
  },
  {
    "question": "i·i = j·j = k·k is...",
    "opt1": "Vector",
    "opt2": "Unity",
    "opt3": "Unit vector",
    "opt4": "Perpendicular",
    "correct": 2
  },
  {
    "question": "In Boyle's Law, which of the following remains constant?",
    "opt1": "Temperature",
    "opt2": "Pressure",
    "opt3": "Energy",
    "opt4": "Mass",
    "correct": 1
  },
  {
    "question": "Which set of variables is required in the study of gases?",
    "opt1": "Volume, pressure, and temperature",
    "opt2": "Density, volume, and mass",
    "opt3": "Volume, temperature, and heat capacity",
    "opt4": "Pressure, temperature, and latent heat",
    "correct": 1
  },
  {
    "question": "According to Charles’ Law, the volume of a gas is directly proportional to its:",
    "opt1": "Temperature",
    "opt2": "Mass",
    "opt3": "Energy",
    "opt4": "Liquid",
    "correct": 1
  },
  {
    "question": "Which of the following correctly represents the pressure law?",
    "opt1": "P₁/T₁ = P₂/T₂",
    "opt2": "P₁P₂ = T₁T₂",
    "opt3": "P₁/T₂ = P₂/T₁",
    "opt4": "P₁T₁ = P₂T₂",
    "correct": 1
  },
  {
    "question": "What is the fractional increase per unit rise in temperature called?",
    "opt1": "Linear expansivity",
    "opt2": "Area expansivity",
    "opt3": "Cubic expansivity",
    "opt4": "None of the above",
    "correct": 4
  },
  {
    "question": "Pressure at equal depths in different liquids depends directly on:",
    "opt1": "Density",
    "opt2": "Temperature",
    "opt3": "Volume",
    "opt4": "All of the above",
    "correct": 1
  },
  {
    "question": "The SI unit of surface tension is:",
    "opt1": "N/m",
    "opt2": "N",
    "opt3": "N/cm",
    "opt4": "m",
    "correct": 1
  },
  {
    "question": "The use of a thermometer is based on which law?",
    "opt1": "Zeroth Law",
    "opt2": "Pressure Law",
    "opt3": "Thermometric Law",
    "opt4": "General Gas Law",
    "correct": 1
  },
  {
    "question": "A mercury thermometer reads 12 cm at 0°C and 25 cm at 100°C. What is the temperature when it reads 18 cm?",
    "opt1": "46.2°C",
    "opt2": "75°C",
    "opt3": "53.3°C",
    "opt4": "61.5°C",
    "correct": 3
  },
  {
    "question": "A wire with a force constant of 90 N/m is stretched by 20 cm. What is the work done?",
    "opt1": "1.8 J",
    "opt2": "18 J",
    "opt3": "9 J",
    "opt4": "45 J",
    "correct": 2
  },
  {
    "question": "What type of heat transfer occurs in a rod without movement of particles?",
    "opt1": "Convection",
    "opt2": "Conduction",
    "opt3": "Radiation",
    "opt4": "Thermodynamics",
    "correct": 2
  },
  {
    "question": "A 0.2 kg copper block at 77°C is placed in water and reaches 35°C. How much heat is lost? (Specific heat capacity = 400 J/kg·K)",
    "opt1": "8400 J",
    "opt2": "3360 J",
    "opt3": "5040 J",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "In the specific heat capacity experiment, what supports the thread holding the object?",
    "opt1": "Beater",
    "opt2": "Glass rod",
    "opt3": "Thermometer",
    "opt4": "Felt",
    "correct": 3
  },
  {
    "question": "The amount of heat needed to raise the temperature of 1 kg of a substance by 1 K is called:",
    "opt1": "Heat capacity",
    "opt2": "Specific heat capacity",
    "opt3": "Black body",
    "opt4": "Evaporation",
    "correct": 2
  },
  {
    "question": "What is the SI unit of heat?",
    "opt1": "kg",
    "opt2": "J",
    "opt3": "J/kg",
    "opt4": "J/kg·K",
    "correct": 2
  },
  {
    "question": "Which force appears to oppose centripetal force in circular motion?",
    "opt1": "Gravitational force",
    "opt2": "Net force",
    "opt3": "Centrifugal force",
    "opt4": "Reluctant force",
    "correct": 3
  },
  {
    "question": "In practical physics, what does the term 'error' represent?",
    "opt1": "mistake",
    "opt2": "precision",
    "opt3": "uncertainty",
    "opt4": "wrong",
    "correct": 3
  },
  {
    "question": "What is the slope of a graph inclined at 45 degrees?",
    "opt1": "1",
    "opt2": "0",
    "opt3": "5",
    "opt4": "2",
    "correct": 1
  },
  {
    "question": "In the formula for calculating error in slope, what does 'n' represent?",
    "opt1": "range",
    "opt2": "number of readings",
    "opt3": "none",
    "opt4": "scaling",
    "correct": 2
  },
  {
    "question": "What is the fractional error for a 4.00 cm average with a maximum error of 0.02 cm?",
    "opt1": "0.003",
    "opt2": "2",
    "opt3": "0.005",
    "opt4": "none",
    "correct": 4
  },
  {
    "question": "How many variables are involved in the simple pendulum experiment?",
    "opt1": "2",
    "opt2": "6",
    "opt3": "4",
    "opt4": "1",
    "correct": 1
  },
  {
    "question": "In simple pendulum experiment, what does 'l' in the pendulum experiment correspond to?",
    "opt1": "l - H",
    "opt2": "l / T²",
    "opt3": "h - H",
    "opt4": "h",
    "correct": 4
  },
  {
    "question": "Which type of table is used to record laboratory results?",
    "opt1": "complete table",
    "opt2": "composite table",
    "opt3": "complementary table",
    "opt4": "none",
    "correct": 4
  },
  {
    "question": "The time for a pendulum to complete 20 oscillations is called the period of oscillation. Is this correct?",
    "opt1": "true",
    "opt2": "depends on situation",
    "opt3": "it is conditional",
    "opt4": "false",
    "correct": 4
  },
  {
    "question": "Ini, Effiong, Oke, Ali, and Nti measured the same table and recorded: 9.1, 8.98, 9.02, 9.00, 9.05 cm. What is the error?",
    "opt1": "±0.024",
    "opt2": "±0.25",
    "opt3": "±0.005",
    "opt4": "none",
    "correct": 1
  },
  {
    "question": "In a simple pendulum experiment, what is the slope of the graph of length vs T<sup>2</sup>, if g = 11 m/s²?",
    "opt1": "0.2264 m·s⁻²",
    "opt2": "0.2532 m·s⁻²",
    "opt3": "0.1773 m·s⁻²",
    "opt4": "0.2786 m·s⁻⁷",
    "correct": 4
  },
  {
    "question": "In Hooke's law experiment, if the initial pointer is at 17.50 cm and extension due to a 50g mass is 83 mm, what is the final pointer reading?",
    "opt1": "42.0 cm",
    "opt2": "30.30 cm",
    "opt3": "25.80 cm",
    "opt4": "34.10 cm",
    "correct": 3
  },
  {
    "question": "What is the value of t<sub>m</sub> when  t<sub>1</sub> = 13.41s and  t<sub>2</sub> = 15.19s?",
    "opt1": "24.605 s",
    "opt2": "14.30 s",
    "opt3": "12.245 s",
    "opt4": "9.9055 s",
    "correct": 2
  },
  {
    "question": "Find the frequency if time for 20 oscillations is 68.60s.",
    "opt1": "0.316 Hz",
    "opt2": "0.281 Hz",
    "opt3": "0.292 Hz",
    "opt4": "0.278 Hz",
    "correct": 3
  },
  {
    "question": "If a pendulum is made up of 82.25 cm string and a spherical metal of 1.0 cm diameter, what is the length of the pendulum?",
    "opt1": "83.25 cm",
    "opt2": "82.75 cm",
    "opt3": "82.25 cm",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "What is the value of -3 - 5?",
    "opt1": "-8",
    "opt2": "8",
    "opt3": "2",
    "opt4": "-2",
    "correct": 1
  },
  {
    "question": "In the height of ceiling experiment with the equation T² ∝ H, the graph of H versus T² is a straight line.",
    "opt1": "It is correct",
    "opt2": "It is impossible",
    "opt3": "If well scaled",
    "opt4": "Possible in mechanics",
    "correct": 1
  },

  {
    "question": "In the period of oscillation T of a meter rule supported at distance h from its center of gravity (G), using the equation T = 2π√((H + h)/g), the equation is...",
    "opt1": "True",
    "opt2": "Subject to confirmation",
    "opt3": "False",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "Experimental data when recorded in a table must maintain uniform number of decimal places per column.",
    "opt1": "Not true",
    "opt2": "True",
    "opt3": "Depends on the person recording",
    "opt4": "None of the above",
    "correct": 2
  }
]


quests1 = [
  {
    "question": "The law that states that if two bodies are separately in equilibrium with a third body, then all three bodies are in thermal equilibrium with each other is known as:",
    "opt1": "The zeroth",
    "opt2": "The first",
    "opt3": "The second",
    "opt4": "The third",
    "correct": 1
  },
  {
    "question": "Absolute zero is:",
    "opt1": "0 K",
    "opt2": "0°C",
    "opt3": "K",
    "opt4": "0°F",
    "correct": 1
  },
  {
    "question": "Absolute temperature means temperature in:",
    "opt1": "K",
    "opt2": "°F",
    "opt3": "°C",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "The unit of heat is:",
    "opt1": "Js",
    "opt2": "K",
    "opt3": "N",
    "opt4": "J",
    "correct": 1
  },
  {
    "question": "Convert -48.5°C to Kelvin:",
    "opt1": "224.65",
    "opt2": "321.65",
    "opt3": "-273.15",
    "opt4": "-321.65",
    "correct": 1
  },
  {
    "question": "Convert 242°C to Fahrenheit:",
    "opt1": "166.4",
    "opt2": "373",
    "opt3": "467.6",
    "opt4": "102.4",
    "correct": 3
  },
  {
    "question": "The Celsius scale of temperature is related to the thermodynamic scale by:",
    "opt1": "T = θ - 273.15",
    "opt2": "T = θ + 327",
    "opt3": "T = θ - 273",
    "opt4": "T = θ + 273.15",
    "correct": 4
  },
  {
    "question": "When an object is immersed in a fluid, it experiences:",
    "opt1": "Momentum",
    "opt2": "Upthrust",
    "opt3": "Pressure",
    "opt4": "Hydrostatic force",
    "correct": 2
  },
  {
    "question": "The value of the coefficient of surface tension for water at 20°C is:",
    "opt1": "7.26 × 10 N/m",
    "opt2": "6.27 × 10<sup>-2</sup> N/m",
    "opt3": "2.76 × 10<sup>-2</sup> N/m",
    "opt4": "72.6 × 10<sup>-2</sup> N/m",
    "correct": 4
  },
  {
    "question": "The collision between gas molecules with themselves and with the walls of the container gives rise to:",
    "opt1": "Potential energy",
    "opt2": "Gas pressure",
    "opt3": "Hydrostatic pressure",
    "opt4": "Temperature",
    "correct": 2
  },
  {
    "question": "Calculate the RMS speed of hydrogen molecules at 273K. Given: ρ = 6×10<sup>-2</sup> kg/m³ and P = 2.48×10<sup>3</sup> N/m².",
    "opt1": "1.13 × 10<sup>2</sup> m/s",
    "opt2": "1.83 × 10<sup>2</sup> m/s",
    "opt3": "3.52 × 10<sup>2</sup> m/s",
    "opt4": "18.3 × 10<sup>2</sup> m/s",
    "correct": 2
  },
  {
    "question": "Estimate the average kinetic energy of gas molecules at 48°C.",
    "opt1": "6.64 × 10<sup>-21</sup> J",
    "opt2": "7.723 × 10<sup>22</sup> J",
    "opt3": "7.72 × 10<sup>-21</sup> J",
    "opt4": "7.72 × 10<sup>-19</sup> J",
    "correct": 1
  },
  {
    "question": "The collisions of gas molecules are:",
    "opt1": "Inelastic",
    "opt2": "Perfectly elastic",
    "opt3": "Elastic and inelastic",
    "opt4": "None of the above",
    "correct": 2
  },
  {
    "question": "A thermodynamic system consists of:",
    "opt1": "Fixed mass of matter separated from its surroundings by a piston and cylinder",
    "opt2": "Varying mass separated by piston and cylinder",
    "opt3": "Fixed mass of liquid separated by cylinder and piston",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "_______ is a process in which the temperature of the system remains constant during change from its initial to final state.",
    "opt1": "Isochoric process",
    "opt2": "Isobaric process",
    "opt3": "Isothermal process",
    "opt4": "Adiabatic process",
    "correct": 3
  },
  {
    "question": "A refrigerator is a reversed ______.",
    "opt1": "Heat pump",
    "opt2": "Heat engine",
    "opt3": "Air-conditioner",
    "opt4": "Heat reservoir",
    "correct": 2
  },
  {
    "question": "SI Unit for entropy of a system is:",
    "opt1": "JKs<sup>–1</sup>",
    "opt2": "KJ<sup>-1</sup>",
    "opt3": "J/K",
    "opt4": "Nm",
    "correct": 3
  },
  {
    "question": "The heat reservoir which rejects heat is called:",
    "opt1": "Sink",
    "opt2": "Source",
    "opt3": "Heat engine",
    "opt4": "Refrigerator",
    "correct": 1
  },
  {
    "question": "Calculate the total entropy of the system when the entropy of a hot reservoir is -15.5J/K and that of the cold reservoir is 42 J/K.",
    "opt1": "57.5 J/K",
    "opt2": "26.5J/K",
    "opt3": "21 J/K",
    "opt4": "-57.5 J/K",
    "correct": 2
  },
  {
    "question": "The height to which a liquid rises in a capillary tube depends on:",
    "opt1": "Surface area of the tube",
    "opt2": "Temperature of the liquid",
    "opt3": "Density of the liquid",
    "opt4": "Nature of the liquid and the tube",
    "correct": 4
  },
  {
    "question": "________ is a substance that has some physical property which changes continuously as the temperature changes.",
    "opt1": "Radiant energy",
    "opt2": "Platinum only",
    "opt3": "All gases only",
    "opt4": "Thermometric substance",
    "correct": 4
  },
  {
    "question": "Which of the following equations represents an ideal gas for one mole of gas?",
    "opt1": "PV = RT",
    "opt2": "PV = nRT",
    "opt3": "PT = RV",
    "opt4": "PV = R",
    "correct": 1
  },
  {
    "question": "A gas whose behavior is described by PV = nRT is called:",
    "opt1": "Real gas",
    "opt2": "Ideal gas",
    "opt3": "Thermodynamic gas",
    "opt4": "Fixed gas",
    "correct": 2
  },
  {
    "question": "If the kinetic theory of gases is based on the ideal gas model, which of the following is NOT correct?",
    "opt1": "Average molecular kinetic energy is directly proportional to absolute temperature",
    "opt2": "All molecules do not move randomly",
    "opt3": "All molecules collide, and the collision is elastic",
    "opt4": "The force of attraction between molecules is negligible",
    "correct": 2
  },
  {
    "question": "Materials which break as soon as the elastic limit is exceeded are known as:",
    "opt1": "Ductile",
    "opt2": "Elastic",
    "opt3": "Brittle",
    "opt4": "Weak materials",
    "correct": 3
  },
  {
    "question": "In the presence of a detergent, the surface tension of a liquid:",
    "opt1": "Increases",
    "opt2": "Decreases",
    "opt3": "Remains constant",
    "opt4": "Becomes zero",
    "correct": 2
  },
  {
    "question": "The capillary rise of a liquid in a narrow tube is inversely proportional to the:",
    "opt1": "Density of the liquid",
    "opt2": "Surface tension of the liquid",
    "opt3": "Diameter of the tube",
    "opt4": "Viscosity of the liquid",
    "correct": 3
  },
  {
    "question": "A system undergoing an adiabatic process experiences:",
    "opt1": "No heat transfer",
    "opt2": "Constant volume",
    "opt3": "Constant pressure",
    "opt4": "Constant temperature",
    "correct": 1
  }
]

quests1 = [
  {
    "question": "Which of the following best defines education?",
    "opt1": "A process of gaining financial independence.",
    "opt2": "A deliberate and systematic influence exerted by a mature person on the immature through instruction and discipline.",
    "opt3": "A form of social entertainment.",
    "opt4": "A religious form of enlightenment.",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a form of education?",
    "opt1": "Formal education",
    "opt2": "Informal education",
    "opt3": "Non-formal education",
    "opt4": "Virtual education",
    "correct": 4
  },
  {
    "question": "Informal education can be best described as:",
    "opt1": "Structured and curriculum-based learning in schools.",
    "opt2": "Learning that takes place in organized educational institutions.",
    "opt3": "Learning that occurs through daily activities and interactions with the environment.",
    "opt4": "Learning under strict government supervision.",
    "correct": 3
  },
  {
    "question": "The purpose of formal education includes all EXCEPT:",
    "opt1": "Transmission of cultural heritage.",
    "opt2": "Training for specific occupations.",
    "opt3": "Promotion of superstition.",
    "opt4": "Development of intellectual and moral virtues.",
    "correct": 3
  },
  {
    "question": "Non-formal education differs from formal education in that it:",
    "opt1": "Is only available to adults.",
    "opt2": "Is confined to school buildings.",
    "opt3": "Occurs outside the formal school system and is often flexible and vocational.",
    "opt4": "Does not involve any learning process.",
    "correct": 3
  },
  {
    "question": "Which of the following best defines education according to Owolabi and Ogunleye?",
    "opt1": "Learning restricted to the classroom",
    "opt2": "The process of social transmission of culture",
    "opt3": "An informal way of acquiring wealth",
    "opt4": "A personal endeavor for certificates",
    "correct": 2
  },
  {
    "question": "Which dimension of education involves structured institutions and curriculum?",
    "opt1": "Informal education",
    "opt2": "Formal education",
    "opt3": "Non-formal education",
    "opt4": "Civic education",
    "correct": 2
  },
  {
    "question": "Non-formal education is mainly characterized by:",
    "opt1": "Rigid structure and certification",
    "opt2": "Age-specific content",
    "opt3": "Flexible learning and targeted skills",
    "opt4": "Teacher-centered learning",
    "correct": 3
  },
  {
    "question": "Informal education is often obtained through:",
    "opt1": "Television only",
    "opt2": "Schools and colleges",
    "opt3": "Daily life experiences",
    "opt4": "Government-sponsored programs",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a dimension of education?",
    "opt1": "Formal education",
    "opt2": "Non-formal education",
    "opt3": "Compulsory education",
    "opt4": "Informal education",
    "correct": 3
  },
  {
    "question": "What characterizes teaching as a noble profession?",
    "opt1": "High salaries",
    "opt2": "Political recognition",
    "opt3": "Commitment to nation building",
    "opt4": "Availability of office space",
    "correct": 3
  },
  {
    "question": "According to Bello and Madu, teachers serve as:",
    "opt1": "Mediators of government policies",
    "opt2": "Agents of social change",
    "opt3": "Representatives of school authorities",
    "opt4": "Enforcers of discipline",
    "correct": 2
  },
  {
    "question": "Which of the following is expected of a noble teacher?",
    "opt1": "Partiality in student evaluation",
    "opt2": "Laxity in classroom control",
    "opt3": "Exemplary behavior and role modeling",
    "opt4": "Neglect of professional development",
    "correct": 3
  },
  {
    "question": "The dignity of the teaching profession is upheld by:",
    "opt1": "Corporal punishment",
    "opt2": "Frequent industrial actions",
    "opt3": "Ethical conduct and discipline",
    "opt4": "Obedience to political leaders",
    "correct": 3
  },
  {
    "question": "Teachers contribute to national development primarily through:",
    "opt1": "Military service",
    "opt2": "Business entrepreneurship",
    "opt3": "Educating the citizenry",
    "opt4": "Judicial activism",
    "correct": 3
  },
  {
    "question": "What is the primary function of TRCN?",
    "opt1": "Regulating school fees",
    "opt2": "Recruiting teachers",
    "opt3": "Regulating and controlling teaching in Nigeria",
    "opt4": "Providing free education",
    "correct": 3
  },
  {
    "question": "Which law established the TRCN?",
    "opt1": "TRCN Act CAP T3 of 2004",
    "opt2": "Nigerian Teachers' Law of 1998",
    "opt3": "Educational Decree 25",
    "opt4": "National Education Policy Act",
    "correct": 1
  },
  {
    "question": "Which of these is NOT a TRCN mandate?",
    "opt1": "Issuing teaching licenses",
    "opt2": "Maintaining teachers' register",
    "opt3": "Training medical personnel",
    "opt4": "Enforcing teaching standards",
    "correct": 3
  },
  {
    "question": "Teachers in Nigeria must register with TRCN to:",
    "opt1": "Gain government employment",
    "opt2": "Be recognized as professionals",
    "opt3": "Earn higher salaries",
    "opt4": "Join school unions",
    "correct": 2
  },
  {
    "question": "TRCN ensures professionalism through:",
    "opt1": "Strike actions",
    "opt2": "Political affiliations",
    "opt3": "Certification and licensing",
    "opt4": "Community awareness",
    "correct": 3
  },
  {
    "question": "The first formal school in Nigeria was established in:",
    "opt1": "1821",
    "opt2": "1842",
    "opt3": "1859",
    "opt4": "1900",
    "correct": 2
  },
  {
    "question": "Who were primarily responsible for early education in Nigeria?",
    "opt1": "Colonial officers",
    "opt2": "Nigerian government",
    "opt3": "Missionaries",
    "opt4": "Traditional rulers",
    "correct": 3
  },
  {
    "question": "The major goal of early missionary education was to:",
    "opt1": "Prepare clerks",
    "opt2": "Train pastors and converts",
    "opt3": "Build empires",
    "opt4": "Support trade",
    "correct": 2
  },
  {
    "question": "Which region first adopted western education in Nigeria?",
    "opt1": "Northern region",
    "opt2": "Eastern region",
    "opt3": "Western region",
    "opt4": "Middle Belt",
    "correct": 3
  },
  {
    "question": "Which of these was NOT a characteristic of traditional Nigerian education?",
    "opt1": "Community participation",
    "opt2": "Oral transmission",
    "opt3": "Religious instruction",
    "opt4": "Textbook-based curriculum",
    "correct": 4
  },
  {
    "question": "Which stage is characterized by rapid physical growth and puberty?",
    "opt1": "Early childhood",
    "opt2": "Middle childhood",
    "opt3": "Adolescence",
    "opt4": "Infancy",
    "correct": 3
  },
  {
    "question": "Cognitive development in children is associated with the work of:",
    "opt1": "Freud",
    "opt2": "Piaget",
    "opt3": "Skinner",
    "opt4": "Maslow",
    "correct": 2
  },
  {
    "question": "Moral development in adolescents is best promoted through:",
    "opt1": "Punishment",
    "opt2": "Peer pressure",
    "opt3": "Ethical discussions",
    "opt4": "Strict discipline",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a stage in child development?",
    "opt1": "Infancy",
    "opt2": "Late adulthood",
    "opt3": "Early childhood",
    "opt4": "Middle childhood",
    "correct": 2
  },
  {
    "question": "Adolescents often struggle with identity due to:",
    "opt1": "Hormonal imbalance",
    "opt2": "Cognitive regression",
    "opt3": "Social expectations and self-awareness",
    "opt4": "Lack of physical growth",
    "correct": 3
  }
]

quests2 = [
  {
    "question": "Which of the following authors defined education as the process of giving and receiving systematic instruction to positively change the learner's behavior?",
    "opt1": "Chukwuma (2020)",
    "opt2": "Avwata (2021)",
    "opt3": "Dalhat (2022)",
    "opt4": "Bala (2022)",
    "correct": 3
  },
  {
    "question": "According to the chapter, education begins and ends at what stages of life?",
    "opt1": "From age 3 to retirement",
    "opt2": "From primary school to university",
    "opt3": "From birth to death",
    "opt4": "From adolescence to adulthood",
    "correct": 3
  },
  {
    "question": "Which of the following best reflects the **purpose** of education as stated in the chapter?",
    "opt1": "To make students obedient",
    "opt2": "To increase literacy rates only",
    "opt3": "To change the learner’s behavior positively",
    "opt4": "To reduce national unemployment",
    "correct": 3
  },
  {
    "question": "What is NOT one of the objectives of Chapter 1?",
    "opt1": "Explain types of education",
    "opt2": "Define philosophy of education",
    "opt3": "Explain the importance of education for global development",
    "opt4": "Mention characteristics of formal, informal, and non-formal education",
    "correct": 2
  },
  {
    "question": "Which form of education occurs within structured institutions and follows a set curriculum?",
    "opt1": "Formal education",
    "opt2": "Informal education",
    "opt3": "Non-formal education",
    "opt4": "Indigenous education",
    "correct": 1
  },
  {
    "question": "Which of these is TRUE about informal education?",
    "opt1": "It is received in classrooms only",
    "opt2": "It follows a formal curriculum",
    "opt3": "It happens through life experiences and interactions",
    "opt4": "It is regulated by government bodies",
    "correct": 3
  },
  {
    "question": "Non-formal education is best described as:",
    "opt1": "Structured education within schools",
    "opt2": "Learning that occurs through daily interaction only",
    "opt3": "Organized learning outside the formal system",
    "opt4": "Unplanned educational processes",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a feature of formal education?",
    "opt1": "Structured curriculum",
    "opt2": "Qualified teachers",
    "opt3": "Casual learning environment",
    "opt4": "Certificates awarded",
    "correct": 3
  },
  {
    "question": "Education helps a person to:",
    "opt1": "Become rich",
    "opt2": "Learn only to read and write",
    "opt3": "Communicate and understand the world around him",
    "opt4": "Avoid schooling",
    "correct": 3
  },
  {
    "question": "According to Chukwuma (2020), education promotes:",
    "opt1": "Daily routines",
    "opt2": "Life of the learner",
    "opt3": "Formal discipline only",
    "opt4": "Economic growth only",
    "correct": 2
  },
  {
    "question": "Which Latin term for education means 'to bring up or to raise'?",
    "opt1": "Educatum",
    "opt2": "Educare",
    "opt3": "Educere",
    "opt4": "Educatus",
    "correct": 2
  },
  {
    "question": "What is the focus of the Latin root 'Educere'?",
    "opt1": "To instruct",
    "opt2": "To raise a child",
    "opt3": "To lead forth or bring out",
    "opt4": "To form character",
    "correct": 3
  },
  {
    "question": "Which three key players are essential in every definition of education?",
    "opt1": "Curriculum, teacher, government",
    "opt2": "Teacher, student, environment",
    "opt3": "Parent, student, society",
    "opt4": "School, textbook, learner",
    "correct": 2
  },
  {
    "question": "What did the case study by Okebukola (1997) reveal about science teachers?",
    "opt1": "They agreed on a single definition of science",
    "opt2": "They refused to define science",
    "opt3": "They defined science from their specific disciplines",
    "opt4": "They misunderstood the concept of science",
    "correct": 3
  },
  {
    "question": "What does the term 'concept' primarily represent?",
    "opt1": "A permanent theory",
    "opt2": "A general idea or abstraction",
    "opt3": "A national curriculum",
    "opt4": "A standard method of teaching",
    "correct": 2
  },
  {
    "question": "Which scholar defined education as 'the bringing out of ideas latent in the mind'?",
    "opt1": "Plato",
    "opt2": "Aristotle",
    "opt3": "Socrates",
    "opt4": "Dewey",
    "correct": 3
  },
  {
    "question": "Which of these is NOT one of the five dimensions of education discussed?",
    "opt1": "Formal",
    "opt2": "Informal",
    "opt3": "International",
    "opt4": "Non-formal",
    "correct": 3
  },
  {
    "question": "What is the operational definition of a concept as stated in the chapter?",
    "opt1": "A direct observation",
    "opt2": "A theory backed by evidence",
    "opt3": "A measurable and testable construct",
    "opt4": "A philosophical assumption",
    "correct": 3
  },
  {
    "question": "Which of the following is a goal of education according to the chapter?",
    "opt1": "Increasing the population",
    "opt2": "Eliminating all traditions",
    "opt3": "Transmitting cultural heritage",
    "opt4": "Creating political parties",
    "correct": 3
  },
  {
    "question": "What does the National Policy on Education provide?",
    "opt1": "Annual education budget",
    "opt2": "Teacher salaries and allowances",
    "opt3": "Framework for Nigeria’s educational system",
    "opt4": "Private university licenses",
    "correct": 3
  },
  {
    "question": "What is the central theme of Chapter 3 in the textbook?",
    "opt1": "Science in Education",
    "opt2": "Teaching as a Noble Profession",
    "opt3": "ICT in Nigerian Schools",
    "opt4": "Philosophy of Education",
    "correct": 2
  },
  {
    "question": "Why is teaching considered a noble profession?",
    "opt1": "It has the highest salary",
    "opt2": "It requires no training",
    "opt3": "All other professions depend on it",
    "opt4": "It involves physical work",
    "correct": 3
  },
  {
    "question": "What distinguishes a profession from an occupation?",
    "opt1": "Level of interest",
    "opt2": "Salary attached",
    "opt3": "Training, ethics, and service",
    "opt4": "Age of practitioner",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a characteristic of the teaching profession?",
    "opt1": "Code of ethics",
    "opt2": "Public service orientation",
    "opt3": "Scientific base",
    "opt4": "Profit-making focus",
    "correct": 4
  },
  {
    "question": "The foundation of all other professions is:",
    "opt1": "Engineering",
    "opt2": "Law",
    "opt3": "Teaching",
    "opt4": "Medicine",
    "correct": 3
  },
  {
    "question": "Teaching as an interpersonal activity implies:",
    "opt1": "It is done in isolation",
    "opt2": "It involves only theory",
    "opt3": "It requires interaction with learners",
    "opt4": "It must be done online",
    "correct": 3
  },
  {
    "question": "Teaching is both a(n) ______ and a science.",
    "opt1": "Sport",
    "opt2": "Art",
    "opt3": "Business",
    "opt4": "Game",
    "correct": 2
  },
  {
    "question": "Which term refers to planned educational interaction?",
    "opt1": "Experiment",
    "opt2": "Sermon",
    "opt3": "Teaching",
    "opt4": "Debate",
    "correct": 3
  },
  {
    "question": "One major challenge to teaching in Nigeria today is:",
    "opt1": "Too many teachers",
    "opt2": "Lack of respect from students",
    "opt3": "Use of outdated methods",
    "opt4": "Integration of ICT",
    "correct": 4
  },
  {
    "question": "Which strategy can improve teaching’s nobility?",
    "opt1": "Increasing corporal punishment",
    "opt2": "Reducing entry qualifications",
    "opt3": "Integration of ICT in classrooms",
    "opt4": "Banning teacher unions",
    "correct": 3
  },
  {
    "question": "What year was the Teachers Registration Council of Nigeria (TRCN) originally established?",
    "opt1": "1999",
    "opt2": "1993",
    "opt3": "2004",
    "opt4": "1995",
    "correct": 2
  },
  {
    "question": "TRCN was created as a parastatal under which Nigerian ministry?",
    "opt1": "Ministry of Information",
    "opt2": "Ministry of Youth Development",
    "opt3": "Federal Ministry of Education",
    "opt4": "Ministry of Labour and Productivity",
    "correct": 3
  },
  {
    "question": "Which Act currently governs the TRCN?",
    "opt1": "TRCN Act Cap T3 of 2004",
    "opt2": "Nigerian Education Act 2003",
    "opt3": "Teacher Service Act 1992",
    "opt4": "TRCN Reformation Act 2001",
    "correct": 1
  },
  {
    "question": "What is the mission of the TRCN?",
    "opt1": "To build more schools for teachers",
    "opt2": "To promote foreign teacher exchange",
    "opt3": "To regulate teacher education and practice to meet global standards",
    "opt4": "To replace outdated teaching methods",
    "correct": 3
  },
  {
    "question": "What is the TRCN’s motto?",
    "opt1": "Teaching is Knowledge",
    "opt2": "Excellence through Dedication",
    "opt3": "Education for Growth",
    "opt4": "Teaching for Excellence",
    "correct": 4
  },
  {
    "question": "Which of these is NOT a function of the TRCN?",
    "opt1": "Registering teachers",
    "opt2": "Building schools",
    "opt3": "Licensing teachers",
    "opt4": "Maintaining teacher discipline",
    "correct": 2
  },
  {
    "question": "What is a core mandate of the TRCN?",
    "opt1": "Promotion of private education",
    "opt2": "Teacher certification and licensing",
    "opt3": "Construction of classrooms",
    "opt4": "Distribution of free books",
    "correct": 2
  },
  {
    "question": "Which of the following is part of TRCN’s future certification goals?",
    "opt1": "Certify only foreign-trained teachers",
    "opt2": "Generalized certifications only",
    "opt3": "Specialized certifications by education level",
    "opt4": "Certifications for retired teachers",
    "correct": 3
  },
  {
    "question": "How does TRCN aim to improve teacher quality?",
    "opt1": "Through physical fitness tests",
    "opt2": "By organizing spelling bees",
    "opt3": "Through certification and licensing",
    "opt4": "By publishing textbooks",
    "correct": 3
  },
  {
    "question": "What does the TRCN classify periodically?",
    "opt1": "Teacher salary grades",
    "opt2": "School locations",
    "opt3": "Teaching methods",
    "opt4": "Teachers by training and qualification",
    "correct": 4
  },
  {
    "question": "What is the main purpose of studying the history of education in Nigeria?",
    "opt1": "To determine the best modern teaching methods",
    "opt2": "To attract international students",
    "opt3": "To avoid collective amnesia and preserve educational heritage",
    "opt4": "To improve funding for Nigerian schools",
    "correct": 3
  },
  {
    "question": "Which educational system existed before the arrival of Islam and Christianity in Nigeria?",
    "opt1": "Islamic education",
    "opt2": "Missionary education",
    "opt3": "Western education",
    "opt4": "Traditional or indigenous education",
    "correct": 4
  },
  {
    "question": "According to the authors, traditional Nigerian education is described as:",
    "opt1": "Western-centric",
    "opt2": "Eurocentric",
    "opt3": "Afro-centric",
    "opt4": "Techno-centric",
    "correct": 3
  },
  {
    "question": "Which region of Nigeria was Islamic education firmly established in?",
    "opt1": "Southern region",
    "opt2": "Eastern region",
    "opt3": "Northern region",
    "opt4": "Western region",
    "correct": 3
  },
  {
    "question": "Christian missionary education in Nigeria was primarily focused in which region?",
    "opt1": "Northern Nigeria",
    "opt2": "Southern Nigeria",
    "opt3": "Central Nigeria",
    "opt4": "Entire country",
    "correct": 2
  },
  {
    "question": "Which of the following best describes indigenous Nigerian education?",
    "opt1": "Focused on religious conversion",
    "opt2": "Formal and certificate-based",
    "opt3": "Practical and culturally rooted",
    "opt4": "Centered on Latin grammar",
    "correct": 3
  },
  {
    "question": "According to the text, Christian missionaries combined evangelism with:",
    "opt1": "Healthcare",
    "opt2": "Political campaigns",
    "opt3": "Educational activities",
    "opt4": "Agricultural practices",
    "correct": 3
  },
  {
    "question": "What year was the first Nigerian university, the University of Ibadan, established?",
    "opt1": "1930",
    "opt2": "1948",
    "opt3": "1960",
    "opt4": "1957",
    "correct": 2
  },
  {
    "question": "Which of the following influenced Nigeria’s worldview and learning style?",
    "opt1": "Latin education",
    "opt2": "Indigenous education",
    "opt3": "French curriculum",
    "opt4": "Online education",
    "correct": 2
  },
  {
    "question": "What was the name of the first higher institution in Nigeria?",
    "opt1": "Yaba College of Technology",
    "opt2": "University of Lagos",
    "opt3": "Hope Waddle Training Institute",
    "opt4": "University of Ibadan",
    "correct": 3
  },
  {
    "question": "What is the primary distinction between growth and development?",
    "opt1": "Growth is emotional while development is physical",
    "opt2": "Growth involves increase in size; development involves overall changes including mental and emotional aspects",
    "opt3": "Growth stops at childhood; development continues forever",
    "opt4": "Growth is temporary; development is permanent",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT one of the four main areas of growth and development?",
    "opt1": "Physical",
    "opt2": "Cognitive",
    "opt3": "Spiritual",
    "opt4": "Emotional",
    "correct": 3
  },
  {
    "question": "At what stage does adolescence generally begin?",
    "opt1": "5 years",
    "opt2": "7 years",
    "opt3": "9–10 years",
    "opt4": "12–13 years",
    "correct": 3
  },
  {
    "question": "What characterizes early adolescence (10–13 years)?",
    "opt1": "Independence from parents and stable identity",
    "opt2": "Significant romantic relationships",
    "opt3": "Growth spurts and hormonal changes",
    "opt4": "Career choice and responsibilities",
    "correct": 3
  },
  {
    "question": "Which theory of development emphasizes identity formation during adolescence?",
    "opt1": "Piaget’s Cognitive Theory",
    "opt2": "Freud’s Psychoanalytic Theory",
    "opt3": "Erikson’s Psychosocial Theory",
    "opt4": "Skinner’s Behaviorist Theory",
    "correct": 3
  },
  {
    "question": "Which developmental stage is associated with abstract thinking and reasoning?",
    "opt1": "Infancy",
    "opt2": "Early childhood",
    "opt3": "Late childhood",
    "opt4": "Adolescence",
    "correct": 4
  },
  {
    "question": "Which of these is a major problem during adolescence?",
    "opt1": "Language acquisition",
    "opt2": "Identity confusion",
    "opt3": "Lack of motor skills",
    "opt4": "Toilet training",
    "correct": 2
  },
  {
    "question": "What is the final stage of adolescence as per the text?",
    "opt1": "14–16 years",
    "opt2": "17–18 years",
    "opt3": "18–21 years",
    "opt4": "20–25 years",
    "correct": 3
  },
  {
    "question": "Which of these domains is NOT explicitly listed as part of adolescent development?",
    "opt1": "Cognitive",
    "opt2": "Affective",
    "opt3": "Economic",
    "opt4": "Social",
    "correct": 3
  },
  {
    "question": "Which intervention is recommended for adolescent behavioral problems?",
    "opt1": "Increased punishment",
    "opt2": "Ignoring bad behavior",
    "opt3": "Intervention strategies like counseling",
    "opt4": "Isolation from peers",
    "correct": 3
  },

]

quests3 = [
    {
    "question": "Which principle of development suggests development follows a sequential pattern?",
    "opt1": "Inter-individual difference",
    "opt2": "Cephalocaudal principle",
    "opt3": "Mass to specific",
    "opt4": "Sequential development",
    "correct": 4
  },
  {
    "question": "What characterizes mid-adolescence (ages 14–17)?",
    "opt1": "Learning basic skills",
    "opt2": "Exploring identity and peer relationships",
    "opt3": "Mastery of adult roles",
    "opt4": "Start of formal schooling",
    "correct": 2
  },
  {
    "question": "Which factor does NOT directly affect adolescent development?",
    "opt1": "Family background",
    "opt2": "Cultural environment",
    "opt3": "Diet",
    "opt4": "Mathematical ability",
    "correct": 4
  },
  {
    "question": "Which phase involves more stable emotional development and decision-making?",
    "opt1": "Infancy",
    "opt2": "Early adolescence",
    "opt3": "Mid-adolescence",
    "opt4": "Late adolescence",
    "correct": 4
  },
  {
    "question": "The rapid change in body shape and size during adolescence is referred to as:",
    "opt1": "Cognitive jump",
    "opt2": "Maturation leap",
    "opt3": "Growth spurt",
    "opt4": "Hormonal balance",
    "correct": 3
  },
  {
    "question": "Which development domain includes moral reasoning and belief systems?",
    "opt1": "Physical",
    "opt2": "Cognitive",
    "opt3": "Social",
    "opt4": "Affective",
    "correct": 2
  },
  {
    "question": "Which psychologist is known for cognitive developmental stages?",
    "opt1": "Freud",
    "opt2": "Piaget",
    "opt3": "Skinner",
    "opt4": "Erikson",
    "correct": 2
  },
  {
    "question": "In which developmental phase do peer groups become most influential?",
    "opt1": "Late childhood",
    "opt2": "Early adolescence",
    "opt3": "Infancy",
    "opt4": "Old age",
    "correct": 2
  },
  {
    "question": "Which of these best describes the nature of development?",
    "opt1": "It is static and age-based",
    "opt2": "It stops after adolescence",
    "opt3": "It is lifelong and multidimensional",
    "opt4": "It is based only on heredity",
    "correct": 3
  },
  {
    "question": "Why is understanding adolescent development important for teachers?",
    "opt1": "To help select class monitors",
    "opt2": "To punish students more effectively",
    "opt3": "To manage classroom furniture",
    "opt4": "To adapt teaching to students’ needs",
    "correct": 4
  },
    {
    "question": "Which commission founded Yaba College of Technology?",
    "opt1": "Ashby Commission",
    "opt2": "Eliot Commission",
    "opt3": "MacPherson Commission",
    "opt4": "Ukeji Commission",
    "correct": 2
  },
  {
    "question": "When was the Ashby Commission report released?",
    "opt1": "1957",
    "opt2": "1965",
    "opt3": "1960",
    "opt4": "1943",
    "correct": 3
  },
  {
    "question": "What was one of the major flaws in Nigeria’s education system identified in the text?",
    "opt1": "Overemphasis on traditional education",
    "opt2": "Lack of university degrees",
    "opt3": "Neglect of technical and vocational education",
    "opt4": "Limited missionary schools",
    "correct": 3
  },
  {
    "question": "What type of education was emphasized more in Nigeria post-independence?",
    "opt1": "Technical education",
    "opt2": "Vocational education",
    "opt3": "Literary education",
    "opt4": "Engineering education",
    "correct": 3
  },
  {
    "question": "What year marked the introduction of the universal primary education scheme in Nigeria?",
    "opt1": "1957",
    "opt2": "1960",
    "opt3": "1948",
    "opt4": "1970",
    "correct": 1
  },
  {
    "question": "Which region effectively implemented free primary education in Nigeria?",
    "opt1": "Northern region",
    "opt2": "Eastern region",
    "opt3": "Western region",
    "opt4": "Central region",
    "correct": 3
  },
  {
    "question": "What role did the regional Ministry of Education play in the Western state?",
    "opt1": "Provided only textbooks",
    "opt2": "Hired teachers and administered schools",
    "opt3": "Funded private schools only",
    "opt4": "Supervised traditional education",
    "correct": 2
  },
  {
    "question": "Which group of people established the Hope Waddle Training Institute?",
    "opt1": "British government",
    "opt2": "Scottish missionaries",
    "opt3": "Nigerian government",
    "opt4": "French Catholic Mission",
    "correct": 2
  },
  {
    "question": "What year was Yaba College of Technology founded?",
    "opt1": "1943",
    "opt2": "1945",
    "opt3": "1947",
    "opt4": "1948",
    "correct": 3
  },
  {
    "question": "How many primary schools were there in Southern Nigeria by 1906?",
    "opt1": "100",
    "opt2": "126",
    "opt3": "87",
    "opt4": "150",
    "correct": 2
  },
    {
    "question": "What does TRCN regulate and control?",
    "opt1": "Teachers’ dress code",
    "opt2": "The teaching profession in all aspects",
    "opt3": "All universities in Nigeria",
    "opt4": "School fees",
    "correct": 2
  },
  {
    "question": "Which type of certification does TRCN currently offer?",
    "opt1": "Subject-specific",
    "opt2": "Generalized certification",
    "opt3": "Skill-based certification",
    "opt4": "Internship certification",
    "correct": 2
  },
  {
    "question": "What is one key benefit of TRCN licensing?",
    "opt1": "Allows teachers to work abroad",
    "opt2": "Improves student outcomes indirectly",
    "opt3": "Reduces number of teachers",
    "opt4": "Eliminates exams",
    "correct": 2
  },
  {
    "question": "What is TRCN's vision?",
    "opt1": "To replace old teachers with younger ones",
    "opt2": "To supervise foreign teacher training",
    "opt3": "To promote excellence through licensing and monitoring",
    "opt4": "To increase school enrollment",
    "correct": 3
  },
  {
    "question": "What does TRCN publish periodically?",
    "opt1": "Teacher promotion lists",
    "opt2": "School rankings",
    "opt3": "List of registered teachers",
    "opt4": "Pupil-teacher ratios",
    "correct": 3
  },
  {
    "question": "What is one way TRCN ensures access to its services?",
    "opt1": "Online social media platforms",
    "opt2": "Opening new liaison offices",
    "opt3": "Mobile classrooms",
    "opt4": "TV campaigns",
    "correct": 2
  },
  {
    "question": "What kind of training does TRCN emphasize?",
    "opt1": "Occasional and informal",
    "opt2": "Short weekend courses only",
    "opt3": "Vigorous and continuous",
    "opt4": "Only postgraduate-level",
    "correct": 3
  },
  {
    "question": "What is the significance of TRCN certification for teachers?",
    "opt1": "Provides salary advance",
    "opt2": "Makes them eligible for government loans",
    "opt3": "Qualifies them to teach and be recognized professionally",
    "opt4": "Exempts them from training",
    "correct": 3
  },
  {
    "question": "Which countries were mentioned as models for TRCN's future direction?",
    "opt1": "Ghana and South Africa",
    "opt2": "India and Canada",
    "opt3": "Finland and USA",
    "opt4": "Brazil and France",
    "correct": 3
  },
  {
    "question": "What new policy was highlighted in the chapter?",
    "opt1": "School Uniform Policy",
    "opt2": "Student Performance Evaluation",
    "opt3": "Teacher Career Path Policy",
    "opt4": "Education Budget Policy",
    "correct": 3
  },
    {
    "question": "Which of these best supports teaching as a profession?",
    "opt1": "Minimum of two years in the field",
    "opt2": "Formal training and certification",
    "opt3": "Working in rural areas",
    "opt4": "Flexible job description",
    "correct": 2
  },
  {
    "question": "Teaching contributes to nation-building because:",
    "opt1": "It creates politicians",
    "opt2": "It is compulsory for all",
    "opt3": "It develops human capital",
    "opt4": "It generates revenue",
    "correct": 3
  },
  {
    "question": "Which of the following is considered an ethical expectation of teachers?",
    "opt1": "Competitiveness",
    "opt2": "Confidentiality",
    "opt3": "Aggressiveness",
    "opt4": "Leniency",
    "correct": 2
  },
  {
    "question": "Which is true about occupations?",
    "opt1": "They require long academic training",
    "opt2": "They follow strict ethical codes",
    "opt3": "They are mostly manual jobs",
    "opt4": "They may not need specialized education",
    "correct": 4
  },
  {
    "question": "The integration of ICT in teaching helps to:",
    "opt1": "Replace the teacher",
    "opt2": "Discourage reading",
    "opt3": "Support modern learning",
    "opt4": "Encourage physical punishment",
    "correct": 3
  },
  {
    "question": "Which is NOT a challenge to the teaching profession mentioned in Chapter 3?",
    "opt1": "Low remuneration",
    "opt2": "Poor working conditions",
    "opt3": "Too many school holidays",
    "opt4": "Lack of professional development",
    "correct": 3
  },
  {
    "question": "What is one way to elevate teaching to its noble status?",
    "opt1": "Awarding bonuses to only top students",
    "opt2": "Improving teacher training and development",
    "opt3": "Discouraging ICT usage",
    "opt4": "Reducing teacher workload",
    "correct": 2
  },
  {
    "question": "What is meant by saying teaching is at the root of all professions?",
    "opt1": "Teachers earn the most money",
    "opt2": "Other professions learn from teachers",
    "opt3": "Teachers don’t retire",
    "opt4": "Only teachers go to school",
    "correct": 2
  },
  {
    "question": "What is the role of the teacher in nation building?",
    "opt1": "Training future citizens and professionals",
    "opt2": "Creating educational games",
    "opt3": "Providing free food",
    "opt4": "Organizing festivals",
    "correct": 1
  },
  {
    "question": "Who benefits most from elevating the status of teachers?",
    "opt1": "Government agencies",
    "opt2": "Learners and society",
    "opt3": "Sports organizations",
    "opt4": "Media houses",
    "correct": 2
  },
    {
    "question": "Which dimension of education occurs outside the formal school system but is organized?",
    "opt1": "Formal education",
    "opt2": "Informal education",
    "opt3": "Non-formal education",
    "opt4": "Casual learning",
    "correct": 3
  },
  {
    "question": "Which concept of education emphasizes continuous learning throughout life?",
    "opt1": "Permanent education",
    "opt2": "Vocational education",
    "opt3": "Tertiary education",
    "opt4": "Primary education",
    "correct": 1
  },
  {
    "question": "Education is said to be elastic in meaning because:",
    "opt1": "It has a fixed interpretation",
    "opt2": "It changes across schools only",
    "opt3": "It is dependent on individual and cultural perspectives",
    "opt4": "It is only taught in tertiary institutions",
    "correct": 3
  },
  {
    "question": "Which of these best describes an 'educated person' according to the chapter?",
    "opt1": "One who has a degree",
    "opt2": "One who can read and write only",
    "opt3": "One who demonstrates refined behavior and applies knowledge constructively",
    "opt4": "One who memorizes facts",
    "correct": 3
  },
  {
    "question": "Which of the following is a classification of concepts?",
    "opt1": "Simple, compound, hybrid",
    "opt2": "Concrete, abstract, process",
    "opt3": "Scientific, cultural, political",
    "opt4": "National, state, local",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a relevance of the National Policy on Education?",
    "opt1": "Provides educational structure",
    "opt2": "Unifies foreign and local schools",
    "opt3": "Clarifies government objectives",
    "opt4": "Specifies school calendar",
    "correct": 2
  },
  {
    "question": "How does informal education mainly occur?",
    "opt1": "Through organized teaching",
    "opt2": "In boarding schools only",
    "opt3": "Via daily experiences and interactions",
    "opt4": "Using textbooks and exams",
    "correct": 3
  },
  {
    "question": "The chapter concludes that no single definition of education is complete without:",
    "opt1": "Government support",
    "opt2": "Religious elements",
    "opt3": "Student, teacher, and environment",
    "opt4": "Textbooks and syllabus",
    "correct": 3
  },
  {
    "question": "Which of these definitions focuses more on the learner's personal development?",
    "opt1": "Educatum",
    "opt2": "Educare",
    "opt3": "Educere",
    "opt4": "Educado",
    "correct": 3
  },
  {
    "question": "What lesson can students draw from Okebukola's case study?",
    "opt1": "Avoid science subjects",
    "opt2": "Ignore discipline-specific views",
    "opt3": "Pay attention to minute details",
    "opt4": "Rely only on teachers’ views",
    "correct": 3
  },
    {
    "question": "Which statement is FALSE regarding education?",
    "opt1": "Education stops at adulthood",
    "opt2": "Education takes place from birth to death",
    "opt3": "Education is formal, informal, and non-formal",
    "opt4": "Education can be self-taught",
    "correct": 1
  },
  {
    "question": "Which form of education allows learning at any time or place, even without the teacher being physically present?",
    "opt1": "Formal education",
    "opt2": "Distance learning",
    "opt3": "Informal education",
    "opt4": "Non-formal education",
    "correct": 2
  },
  {
    "question": "Which of these best describes the chapter’s viewpoint on the cost of education?",
    "opt1": "Education is a waste of money",
    "opt2": "Education is too expensive for most people",
    "opt3": "Education is expensive, but ignorance is costlier",
    "opt4": "Education should be free everywhere",
    "correct": 3
  },
  {
    "question": "What does the chapter say education encourages?",
    "opt1": "Repetition of traditional methods",
    "opt2": "Obedience to authorities",
    "opt3": "Thinking outside the box and new ideas",
    "opt4": "Avoidance of change",
    "correct": 3
  },
  {
    "question": "According to Avwata (2021), education includes:",
    "opt1": "Only formal learning",
    "opt2": "Formal, informal, and non-formal processes",
    "opt3": "Military training",
    "opt4": "Political orientation",
    "correct": 2
  },
  {
    "question": "What aspect of education helps one develop confidence and courage?",
    "opt1": "Examinations",
    "opt2": "Classroom tests",
    "opt3": "Thinking and experimentation",
    "opt4": "Discipline alone",
    "correct": 3
  },
  {
    "question": "Which term refers to the design and imparting of a special curriculum to learners?",
    "opt1": "Knowledge sharing",
    "opt2": "Curriculum planning",
    "opt3": "Systematic education",
    "opt4": "Formal learning",
    "correct": 3
  },
  {
    "question": "What distinguishes non-formal education from formal education?",
    "opt1": "Non-formal has no goal",
    "opt2": "Non-formal lacks any form of structure",
    "opt3": "Non-formal takes place outside the school system",
    "opt4": "Non-formal uses textbooks always",
    "correct": 3
  },
  {
    "question": "According to the chapter, education contributes to:",
    "opt1": "Individual confusion",
    "opt2": "Global insecurity",
    "opt3": "National, regional, and global development",
    "opt4": "Isolationism",
    "correct": 3
  },
  {
    "question": "Self-teaching is considered possible today due to:",
    "opt1": "Lack of schools",
    "opt2": "Shortage of teachers",
    "opt3": "Flexible means of acquiring education",
    "opt4": "Traditional learning methods",
    "correct": 3
  }
  ]


quests4 = [
    {
    "question": "The major objective of classroom management is to:",
    "opt1": "Ensure silence in the classroom",
    "opt2": "Control student behavior",
    "opt3": "Facilitate effective learning",
    "opt4": "Complete the syllabus quickly",
    "correct": 3
  },
  {
    "question": "An example of a visual teaching aid is:",
    "opt1": "Audio tape",
    "opt2": "Blackboard",
    "opt3": "Classroom monitor",
    "opt4": "Radio",
    "correct": 2
  },
    {
    "question": "What are teaching resources primarily used for in the classroom?",
    "opt1": "To entertain students",
    "opt2": "To substitute teachers",
    "opt3": "To aid learning and teaching effectiveness",
    "opt4": "To reduce the syllabus",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a category of teaching resources?",
    "opt1": "Audio-visual materials",
    "opt2": "Human resources",
    "opt3": "Digital libraries",
    "opt4": "Classroom snacks",
    "correct": 4
  },
  {
    "question": "The term 'instructional materials' is synonymous with:",
    "opt1": "Extra curriculum",
    "opt2": "Recreational facilities",
    "opt3": "Teaching aids",
    "opt4": "Furniture",
    "correct": 3
  },
  {
    "question": "Who is primarily responsible for effective classroom management?",
    "opt1": "Students",
    "opt2": "Government",
    "opt3": "Teachers",
    "opt4": "Parents",
    "correct": 3
  },
  {
    "question": "Which of the following helps improve students' attention and retention?",
    "opt1": "Frequent punishment",
    "opt2": "Use of relevant teaching resources",
    "opt3": "Ignoring misbehavior",
    "opt4": "Extra homework",
    "correct": 2
  },
  {
    "question": "Which of the following is considered a human teaching resource?",
    "opt1": "Whiteboard",
    "opt2": "Projector",
    "opt3": "Textbook",
    "opt4": "Guest speaker",
    "correct": 4
  },
  {
    "question": "The systematic organization of classroom activities is called:",
    "opt1": "Curriculum design",
    "opt2": "Instructional supervision",
    "opt3": "Classroom management",
    "opt4": "Time tabling",
    "correct": 3
  },
  {
    "question": "Which factor does NOT directly influence classroom management?",
    "opt1": "Teacher's personality",
    "opt2": "Seating arrangement",
    "opt3": "Students' age",
    "opt4": "School fees",
    "correct": 4
  },
  {
    "question": "What is the primary focus of curriculum implementation?",
    "opt1": "Preparing instructional materials",
    "opt2": "Developing assessment methods",
    "opt3": "Delivering planned curriculum content",
    "opt4": "Evaluating students' performance",
    "correct": 3
  },
  {
    "question": "Which of these best defines curriculum development?",
    "opt1": "Instructional design",
    "opt2": "Planning, designing, and organizing learning experiences",
    "opt3": "Preparing examination materials",
    "opt4": "Organizing school management",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a type of curriculum?",
    "opt1": "Formal curriculum",
    "opt2": "Informal curriculum",
    "opt3": "Non-academic curriculum",
    "opt4": "Hidden curriculum",
    "correct": 3
  },
  {
    "question": "Which curriculum refers to what is actually taught in school?",
    "opt1": "Null curriculum",
    "opt2": "Hidden curriculum",
    "opt3": "Formal curriculum",
    "opt4": "Enacted curriculum",
    "correct": 4
  },
  {
    "question": "Which type of curriculum is not planned but learned through experience?",
    "opt1": "Formal curriculum",
    "opt2": "Hidden curriculum",
    "opt3": "Null curriculum",
    "opt4": "Official curriculum",
    "correct": 2
  },
  {
    "question": "What does 'null curriculum' imply?",
    "opt1": "Curriculum that is taught without assessment",
    "opt2": "Content intentionally excluded from instruction",
    "opt3": "Learning through informal settings",
    "opt4": "The sum total of all school activities",
    "correct": 2
  },
  {
    "question": "Which is the correct order of curriculum development stages?",
    "opt1": "Planning, Implementation, Evaluation",
    "opt2": "Evaluation, Planning, Design",
    "opt3": "Design, Planning, Implementation",
    "opt4": "Implementation, Planning, Evaluation",
    "correct": 1
  },
  {
    "question": "Curriculum implementation largely depends on:",
    "opt1": "Textbook publishers",
    "opt2": "Teachers and instructional methods",
    "opt3": "Government policies only",
    "opt4": "Curriculum theorists",
    "correct": 2
  },
  {
    "question": "Which type of curriculum includes extracurricular activities?",
    "opt1": "Hidden curriculum",
    "opt2": "Informal curriculum",
    "opt3": "Core curriculum",
    "opt4": "Null curriculum",
    "correct": 2
  },
    {
    "question": "A curriculum that adapts to learners' needs and environment is considered:",
    "opt1": "Static curriculum",
    "opt2": "Rigid curriculum",
    "opt3": "Dynamic curriculum",
    "opt4": "Hidden curriculum",
    "correct": 3
  },
  {
    "question": "Which of the following is a key strategy for accelerated learning according to Chapter 21?",
    "opt1": "Focusing only on assessments",
    "opt2": "Ignoring students' backgrounds",
    "opt3": "Using rote memorization",
    "opt4": "Employing interactive teaching methods",
    "correct": 4
  },
  {
    "question": "What role does student engagement play in accelerated performance?",
    "opt1": "It reduces performance",
    "opt2": "It is irrelevant",
    "opt3": "It enhances interest and learning speed",
    "opt4": "It complicates the teaching process",
    "correct": 3
  },
  {
    "question": "Which method supports individualized learning pace for students?",
    "opt1": "Group punishment",
    "opt2": "Personalized learning plans",
    "opt3": "Fixed curriculum for all",
    "opt4": "Lecture-only method",
    "correct": 2
  },
  {
    "question": "The use of multimedia tools in teaching helps in:",
    "opt1": "Slowing down learning",
    "opt2": "Increasing teacher workload only",
    "opt3": "Enhancing conceptual understanding",
    "opt4": "Reducing class participation",
    "correct": 3
  },
  {
    "question": "Which of the following encourages active learning?",
    "opt1": "Copying from the board",
    "opt2": "Teacher monologue",
    "opt3": "Project-based learning",
    "opt4": "Long-duration lectures",
    "correct": 3
  },
  {
    "question": "Differentiated instruction is best described as:",
    "opt1": "One-size-fits-all teaching",
    "opt2": "Using the same materials for all students",
    "opt3": "Tailoring teaching to students’ needs",
    "opt4": "Ignoring student feedback",
    "correct": 3
  },
  {
    "question": "Which teaching method combines both visual and auditory elements for better comprehension?",
    "opt1": "Chalk and talk",
    "opt2": "Audio-lingual method",
    "opt3": "Multisensory approach",
    "opt4": "Dictation exercises",
    "correct": 3
  },
  {
    "question": "Formative assessments help in:",
    "opt1": "Judging teachers’ salaries",
    "opt2": "Failing slow learners",
    "opt3": "Providing feedback for improvement",
    "opt4": "Ranking students for prizes",
    "correct": 3
  },
  {
    "question": "Collaborative learning is beneficial because it:",
    "opt1": "Promotes unhealthy competition",
    "opt2": "Discourages participation",
    "opt3": "Fosters peer interaction and teamwork",
    "opt4": "Eliminates the need for teachers",
    "correct": 3
  },
  {
    "question": "An important teacher skill for facilitating accelerated learning is:",
    "opt1": "Strict discipline enforcement",
    "opt2": "Mastery of content and flexible pedagogy",
    "opt3": "Avoiding student questions",
    "opt4": "Speaking fast to cover more topics",
    "correct": 2
  },
    {
    "question": "Which of the following is a key characteristic of a 21st-century classroom?",
    "opt1": "Teacher-centered instruction",
    "opt2": "Emphasis on rote memorization",
    "opt3": "Integration of technology in learning",
    "opt4": "Passive student participation",
    "correct": 3
  },
  {
    "question": "In managing a 21st-century classroom, teachers are expected to:",
    "opt1": "Maintain strict authority without input from students",
    "opt2": "Discourage collaboration among students",
    "opt3": "Incorporate student voice and choice",
    "opt4": "Rely solely on textbooks",
    "correct": 3
  },
  {
    "question": "Which teaching strategy is most aligned with 21st-century skills?",
    "opt1": "Drill and practice",
    "opt2": "Lecture-based delivery",
    "opt3": "Problem-based learning",
    "opt4": "Dictation and note-copying",
    "correct": 3
  },
  {
    "question": "What is a major benefit of using ICT in the classroom?",
    "opt1": "It increases teacher workload",
    "opt2": "It limits student access to knowledge",
    "opt3": "It facilitates personalized learning",
    "opt4": "It discourages group work",
    "correct": 3
  },
  {
    "question": "Which of the following best describes 21st-century learners?",
    "opt1": "Passive recipients of knowledge",
    "opt2": "Memorizers of facts",
    "opt3": "Active, collaborative, and tech-savvy",
    "opt4": "Restricted to classroom learning",
    "correct": 3
  },
  {
    "question": "To ensure effective teaching in the 21st-century classroom, teachers should:",
    "opt1": "Avoid using digital tools",
    "opt2": "Promote critical thinking and innovation",
    "opt3": "Focus solely on content delivery",
    "opt4": "Stick to a rigid curriculum",
    "correct": 2
  },
  {
    "question": "A defining feature of 21st-century teaching is:",
    "opt1": "Teacher monopoly on information",
    "opt2": "Integration of multiple literacies",
    "opt3": "Elimination of student assessments",
    "opt4": "Discouragement of feedback",
    "correct": 2
  },
  {
    "question": "Which classroom environment best supports 21st-century learning?",
    "opt1": "One with fixed seating and silent students",
    "opt2": "A traditional lecture hall",
    "opt3": "Flexible spaces that encourage interaction",
    "opt4": "Strict rows and chalkboard use only",
    "correct": 3
  },
  {
    "question": "One of the roles of the teacher in the 21st-century classroom is to:",
    "opt1": "Dictate every learning outcome",
    "opt2": "Facilitate and guide student inquiry",
    "opt3": "Ensure students avoid digital tools",
    "opt4": "Focus on low-order thinking skills",
    "correct": 2
  },
  {
    "question": "The goal of 21st-century education includes all EXCEPT:",
    "opt1": "Developing problem solvers",
    "opt2": "Fostering collaboration",
    "opt3": "Creating lifelong learners",
    "opt4": "Isolating learners from global trends",
    "correct": 4
  }

]

quests5 = [
    {
    "question": "Who plays the central role in curriculum implementation?",
    "opt1": "Curriculum developers",
    "opt2": "Students",
    "opt3": "Teachers",
    "opt4": "Policy makers",
    "correct": 3
  },
  {
    "question": "Which of these stakeholders is least involved in curriculum development?",
    "opt1": "Teachers",
    "opt2": "Students",
    "opt3": "Parents",
    "opt4": "Accountants",
    "correct": 4
  },
  {
    "question": "The curriculum that is officially approved and documented is known as:",
    "opt1": "Hidden curriculum",
    "opt2": "Official curriculum",
    "opt3": "Null curriculum",
    "opt4": "Informal curriculum",
    "correct": 2
  },
  {
    "question": "Curriculum evaluation is primarily aimed at:",
    "opt1": "Disciplining students",
    "opt2": "Training teachers",
    "opt3": "Improving curriculum effectiveness",
    "opt4": "Reducing school budgets",
    "correct": 3
  },
  {
    "question": "The term 'curriculum' originated from which language?",
    "opt1": "Latin",
    "opt2": "Greek",
    "opt3": "French",
    "opt4": "Arabic",
    "correct": 1
  },
  {
    "question": "Which curriculum is often learned unintentionally through school culture?",
    "opt1": "Null curriculum",
    "opt2": "Enacted curriculum",
    "opt3": "Hidden curriculum",
    "opt4": "Formal curriculum",
    "correct": 3
  },
  {
    "question": "Curriculum content should be selected based on all EXCEPT:",
    "opt1": "Relevance to learners",
    "opt2": "Cultural values",
    "opt3": "Teacher preferences only",
    "opt4": "National goals",
    "correct": 3
  },
  {
    "question": "Which is a major challenge in curriculum implementation?",
    "opt1": "Teacher absenteeism",
    "opt2": "Over-reliance on local content",
    "opt3": "Strict school uniforms",
    "opt4": "Student punctuality",
    "correct": 1
  },
  {
    "question": "The key output of curriculum development is:",
    "opt1": "Lesson notes",
    "opt2": "Curriculum guide",
    "opt3": "Timetable",
    "opt4": "Report cards",
    "correct": 2
  },
  {
    "question": "Effective curriculum implementation requires:",
    "opt1": "Political will only",
    "opt2": "Flexible learning schedules",
    "opt3": "Availability of resources and teacher training",
    "opt4": "Strict discipline policies",
    "correct": 3
  },
  {
    "question": "Which method promotes accelerated learning through hands-on experience?",
    "opt1": "Rote learning",
    "opt2": "Project-based learning",
    "opt3": "Copying notes",
    "opt4": "Dictation drills",
    "correct": 2
  },
  {
    "question": "According to Chapter 21, effective feedback should be:",
    "opt1": "Delayed and general",
    "opt2": "Negative and harsh",
    "opt3": "Timely and specific",
    "opt4": "Irregular and confusing",
    "correct": 3
  },
  {
    "question": "What is a major advantage of group work in the classroom?",
    "opt1": "Increases isolation",
    "opt2": "Discourages cooperation",
    "opt3": "Encourages peer learning",
    "opt4": "Eliminates individual accountability",
    "correct": 3
  },
  {
    "question": "Which of these best describes a flipped classroom approach?",
    "opt1": "Students learn new content at home and practice in class",
    "opt2": "Students memorize everything in class",
    "opt3": "Teachers lecture and give homework daily",
    "opt4": "All lessons are delivered online only",
    "correct": 1
  },
  {
    "question": "Which of the following best enhances critical thinking?",
    "opt1": "Objective tests only",
    "opt2": "Debates and discussions",
    "opt3": "Copying model answers",
    "opt4": "Recitation of facts",
    "correct": 2
  },
  {
    "question": "One of the benefits of using instructional technology is:",
    "opt1": "It replaces teachers completely",
    "opt2": "It bores learners",
    "opt3": "It enhances engagement and understanding",
    "opt4": "It restricts access to information",
    "correct": 3
  },
  {
    "question": "Accelerated learning requires teachers to:",
    "opt1": "Ignore student differences",
    "opt2": "Use only lectures",
    "opt3": "Adapt methods to student needs",
    "opt4": "Stick to rigid routines",
    "correct": 3
  },
  {
    "question": "In the context of this chapter, motivation helps students by:",
    "opt1": "Making them compete harshly",
    "opt2": "Increasing boredom",
    "opt3": "Enhancing focus and drive to learn",
    "opt4": "Encouraging absenteeism",
    "correct": 3
  },
  {
    "question": "Which learning style involves seeing and visualizing content?",
    "opt1": "Auditory",
    "opt2": "Kinesthetic",
    "opt3": "Visual",
    "opt4": "Tactile",
    "correct": 3
  },
  {
    "question": "What is the main focus of student-centered learning?",
    "opt1": "Teacher control of all activities",
    "opt2": "Maximizing test scores only",
    "opt3": "Active participation and collaboration",
    "opt4": "Punishment-based discipline",
    "correct": 3
  },
    {
    "question": "Effective use of teaching resources leads to:",
    "opt1": "Over-dependence on technology",
    "opt2": "Teacher laziness",
    "opt3": "Increased student engagement",
    "opt4": "Fewer exams",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a function of classroom management?",
    "opt1": "Promoting discipline",
    "opt2": "Fostering learning",
    "opt3": "Limiting participation",
    "opt4": "Reducing disruption",
    "correct": 3
  },
  {
    "question": "The use of teaching resources must align with:",
    "opt1": "Government policies",
    "opt2": "Students' expectations",
    "opt3": "Lesson objectives",
    "opt4": "Financial strength",
    "correct": 3
  },
  {
    "question": "Which principle is essential for selecting instructional materials?",
    "opt1": "Affordability only",
    "opt2": "Relevance to lesson objectives",
    "opt3": "Attractiveness alone",
    "opt4": "Large size",
    "correct": 2
  },
  {
    "question": "Classroom management includes all the following EXCEPT:",
    "opt1": "Discipline enforcement",
    "opt2": "Seating arrangement",
    "opt3": "Curriculum drafting",
    "opt4": "Time management",
    "correct": 3
  },
  {
    "question": "Which resource can be used to enhance digital learning in classrooms?",
    "opt1": "Chalkboard",
    "opt2": "Tablet devices",
    "opt3": "Handouts",
    "opt4": "Broom",
    "correct": 2
  },
  {
    "question": "The primary benefit of proper classroom management is:",
    "opt1": "Increased workload",
    "opt2": "Improved academic performance",
    "opt3": "Teacher fatigue",
    "opt4": "More free time",
    "correct": 2
  },
  {
    "question": "The teacher can promote active learning by:",
    "opt1": "Using outdated methods",
    "opt2": "Ignoring feedback",
    "opt3": "Integrating relevant instructional materials",
    "opt4": "Speaking monotonously",
    "correct": 3
  },
  {
    "question": "Instructional materials should be:",
    "opt1": "Expensive and flashy",
    "opt2": "Culturally irrelevant",
    "opt3": "Relevant and accessible",
    "opt4": "Only theoretical",
    "correct": 3
  },
  {
    "question": "The environment of the classroom should be:",
    "opt1": "Chaotic",
    "opt2": "Neutral",
    "opt3": "Unfriendly",
    "opt4": "Conducive to learning",
    "correct": 4
  },
    {
    "question": "Which of the following skills is considered crucial for learners in the 21st century?",
    "opt1": "Handwriting accuracy",
    "opt2": "Memorization of facts",
    "opt3": "Critical thinking",
    "opt4": "Passive listening",
    "correct": 3
  },
  {
    "question": "What is the major difference between traditional and 21st-century classrooms?",
    "opt1": "Teacher is absent in 21st-century classrooms",
    "opt2": "Students rely more on books",
    "opt3": "Learning is more student-centered",
    "opt4": "Learning happens only in physical spaces",
    "correct": 3
  },
  {
    "question": "Which of these best supports personalized learning?",
    "opt1": "One-size-fits-all instruction",
    "opt2": "Flexible digital tools",
    "opt3": "Strict curriculum pacing",
    "opt4": "Limited student interaction",
    "correct": 2
  },
  {
    "question": "What is a key outcome of using collaborative learning strategies?",
    "opt1": "Students learn to work independently only",
    "opt2": "Reduced social skills",
    "opt3": "Improved teamwork and communication",
    "opt4": "Decreased participation",
    "correct": 3
  },
  {
    "question": "A 21st-century teacher is expected to be:",
    "opt1": "A knowledge transmitter",
    "opt2": "A classroom disciplinarian",
    "opt3": "A facilitator and innovator",
    "opt4": "A non-digital native",
    "correct": 3
  },
  {
    "question": "Which of the following best encourages creativity in the classroom?",
    "opt1": "Rigid rules and uniform answers",
    "opt2": "Standardized testing only",
    "opt3": "Open-ended projects and exploration",
    "opt4": "Fixed content delivery",
    "correct": 3
  },
  {
    "question": "Digital literacy in the 21st-century classroom means:",
    "opt1": "Avoiding screen time",
    "opt2": "Memorizing computer parts",
    "opt3": "Using technology effectively for learning",
    "opt4": "Learning typing skills only",
    "correct": 3
  },
  {
    "question": "One of the advantages of integrating ICT in classrooms is:",
    "opt1": "Increased dependence on the teacher",
    "opt2": "Promotion of learner autonomy",
    "opt3": "Less content availability",
    "opt4": "Obsolete instructional methods",
    "correct": 2
  },
  {
    "question": "The 4Cs of 21st-century learning include all EXCEPT:",
    "opt1": "Communication",
    "opt2": "Collaboration",
    "opt3": "Cramping",
    "opt4": "Creativity",
    "correct": 3
  },
  {
    "question": "Which of the following supports global competence among learners?",
    "opt1": "Ignoring multicultural perspectives",
    "opt2": "Rote learning",
    "opt3": "Exposure to diverse worldviews",
    "opt4": "Focus on local issues only",
    "correct": 3
  }
  ]


quests6 = [
  {
    "question": "Which of the following best defines anthropology?",
    "opt1": "The study of ancient texts and languages",
    "opt2": "The comparative, holistic study of humankind",
    "opt3": "The analysis of human genetic mutations",
    "opt4": "The examination of animal behavior",
    "correct": 2
  },
  {
    "question": "What is meant by the 'holistic' perspective in anthropology?",
    "opt1": "Focusing exclusively on biological aspects",
    "opt2": "Studying cultural, biological, linguistic, and archaeological facets together",
    "opt3": "Comparing only two societies at a time",
    "opt4": "Emphasizing material culture over beliefs",
    "correct": 2
  },
  {
    "question": "Anthropology’s comparative method involves:",
    "opt1": "Isolating a single cultural trait in one society",
    "opt2": "Comparing cultural phenomena across different societies",
    "opt3": "Studying evolutionary changes in a laboratory",
    "opt4": "Translating ancient manuscripts literally",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT one of anthropology’s four traditional subfields?",
    "opt1": "Cultural anthropology",
    "opt2": "Archaeology",
    "opt3": "Sociology",
    "opt4": "Linguistic anthropology",
    "correct": 3
  },
  {
    "question": "Cultural anthropology primarily focuses on:",
    "opt1": "Human biological evolution",
    "opt2": "Patterns of human behavior, belief, and social organization",
    "opt3": "The excavation of ancient sites",
    "opt4": "Animal communication systems",
    "correct": 2
  },
  {
    "question": "Archaeology as a subfield of anthropology is concerned with:",
    "opt1": "Living languages and their syntax",
    "opt2": "Material remains of past societies",
    "opt3": "Human skeletal variation",
    "opt4": "Modern social institutions",
    "correct": 2
  },
  {
    "question": "Biological (physical) anthropology includes the study of:",
    "opt1": "Artifacts and architectural remains",
    "opt2": "Primatology and human osteology",
    "opt3": "Folklore and myths",
    "opt4": "Linguistic structures",
    "correct": 2
  },
  {
    "question": "Linguistic anthropology investigates:",
    "opt1": "The evolution of human anatomy",
    "opt2": "Material culture patterns",
    "opt3": "Human communication and language use",
    "opt4": "Population genetics",
    "correct": 3
  },
  {
    "question": "Applied anthropology is best described as:",
    "opt1": "Theoretical speculation about early hominins",
    "opt2": "Using anthropological knowledge to solve real-world problems",
    "opt3": "Recording languages for preservation only",
    "opt4": "Conducting laboratory experiments on human cells",
    "correct": 2
  },
  {
    "question": "Ethnography primarily involves:",
    "opt1": "Statistical analysis of survey data",
    "opt2": "Long-term, immersive fieldwork and participant observation",
    "opt3": "Excavating burial sites",
    "opt4": "Comparing artifact typologies",
    "correct": 2
  },
  {
    "question": "What is the most fundamental characteristic of culture?",
    "opt1": "It is inherited biologically",
    "opt2": "It is static and unchanging",
    "opt3": "It is learned and shared",
    "opt4": "It exists only in modern societies",
    "correct": 3
  },
  {
    "question": "Which of the following is an example of a cultural symbol?",
    "opt1": "Blood type",
    "opt2": "National flag",
    "opt3": "DNA sequence",
    "opt4": "Muscle reflex",
    "correct": 2
  },
  {
    "question": "Cultural norms can best be described as:",
    "opt1": "Instinctive behaviors shared by animals",
    "opt2": "Genetic predispositions",
    "opt3": "Standards or rules about acceptable behavior",
    "opt4": "Scientific laws that apply globally",
    "correct": 3
  },
  {
    "question": "Which of the following statements is true about culture?",
    "opt1": "Culture is biologically transmitted",
    "opt2": "Culture is only found in industrial societies",
    "opt3": "Culture influences perception and behavior",
    "opt4": "Culture and society are the same thing",
    "correct": 3
  },
  {
    "question": "What term describes the tendency to view one's own culture as superior?",
    "opt1": "Cultural relativism",
    "opt2": "Ethnocentrism",
    "opt3": "Globalization",
    "opt4": "Acculturation",
    "correct": 2
  },
  {
    "question": "What does cultural relativism encourage us to do?",
    "opt1": "Judge other cultures by our own values",
    "opt2": "Ignore differences among societies",
    "opt3": "Evaluate cultures based on their own standards",
    "opt4": "Replace traditional values with Western values",
    "correct": 3
  },
  {
    "question": "Enculturation refers to:",
    "opt1": "Adapting to environmental changes",
    "opt2": "Learning one’s culture through growing up in it",
    "opt3": "Replacing one culture with another",
    "opt4": "The process of evolution",
    "correct": 2
  },
  {
    "question": "Which is NOT a function of culture?",
    "opt1": "Guiding behavior",
    "opt2": "Providing identity",
    "opt3": "Determining genetic traits",
    "opt4": "Establishing social norms",
    "correct": 3
  },
  {
    "question": "The idea that culture is integrated means:",
    "opt1": "All parts of culture operate independently",
    "opt2": "One cultural trait exists in isolation",
    "opt3": "Cultural elements are interrelated and affect each other",
    "opt4": "Culture resists change completely",
    "correct": 3
  },
  {
    "question": "Which of the following best demonstrates culture as adaptive?",
    "opt1": "Wearing thick clothing in cold climates",
    "opt2": "Sweating during exercise",
    "opt3": "Heart rate adjustment",
    "opt4": "Blinking in bright light",
    "correct": 1
  },
  {
    "question": "What is the primary method of data collection in anthropology fieldwork?",
    "opt1": "Television interviews",
    "opt2": "Online surveys",
    "opt3": "Participant observation",
    "opt4": "DNA sampling",
    "correct": 3
  },
  {
    "question": "Which term describes the long-term, immersive approach of living among a group to study their culture?",
    "opt1": "Content analysis",
    "opt2": "Participant observation",
    "opt3": "Secondary research",
    "opt4": "Controlled experiments",
    "correct": 2
  },
  {
    "question": "What is an ethnography?",
    "opt1": "A map of ancient ruins",
    "opt2": "A statistical analysis of human DNA",
    "opt3": "A written account of fieldwork and cultural description",
    "opt4": "A video documentary of a ceremony",
    "correct": 3
  },
  {
    "question": "Which of the following best defines informants in anthropology?",
    "opt1": "Government officials",
    "opt2": "People who supply personal data for experiments",
    "opt3": "Local individuals who help anthropologists understand their culture",
    "opt4": "Subjects of medical trials",
    "correct": 3
  },
  {
    "question": "Which is NOT a method commonly used in anthropological fieldwork?",
    "opt1": "Gene sequencing",
    "opt2": "Interviewing",
    "opt3": "Mapping",
    "opt4": "Genealogy",
    "correct": 1
  },
  {
    "question": "The reflexive approach in fieldwork emphasizes:",
    "opt1": "Staying objective and invisible",
    "opt2": "Ignoring personal biases",
    "opt3": "Considering the anthropologist’s own influence on research",
    "opt4": "Eliminating cultural context",
    "correct": 3
  },
  {
    "question": "What is a key ethical concern in anthropological research?",
    "opt1": "Securing funding",
    "opt2": "Maintaining objectivity at all costs",
    "opt3": "Protecting the dignity and rights of participants",
    "opt4": "Writing lengthy reports",
    "correct": 3
  },
  {
    "question": "Informed consent in fieldwork involves:",
    "opt1": "Getting participants to agree without telling them the purpose",
    "opt2": "Paying locals for their participation",
    "opt3": "Informing participants of their role and obtaining permission",
    "opt4": "Signing legal contracts",
    "correct": 3
  },
  {
    "question": "Anthropologists often keep detailed daily notes during fieldwork. These are called:",
    "opt1": "Field diaries",
    "opt2": "Testimonies",
    "opt3": "Reports",
    "opt4": "Scripts",
    "correct": 1
  },
  {
    "question": "Which skill is most crucial for successful fieldwork?",
    "opt1": "Translation",
    "opt2": "Cultural sensitivity",
    "opt3": "Photography",
    "opt4": "Cooking",
    "correct": 2
  },
  {
    "question": "A dialect is:",
    "opt1": "A separate language with its own alphabet",
    "opt2": "A regional or social variation of a language",
    "opt3": "An outdated version of speech",
    "opt4": "A mix of slang and formal words",
    "correct": 2
  },
  {
    "question": "Paralanguage includes all of the following EXCEPT:",
    "opt1": "Tone of voice",
    "opt2": "Pitch",
    "opt3": "Volume",
    "opt4": "Grammar rules",
    "correct": 4
  },
  {
    "question": "Kinesics is the study of:",
    "opt1": "Written communication",
    "opt2": "Body movement and gestures",
    "opt3": "Phonetic transcription",
    "opt4": "Language evolution",
    "correct": 2
  },
  {
    "question": "Which of the following is an example of proxemics?",
    "opt1": "The use of metaphor in poetry",
    "opt2": "Physical distance maintained during interaction",
    "opt3": "Language pronunciation errors",
    "opt4": "Written punctuation marks",
    "correct": 2
  },
  {
    "question": "What is a lexicon?",
    "opt1": "A book of grammar rules",
    "opt2": "The set of all morphemes in a culture",
    "opt3": "The vocabulary of a language",
    "opt4": "An index of body language cues",
    "correct": 3
  },
  {
    "question": "Syntax refers to:",
    "opt1": "The structure of bones in the mouth",
    "opt2": "Rules for arranging words in sentences",
    "opt3": "Language borrowing",
    "opt4": "The act of signing documents",
    "correct": 2
  },
  {
    "question": "Which field studies the structure of speech sounds?",
    "opt1": "Morphology",
    "opt2": "Semantics",
    "opt3": "Phonology",
    "opt4": "Symbolism",
    "correct": 3
  },
  {
    "question": "Which of the following can be considered a sociolinguistic study?",
    "opt1": "Analyzing ancient fossils",
    "opt2": "Measuring bones for speech capacity",
    "opt3": "Studying language use in social contexts",
    "opt4": "Studying monkey calls",
    "correct": 3
  },
  {
    "question": "Which is a key reason anthropologists value endangered languages?",
    "opt1": "They provide new economic opportunities",
    "opt2": "They are grammatically simpler",
    "opt3": "They preserve unique worldviews and knowledge",
    "opt4": "They replace dominant languages",
    "correct": 3
  },
  {
    "question": "Language is considered a cultural resource because it:",
    "opt1": "Cannot be taught or learned",
    "opt2": "Is genetically determined",
    "opt3": "Expresses and reinforces cultural meanings",
    "opt4": "Functions like biological inheritance",
    "correct": 3
  },
  {
    "question": "Which method is most often used to date fossils?",
    "opt1": "Oral tradition",
    "opt2": "Carbon-14 dating",
    "opt3": "X-ray photography",
    "opt4": "Thermal imaging",
    "correct": 2
  },
  {
    "question": "Which of the following is considered a hominin trait?",
    "opt1": "Knuckle-walking",
    "opt2": "Bipedalism",
    "opt3": "Sharp canine teeth",
    "opt4": "Quadrupedal motion",
    "correct": 2
  },
  {
    "question": "What is the significance of the foramen magnum position in human evolution?",
    "opt1": "It indicates diet preference",
    "opt2": "It shows vocal range",
    "opt3": "It reflects upright posture",
    "opt4": "It relates to brain size",
    "correct": 3
  },
  {
    "question": "Which of these species is considered the earliest known hominin?",
    "opt1": "Homo erectus",
    "opt2": "Australopithecus afarensis",
    "opt3": "Sahelanthropus tchadensis",
    "opt4": "Neanderthalensis",
    "correct": 3
  },
  {
    "question": "Australopithecus afarensis is best known from the fossil skeleton nicknamed:",
    "opt1": "Tom",
    "opt2": "Lucy",
    "opt3": "Ardi",
    "opt4": "Koko",
    "correct": 2
  },
  {
    "question": "What is a defining feature of Homo habilis?",
    "opt1": "Use of written symbols",
    "opt2": "Creation of fire",
    "opt3": "Use of stone tools",
    "opt4": "Burial of the dead",
    "correct": 3
  },
  {
    "question": "Which hominin species is known for migrating out of Africa first?",
    "opt1": "Homo habilis",
    "opt2": "Homo erectus",
    "opt3": "Homo neanderthalensis",
    "opt4": "Homo sapiens",
    "correct": 2
  },
  {
    "question": "What does the term 'Oldowan tools' refer to?",
    "opt1": "Weapons used by early kings",
    "opt2": "The oldest bronze artifacts",
    "opt3": "Simple stone tools made by Homo habilis",
    "opt4": "Pottery used in rituals",
    "correct": 3
  },
  {
    "question": "Which of the following traits distinguish Homo sapiens from earlier hominins?",
    "opt1": "Bipedal locomotion",
    "opt2": "Larger brain and symbolic thought",
    "opt3": "Thick brow ridges",
    "opt4": "Knuckle-walking",
    "correct": 2
  },
  {
    "question": "Neanderthals are thought to have:",
    "opt1": "Evolved in Australia",
    "opt2": "Lacked social cooperation",
    "opt3": "Used complex tools and buried their dead",
    "opt4": "Used only basic hand gestures",
    "correct": 3
  },
  {
    "question": "The evolutionary process by which new species arise is known as:",
    "opt1": "Enculturation",
    "opt2": "Speciation",
    "opt3": "Domestication",
    "opt4": "Globalization",
    "correct": 2
  },


]



quests7 = [
  {
    "question": "What was the main assumption of early evolutionism in anthropology?",
    "opt1": "All societies are static",
    "opt2": "Societies progress through fixed stages from 'primitive' to 'civilized'",
    "opt3": "Each culture is unique and incomparable",
    "opt4": "Human behavior is biologically determined",
    "correct": 2
  },
  {
    "question": "Who is associated with the development of cultural functionalism?",
    "opt1": "Franz Boas",
    "opt2": "E.B. Tylor",
    "opt3": "Bronisław Malinowski",
    "opt4": "Margaret Mead",
    "correct": 3
  },
  {
    "question": "Which of the following best describes Franz Boas' contribution to anthropology?",
    "opt1": "Support for racial classification",
    "opt2": "Promotion of unilineal evolution",
    "opt3": "Development of historical particularism",
    "opt4": "Belief in biological determinism",
    "correct": 3
  },
  {
    "question": "Structural functionalism views society as:",
    "opt1": "A collection of isolated individuals",
    "opt2": "A chaotic system",
    "opt3": "An integrated whole where parts serve social needs",
    "opt4": "A place without shared values",
    "correct": 3
  },
  {
    "question": "Which school of thought emphasizes the role of symbols in constructing meaning?",
    "opt1": "Cultural materialism",
    "opt2": "Symbolic anthropology",
    "opt3": "Neo-evolutionism",
    "opt4": "Functionalism",
    "correct": 2
  },
  {
    "question": "What is the main idea behind cultural materialism?",
    "opt1": "Religion is the primary driver of society",
    "opt2": "Material conditions determine social organization and ideology",
    "opt3": "Cultures evolve independently of environment",
    "opt4": "History has no influence on culture",
    "correct": 2
  },
  {
    "question": "Postmodernism in anthropology is characterized by:",
    "opt1": "Objectivity and grand theories",
    "opt2": "Rejecting ethnographic subjectivity",
    "opt3": "Questioning authority, objectivity, and the possibility of a single truth",
    "opt4": "Strict scientific quantification",
    "correct": 3
  },
  {
    "question": "Which theory emphasizes the dynamic interplay of power, inequality, and resistance in cultures?",
    "opt1": "Evolutionism",
    "opt2": "Structural functionalism",
    "opt3": "Conflict theory",
    "opt4": "Cultural relativism",
    "correct": 3
  },
  {
    "question": "Clifford Geertz is most associated with which anthropological perspective?",
    "opt1": "Cultural ecology",
    "opt2": "Interpretive anthropology",
    "opt3": "Neofunctionalism",
    "opt4": "Social Darwinism",
    "correct": 2
  },
  {
    "question": "Which theoretical approach critiques the neutrality of the researcher and emphasizes reflexivity?",
    "opt1": "Symbolic anthropology",
    "opt2": "Functionalism",
    "opt3": "Postmodernism",
    "opt4": "Cultural evolutionism",
    "correct": 3
  },
  {
    "question": "What is the primary critique of the biological concept of race in anthropology?",
    "opt1": "It accurately reflects human genetic diversity",
    "opt2": "It is based on clear, scientific classifications",
    "opt3": "It oversimplifies and distorts the complex reality of human variation",
    "opt4": "It is the only way to study human ancestry",
    "correct": 3
  },
  {
    "question": "Which factor best explains the physical differences observed among human populations?",
    "opt1": "Cultural rituals",
    "opt2": "Environmental adaptations over generations",
    "opt3": "Differences in intelligence",
    "opt4": "Language barriers",
    "correct": 2
  },
  {
    "question": "What does clinal variation in human biology refer to?",
    "opt1": "Sharp divisions between racial groups",
    "opt2": "Random mutations in DNA",
    "opt3": "Gradual changes in traits across geographic regions",
    "opt4": "Changes that follow national borders",
    "correct": 3
  },
  {
    "question": "Which of the following best represents an example of social construction of race?",
    "opt1": "Genetic differences in blood types",
    "opt2": "Classifying people based on perceived skin color and ancestry",
    "opt3": "Measuring height in children",
    "opt4": "Analyzing fingerprint patterns",
    "correct": 2
  },
  {
    "question": "How does anthropology understand the concept of race today?",
    "opt1": "As a valid biological classification",
    "opt2": "As a purely medical category",
    "opt3": "As a cultural and social concept with real consequences",
    "opt4": "As irrelevant to social life",
    "correct": 3
  },
  {
    "question": "Which statement reflects the current scientific consensus on race and genetics?",
    "opt1": "There are distinct racial gene pools",
    "opt2": "Most genetic variation exists between races",
    "opt3": "Race is a useful category for understanding genetic differences",
    "opt4": "There is more genetic variation within so-called races than between them",
    "correct": 4
  },
  {
    "question": "Which practice historically reinforced racial classification systems?",
    "opt1": "Multicultural education",
    "opt2": "Colonialism and slavery",
    "opt3": "Ethnographic fieldwork",
    "opt4": "Genetic counseling",
    "correct": 2
  },
  {
    "question": "Which term describes the belief that some races are inherently superior to others?",
    "opt1": "Racism",
    "opt2": "Clinalism",
    "opt3": "Biological essentialism",
    "opt4": "Cultural relativism",
    "correct": 1
  },
  {
    "question": "How does anthropology contribute to the fight against racism?",
    "opt1": "By proving cultural supremacy of some groups",
    "opt2": "By promoting eugenics",
    "opt3": "By showing that race is a cultural idea, not a biological reality",
    "opt4": "By restricting interracial interactions",
    "correct": 3
  },
  {
    "question": "Which of the following best illustrates institutional racism?",
    "opt1": "A personal insult based on race",
    "opt2": "Government policies that disadvantage certain racial groups",
    "opt3": "A one-time incident of racial bias",
    "opt4": "Genetic similarities across populations",
    "correct": 2
  },
  {
    "question": "What is the basic function of kinship in most societies?",
    "opt1": "To enforce religious beliefs",
    "opt2": "To determine social roles, rights, and obligations",
    "opt3": "To divide people by wealth",
    "opt4": "To eliminate marriage customs",
    "correct": 2
  },
  {
    "question": "What term describes a family that includes parents, children, and other relatives?",
    "opt1": "Nuclear family",
    "opt2": "Extended family",
    "opt3": "Isolated family",
    "opt4": "Sibling family",
    "correct": 2
  },
  {
    "question": "Which type of descent traces lineage through the mother’s line only?",
    "opt1": "Patrilineal descent",
    "opt2": "Bilineal descent",
    "opt3": "Matrilineal descent",
    "opt4": "Neolocal descent",
    "correct": 3
  },
  {
    "question": "What is endogamy?",
    "opt1": "Marriage outside the social group",
    "opt2": "Prohibition of all marriage",
    "opt3": "Marriage within a specific social or cultural group",
    "opt4": "Marriage between enemies",
    "correct": 3
  },
  {
    "question": "Polygyny refers to a marriage system where:",
    "opt1": "One man marries one woman",
    "opt2": "One woman marries multiple men",
    "opt3": "One man marries multiple women",
    "opt4": "All individuals marry each other equally",
    "correct": 3
  },
  {
    "question": "Which marriage practice involves the husband's family providing resources to the wife's family?",
    "opt1": "Bride service",
    "opt2": "Dowry",
    "opt3": "Bridewealth",
    "opt4": "Matriarchal exchange",
    "correct": 3
  },
  {
    "question": "Which term best describes post-marital residence with the husband's family?",
    "opt1": "Neolocal",
    "opt2": "Matrilocal",
    "opt3": "Avunculocal",
    "opt4": "Patrilocal",
    "correct": 4
  },
  {
    "question": "A clan differs from a lineage in that:",
    "opt1": "A clan has no known common ancestor",
    "opt2": "A clan is smaller and tightly knit",
    "opt3": "Lineages trace descent through both sides equally",
    "opt4": "Lineages do not affect inheritance",
    "correct": 1
  },
  {
    "question": "Which of the following is a function of marriage in most cultures?",
    "opt1": "Limiting human reproduction",
    "opt2": "Establishing legal paternity and family alliances",
    "opt3": "Promoting isolation",
    "opt4": "Preventing economic exchanges",
    "correct": 2
  },
  {
    "question": "Which family type is most associated with industrial societies?",
    "opt1": "Extended family",
    "opt2": "Patrilineal family",
    "opt3": "Nuclear family",
    "opt4": "Fraternal family",
    "correct": 3
  },
  {
    "question": "What distinguishes ethnographic fieldwork from other research methods in anthropology?",
    "opt1": "It relies entirely on surveys",
    "opt2": "It involves immersive, long-term observation of a cultural group",
    "opt3": "It avoids human subjects entirely",
    "opt4": "It is performed in laboratories",
    "correct": 2
  },
  {
    "question": "Which method best supports the anthropologist's goal of understanding insider perspectives?",
    "opt1": "Random sampling",
    "opt2": "Participant observation",
    "opt3": "Content analysis",
    "opt4": "Aerial photography",
    "correct": 2
  },
  {
    "question": "What is the key purpose of using interviews in ethnographic research?",
    "opt1": "To test medical hypotheses",
    "opt2": "To obtain local meanings, narratives, and interpretations",
    "opt3": "To identify bone structures",
    "opt4": "To record government data",
    "correct": 2
  },
  {
    "question": "Why is reflexivity important in cultural anthropology research?",
    "opt1": "It minimizes fieldwork time",
    "opt2": "It enhances statistical analysis",
    "opt3": "It helps researchers recognize their own influence on data",
    "opt4": "It ensures legal compliance",
    "correct": 3
  },
  {
    "question": "A ‘gatekeeper’ in field research refers to:",
    "opt1": "An official who denies access to researchers",
    "opt2": "A data analyst who processes findings",
    "opt3": "A local individual who facilitates community access for the researcher",
    "opt4": "A person who funds the research",
    "correct": 3
  },
  {
    "question": "Which of the following is a quantitative method in anthropology?",
    "opt1": "Mapping kinship systems",
    "opt2": "Recording oral histories",
    "opt3": "Counting the frequency of rituals",
    "opt4": "Writing ethnographic narratives",
    "correct": 3
  },
  {
    "question": "Which ethical responsibility must always be observed in anthropological research?",
    "opt1": "Publication in top journals",
    "opt2": "Informed consent from participants",
    "opt3": "Approval by politicians",
    "opt4": "Avoiding controversial topics",
    "correct": 2
  },
  {
    "question": "The term 'emic' perspective refers to:",
    "opt1": "The anthropologist's analytical viewpoint",
    "opt2": "An external observer’s view",
    "opt3": "The insider’s view and cultural understanding",
    "opt4": "The laboratory-based interpretation",
    "correct": 3
  },
  {
    "question": "Which of the following best exemplifies triangulation in fieldwork?",
    "opt1": "Using one method to validate data",
    "opt2": "Combining interviews, surveys, and observation for confirmation",
    "opt3": "Ignoring conflicting data sources",
    "opt4": "Calculating mean scores only",
    "correct": 2
  },
  {
    "question": "Why do anthropologists conduct genealogical studies?",
    "opt1": "To study DNA sequencing",
    "opt2": "To map power grids",
    "opt3": "To understand kinship systems and inheritance patterns",
    "opt4": "To determine IQ scores",
    "correct": 3
  },
  {
    "question": "What is the significance of bipedalism in human evolution?",
    "opt1": "It allowed for faster tree climbing",
    "opt2": "It enabled use of the mouth for carrying food",
    "opt3": "It freed the hands for tool use and environmental manipulation",
    "opt4": "It enhanced tail movement",
    "correct": 3
  },
  {
    "question": "Which hominin species is most directly associated with the first known use of stone tools?",
    "opt1": "Homo habilis",
    "opt2": "Australopithecus afarensis",
    "opt3": "Neanderthals",
    "opt4": "Homo sapiens sapiens",
    "correct": 1
  },
  {
    "question": "What does the term 'hominin' refer to?",
    "opt1": "Any extinct species of monkey",
    "opt2": "Modern humans and their immediate fossil ancestors",
    "opt3": "All great apes",
    "opt4": "Only Neanderthals",
    "correct": 2
  },
  {
    "question": "Which anatomical change is closely linked to speech development in humans?",
    "opt1": "Opposable thumbs",
    "opt2": "Expanded cranial capacity and descended larynx",
    "opt3": "Elongated arms",
    "opt4": "Shortened legs",
    "correct": 2
  },
  {
    "question": "What does the 'Out of Africa' model of human origins propose?",
    "opt1": "Humans originated in Europe",
    "opt2": "Humans evolved simultaneously on different continents",
    "opt3": "Homo sapiens evolved in Africa and then migrated globally",
    "opt4": "Homo sapiens interbred with chimpanzees",
    "correct": 3
  },
  {
    "question": "Why is the fossil record considered incomplete?",
    "opt1": "Because fossils decay too quickly",
    "opt2": "Because all fossils are too damaged to study",
    "opt3": "Because fossilization is rare and depends on specific conditions",
    "opt4": "Because anthropology avoids studying bones",
    "correct": 3
  },
  {
    "question": "What key evidence supports the idea that Neanderthals had symbolic thought?",
    "opt1": "Their skeletal structure",
    "opt2": "Their tools were simpler than those of Homo sapiens",
    "opt3": "They buried their dead with grave goods",
    "opt4": "They could not speak",
    "correct": 3
  },
  {
    "question": "Which species is thought to be the first to control fire?",
    "opt1": "Homo erectus",
    "opt2": "Australopithecus robustus",
    "opt3": "Homo sapiens",
    "opt4": "Paranthropus boisei",
    "correct": 1
  },
  {
    "question": "Which of the following best illustrates a behavioral adaptation in early hominins?",
    "opt1": "Development of thick fur",
    "opt2": "Creation of stone tools for hunting and defense",
    "opt3": "Elongated canine teeth",
    "opt4": "Nesting in trees",
    "correct": 2
  },
  {
    "question": "Genetic studies of mitochondrial DNA suggest that:",
    "opt1": "Humans evolved from chimpanzees directly",
    "opt2": "All modern humans share a common ancestor from Africa",
    "opt3": "Neanderthals and Homo sapiens are unrelated",
    "opt4": "Genetics has no role in human evolution",
    "correct": 2
  },
  {
    "question": "How does culture influence the biological functioning of humans?",
    "opt1": "By altering genetic inheritance",
    "opt2": "By shaping diet, behavior, and exposure to environments",
    "opt3": "Through DNA manipulation",
    "opt4": "By reducing the need for evolution",
    "correct": 2
  },
  {
    "question": "Which of the following statements best illustrates the dynamic nature of culture?",
    "opt1": "Culture is entirely inherited from parents",
    "opt2": "Culture remains unchanged across generations",
    "opt3": "Cultural practices evolve in response to internal and external factors",
    "opt4": "Only primitive cultures change with time",
    "correct": 3
  },
  {
    "question": "Which of the following best shows how culture is shared?",
    "opt1": "A solitary person creating a ritual",
    "opt2": "An invention passed silently through observation",
    "opt3": "Members of a society collectively performing a festival",
    "opt4": "An individual dreaming of ancestors",
    "correct": 3
  },
  {
    "question": "Which scenario best demonstrates cultural adaptation?",
    "opt1": "A baby learning to crawl",
    "opt2": "A community designing stilt houses in flood-prone areas",
    "opt3": "People genetically developing darker skin in sunny regions",
    "opt4": "A tiger adjusting to seasonal changes",
    "correct": 2
  },
  {
    "question": "In what way is culture considered symbolic?",
    "opt1": "Because it is genetically coded",
    "opt2": "Because its meanings depend on biological processes",
    "opt3": "Because humans assign arbitrary meaning to objects and behaviors",
    "opt4": "Because it is strictly rational and mathematical",
    "correct": 3
  },
  {
    "question": "Why is the concept of cultural integration important to anthropologists?",
    "opt1": "To isolate individual cultural traits",
    "opt2": "To understand how one cultural aspect affects others",
    "opt3": "To avoid comparative studies",
    "opt4": "To promote ethnocentrism",
    "correct": 2
  },
  {
    "question": "Which of the following can best explain cultural diversity?",
    "opt1": "Genetic mutations",
    "opt2": "Isolation, historical experiences, and environmental differences",
    "opt3": "Uniform global education",
    "opt4": "Biological uniformity",
    "correct": 2
  },
  {
    "question": "Why is culture considered uniquely human?",
    "opt1": "Because only humans learn through observation",
    "opt2": "Because only humans use tools",
    "opt3": "Because it involves complex systems of symbols and shared meanings",
    "opt4": "Because it evolves biologically",
    "correct": 3
  },
  {
    "question": "What does it mean that culture is 'superorganic'?",
    "opt1": "It is a living organism",
    "opt2": "It transcends individual behavior and exists as a collective reality",
    "opt3": "It is made up entirely of physical structures",
    "opt4": "It can be consumed or digested",
    "correct": 2
  },
  {
    "question": "How does cultural knowledge influence perception?",
    "opt1": "It blinds individuals to their surroundings",
    "opt2": "It forces uniform interpretations globally",
    "opt3": "It shapes how individuals interpret reality and interact with their world",
    "opt4": "It removes individual agency",
    "correct": 3
  }
]





quests8 = [
    { "question": "What is the molar mass of sodium hydrogen carbonate (NaHCO<sub>3</sub>)?", "opt1": "84 g/mol", "opt2": "100 g/mol", "opt3": "76 g/mol", "opt4": "68 g/mol", "correct": 1 },
  { "question": "In the reaction between NaHCO<sub>3</sub> and HCl, which gas is released?", "opt1": "Oxygen", "opt2": "Nitrogen", "opt3": "Carbon dioxide", "opt4": "Hydrogen", "correct": 3 },
  { "question": "What is the concentration of HCl solution used in the first question?", "opt1": "0.128 M", "opt2": "0.6441 M", "opt3": "0.190 M", "opt4": "0.250 M", "correct": 3 },
  { "question": "The volume of NaOH used in the titration of excess HCl is:", "opt1": "47.1 mL", "opt2": "53.07 mL", "opt3": "50.0 mL", "opt4": "25.0 mL", "correct": 1 },
  { "question": "What is the balanced equation for the reaction of NaHCO<sub>3</sub> with HCl?", "opt1": "NaHCO<sub>3</sub> + HCl → NaCl + H<sub>2</sub>CO<sub>3</sub>", "opt2": "NaHCO<sub>3</sub> + HCl → NaCl + H<sub>2</sub>O + CO<sub>2</sub>", "opt3": "NaHCO<sub>3</sub> + H<sub>2</sub>O → NaOH + CO<sub>2</sub>", "opt4": "NaHCO<sub>3</sub> → NaOH + H<sub>2</sub>O + CO<sub>2</sub>", "correct": 2 },
  { "question": "What is the primary function of NaOH in the titration of HCl?", "opt1": "Oxidation", "opt2": "Neutralization", "opt3": "Precipitation", "opt4": "Reduction", "correct": 2 },
  { "question": "How many moles of NaOH are present in 47.1 mL of 0.128 M solution?", "opt1": "0.0603 mol", "opt2": "0.00603 mol", "opt3": "0.602 mol", "opt4": "0.603 mol", "correct": 2 },
  { "question": "What type of acid is H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "Monoprotic", "opt2": "Diprotic", "opt3": "Triprotic", "opt4": "Polyprotic", "correct": 3 },
  { "question": "What is the molarity of NaOH solution used in the titration of H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "0.128 M", "opt2": "0.6441 M", "opt3": "0.190 M", "opt4": "0.250 M", "correct": 2 },
  { "question": "What is the oxidation state of arsenic in H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "+3", "opt2": "+5", "opt3": "+4", "opt4": "+1", "correct": 2 },
  { "question": "Which of the following has the highest entropy at 25°C?", "opt1": "Ne(g)", "opt2": "NaCl(s)", "opt3": "H<sub>2</sub>(g)", "opt4": "SO<sub>2</sub>(g)", "correct": 4 },
  { "question": "Which of the following processes has a positive entropy change?", "opt1": "2H<sub>2</sub>(g) → 2H<sub>2</sub>(l)", "opt2": "C(s) + O<sub>2</sub>(g) → CO<sub>2</sub>(g)", "opt3": "NaCl(s) → NaCl(aq)", "opt4": "2H<sub>2</sub>O(l) → 2H<sub>2</sub>(g) + O<sub>2</sub>(g)", "correct": 4 },
  { "question": "What is the half-life of phosphorus-32?", "opt1": "14.3 days", "opt2": "32.0 days", "opt3": "72 hours", "opt4": "2.69 days", "correct": 1 },
  { "question": "What is the atomic mass of gold (Au-198) used in the decay calculation?", "opt1": "198 amu", "opt2": "197 amu", "opt3": "200 amu", "opt4": "195 amu", "correct": 1 },
  { "question": "Which element is used as a radioactive tracer in the body for cancer treatment?", "opt1": "Gold-198", "opt2": "Phosphorus-32", "opt3": "Iodine-131", "opt4": "Cobalt-60", "correct": 3 },
  { "question": "What type of reaction occurs between H<sub>3</sub>AsO<sub>4</sub> and NaOH?", "opt1": "Acid-base", "opt2": "Redox", "opt3": "Precipitation", "opt4": "Decomposition", "correct": 1 },
  { "question": "How many moles of NaOH are needed to neutralize one mole of H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "1", "opt2": "2", "opt3": "3", "opt4": "4", "correct": 3 },
  { "question": "What is the gas produced when NaHCO<sub>3</sub> reacts with HCl?", "opt1": "Oxygen", "opt2": "Carbon dioxide", "opt3": "Hydrogen", "opt4": "Nitrogen", "correct": 2 },
  { "question": "Which of the following has the lowest entropy at 25°C?", "opt1": "Ne(g)", "opt2": "NaCl(s)", "opt3": "SO<sub>2</sub>(g)", "opt4": "H<sub>2</sub>(g)", "correct": 2 },
  { "question": "The purpose of adding NaOH in the titration of H<sub>3</sub>AsO<sub>4</sub> is to:", "opt1": "Increase acidity", "opt2": "Neutralize the acid", "opt3": "Produce a precipitate", "opt4": "Remove water", "correct": 2 },
  { "question": "What is the charge on the arsenic ion in H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "-3", "opt2": "+3", "opt3": "+5", "opt4": "+1", "correct": 3 },
  { "question": "What is the function of the NaHCO<sub>3</sub> in the antacid?", "opt1": "Increases acidity", "opt2": "Acts as a buffer", "opt3": "Produces gas", "opt4": "Oxidizes acids", "correct": 2 },
  { "question": "Which of the following is a strong acid?", "opt1": "H<sub>3</sub>AsO<sub>4</sub>", "opt2": "HCl", "opt3": "NaHCO<sub>3</sub>", "opt4": "H<sub>2</sub>O", "correct": 2 },
  { "question": "In the titration of H<sub>3</sub>AsO<sub>4</sub>, the endpoint is determined by:", "opt1": "Color change", "opt2": "Gas release", "opt3": "Temperature rise", "opt4": "pH change", "correct": 4 },
  { "question": "What is the unit of molarity?", "opt1": "mol/g", "opt2": "g/mol", "opt3": "mol/L", "opt4": "g/L", "correct": 3 },
  {
    "question": "Radioactivity was discovered by which of the following scientists?",
    "opt1": "Marie Curie",
    "opt2": "Henri Becquerel",
    "opt3": "Ernest Rutherford",
    "opt4": "Niels Bohr",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a type of radioactive decay?",
    "opt1": "Alpha decay",
    "opt2": "Beta decay",
    "opt3": "Gamma decay",
    "opt4": "Proton decay",
    "correct": 4
  },
  {
    "question": "Alpha particles consist of:",
    "opt1": "Two protons and two neutrons",
    "opt2": "Two electrons and two protons",
    "opt3": "One electron and one proton",
    "opt4": "One neutron and one proton",
    "correct": 1
  },
  {
    "question": "The number of protons or atomic number is reduced by 2 by which form of radioactive decay?",
    "opt1": "Alpha decay",
    "opt2": "Beta decay",
    "opt3": "Gamma decay",
    "opt4": "Proton decay",
    "correct": 1
  },
  {
    "question": "The SI unit of radioactivity is:",
    "opt1": "Curie",
    "opt2": "Rutherford",
    "opt3": "Becquerel",
    "opt4": "Roentgen",
    "correct": 3
  },
  {
    "question": "Radioactivity that takes the form of high energy electromagnetic waves would be:",
    "opt1": "Alpha",
    "opt2": "Beta",
    "opt3": "Gamma",
    "opt4": "Zeta",
    "correct": 3
  },
  {
    "question": "A beta particle is:",
    "opt1": "A helium nucleus",
    "opt2": "A high-energy electron",
    "opt3": "An electromagnetic wave",
    "opt4": "A hydrogen nucleus",
    "correct": 2
  },
  {
    "question": "Which of the following statements about gamma radiation is true?",
    "opt1": "It has no charge and no mass",
    "opt2": "It has a positive charge",
    "opt3": "It consists of fast-moving electrons",
    "opt4": "It is deflected by an electric field",
    "correct": 1
  },
  {
    "question": "The half-life of a radioactive substance is:",
    "opt1": "The time taken for half of its atoms to decay",
    "opt2": "The time taken for all atoms to decay",
    "opt3": "The time taken for double the atoms to decay",
    "opt4": "The time taken for the activity to increase",
    "correct": 1
  },
  {
    "question": "Which of the following materials is most effective in stopping gamma radiation?",
    "opt1": "Paper",
    "opt2": "Aluminum",
    "opt3": "Lead",
    "opt4": "Plastic",
    "correct": 3
  },
  {
    "question": "Which of the following elements is commonly used in nuclear reactors as a fuel?",
    "opt1": "Uranium<sub>235</sub>",
    "opt2": "Carbon",
    "opt3": "Radium<sub>226</sub>",
    "opt4": "Potassium<sub>40</sub>",
    "correct": 1
  },
  {
    "question": "Which radiation is deflected by an electric field?",
    "opt1": "Alpha and beta",
    "opt2": "Beta and gamma",
    "opt3": "Gamma only",
    "opt4": "Alpha only",
    "correct": 1
  },
  {
    "question": "The half-life of a radioactive substance is 5 hours. If you start with 80 grams, how much will remain after 10 hours?",
    "opt1": "40 g",
    "opt2": "20 g",
    "opt3": "10 g",
    "opt4": "5 g",
    "correct": 2
  },
  {
    "question": "A sample of a radioactive element has a decay constant of 0.001 s. What is its half-life?",
    "opt1": "693 s",
    "opt2": "500 s",
    "opt3": "1000 s",
    "opt4": "6930 s",
    "correct": 1
  },
  {
    "question": "The activity of a radioactive sample is initially 800 Bq. After two half-lives, what is its activity?",
    "opt1": "400 Bq",
    "opt2": "200 Bq",
    "opt3": "100 Bq",
    "opt4": "50 Bq",
    "correct": 2
  },
  {
    "question": "A radioactive isotope has a half-life of 56.6 days. What fraction of the isotope remains after 449 days?",
    "opt1": "3.2 x 10<sup>-3</sup>",
    "opt2": "1.00",
    "opt3": "0.92",
    "opt4": "4.1 x 10<sup>-2</sup>",
    "correct": 1
  },
  {
    "question": "If a radioactive isotope has a half-life of 3 days, what fraction of the original sample remains after 9 days?",
    "opt1": "1/2",
    "opt2": "1/4",
    "opt3": "1/8",
    "opt4": "1/16",
    "correct": 3
  },
  {
    "question": "A radioactive sample has an initial mass of 40g. After 16 days, only 2.5g remains. What is its half-life?",
    "opt1": "4 days",
    "opt2": "5 days",
    "opt3": "6 days",
    "opt4": "8 days",
    "correct": 1
  },

  {
    "question": "The elements of group 14, 15, 16, and 17 are ________.",
    "opt1": "d block elements",
    "opt2": "s block elements",
    "opt3": "p block elements",
    "opt4": "f block elements",
    "correct": 3
  },
  {
    "question": "The following are the factors that affect ionization energy except ________.",
    "opt1": "Size of atom",
    "opt2": "Energy level",
    "opt3": "Shielding effect",
    "opt4": "Atomic orbital",
    "correct": 4
  },
  {
    "question": "Which of the following quantum numbers does not determine the wave properties of an electron in an atom?",
    "opt1": "<i>n</i>",
    "opt2": "<i>l</i>",
    "opt3": "<i>m</i>",
    "opt4": "<i>s</i>",
    "correct": 4
  },
  {
    "question": "Calculate the wavelength of light emitted when a hydrogen atom changes from <i>n</i> = 5 to <i>n</i> = 3. (R = 1.0968 × 10<sup>7</sup> m<sup>−1</sup>)",
    "opt1": "1.3 × 10<sup>−6</sup> m",
    "opt2": "1.6 × 10<sup>−6</sup> m",
    "opt3": "4.7 × 10<sup>−6</sup> m",
    "opt4": "2.3 × 10<sup>−6</sup> m",
    "correct": 1,
    "workings": "Using Rydberg formula: 1/λ = R(1/n₁² − 1/n₂²) = 1.0968×10⁷(1/9 − 1/25) = 1.0968×10⁷(16/225) ≈ 7.618×10⁵ ⇒ λ ≈ 1.2821×10<sup>−6</sup> m"
  },
  {
    "question": "What are the number of protons, neutrons and electrons (Z = 34, A = 79) respectively in Se?",
    "opt1": "32, 34, 79",
    "opt2": "34, 45, 36",
    "opt3": "34, 45, 34",
    "opt4": "34, 45, 32",
    "correct": 3
  },
  {
    "question": "In which pair of elements do the nuclei of the atoms contain the same number of neutrons?",
    "opt1": "Li and Ba",
    "opt2": "N and O",
    "opt3": "Na and Mg",
    "opt4": "S and Be",
    "correct": 3
  },
  {
    "question": "The number of nuclear disintegrations per unit time occurring in a radioactive material is known as:",
    "opt1": "Scintillation source",
    "opt2": "Activity of a radioactive source",
    "opt3": "Activity curie source",
    "opt4": "Disintegration source",
    "correct": 2
  },
#   {
#     "question": "A radioactive source has a half-life of 80 s. How long will it take for 7/8 of the source to decay?",
#     "opt1": "10 s",
#     "opt2": "70 s",
#     "opt3": "240 s",
#     "opt4": "640 s",
#     "correct": 3,
#     "workings": "To decay to 1/8, 3 half-lives are needed: (1/2)<sup>3</sup> = 1/8 ⇒ 3 × 80 s = 240 s"
#   },
  {
    "question": "A gas expands and does 325 J of work on the surroundings while absorbing 127 J of heat. What is the change in energy of the gas?",
    "opt1": "−198 J",
    "opt2": "+198 J",
    "opt3": "−425 J",
    "opt4": "+521 J",
    "correct": 1,
    "workings": "ΔU = Q − W = 127 J − 325 J = −198 J"
  },
  {
    "question": "Which of these molecules has the largest bond angle?",
    "opt1": "H<sub>2</sub>O",
    "opt2": "CO<sub>2</sub>",
    "opt3": "NH<sub>3</sub>",
    "opt4": "CH<sub>4</sub>",
    "correct": 2
  },
  {
    "question": "Which of the reactions below does not form a precipitate?",
    "opt1": "KI + Pb(NO<sub>3</sub>)<sub>2</sub>",
    "opt2": "BaCl<sub>2</sub> + Na<sub>2</sub>SO<sub>4</sub>",
    "opt3": "NaCl + AgNO<sub>3</sub>",
    "opt4": "NaCl + Fe(NO<sub>3</sub>)<sub>3</sub>",
    "correct": 4
  },
  {
    "question": "Which statement is true for all the three types of radioactive emissions?",
    "opt1": "They are deflected by electric fields",
    "opt2": "They ionize gases",
    "opt3": "They are completely absorbed by a thin aluminum sheet",
    "opt4": "They emit light",
    "correct": 2
  },
  {
    "question": "A nuclide of plutonium has a mass number of 242 and atomic number 94. How many neutrons are in its nucleus?",
    "opt1": "242",
    "opt2": "336",
    "opt3": "148",
    "opt4": "94",
    "correct": 3,
    "workings": "Neutrons = Mass number − Atomic number = 242 − 94 = 148"
  },

  {
    "question": "Across the period ionization potential is likely to increase because of.....",
    "opt1": "shielding effect",
    "opt2": "increase in nuclear charge",
    "opt3": "decrease in nuclear charge",
    "opt4": "all the mentioned",
    "correct": 2
  },
  {
    "question": "How many moles of Carbon(IV) oxide are likely to be present in butane after combustion?",
    "opt1": "2",
    "opt2": "3",
    "opt3": "8",
    "opt4": "10",
    "correct": 3
  },
  {
    "question": "Which of the following contain both ionic and covalent bonds in the same compound?",
    "opt1": "BaCO<sub>3</sub>",
    "opt2": "MgCl<sub>2</sub>",
    "opt3": "BaO",
    "opt4": "H<sub>2</sub>S",
    "correct": 1
  },
  {
    "question": "Which of the following statements about hydrogen atom is false?",
    "opt1": "An electron in n = 1 level of the hydrogen atom is in its ground state",
    "opt2": "On average, an electron in the n = 3 level is farther from the nucleus than one in n = 1",
    "opt3": "The wavelength of light emitted when the electron goes from n = 3 to n = 1 is the same as when it goes from n = 1 to n = 3",
    "opt4": "An electron in n = 1 level is higher in energy than one in the n = 4 level",
    "correct": 4
  },
  {
    "question": "A 25.0 ml sample of hydrochloric acid (HCl) was titrated with 0.150 M NaOH. The burette reading shows that 30.0 ml of NaOH was required to reach the equivalence point. What is the molarity of the HCl solution?",
    "opt1": "0.167 M",
    "opt2": "0.14 M",
    "opt3": "0.18 M",
    "opt4": "0.22 M",
    "correct": 3
  },
  {
    "question": "How many ml of 0.200 M NaOH are required to completely neutralize 50.0 ml of 0.100 M H<sub>2</sub>SO<sub>4</sub>?",
    "opt1": "50 ml",
    "opt2": "40 ml",
    "opt3": "30 ml",
    "opt4": "20 ml",
    "correct": 1
  }
]

quests10 = [
  {
    "question": "According to C. Wright Mills, what best defines the 'Sociological Imagination'?",
    "opt1": "A talent for remembering facts",
    "opt2": "A critical awareness of the link between individuals and the wider society",
    "opt3": "The ability to memorize statistics",
    "opt4": "An intuitive understanding of emotions",
    "correct": 2
  },
  {
    "question": "Which of the following best describes sociology as a scientific discipline?",
    "opt1": "It relies on natural laws to explain human behavior",
    "opt2": "It uses systematic observation and critical analysis of human interactions",
    "opt3": "It focuses mainly on physical traits of individuals",
    "opt4": "It is based on religious and moral guidance",
    "correct": 2
  },
  {
    "question": "Which of the following perspectives categorizes sociology based on current societal problems and issues?",
    "opt1": "Historical Perspective",
    "opt2": "Empirical Perspective",
    "opt3": "Analytical Perspective",
    "opt4": "Comparative Perspective",
    "correct": 2
  },
  {
    "question": "What did Auguste Comte refer to sociology as in the hierarchy of sciences?",
    "opt1": "A social experiment",
    "opt2": "The lowest science",
    "opt3": "The queen of sciences",
    "opt4": "A religious discipline",
    "correct": 3
  },
  {
    "question": "Herbert Spencer believed that social evolution occurs through:",
    "opt1": "Scientific experiments",
    "opt2": "Religious teachings",
    "opt3": "The survival of the fittest",
    "opt4": "Social planning by elites",
    "correct": 3
  },
  {
    "question": "What is the term Emile Durkheim used to refer to external societal forces that influence individual behavior?",
    "opt1": "Social norms",
    "opt2": "Social structure",
    "opt3": "Social facts",
    "opt4": "Group behavior",
    "correct": 3
  },
  {
    "question": "Max Weber's concept of 'Verstehen' emphasizes:",
    "opt1": "Statistical analysis of behavior",
    "opt2": "Economic productivity",
    "opt3": "Interpretive understanding of social actions",
    "opt4": "Literal interpretation of laws",
    "correct": 3
  },
  {
    "question": "What did Karl Marx identify as the main source of conflict in capitalist societies?",
    "opt1": "Religious differences",
    "opt2": "Family disagreements",
    "opt3": "Class struggle between the proletariat and the bourgeoisie",
    "opt4": "Political elections",
    "correct": 3
  },
  {
    "question": "Which sociological perspective views society as a stable and well-integrated system?",
    "opt1": "Conflict Perspective",
    "opt2": "Feminist Perspective",
    "opt3": "Functionalist Perspective",
    "opt4": "Interactionist Perspective",
    "correct": 3
  },
  {
    "question": "Robert Merton’s distinction between manifest and latent functions refers to:",
    "opt1": "Primary and secondary education",
    "opt2": "Expected and unexpected social outcomes",
    "opt3": "Traditional and modern cultures",
    "opt4": "Urban and rural life",
    "correct": 2
  },
  {
    "question": "Which sociologist is credited with founding the interactionist perspective?",
    "opt1": "Talcott Parsons",
    "opt2": "Herbert Spencer",
    "opt3": "George Herbert Mead",
    "opt4": "Robert Merton",
    "correct": 3
  },
  {
    "question": "In the context of socialization, the 'looking-glass self' was developed by:",
    "opt1": "Jean Piaget",
    "opt2": "Sigmund Freud",
    "opt3": "Erving Goffman",
    "opt4": "Charles Horton Cooley",
    "correct": 4
  },
  {
    "question": "Which of the following best defines a social institution?",
    "opt1": "A place for religious activities",
    "opt2": "A patterned and organized set of roles and norms focused on social needs",
    "opt3": "A symbolic interaction",
    "opt4": "A family unit only",
    "correct": 2
  },
  {
    "question": "Talcott Parsons' concept of 'social system' is based on:",
    "opt1": "Conflict theory",
    "opt2": "Religious unity",
    "opt3": "Interdependence of social parts for stability",
    "opt4": "Military governance",
    "correct": 3
  },
  {
    "question": "Which term refers to expectations attached to a social position?",
    "opt1": "Status",
    "opt2": "Role",
    "opt3": "Culture",
    "opt4": "Norm",
    "correct": 2
  },
  {
    "question": "What is meant by 'achieved status'?",
    "opt1": "A status inherited at birth",
    "opt2": "A social position gained through personal effort",
    "opt3": "An unchangeable identity",
    "opt4": "A biological position",
    "correct": 2
  },
  {
    "question": "Cultural acculturation occurs when:",
    "opt1": "A person lives in isolation",
    "opt2": "Two cultures interact and influence each other",
    "opt3": "People are born into a culture",
    "opt4": "Socialization fails",
    "correct": 2
  },
  {
    "question": "According to the conflict perspective, social order is maintained through:",
    "opt1": "Consensus and cooperation",
    "opt2": "Symbolic communication",
    "opt3": "Force and coercion by dominant groups",
    "opt4": "Religious beliefs",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT an agent of socialization?",
    "opt1": "Family",
    "opt2": "Peer group",
    "opt3": "Climate",
    "opt4": "Mass media",
    "correct": 3
  },
  {
    "question": "Which sociological theory focuses on small-scale, face-to-face interactions?",
    "opt1": "Functionalism",
    "opt2": "Conflict theory",
    "opt3": "Interactionism",
    "opt4": "Systems theory",
    "correct": 3
  },
  {
    "question": "Which theorist pioneered the concept of 'bureaucracy' as an ideal type?",
    "opt1": "Marx",
    "opt2": "Spencer",
    "opt3": "Weber",
    "opt4": "Freud",
    "correct": 3
  },
  {
    "question": "A series of social relationships linking an individual to others is called a:",
    "opt1": "Social structure",
    "opt2": "Social class",
    "opt3": "Social network",
    "opt4": "Social institution",
    "correct": 3
  },
  {
    "question": "What does 'socialization' primarily aim to achieve?",
    "opt1": "Assign individuals to political groups",
    "opt2": "Integrate individuals into social norms and values",
    "opt3": "Isolate individuals from society",
    "opt4": "Prepare individuals for warfare",
    "correct": 2
  },
  {
    "question": "An individual's 'master status' is:",
    "opt1": "Always achieved by academic performance",
    "opt2": "A role learned in childhood",
    "opt3": "The most dominant status that shapes identity",
    "opt4": "A short-term role in childhood",
    "correct": 3
  },
  {
    "question": "Which of the following is true about the relationship between sociology and other social sciences?",
    "opt1": "They have completely separate topics of interest",
    "opt2": "They overlap significantly and often use interdisciplinary approaches",
    "opt3": "Sociology is unrelated to psychology",
    "opt4": "Anthropology uses completely different methods",
    "correct": 2
  },
  {
    "question": "What distinguishes the empirical perspective in sociology?",
    "opt1": "Study of the supernatural",
    "opt2": "Focus on ancient civilizations only",
    "opt3": "Use of current data and real-world observation",
    "opt4": "Relying solely on intuition",
    "correct": 3
  },
  {
    "question": "Which of the following is a key assumption of functionalist theory?",
    "opt1": "Social change is constant and unresolvable",
    "opt2": "Each part of society contributes to its stability",
    "opt3": "Society is inherently chaotic",
    "opt4": "Social behavior is driven by unconscious forces",
    "correct": 2
  },
  {
    "question": "Who argued that society should be studied using the same scientific rigor as natural sciences?",
    "opt1": "Herbert Spencer",
    "opt2": "Sigmund Freud",
    "opt3": "Auguste Comte",
    "opt4": "Talcott Parsons",
    "correct": 3
  },
  {
    "question": "Which perspective emphasizes that power is unequally distributed and used to maintain dominance?",
    "opt1": "Functionalism",
    "opt2": "Interactionism",
    "opt3": "Feminism",
    "opt4": "Conflict theory",
    "correct": 4
  }
]


quests11 = [
  {
    "question": "Which scholar argued that sociology must study social facts as 'things'?",
    "opt1": "Max Weber",
    "opt2": "Herbert Spencer",
    "opt3": "Emile Durkheim",
    "opt4": "Karl Marx",
    "correct": 3
  },
  {
    "question": "The distinction between mechanical and organic solidarity was made by:",
    "opt1": "Auguste Comte",
    "opt2": "Herbert Spencer",
    "opt3": "Talcott Parsons",
    "opt4": "Emile Durkheim",
    "correct": 4
  },
  {
    "question": "According to Talcott Parsons, a well-functioning society must meet which of the following functions?",
    "opt1": "GDP growth",
    "opt2": "Economic stratification",
    "opt3": "AGIL system functions",
    "opt4": "Legal accountability",
    "correct": 3
  },
  {
    "question": "Which sociologist introduced the concept of 'ideal type' as a tool of analysis?",
    "opt1": "Robert Merton",
    "opt2": "Karl Marx",
    "opt3": "Max Weber",
    "opt4": "George Mead",
    "correct": 3
  },
  {
    "question": "The conflict perspective in sociology is primarily associated with:",
    "opt1": "Herbert Spencer",
    "opt2": "Karl Marx",
    "opt3": "Erving Goffman",
    "opt4": "Jean Piaget",
    "correct": 2
  },
  {
    "question": "Which of the following perspectives would most likely analyze inequality in access to education?",
    "opt1": "Functionalism",
    "opt2": "Symbolic interactionism",
    "opt3": "Conflict theory",
    "opt4": "Phenomenology",
    "correct": 3
  },
  {
    "question": "Robert Merton’s idea of 'dysfunction' refers to:",
    "opt1": "Elements that maintain equilibrium",
    "opt2": "Social processes that disrupt society's stability",
    "opt3": "Criminal behaviors only",
    "opt4": "Roles played by elites",
    "correct": 2
  },
  {
    "question": "According to Mead, the self develops through:",
    "opt1": "Isolation and meditation",
    "opt2": "Genetic inheritance only",
    "opt3": "Interaction and understanding roles of others",
    "opt4": "Formal education alone",
    "correct": 3
  },
  {
    "question": "What is the concept used to describe the total way of life of a people?",
    "opt1": "Social structure",
    "opt2": "Status",
    "opt3": "Culture",
    "opt4": "Ethnocentrism",
    "correct": 3
  },
  {
    "question": "Which of the following best explains 'role conflict'?",
    "opt1": "When one person shares the same role with others",
    "opt2": "When a person fails to perform any role",
    "opt3": "When expectations from multiple statuses contradict",
    "opt4": "When cultural norms are ignored",
    "correct": 3
  },
  {
    "question": "A set of socially defined positions within a society is called:",
    "opt1": "Values",
    "opt2": "Roles",
    "opt3": "Status",
    "opt4": "Customs",
    "correct": 3
  },
  {
    "question": "Which term refers to rules and expectations for behavior associated with a social position?",
    "opt1": "Values",
    "opt2": "Norms",
    "opt3": "Roles",
    "opt4": "Sanctions",
    "correct": 3
  },
  {
    "question": "Which agent of socialization is responsible for teaching formal knowledge and discipline?",
    "opt1": "Peer groups",
    "opt2": "Family",
    "opt3": "Religious groups",
    "opt4": "School",
    "correct": 4
  },
  {
    "question": "What is a master status?",
    "opt1": "A role that is performed in secret",
    "opt2": "The most dominant status a person holds",
    "opt3": "A temporary social position",
    "opt4": "An inherited position with no effect on behavior",
    "correct": 2
  },
  {
    "question": "The feminist perspective in sociology focuses on:",
    "opt1": "The symbolic meaning of rituals",
    "opt2": "Power and gender inequality in social structures",
    "opt3": "The economic impact of globalization",
    "opt4": "Rural versus urban conflict",
    "correct": 2
  },
  {
    "question": "Cultural pluralism refers to:",
    "opt1": "A society with only one dominant culture",
    "opt2": "Complete assimilation of minority groups",
    "opt3": "Multiple cultural groups coexisting while retaining their distinctiveness",
    "opt4": "Forcing a uniform national identity",
    "correct": 3
  },
  {
    "question": "An example of a non-material culture is:",
    "opt1": "A mobile phone",
    "opt2": "A religious belief",
    "opt3": "A factory building",
    "opt4": "A school bus",
    "correct": 2
  },
  {
    "question": "Which perspective focuses on how individuals create meaning through interaction?",
    "opt1": "Conflict theory",
    "opt2": "Functionalism",
    "opt3": "Interactionism",
    "opt4": "Evolutionism",
    "correct": 3
  },
  {
    "question": "The concept of 'dramaturgical approach' sees individuals as:",
    "opt1": "Scientists experimenting in society",
    "opt2": "Performers projecting images in social interactions",
    "opt3": "Passive agents of culture",
    "opt4": "Victims of social rules",
    "correct": 2
  },
  {
    "question": "Which sociological concept explains how societies survive by fulfilling core tasks like preserving order and producing goods?",
    "opt1": "Conflict theory",
    "opt2": "Ethnocentrism",
    "opt3": "Social institutions",
    "opt4": "Cultural relativism",
    "correct": 3
  },
  {
    "question": "What central idea did Karl Marx contribute to the understanding of society?",
    "opt1": "Societies function best through religious institutions",
    "opt2": "Human societies are shaped by environmental forces",
    "opt3": "Social conflict arises from class struggles over economic resources",
    "opt4": "Society should be understood through symbols",
    "correct": 3
  },
  {
    "question": "Which of the following correctly defines 'ascribed status'?",
    "opt1": "A social position earned through merit",
    "opt2": "A role acquired from education",
    "opt3": "A status assigned involuntarily at birth or later in life",
    "opt4": "A temporary professional title",
    "correct": 3
  },
  {
    "question": "What does the concept of 'anomie' describe in Durkheim’s theory?",
    "opt1": "A society where religion dominates politics",
    "opt2": "A condition of normlessness and loss of direction in society",
    "opt3": "A state of gender balance",
    "opt4": "A peaceful transition of power",
    "correct": 2
  },
  {
    "question": "Which of the following best describes a social institution?",
    "opt1": "A group of friends sharing interests",
    "opt2": "A formal school building",
    "opt3": "A structured system addressing basic societal needs",
    "opt4": "An individual's self-concept",
    "correct": 3
  },
  {
    "question": "Which sociologist emphasized the power of 'social facts' as external and coercive forces?",
    "opt1": "Weber",
    "opt2": "Durkheim",
    "opt3": "Spencer",
    "opt4": "Mead",
    "correct": 2
  },
  {
    "question": "The interpretative perspective in sociology emphasizes:",
    "opt1": "Conflict between elite groups",
    "opt2": "Objective measurement of social phenomena",
    "opt3": "Subjective meaning individuals attach to social action",
    "opt4": "Military control of social roles",
    "correct": 3
  },
  {
    "question": "Which of the following is a dysfunction of cultural pluralism?",
    "opt1": "Promotion of ethnic creativity",
    "opt2": "Increase in collective bargaining",
    "opt3": "Enhanced cultural diversity",
    "opt4": "Difficulty forging national unity",
    "correct": 4
  },
  {
    "question": "The interactionist perspective sees society primarily through the lens of:",
    "opt1": "Historical development",
    "opt2": "Ongoing power struggles",
    "opt3": "Symbolic exchanges in everyday life",
    "opt4": "Religious indoctrination",
    "correct": 3
  },
  {
    "question": "What is 'ethnomethodology' concerned with?",
    "opt1": "Power and hierarchy",
    "opt2": "Large-scale social structures",
    "opt3": "Methods people use in everyday interactions",
    "opt4": "Analysis of economic systems",
    "correct": 3
  },
  {
    "question": "Which of these is an example of a manifest function of education?",
    "opt1": "Reinforcement of gender inequality",
    "opt2": "Building informal friendships",
    "opt3": "Transmission of knowledge and skills",
    "opt4": "Hidden promotion of social class gaps",
    "correct": 3
  },
  {
    "question": "How does the feminist perspective interpret society?",
    "opt1": "Through economic models",
    "opt2": "Through competition between ethnic groups",
    "opt3": "Through power relations and gender inequality",
    "opt4": "Through biological predispositions",
    "correct": 3
  },
]


quests = [
  {
    "question": "The law that states that if two bodies are separately in equilibrium with a third body, then all three bodies are in thermal equilibrium with each other is known as:",
    "opt1": "The zeroth",
    "opt2": "The first",
    "opt3": "The second",
    "opt4": "The third",
    "correct": 1
  },
  {
    "question": "Absolute zero is:",
    "opt1": "0 K",
    "opt2": "0°C",
    "opt3": "K",
    "opt4": "0°F",
    "correct": 1
  },
  {
    "question": "Absolute temperature means temperature in:",
    "opt1": "K",
    "opt2": "°F",
    "opt3": "°C",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "The unit of heat is:",
    "opt1": "Js",
    "opt2": "K",
    "opt3": "N",
    "opt4": "J",
    "correct": 1
  },
  {
    "question": "Convert -48.5°C to Kelvin:",
    "opt1": "224.65",
    "opt2": "321.65",
    "opt3": "-273.15",
    "opt4": "-321.65",
    "correct": 1
  },
  {
    "question": "Convert 242°C to Fahrenheit:",
    "opt1": "166.4",
    "opt2": "373",
    "opt3": "467.6",
    "opt4": "102.4",
    "correct": 3
  },
  {
    "question": "The Celsius scale of temperature is related to the thermodynamic scale by:",
    "opt1": "T = θ - 273.15",
    "opt2": "T = θ + 327",
    "opt3": "T = θ - 273",
    "opt4": "T = θ + 273.15",
    "correct": 4
  },
  {
    "question": "When an object is immersed in a fluid, it experiences:",
    "opt1": "Momentum",
    "opt2": "Upthrust",
    "opt3": "Pressure",
    "opt4": "Hydrostatic force",
    "correct": 2
  },
  {
    "question": "The value of the coefficient of surface tension for water at 20°C is:",
    "opt1": "7.26 × 10 N/m",
    "opt2": "6.27 × 10<sup>-2</sup> N/m",
    "opt3": "2.76 × 10<sup>-2</sup> N/m",
    "opt4": "72.6 × 10<sup>-2</sup> N/m",
    "correct": 4
  },
  {
    "question": "The collision between gas molecules with themselves and with the walls of the container gives rise to:",
    "opt1": "Potential energy",
    "opt2": "Gas pressure",
    "opt3": "Hydrostatic pressure",
    "opt4": "Temperature",
    "correct": 2
  },
  {
    "question": "Calculate the RMS speed of hydrogen molecules at 273K. Given: ρ = 6×10<sup>-2</sup> kg/m³ and P = 2.48×10<sup>3</sup> N/m².",
    "opt1": "1.13 × 10<sup>2</sup> m/s",
    "opt2": "1.83 × 10<sup>2</sup> m/s",
    "opt3": "3.52 × 10<sup>2</sup> m/s",
    "opt4": "18.3 × 10<sup>2</sup> m/s",
    "correct": 2
  },
  {
    "question": "Estimate the average kinetic energy of gas molecules at 48°C.",
    "opt1": "6.64 × 10<sup>-21</sup> J",
    "opt2": "7.723 × 10<sup>22</sup> J",
    "opt3": "7.72 × 10<sup>-21</sup> J",
    "opt4": "7.72 × 10<sup>-19</sup> J",
    "correct": 1
  },
  {
    "question": "The collisions of gas molecules are:",
    "opt1": "Inelastic",
    "opt2": "Perfectly elastic",
    "opt3": "Elastic and inelastic",
    "opt4": "None of the above",
    "correct": 2
  },
  {
    "question": "A thermodynamic system consists of:",
    "opt1": "Fixed mass of matter separated from its surroundings by a piston and cylinder",
    "opt2": "Varying mass separated by piston and cylinder",
    "opt3": "Fixed mass of liquid separated by cylinder and piston",
    "opt4": "None of the above",
    "correct": 1
  },
  {
    "question": "_______ is a process in which the temperature of the system remains constant during change from its initial to final state.",
    "opt1": "Isochoric process",
    "opt2": "Isobaric process",
    "opt3": "Isothermal process",
    "opt4": "Adiabatic process",
    "correct": 3
  },
  {
    "question": "A refrigerator is a reversed ______.",
    "opt1": "Heat pump",
    "opt2": "Heat engine",
    "opt3": "Air-conditioner",
    "opt4": "Heat reservoir",
    "correct": 2
  },
  {
    "question": "SI Unit for entropy of a system is:",
    "opt1": "JKs<sup>–1</sup>",
    "opt2": "KJ<sup>-1</sup>",
    "opt3": "J/K",
    "opt4": "Nm",
    "correct": 3
  },
  {
    "question": "The heat reservoir which rejects heat is called:",
    "opt1": "Sink",
    "opt2": "Source",
    "opt3": "Heat engine",
    "opt4": "Refrigerator",
    "correct": 1
  },
  {
    "question": "Calculate the total entropy of the system when the entropy of a hot reservoir is -15.5J/K and that of the cold reservoir is 42 J/K.",
    "opt1": "57.5 J/K",
    "opt2": "26.5J/K",
    "opt3": "21 J/K",
    "opt4": "-57.5 J/K",
    "correct": 2
  },
  {
    "question": "The height to which a liquid rises in a capillary tube depends on:",
    "opt1": "Surface area of the tube",
    "opt2": "Temperature of the liquid",
    "opt3": "Density of the liquid",
    "opt4": "Nature of the liquid and the tube",
    "correct": 4
  },
  {
    "question": "________ is a substance that has some physical property which changes continuously as the temperature changes.",
    "opt1": "Radiant energy",
    "opt2": "Platinum only",
    "opt3": "All gases only",
    "opt4": "Thermometric substance",
    "correct": 4
  },
  {
    "question": "Which of the following equations represents an ideal gas for one mole of gas?",
    "opt1": "PV = RT",
    "opt2": "PV = nRT",
    "opt3": "PT = RV",
    "opt4": "PV = R",
    "correct": 1
  },
  {
    "question": "A gas whose behavior is described by PV = nRT is called:",
    "opt1": "Real gas",
    "opt2": "Ideal gas",
    "opt3": "Thermodynamic gas",
    "opt4": "Fixed gas",
    "correct": 2
  },
  {
    "question": "If the kinetic theory of gases is based on the ideal gas model, which of the following is NOT correct?",
    "opt1": "Average molecular kinetic energy is directly proportional to absolute temperature",
    "opt2": "All molecules do not move randomly",
    "opt3": "All molecules collide, and the collision is elastic",
    "opt4": "The force of attraction between molecules is negligible",
    "correct": 2
  },
  {
    "question": "Materials which break as soon as the elastic limit is exceeded are known as:",
    "opt1": "Ductile",
    "opt2": "Elastic",
    "opt3": "Brittle",
    "opt4": "Weak materials",
    "correct": 3
  },
  {
    "question": "In the presence of a detergent, the surface tension of a liquid:",
    "opt1": "Increases",
    "opt2": "Decreases",
    "opt3": "Remains constant",
    "opt4": "Becomes zero",
    "correct": 2
  },
  {
    "question": "The capillary rise of a liquid in a narrow tube is inversely proportional to the:",
    "opt1": "Density of the liquid",
    "opt2": "Surface tension of the liquid",
    "opt3": "Diameter of the tube",
    "opt4": "Viscosity of the liquid",
    "correct": 3
  },
  {
    "question": "A system undergoing an adiabatic process experiences:",
    "opt1": "No heat transfer",
    "opt2": "Constant volume",
    "opt3": "Constant pressure",
    "opt4": "Constant temperature",
    "correct": 1
  }
]

quests1 = [
  {
    "question": "Which of the following best defines education?",
    "opt1": "A process of gaining financial independence.",
    "opt2": "A deliberate and systematic influence exerted by a mature person on the immature through instruction and discipline.",
    "opt3": "A form of social entertainment.",
    "opt4": "A religious form of enlightenment.",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a form of education?",
    "opt1": "Formal education",
    "opt2": "Informal education",
    "opt3": "Non-formal education",
    "opt4": "Virtual education",
    "correct": 4
  },
  {
    "question": "Informal education can be best described as:",
    "opt1": "Structured and curriculum-based learning in schools.",
    "opt2": "Learning that takes place in organized educational institutions.",
    "opt3": "Learning that occurs through daily activities and interactions with the environment.",
    "opt4": "Learning under strict government supervision.",
    "correct": 3
  },
  {
    "question": "The purpose of formal education includes all EXCEPT:",
    "opt1": "Transmission of cultural heritage.",
    "opt2": "Training for specific occupations.",
    "opt3": "Promotion of superstition.",
    "opt4": "Development of intellectual and moral virtues.",
    "correct": 3
  },
  {
    "question": "Non-formal education differs from formal education in that it:",
    "opt1": "Is only available to adults.",
    "opt2": "Is confined to school buildings.",
    "opt3": "Occurs outside the formal school system and is often flexible and vocational.",
    "opt4": "Does not involve any learning process.",
    "correct": 3
  },
  {
    "question": "Which of the following best defines education according to Owolabi and Ogunleye?",
    "opt1": "Learning restricted to the classroom",
    "opt2": "The process of social transmission of culture",
    "opt3": "An informal way of acquiring wealth",
    "opt4": "A personal endeavor for certificates",
    "correct": 2
  },
  {
    "question": "Which dimension of education involves structured institutions and curriculum?",
    "opt1": "Informal education",
    "opt2": "Formal education",
    "opt3": "Non-formal education",
    "opt4": "Civic education",
    "correct": 2
  },
  {
    "question": "Non-formal education is mainly characterized by:",
    "opt1": "Rigid structure and certification",
    "opt2": "Age-specific content",
    "opt3": "Flexible learning and targeted skills",
    "opt4": "Teacher-centered learning",
    "correct": 3
  },
  {
    "question": "Informal education is often obtained through:",
    "opt1": "Television only",
    "opt2": "Schools and colleges",
    "opt3": "Daily life experiences",
    "opt4": "Government-sponsored programs",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a dimension of education?",
    "opt1": "Formal education",
    "opt2": "Non-formal education",
    "opt3": "Compulsory education",
    "opt4": "Informal education",
    "correct": 3
  },
  {
    "question": "What characterizes teaching as a noble profession?",
    "opt1": "High salaries",
    "opt2": "Political recognition",
    "opt3": "Commitment to nation building",
    "opt4": "Availability of office space",
    "correct": 3
  },
  {
    "question": "According to Bello and Madu, teachers serve as:",
    "opt1": "Mediators of government policies",
    "opt2": "Agents of social change",
    "opt3": "Representatives of school authorities",
    "opt4": "Enforcers of discipline",
    "correct": 2
  },
  {
    "question": "Which of the following is expected of a noble teacher?",
    "opt1": "Partiality in student evaluation",
    "opt2": "Laxity in classroom control",
    "opt3": "Exemplary behavior and role modeling",
    "opt4": "Neglect of professional development",
    "correct": 3
  },
  {
    "question": "The dignity of the teaching profession is upheld by:",
    "opt1": "Corporal punishment",
    "opt2": "Frequent industrial actions",
    "opt3": "Ethical conduct and discipline",
    "opt4": "Obedience to political leaders",
    "correct": 3
  },
  {
    "question": "Teachers contribute to national development primarily through:",
    "opt1": "Military service",
    "opt2": "Business entrepreneurship",
    "opt3": "Educating the citizenry",
    "opt4": "Judicial activism",
    "correct": 3
  },
  {
    "question": "What is the primary function of TRCN?",
    "opt1": "Regulating school fees",
    "opt2": "Recruiting teachers",
    "opt3": "Regulating and controlling teaching in Nigeria",
    "opt4": "Providing free education",
    "correct": 3
  },
  {
    "question": "Which law established the TRCN?",
    "opt1": "TRCN Act CAP T3 of 2004",
    "opt2": "Nigerian Teachers' Law of 1998",
    "opt3": "Educational Decree 25",
    "opt4": "National Education Policy Act",
    "correct": 1
  },
  {
    "question": "Which of these is NOT a TRCN mandate?",
    "opt1": "Issuing teaching licenses",
    "opt2": "Maintaining teachers' register",
    "opt3": "Training medical personnel",
    "opt4": "Enforcing teaching standards",
    "correct": 3
  },
  {
    "question": "Teachers in Nigeria must register with TRCN to:",
    "opt1": "Gain government employment",
    "opt2": "Be recognized as professionals",
    "opt3": "Earn higher salaries",
    "opt4": "Join school unions",
    "correct": 2
  },
  {
    "question": "TRCN ensures professionalism through:",
    "opt1": "Strike actions",
    "opt2": "Political affiliations",
    "opt3": "Certification and licensing",
    "opt4": "Community awareness",
    "correct": 3
  },
  {
    "question": "The first formal school in Nigeria was established in:",
    "opt1": "1821",
    "opt2": "1842",
    "opt3": "1859",
    "opt4": "1900",
    "correct": 2
  },
  {
    "question": "Who were primarily responsible for early education in Nigeria?",
    "opt1": "Colonial officers",
    "opt2": "Nigerian government",
    "opt3": "Missionaries",
    "opt4": "Traditional rulers",
    "correct": 3
  },
  {
    "question": "The major goal of early missionary education was to:",
    "opt1": "Prepare clerks",
    "opt2": "Train pastors and converts",
    "opt3": "Build empires",
    "opt4": "Support trade",
    "correct": 2
  },
  {
    "question": "Which region first adopted western education in Nigeria?",
    "opt1": "Northern region",
    "opt2": "Eastern region",
    "opt3": "Western region",
    "opt4": "Middle Belt",
    "correct": 3
  },
  {
    "question": "Which of these was NOT a characteristic of traditional Nigerian education?",
    "opt1": "Community participation",
    "opt2": "Oral transmission",
    "opt3": "Religious instruction",
    "opt4": "Textbook-based curriculum",
    "correct": 4
  },
  {
    "question": "Which stage is characterized by rapid physical growth and puberty?",
    "opt1": "Early childhood",
    "opt2": "Middle childhood",
    "opt3": "Adolescence",
    "opt4": "Infancy",
    "correct": 3
  },
  {
    "question": "Cognitive development in children is associated with the work of:",
    "opt1": "Freud",
    "opt2": "Piaget",
    "opt3": "Skinner",
    "opt4": "Maslow",
    "correct": 2
  },
  {
    "question": "Moral development in adolescents is best promoted through:",
    "opt1": "Punishment",
    "opt2": "Peer pressure",
    "opt3": "Ethical discussions",
    "opt4": "Strict discipline",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a stage in child development?",
    "opt1": "Infancy",
    "opt2": "Late adulthood",
    "opt3": "Early childhood",
    "opt4": "Middle childhood",
    "correct": 2
  },
  {
    "question": "Adolescents often struggle with identity due to:",
    "opt1": "Hormonal imbalance",
    "opt2": "Cognitive regression",
    "opt3": "Social expectations and self-awareness",
    "opt4": "Lack of physical growth",
    "correct": 3
  }
]

quests2 = [
  {
    "question": "Which of the following authors defined education as the process of giving and receiving systematic instruction to positively change the learner's behavior?",
    "opt1": "Chukwuma (2020)",
    "opt2": "Avwata (2021)",
    "opt3": "Dalhat (2022)",
    "opt4": "Bala (2022)",
    "correct": 3
  },
  {
    "question": "According to the chapter, education begins and ends at what stages of life?",
    "opt1": "From age 3 to retirement",
    "opt2": "From primary school to university",
    "opt3": "From birth to death",
    "opt4": "From adolescence to adulthood",
    "correct": 3
  },
  {
    "question": "Which of the following best reflects the **purpose** of education as stated in the chapter?",
    "opt1": "To make students obedient",
    "opt2": "To increase literacy rates only",
    "opt3": "To change the learner’s behavior positively",
    "opt4": "To reduce national unemployment",
    "correct": 3
  },
  {
    "question": "What is NOT one of the objectives of Chapter 1?",
    "opt1": "Explain types of education",
    "opt2": "Define philosophy of education",
    "opt3": "Explain the importance of education for global development",
    "opt4": "Mention characteristics of formal, informal, and non-formal education",
    "correct": 2
  },
  {
    "question": "Which form of education occurs within structured institutions and follows a set curriculum?",
    "opt1": "Formal education",
    "opt2": "Informal education",
    "opt3": "Non-formal education",
    "opt4": "Indigenous education",
    "correct": 1
  },
  {
    "question": "Which of these is TRUE about informal education?",
    "opt1": "It is received in classrooms only",
    "opt2": "It follows a formal curriculum",
    "opt3": "It happens through life experiences and interactions",
    "opt4": "It is regulated by government bodies",
    "correct": 3
  },
  {
    "question": "Non-formal education is best described as:",
    "opt1": "Structured education within schools",
    "opt2": "Learning that occurs through daily interaction only",
    "opt3": "Organized learning outside the formal system",
    "opt4": "Unplanned educational processes",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a feature of formal education?",
    "opt1": "Structured curriculum",
    "opt2": "Qualified teachers",
    "opt3": "Casual learning environment",
    "opt4": "Certificates awarded",
    "correct": 3
  },
  {
    "question": "Education helps a person to:",
    "opt1": "Become rich",
    "opt2": "Learn only to read and write",
    "opt3": "Communicate and understand the world around him",
    "opt4": "Avoid schooling",
    "correct": 3
  },
  {
    "question": "According to Chukwuma (2020), education promotes:",
    "opt1": "Daily routines",
    "opt2": "Life of the learner",
    "opt3": "Formal discipline only",
    "opt4": "Economic growth only",
    "correct": 2
  },
  {
    "question": "Which Latin term for education means 'to bring up or to raise'?",
    "opt1": "Educatum",
    "opt2": "Educare",
    "opt3": "Educere",
    "opt4": "Educatus",
    "correct": 2
  },
  {
    "question": "What is the focus of the Latin root 'Educere'?",
    "opt1": "To instruct",
    "opt2": "To raise a child",
    "opt3": "To lead forth or bring out",
    "opt4": "To form character",
    "correct": 3
  },
  {
    "question": "Which three key players are essential in every definition of education?",
    "opt1": "Curriculum, teacher, government",
    "opt2": "Teacher, student, environment",
    "opt3": "Parent, student, society",
    "opt4": "School, textbook, learner",
    "correct": 2
  },
  {
    "question": "What did the case study by Okebukola (1997) reveal about science teachers?",
    "opt1": "They agreed on a single definition of science",
    "opt2": "They refused to define science",
    "opt3": "They defined science from their specific disciplines",
    "opt4": "They misunderstood the concept of science",
    "correct": 3
  },
  {
    "question": "What does the term 'concept' primarily represent?",
    "opt1": "A permanent theory",
    "opt2": "A general idea or abstraction",
    "opt3": "A national curriculum",
    "opt4": "A standard method of teaching",
    "correct": 2
  },
  {
    "question": "Which scholar defined education as 'the bringing out of ideas latent in the mind'?",
    "opt1": "Plato",
    "opt2": "Aristotle",
    "opt3": "Socrates",
    "opt4": "Dewey",
    "correct": 3
  },
  {
    "question": "Which of these is NOT one of the five dimensions of education discussed?",
    "opt1": "Formal",
    "opt2": "Informal",
    "opt3": "International",
    "opt4": "Non-formal",
    "correct": 3
  },
  {
    "question": "What is the operational definition of a concept as stated in the chapter?",
    "opt1": "A direct observation",
    "opt2": "A theory backed by evidence",
    "opt3": "A measurable and testable construct",
    "opt4": "A philosophical assumption",
    "correct": 3
  },
  {
    "question": "Which of the following is a goal of education according to the chapter?",
    "opt1": "Increasing the population",
    "opt2": "Eliminating all traditions",
    "opt3": "Transmitting cultural heritage",
    "opt4": "Creating political parties",
    "correct": 3
  },
  {
    "question": "What does the National Policy on Education provide?",
    "opt1": "Annual education budget",
    "opt2": "Teacher salaries and allowances",
    "opt3": "Framework for Nigeria’s educational system",
    "opt4": "Private university licenses",
    "correct": 3
  },
  {
    "question": "What is the central theme of Chapter 3 in the textbook?",
    "opt1": "Science in Education",
    "opt2": "Teaching as a Noble Profession",
    "opt3": "ICT in Nigerian Schools",
    "opt4": "Philosophy of Education",
    "correct": 2
  },
  {
    "question": "Why is teaching considered a noble profession?",
    "opt1": "It has the highest salary",
    "opt2": "It requires no training",
    "opt3": "All other professions depend on it",
    "opt4": "It involves physical work",
    "correct": 3
  },
  {
    "question": "What distinguishes a profession from an occupation?",
    "opt1": "Level of interest",
    "opt2": "Salary attached",
    "opt3": "Training, ethics, and service",
    "opt4": "Age of practitioner",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a characteristic of the teaching profession?",
    "opt1": "Code of ethics",
    "opt2": "Public service orientation",
    "opt3": "Scientific base",
    "opt4": "Profit-making focus",
    "correct": 4
  },
  {
    "question": "The foundation of all other professions is:",
    "opt1": "Engineering",
    "opt2": "Law",
    "opt3": "Teaching",
    "opt4": "Medicine",
    "correct": 3
  },
  {
    "question": "Teaching as an interpersonal activity implies:",
    "opt1": "It is done in isolation",
    "opt2": "It involves only theory",
    "opt3": "It requires interaction with learners",
    "opt4": "It must be done online",
    "correct": 3
  },
  {
    "question": "Teaching is both a(n) ______ and a science.",
    "opt1": "Sport",
    "opt2": "Art",
    "opt3": "Business",
    "opt4": "Game",
    "correct": 2
  },
  {
    "question": "Which term refers to planned educational interaction?",
    "opt1": "Experiment",
    "opt2": "Sermon",
    "opt3": "Teaching",
    "opt4": "Debate",
    "correct": 3
  },
  {
    "question": "One major challenge to teaching in Nigeria today is:",
    "opt1": "Too many teachers",
    "opt2": "Lack of respect from students",
    "opt3": "Use of outdated methods",
    "opt4": "Integration of ICT",
    "correct": 4
  },
  {
    "question": "Which strategy can improve teaching’s nobility?",
    "opt1": "Increasing corporal punishment",
    "opt2": "Reducing entry qualifications",
    "opt3": "Integration of ICT in classrooms",
    "opt4": "Banning teacher unions",
    "correct": 3
  },
  {
    "question": "What year was the Teachers Registration Council of Nigeria (TRCN) originally established?",
    "opt1": "1999",
    "opt2": "1993",
    "opt3": "2004",
    "opt4": "1995",
    "correct": 2
  },
  {
    "question": "TRCN was created as a parastatal under which Nigerian ministry?",
    "opt1": "Ministry of Information",
    "opt2": "Ministry of Youth Development",
    "opt3": "Federal Ministry of Education",
    "opt4": "Ministry of Labour and Productivity",
    "correct": 3
  },
  {
    "question": "Which Act currently governs the TRCN?",
    "opt1": "TRCN Act Cap T3 of 2004",
    "opt2": "Nigerian Education Act 2003",
    "opt3": "Teacher Service Act 1992",
    "opt4": "TRCN Reformation Act 2001",
    "correct": 1
  },
  {
    "question": "What is the mission of the TRCN?",
    "opt1": "To build more schools for teachers",
    "opt2": "To promote foreign teacher exchange",
    "opt3": "To regulate teacher education and practice to meet global standards",
    "opt4": "To replace outdated teaching methods",
    "correct": 3
  },
  {
    "question": "What is the TRCN’s motto?",
    "opt1": "Teaching is Knowledge",
    "opt2": "Excellence through Dedication",
    "opt3": "Education for Growth",
    "opt4": "Teaching for Excellence",
    "correct": 4
  },
  {
    "question": "Which of these is NOT a function of the TRCN?",
    "opt1": "Registering teachers",
    "opt2": "Building schools",
    "opt3": "Licensing teachers",
    "opt4": "Maintaining teacher discipline",
    "correct": 2
  },
  {
    "question": "What is a core mandate of the TRCN?",
    "opt1": "Promotion of private education",
    "opt2": "Teacher certification and licensing",
    "opt3": "Construction of classrooms",
    "opt4": "Distribution of free books",
    "correct": 2
  },
  {
    "question": "Which of the following is part of TRCN’s future certification goals?",
    "opt1": "Certify only foreign-trained teachers",
    "opt2": "Generalized certifications only",
    "opt3": "Specialized certifications by education level",
    "opt4": "Certifications for retired teachers",
    "correct": 3
  },
  {
    "question": "How does TRCN aim to improve teacher quality?",
    "opt1": "Through physical fitness tests",
    "opt2": "By organizing spelling bees",
    "opt3": "Through certification and licensing",
    "opt4": "By publishing textbooks",
    "correct": 3
  },
  {
    "question": "What does the TRCN classify periodically?",
    "opt1": "Teacher salary grades",
    "opt2": "School locations",
    "opt3": "Teaching methods",
    "opt4": "Teachers by training and qualification",
    "correct": 4
  },
  {
    "question": "What is the main purpose of studying the history of education in Nigeria?",
    "opt1": "To determine the best modern teaching methods",
    "opt2": "To attract international students",
    "opt3": "To avoid collective amnesia and preserve educational heritage",
    "opt4": "To improve funding for Nigerian schools",
    "correct": 3
  },
  {
    "question": "Which educational system existed before the arrival of Islam and Christianity in Nigeria?",
    "opt1": "Islamic education",
    "opt2": "Missionary education",
    "opt3": "Western education",
    "opt4": "Traditional or indigenous education",
    "correct": 4
  },
  {
    "question": "According to the authors, traditional Nigerian education is described as:",
    "opt1": "Western-centric",
    "opt2": "Eurocentric",
    "opt3": "Afro-centric",
    "opt4": "Techno-centric",
    "correct": 3
  },
  {
    "question": "Which region of Nigeria was Islamic education firmly established in?",
    "opt1": "Southern region",
    "opt2": "Eastern region",
    "opt3": "Northern region",
    "opt4": "Western region",
    "correct": 3
  },
  {
    "question": "Christian missionary education in Nigeria was primarily focused in which region?",
    "opt1": "Northern Nigeria",
    "opt2": "Southern Nigeria",
    "opt3": "Central Nigeria",
    "opt4": "Entire country",
    "correct": 2
  },
  {
    "question": "Which of the following best describes indigenous Nigerian education?",
    "opt1": "Focused on religious conversion",
    "opt2": "Formal and certificate-based",
    "opt3": "Practical and culturally rooted",
    "opt4": "Centered on Latin grammar",
    "correct": 3
  },
  {
    "question": "According to the text, Christian missionaries combined evangelism with:",
    "opt1": "Healthcare",
    "opt2": "Political campaigns",
    "opt3": "Educational activities",
    "opt4": "Agricultural practices",
    "correct": 3
  },
  {
    "question": "What year was the first Nigerian university, the University of Ibadan, established?",
    "opt1": "1930",
    "opt2": "1948",
    "opt3": "1960",
    "opt4": "1957",
    "correct": 2
  },
  {
    "question": "Which of the following influenced Nigeria’s worldview and learning style?",
    "opt1": "Latin education",
    "opt2": "Indigenous education",
    "opt3": "French curriculum",
    "opt4": "Online education",
    "correct": 2
  },
  {
    "question": "What was the name of the first higher institution in Nigeria?",
    "opt1": "Yaba College of Technology",
    "opt2": "University of Lagos",
    "opt3": "Hope Waddle Training Institute",
    "opt4": "University of Ibadan",
    "correct": 3
  },
  {
    "question": "What is the primary distinction between growth and development?",
    "opt1": "Growth is emotional while development is physical",
    "opt2": "Growth involves increase in size; development involves overall changes including mental and emotional aspects",
    "opt3": "Growth stops at childhood; development continues forever",
    "opt4": "Growth is temporary; development is permanent",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT one of the four main areas of growth and development?",
    "opt1": "Physical",
    "opt2": "Cognitive",
    "opt3": "Spiritual",
    "opt4": "Emotional",
    "correct": 3
  },
  {
    "question": "At what stage does adolescence generally begin?",
    "opt1": "5 years",
    "opt2": "7 years",
    "opt3": "9–10 years",
    "opt4": "12–13 years",
    "correct": 3
  },
  {
    "question": "What characterizes early adolescence (10–13 years)?",
    "opt1": "Independence from parents and stable identity",
    "opt2": "Significant romantic relationships",
    "opt3": "Growth spurts and hormonal changes",
    "opt4": "Career choice and responsibilities",
    "correct": 3
  },
  {
    "question": "Which theory of development emphasizes identity formation during adolescence?",
    "opt1": "Piaget’s Cognitive Theory",
    "opt2": "Freud’s Psychoanalytic Theory",
    "opt3": "Erikson’s Psychosocial Theory",
    "opt4": "Skinner’s Behaviorist Theory",
    "correct": 3
  },
  {
    "question": "Which developmental stage is associated with abstract thinking and reasoning?",
    "opt1": "Infancy",
    "opt2": "Early childhood",
    "opt3": "Late childhood",
    "opt4": "Adolescence",
    "correct": 4
  },
  {
    "question": "Which of these is a major problem during adolescence?",
    "opt1": "Language acquisition",
    "opt2": "Identity confusion",
    "opt3": "Lack of motor skills",
    "opt4": "Toilet training",
    "correct": 2
  },
  {
    "question": "What is the final stage of adolescence as per the text?",
    "opt1": "14–16 years",
    "opt2": "17–18 years",
    "opt3": "18–21 years",
    "opt4": "20–25 years",
    "correct": 3
  },
  {
    "question": "Which of these domains is NOT explicitly listed as part of adolescent development?",
    "opt1": "Cognitive",
    "opt2": "Affective",
    "opt3": "Economic",
    "opt4": "Social",
    "correct": 3
  },
  {
    "question": "Which intervention is recommended for adolescent behavioral problems?",
    "opt1": "Increased punishment",
    "opt2": "Ignoring bad behavior",
    "opt3": "Intervention strategies like counseling",
    "opt4": "Isolation from peers",
    "correct": 3
  },

]

quests3 = [
    {
    "question": "Which principle of development suggests development follows a sequential pattern?",
    "opt1": "Inter-individual difference",
    "opt2": "Cephalocaudal principle",
    "opt3": "Mass to specific",
    "opt4": "Sequential development",
    "correct": 4
  },
  {
    "question": "What characterizes mid-adolescence (ages 14–17)?",
    "opt1": "Learning basic skills",
    "opt2": "Exploring identity and peer relationships",
    "opt3": "Mastery of adult roles",
    "opt4": "Start of formal schooling",
    "correct": 2
  },
  {
    "question": "Which factor does NOT directly affect adolescent development?",
    "opt1": "Family background",
    "opt2": "Cultural environment",
    "opt3": "Diet",
    "opt4": "Mathematical ability",
    "correct": 4
  },
  {
    "question": "Which phase involves more stable emotional development and decision-making?",
    "opt1": "Infancy",
    "opt2": "Early adolescence",
    "opt3": "Mid-adolescence",
    "opt4": "Late adolescence",
    "correct": 4
  },
  {
    "question": "The rapid change in body shape and size during adolescence is referred to as:",
    "opt1": "Cognitive jump",
    "opt2": "Maturation leap",
    "opt3": "Growth spurt",
    "opt4": "Hormonal balance",
    "correct": 3
  },
  {
    "question": "Which development domain includes moral reasoning and belief systems?",
    "opt1": "Physical",
    "opt2": "Cognitive",
    "opt3": "Social",
    "opt4": "Affective",
    "correct": 2
  },
  {
    "question": "Which psychologist is known for cognitive developmental stages?",
    "opt1": "Freud",
    "opt2": "Piaget",
    "opt3": "Skinner",
    "opt4": "Erikson",
    "correct": 2
  },
  {
    "question": "In which developmental phase do peer groups become most influential?",
    "opt1": "Late childhood",
    "opt2": "Early adolescence",
    "opt3": "Infancy",
    "opt4": "Old age",
    "correct": 2
  },
  {
    "question": "Which of these best describes the nature of development?",
    "opt1": "It is static and age-based",
    "opt2": "It stops after adolescence",
    "opt3": "It is lifelong and multidimensional",
    "opt4": "It is based only on heredity",
    "correct": 3
  },
  {
    "question": "Why is understanding adolescent development important for teachers?",
    "opt1": "To help select class monitors",
    "opt2": "To punish students more effectively",
    "opt3": "To manage classroom furniture",
    "opt4": "To adapt teaching to students’ needs",
    "correct": 4
  },
    {
    "question": "Which commission founded Yaba College of Technology?",
    "opt1": "Ashby Commission",
    "opt2": "Eliot Commission",
    "opt3": "MacPherson Commission",
    "opt4": "Ukeji Commission",
    "correct": 2
  },
  {
    "question": "When was the Ashby Commission report released?",
    "opt1": "1957",
    "opt2": "1965",
    "opt3": "1960",
    "opt4": "1943",
    "correct": 3
  },
  {
    "question": "What was one of the major flaws in Nigeria’s education system identified in the text?",
    "opt1": "Overemphasis on traditional education",
    "opt2": "Lack of university degrees",
    "opt3": "Neglect of technical and vocational education",
    "opt4": "Limited missionary schools",
    "correct": 3
  },
  {
    "question": "What type of education was emphasized more in Nigeria post-independence?",
    "opt1": "Technical education",
    "opt2": "Vocational education",
    "opt3": "Literary education",
    "opt4": "Engineering education",
    "correct": 3
  },
  {
    "question": "What year marked the introduction of the universal primary education scheme in Nigeria?",
    "opt1": "1957",
    "opt2": "1960",
    "opt3": "1948",
    "opt4": "1970",
    "correct": 1
  },
  {
    "question": "Which region effectively implemented free primary education in Nigeria?",
    "opt1": "Northern region",
    "opt2": "Eastern region",
    "opt3": "Western region",
    "opt4": "Central region",
    "correct": 3
  },
  {
    "question": "What role did the regional Ministry of Education play in the Western state?",
    "opt1": "Provided only textbooks",
    "opt2": "Hired teachers and administered schools",
    "opt3": "Funded private schools only",
    "opt4": "Supervised traditional education",
    "correct": 2
  },
  {
    "question": "Which group of people established the Hope Waddle Training Institute?",
    "opt1": "British government",
    "opt2": "Scottish missionaries",
    "opt3": "Nigerian government",
    "opt4": "French Catholic Mission",
    "correct": 2
  },
  {
    "question": "What year was Yaba College of Technology founded?",
    "opt1": "1943",
    "opt2": "1945",
    "opt3": "1947",
    "opt4": "1948",
    "correct": 3
  },
  {
    "question": "How many primary schools were there in Southern Nigeria by 1906?",
    "opt1": "100",
    "opt2": "126",
    "opt3": "87",
    "opt4": "150",
    "correct": 2
  },
    {
    "question": "What does TRCN regulate and control?",
    "opt1": "Teachers’ dress code",
    "opt2": "The teaching profession in all aspects",
    "opt3": "All universities in Nigeria",
    "opt4": "School fees",
    "correct": 2
  },
  {
    "question": "Which type of certification does TRCN currently offer?",
    "opt1": "Subject-specific",
    "opt2": "Generalized certification",
    "opt3": "Skill-based certification",
    "opt4": "Internship certification",
    "correct": 2
  },
  {
    "question": "What is one key benefit of TRCN licensing?",
    "opt1": "Allows teachers to work abroad",
    "opt2": "Improves student outcomes indirectly",
    "opt3": "Reduces number of teachers",
    "opt4": "Eliminates exams",
    "correct": 2
  },
  {
    "question": "What is TRCN's vision?",
    "opt1": "To replace old teachers with younger ones",
    "opt2": "To supervise foreign teacher training",
    "opt3": "To promote excellence through licensing and monitoring",
    "opt4": "To increase school enrollment",
    "correct": 3
  },
  {
    "question": "What does TRCN publish periodically?",
    "opt1": "Teacher promotion lists",
    "opt2": "School rankings",
    "opt3": "List of registered teachers",
    "opt4": "Pupil-teacher ratios",
    "correct": 3
  },
  {
    "question": "What is one way TRCN ensures access to its services?",
    "opt1": "Online social media platforms",
    "opt2": "Opening new liaison offices",
    "opt3": "Mobile classrooms",
    "opt4": "TV campaigns",
    "correct": 2
  },
  {
    "question": "What kind of training does TRCN emphasize?",
    "opt1": "Occasional and informal",
    "opt2": "Short weekend courses only",
    "opt3": "Vigorous and continuous",
    "opt4": "Only postgraduate-level",
    "correct": 3
  },
  {
    "question": "What is the significance of TRCN certification for teachers?",
    "opt1": "Provides salary advance",
    "opt2": "Makes them eligible for government loans",
    "opt3": "Qualifies them to teach and be recognized professionally",
    "opt4": "Exempts them from training",
    "correct": 3
  },
  {
    "question": "Which countries were mentioned as models for TRCN's future direction?",
    "opt1": "Ghana and South Africa",
    "opt2": "India and Canada",
    "opt3": "Finland and USA",
    "opt4": "Brazil and France",
    "correct": 3
  },
  {
    "question": "What new policy was highlighted in the chapter?",
    "opt1": "School Uniform Policy",
    "opt2": "Student Performance Evaluation",
    "opt3": "Teacher Career Path Policy",
    "opt4": "Education Budget Policy",
    "correct": 3
  },
    {
    "question": "Which of these best supports teaching as a profession?",
    "opt1": "Minimum of two years in the field",
    "opt2": "Formal training and certification",
    "opt3": "Working in rural areas",
    "opt4": "Flexible job description",
    "correct": 2
  },
  {
    "question": "Teaching contributes to nation-building because:",
    "opt1": "It creates politicians",
    "opt2": "It is compulsory for all",
    "opt3": "It develops human capital",
    "opt4": "It generates revenue",
    "correct": 3
  },
  {
    "question": "Which of the following is considered an ethical expectation of teachers?",
    "opt1": "Competitiveness",
    "opt2": "Confidentiality",
    "opt3": "Aggressiveness",
    "opt4": "Leniency",
    "correct": 2
  },
  {
    "question": "Which is true about occupations?",
    "opt1": "They require long academic training",
    "opt2": "They follow strict ethical codes",
    "opt3": "They are mostly manual jobs",
    "opt4": "They may not need specialized education",
    "correct": 4
  },
  {
    "question": "The integration of ICT in teaching helps to:",
    "opt1": "Replace the teacher",
    "opt2": "Discourage reading",
    "opt3": "Support modern learning",
    "opt4": "Encourage physical punishment",
    "correct": 3
  },
  {
    "question": "Which is NOT a challenge to the teaching profession mentioned in Chapter 3?",
    "opt1": "Low remuneration",
    "opt2": "Poor working conditions",
    "opt3": "Too many school holidays",
    "opt4": "Lack of professional development",
    "correct": 3
  },
  {
    "question": "What is one way to elevate teaching to its noble status?",
    "opt1": "Awarding bonuses to only top students",
    "opt2": "Improving teacher training and development",
    "opt3": "Discouraging ICT usage",
    "opt4": "Reducing teacher workload",
    "correct": 2
  },
  {
    "question": "What is meant by saying teaching is at the root of all professions?",
    "opt1": "Teachers earn the most money",
    "opt2": "Other professions learn from teachers",
    "opt3": "Teachers don’t retire",
    "opt4": "Only teachers go to school",
    "correct": 2
  },
  {
    "question": "What is the role of the teacher in nation building?",
    "opt1": "Training future citizens and professionals",
    "opt2": "Creating educational games",
    "opt3": "Providing free food",
    "opt4": "Organizing festivals",
    "correct": 1
  },
  {
    "question": "Who benefits most from elevating the status of teachers?",
    "opt1": "Government agencies",
    "opt2": "Learners and society",
    "opt3": "Sports organizations",
    "opt4": "Media houses",
    "correct": 2
  },
    {
    "question": "Which dimension of education occurs outside the formal school system but is organized?",
    "opt1": "Formal education",
    "opt2": "Informal education",
    "opt3": "Non-formal education",
    "opt4": "Casual learning",
    "correct": 3
  },
  {
    "question": "Which concept of education emphasizes continuous learning throughout life?",
    "opt1": "Permanent education",
    "opt2": "Vocational education",
    "opt3": "Tertiary education",
    "opt4": "Primary education",
    "correct": 1
  },
  {
    "question": "Education is said to be elastic in meaning because:",
    "opt1": "It has a fixed interpretation",
    "opt2": "It changes across schools only",
    "opt3": "It is dependent on individual and cultural perspectives",
    "opt4": "It is only taught in tertiary institutions",
    "correct": 3
  },
  {
    "question": "Which of these best describes an 'educated person' according to the chapter?",
    "opt1": "One who has a degree",
    "opt2": "One who can read and write only",
    "opt3": "One who demonstrates refined behavior and applies knowledge constructively",
    "opt4": "One who memorizes facts",
    "correct": 3
  },
  {
    "question": "Which of the following is a classification of concepts?",
    "opt1": "Simple, compound, hybrid",
    "opt2": "Concrete, abstract, process",
    "opt3": "Scientific, cultural, political",
    "opt4": "National, state, local",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a relevance of the National Policy on Education?",
    "opt1": "Provides educational structure",
    "opt2": "Unifies foreign and local schools",
    "opt3": "Clarifies government objectives",
    "opt4": "Specifies school calendar",
    "correct": 2
  },
  {
    "question": "How does informal education mainly occur?",
    "opt1": "Through organized teaching",
    "opt2": "In boarding schools only",
    "opt3": "Via daily experiences and interactions",
    "opt4": "Using textbooks and exams",
    "correct": 3
  },
  {
    "question": "The chapter concludes that no single definition of education is complete without:",
    "opt1": "Government support",
    "opt2": "Religious elements",
    "opt3": "Student, teacher, and environment",
    "opt4": "Textbooks and syllabus",
    "correct": 3
  },
  {
    "question": "Which of these definitions focuses more on the learner's personal development?",
    "opt1": "Educatum",
    "opt2": "Educare",
    "opt3": "Educere",
    "opt4": "Educado",
    "correct": 3
  },
  {
    "question": "What lesson can students draw from Okebukola's case study?",
    "opt1": "Avoid science subjects",
    "opt2": "Ignore discipline-specific views",
    "opt3": "Pay attention to minute details",
    "opt4": "Rely only on teachers’ views",
    "correct": 3
  },
    {
    "question": "Which statement is FALSE regarding education?",
    "opt1": "Education stops at adulthood",
    "opt2": "Education takes place from birth to death",
    "opt3": "Education is formal, informal, and non-formal",
    "opt4": "Education can be self-taught",
    "correct": 1
  },
  {
    "question": "Which form of education allows learning at any time or place, even without the teacher being physically present?",
    "opt1": "Formal education",
    "opt2": "Distance learning",
    "opt3": "Informal education",
    "opt4": "Non-formal education",
    "correct": 2
  },
  {
    "question": "Which of these best describes the chapter’s viewpoint on the cost of education?",
    "opt1": "Education is a waste of money",
    "opt2": "Education is too expensive for most people",
    "opt3": "Education is expensive, but ignorance is costlier",
    "opt4": "Education should be free everywhere",
    "correct": 3
  },
  {
    "question": "What does the chapter say education encourages?",
    "opt1": "Repetition of traditional methods",
    "opt2": "Obedience to authorities",
    "opt3": "Thinking outside the box and new ideas",
    "opt4": "Avoidance of change",
    "correct": 3
  },
  {
    "question": "According to Avwata (2021), education includes:",
    "opt1": "Only formal learning",
    "opt2": "Formal, informal, and non-formal processes",
    "opt3": "Military training",
    "opt4": "Political orientation",
    "correct": 2
  },
  {
    "question": "What aspect of education helps one develop confidence and courage?",
    "opt1": "Examinations",
    "opt2": "Classroom tests",
    "opt3": "Thinking and experimentation",
    "opt4": "Discipline alone",
    "correct": 3
  },
  {
    "question": "Which term refers to the design and imparting of a special curriculum to learners?",
    "opt1": "Knowledge sharing",
    "opt2": "Curriculum planning",
    "opt3": "Systematic education",
    "opt4": "Formal learning",
    "correct": 3
  },
  {
    "question": "What distinguishes non-formal education from formal education?",
    "opt1": "Non-formal has no goal",
    "opt2": "Non-formal lacks any form of structure",
    "opt3": "Non-formal takes place outside the school system",
    "opt4": "Non-formal uses textbooks always",
    "correct": 3
  },
  {
    "question": "According to the chapter, education contributes to:",
    "opt1": "Individual confusion",
    "opt2": "Global insecurity",
    "opt3": "National, regional, and global development",
    "opt4": "Isolationism",
    "correct": 3
  },
  {
    "question": "Self-teaching is considered possible today due to:",
    "opt1": "Lack of schools",
    "opt2": "Shortage of teachers",
    "opt3": "Flexible means of acquiring education",
    "opt4": "Traditional learning methods",
    "correct": 3
  }
  ]


quests4 = [
    {
    "question": "The major objective of classroom management is to:",
    "opt1": "Ensure silence in the classroom",
    "opt2": "Control student behavior",
    "opt3": "Facilitate effective learning",
    "opt4": "Complete the syllabus quickly",
    "correct": 3
  },
  {
    "question": "An example of a visual teaching aid is:",
    "opt1": "Audio tape",
    "opt2": "Blackboard",
    "opt3": "Classroom monitor",
    "opt4": "Radio",
    "correct": 2
  },
    {
    "question": "What are teaching resources primarily used for in the classroom?",
    "opt1": "To entertain students",
    "opt2": "To substitute teachers",
    "opt3": "To aid learning and teaching effectiveness",
    "opt4": "To reduce the syllabus",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a category of teaching resources?",
    "opt1": "Audio-visual materials",
    "opt2": "Human resources",
    "opt3": "Digital libraries",
    "opt4": "Classroom snacks",
    "correct": 4
  },
  {
    "question": "The term 'instructional materials' is synonymous with:",
    "opt1": "Extra curriculum",
    "opt2": "Recreational facilities",
    "opt3": "Teaching aids",
    "opt4": "Furniture",
    "correct": 3
  },
  {
    "question": "Who is primarily responsible for effective classroom management?",
    "opt1": "Students",
    "opt2": "Government",
    "opt3": "Teachers",
    "opt4": "Parents",
    "correct": 3
  },
  {
    "question": "Which of the following helps improve students' attention and retention?",
    "opt1": "Frequent punishment",
    "opt2": "Use of relevant teaching resources",
    "opt3": "Ignoring misbehavior",
    "opt4": "Extra homework",
    "correct": 2
  },
  {
    "question": "Which of the following is considered a human teaching resource?",
    "opt1": "Whiteboard",
    "opt2": "Projector",
    "opt3": "Textbook",
    "opt4": "Guest speaker",
    "correct": 4
  },
  {
    "question": "The systematic organization of classroom activities is called:",
    "opt1": "Curriculum design",
    "opt2": "Instructional supervision",
    "opt3": "Classroom management",
    "opt4": "Time tabling",
    "correct": 3
  },
  {
    "question": "Which factor does NOT directly influence classroom management?",
    "opt1": "Teacher's personality",
    "opt2": "Seating arrangement",
    "opt3": "Students' age",
    "opt4": "School fees",
    "correct": 4
  },
  {
    "question": "What is the primary focus of curriculum implementation?",
    "opt1": "Preparing instructional materials",
    "opt2": "Developing assessment methods",
    "opt3": "Delivering planned curriculum content",
    "opt4": "Evaluating students' performance",
    "correct": 3
  },
  {
    "question": "Which of these best defines curriculum development?",
    "opt1": "Instructional design",
    "opt2": "Planning, designing, and organizing learning experiences",
    "opt3": "Preparing examination materials",
    "opt4": "Organizing school management",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a type of curriculum?",
    "opt1": "Formal curriculum",
    "opt2": "Informal curriculum",
    "opt3": "Non-academic curriculum",
    "opt4": "Hidden curriculum",
    "correct": 3
  },
  {
    "question": "Which curriculum refers to what is actually taught in school?",
    "opt1": "Null curriculum",
    "opt2": "Hidden curriculum",
    "opt3": "Formal curriculum",
    "opt4": "Enacted curriculum",
    "correct": 4
  },
  {
    "question": "Which type of curriculum is not planned but learned through experience?",
    "opt1": "Formal curriculum",
    "opt2": "Hidden curriculum",
    "opt3": "Null curriculum",
    "opt4": "Official curriculum",
    "correct": 2
  },
  {
    "question": "What does 'null curriculum' imply?",
    "opt1": "Curriculum that is taught without assessment",
    "opt2": "Content intentionally excluded from instruction",
    "opt3": "Learning through informal settings",
    "opt4": "The sum total of all school activities",
    "correct": 2
  },
  {
    "question": "Which is the correct order of curriculum development stages?",
    "opt1": "Planning, Implementation, Evaluation",
    "opt2": "Evaluation, Planning, Design",
    "opt3": "Design, Planning, Implementation",
    "opt4": "Implementation, Planning, Evaluation",
    "correct": 1
  },
  {
    "question": "Curriculum implementation largely depends on:",
    "opt1": "Textbook publishers",
    "opt2": "Teachers and instructional methods",
    "opt3": "Government policies only",
    "opt4": "Curriculum theorists",
    "correct": 2
  },
  {
    "question": "Which type of curriculum includes extracurricular activities?",
    "opt1": "Hidden curriculum",
    "opt2": "Informal curriculum",
    "opt3": "Core curriculum",
    "opt4": "Null curriculum",
    "correct": 2
  },
    {
    "question": "A curriculum that adapts to learners' needs and environment is considered:",
    "opt1": "Static curriculum",
    "opt2": "Rigid curriculum",
    "opt3": "Dynamic curriculum",
    "opt4": "Hidden curriculum",
    "correct": 3
  },
  {
    "question": "Which of the following is a key strategy for accelerated learning according to Chapter 21?",
    "opt1": "Focusing only on assessments",
    "opt2": "Ignoring students' backgrounds",
    "opt3": "Using rote memorization",
    "opt4": "Employing interactive teaching methods",
    "correct": 4
  },
  {
    "question": "What role does student engagement play in accelerated performance?",
    "opt1": "It reduces performance",
    "opt2": "It is irrelevant",
    "opt3": "It enhances interest and learning speed",
    "opt4": "It complicates the teaching process",
    "correct": 3
  },
  {
    "question": "Which method supports individualized learning pace for students?",
    "opt1": "Group punishment",
    "opt2": "Personalized learning plans",
    "opt3": "Fixed curriculum for all",
    "opt4": "Lecture-only method",
    "correct": 2
  },
  {
    "question": "The use of multimedia tools in teaching helps in:",
    "opt1": "Slowing down learning",
    "opt2": "Increasing teacher workload only",
    "opt3": "Enhancing conceptual understanding",
    "opt4": "Reducing class participation",
    "correct": 3
  },
  {
    "question": "Which of the following encourages active learning?",
    "opt1": "Copying from the board",
    "opt2": "Teacher monologue",
    "opt3": "Project-based learning",
    "opt4": "Long-duration lectures",
    "correct": 3
  },
  {
    "question": "Differentiated instruction is best described as:",
    "opt1": "One-size-fits-all teaching",
    "opt2": "Using the same materials for all students",
    "opt3": "Tailoring teaching to students’ needs",
    "opt4": "Ignoring student feedback",
    "correct": 3
  },
  {
    "question": "Which teaching method combines both visual and auditory elements for better comprehension?",
    "opt1": "Chalk and talk",
    "opt2": "Audio-lingual method",
    "opt3": "Multisensory approach",
    "opt4": "Dictation exercises",
    "correct": 3
  },
  {
    "question": "Formative assessments help in:",
    "opt1": "Judging teachers’ salaries",
    "opt2": "Failing slow learners",
    "opt3": "Providing feedback for improvement",
    "opt4": "Ranking students for prizes",
    "correct": 3
  },
  {
    "question": "Collaborative learning is beneficial because it:",
    "opt1": "Promotes unhealthy competition",
    "opt2": "Discourages participation",
    "opt3": "Fosters peer interaction and teamwork",
    "opt4": "Eliminates the need for teachers",
    "correct": 3
  },
  {
    "question": "An important teacher skill for facilitating accelerated learning is:",
    "opt1": "Strict discipline enforcement",
    "opt2": "Mastery of content and flexible pedagogy",
    "opt3": "Avoiding student questions",
    "opt4": "Speaking fast to cover more topics",
    "correct": 2
  },
    {
    "question": "Which of the following is a key characteristic of a 21st-century classroom?",
    "opt1": "Teacher-centered instruction",
    "opt2": "Emphasis on rote memorization",
    "opt3": "Integration of technology in learning",
    "opt4": "Passive student participation",
    "correct": 3
  },
  {
    "question": "In managing a 21st-century classroom, teachers are expected to:",
    "opt1": "Maintain strict authority without input from students",
    "opt2": "Discourage collaboration among students",
    "opt3": "Incorporate student voice and choice",
    "opt4": "Rely solely on textbooks",
    "correct": 3
  },
  {
    "question": "Which teaching strategy is most aligned with 21st-century skills?",
    "opt1": "Drill and practice",
    "opt2": "Lecture-based delivery",
    "opt3": "Problem-based learning",
    "opt4": "Dictation and note-copying",
    "correct": 3
  },
  {
    "question": "What is a major benefit of using ICT in the classroom?",
    "opt1": "It increases teacher workload",
    "opt2": "It limits student access to knowledge",
    "opt3": "It facilitates personalized learning",
    "opt4": "It discourages group work",
    "correct": 3
  },
  {
    "question": "Which of the following best describes 21st-century learners?",
    "opt1": "Passive recipients of knowledge",
    "opt2": "Memorizers of facts",
    "opt3": "Active, collaborative, and tech-savvy",
    "opt4": "Restricted to classroom learning",
    "correct": 3
  },
  {
    "question": "To ensure effective teaching in the 21st-century classroom, teachers should:",
    "opt1": "Avoid using digital tools",
    "opt2": "Promote critical thinking and innovation",
    "opt3": "Focus solely on content delivery",
    "opt4": "Stick to a rigid curriculum",
    "correct": 2
  },
  {
    "question": "A defining feature of 21st-century teaching is:",
    "opt1": "Teacher monopoly on information",
    "opt2": "Integration of multiple literacies",
    "opt3": "Elimination of student assessments",
    "opt4": "Discouragement of feedback",
    "correct": 2
  },
  {
    "question": "Which classroom environment best supports 21st-century learning?",
    "opt1": "One with fixed seating and silent students",
    "opt2": "A traditional lecture hall",
    "opt3": "Flexible spaces that encourage interaction",
    "opt4": "Strict rows and chalkboard use only",
    "correct": 3
  },
  {
    "question": "One of the roles of the teacher in the 21st-century classroom is to:",
    "opt1": "Dictate every learning outcome",
    "opt2": "Facilitate and guide student inquiry",
    "opt3": "Ensure students avoid digital tools",
    "opt4": "Focus on low-order thinking skills",
    "correct": 2
  },
  {
    "question": "The goal of 21st-century education includes all EXCEPT:",
    "opt1": "Developing problem solvers",
    "opt2": "Fostering collaboration",
    "opt3": "Creating lifelong learners",
    "opt4": "Isolating learners from global trends",
    "correct": 4
  }

]

quests5 = [
    {
    "question": "Who plays the central role in curriculum implementation?",
    "opt1": "Curriculum developers",
    "opt2": "Students",
    "opt3": "Teachers",
    "opt4": "Policy makers",
    "correct": 3
  },
  {
    "question": "Which of these stakeholders is least involved in curriculum development?",
    "opt1": "Teachers",
    "opt2": "Students",
    "opt3": "Parents",
    "opt4": "Accountants",
    "correct": 4
  },
  {
    "question": "The curriculum that is officially approved and documented is known as:",
    "opt1": "Hidden curriculum",
    "opt2": "Official curriculum",
    "opt3": "Null curriculum",
    "opt4": "Informal curriculum",
    "correct": 2
  },
  {
    "question": "Curriculum evaluation is primarily aimed at:",
    "opt1": "Disciplining students",
    "opt2": "Training teachers",
    "opt3": "Improving curriculum effectiveness",
    "opt4": "Reducing school budgets",
    "correct": 3
  },
  {
    "question": "The term 'curriculum' originated from which language?",
    "opt1": "Latin",
    "opt2": "Greek",
    "opt3": "French",
    "opt4": "Arabic",
    "correct": 1
  },
  {
    "question": "Which curriculum is often learned unintentionally through school culture?",
    "opt1": "Null curriculum",
    "opt2": "Enacted curriculum",
    "opt3": "Hidden curriculum",
    "opt4": "Formal curriculum",
    "correct": 3
  },
  {
    "question": "Curriculum content should be selected based on all EXCEPT:",
    "opt1": "Relevance to learners",
    "opt2": "Cultural values",
    "opt3": "Teacher preferences only",
    "opt4": "National goals",
    "correct": 3
  },
  {
    "question": "Which is a major challenge in curriculum implementation?",
    "opt1": "Teacher absenteeism",
    "opt2": "Over-reliance on local content",
    "opt3": "Strict school uniforms",
    "opt4": "Student punctuality",
    "correct": 1
  },
  {
    "question": "The key output of curriculum development is:",
    "opt1": "Lesson notes",
    "opt2": "Curriculum guide",
    "opt3": "Timetable",
    "opt4": "Report cards",
    "correct": 2
  },
  {
    "question": "Effective curriculum implementation requires:",
    "opt1": "Political will only",
    "opt2": "Flexible learning schedules",
    "opt3": "Availability of resources and teacher training",
    "opt4": "Strict discipline policies",
    "correct": 3
  },
  {
    "question": "Which method promotes accelerated learning through hands-on experience?",
    "opt1": "Rote learning",
    "opt2": "Project-based learning",
    "opt3": "Copying notes",
    "opt4": "Dictation drills",
    "correct": 2
  },
  {
    "question": "According to Chapter 21, effective feedback should be:",
    "opt1": "Delayed and general",
    "opt2": "Negative and harsh",
    "opt3": "Timely and specific",
    "opt4": "Irregular and confusing",
    "correct": 3
  },
  {
    "question": "What is a major advantage of group work in the classroom?",
    "opt1": "Increases isolation",
    "opt2": "Discourages cooperation",
    "opt3": "Encourages peer learning",
    "opt4": "Eliminates individual accountability",
    "correct": 3
  },
  {
    "question": "Which of these best describes a flipped classroom approach?",
    "opt1": "Students learn new content at home and practice in class",
    "opt2": "Students memorize everything in class",
    "opt3": "Teachers lecture and give homework daily",
    "opt4": "All lessons are delivered online only",
    "correct": 1
  },
  {
    "question": "Which of the following best enhances critical thinking?",
    "opt1": "Objective tests only",
    "opt2": "Debates and discussions",
    "opt3": "Copying model answers",
    "opt4": "Recitation of facts",
    "correct": 2
  },
  {
    "question": "One of the benefits of using instructional technology is:",
    "opt1": "It replaces teachers completely",
    "opt2": "It bores learners",
    "opt3": "It enhances engagement and understanding",
    "opt4": "It restricts access to information",
    "correct": 3
  },
  {
    "question": "Accelerated learning requires teachers to:",
    "opt1": "Ignore student differences",
    "opt2": "Use only lectures",
    "opt3": "Adapt methods to student needs",
    "opt4": "Stick to rigid routines",
    "correct": 3
  },
  {
    "question": "In the context of this chapter, motivation helps students by:",
    "opt1": "Making them compete harshly",
    "opt2": "Increasing boredom",
    "opt3": "Enhancing focus and drive to learn",
    "opt4": "Encouraging absenteeism",
    "correct": 3
  },
  {
    "question": "Which learning style involves seeing and visualizing content?",
    "opt1": "Auditory",
    "opt2": "Kinesthetic",
    "opt3": "Visual",
    "opt4": "Tactile",
    "correct": 3
  },
  {
    "question": "What is the main focus of student-centered learning?",
    "opt1": "Teacher control of all activities",
    "opt2": "Maximizing test scores only",
    "opt3": "Active participation and collaboration",
    "opt4": "Punishment-based discipline",
    "correct": 3
  },
    {
    "question": "Effective use of teaching resources leads to:",
    "opt1": "Over-dependence on technology",
    "opt2": "Teacher laziness",
    "opt3": "Increased student engagement",
    "opt4": "Fewer exams",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a function of classroom management?",
    "opt1": "Promoting discipline",
    "opt2": "Fostering learning",
    "opt3": "Limiting participation",
    "opt4": "Reducing disruption",
    "correct": 3
  },
  {
    "question": "The use of teaching resources must align with:",
    "opt1": "Government policies",
    "opt2": "Students' expectations",
    "opt3": "Lesson objectives",
    "opt4": "Financial strength",
    "correct": 3
  },
  {
    "question": "Which principle is essential for selecting instructional materials?",
    "opt1": "Affordability only",
    "opt2": "Relevance to lesson objectives",
    "opt3": "Attractiveness alone",
    "opt4": "Large size",
    "correct": 2
  },
  {
    "question": "Classroom management includes all the following EXCEPT:",
    "opt1": "Discipline enforcement",
    "opt2": "Seating arrangement",
    "opt3": "Curriculum drafting",
    "opt4": "Time management",
    "correct": 3
  },
  {
    "question": "Which resource can be used to enhance digital learning in classrooms?",
    "opt1": "Chalkboard",
    "opt2": "Tablet devices",
    "opt3": "Handouts",
    "opt4": "Broom",
    "correct": 2
  },
  {
    "question": "The primary benefit of proper classroom management is:",
    "opt1": "Increased workload",
    "opt2": "Improved academic performance",
    "opt3": "Teacher fatigue",
    "opt4": "More free time",
    "correct": 2
  },
  {
    "question": "The teacher can promote active learning by:",
    "opt1": "Using outdated methods",
    "opt2": "Ignoring feedback",
    "opt3": "Integrating relevant instructional materials",
    "opt4": "Speaking monotonously",
    "correct": 3
  },
  {
    "question": "Instructional materials should be:",
    "opt1": "Expensive and flashy",
    "opt2": "Culturally irrelevant",
    "opt3": "Relevant and accessible",
    "opt4": "Only theoretical",
    "correct": 3
  },
  {
    "question": "The environment of the classroom should be:",
    "opt1": "Chaotic",
    "opt2": "Neutral",
    "opt3": "Unfriendly",
    "opt4": "Conducive to learning",
    "correct": 4
  },
    {
    "question": "Which of the following skills is considered crucial for learners in the 21st century?",
    "opt1": "Handwriting accuracy",
    "opt2": "Memorization of facts",
    "opt3": "Critical thinking",
    "opt4": "Passive listening",
    "correct": 3
  },
  {
    "question": "What is the major difference between traditional and 21st-century classrooms?",
    "opt1": "Teacher is absent in 21st-century classrooms",
    "opt2": "Students rely more on books",
    "opt3": "Learning is more student-centered",
    "opt4": "Learning happens only in physical spaces",
    "correct": 3
  },
  {
    "question": "Which of these best supports personalized learning?",
    "opt1": "One-size-fits-all instruction",
    "opt2": "Flexible digital tools",
    "opt3": "Strict curriculum pacing",
    "opt4": "Limited student interaction",
    "correct": 2
  },
  {
    "question": "What is a key outcome of using collaborative learning strategies?",
    "opt1": "Students learn to work independently only",
    "opt2": "Reduced social skills",
    "opt3": "Improved teamwork and communication",
    "opt4": "Decreased participation",
    "correct": 3
  },
  {
    "question": "A 21st-century teacher is expected to be:",
    "opt1": "A knowledge transmitter",
    "opt2": "A classroom disciplinarian",
    "opt3": "A facilitator and innovator",
    "opt4": "A non-digital native",
    "correct": 3
  },
  {
    "question": "Which of the following best encourages creativity in the classroom?",
    "opt1": "Rigid rules and uniform answers",
    "opt2": "Standardized testing only",
    "opt3": "Open-ended projects and exploration",
    "opt4": "Fixed content delivery",
    "correct": 3
  },
  {
    "question": "Digital literacy in the 21st-century classroom means:",
    "opt1": "Avoiding screen time",
    "opt2": "Memorizing computer parts",
    "opt3": "Using technology effectively for learning",
    "opt4": "Learning typing skills only",
    "correct": 3
  },
  {
    "question": "One of the advantages of integrating ICT in classrooms is:",
    "opt1": "Increased dependence on the teacher",
    "opt2": "Promotion of learner autonomy",
    "opt3": "Less content availability",
    "opt4": "Obsolete instructional methods",
    "correct": 2
  },
  {
    "question": "The 4Cs of 21st-century learning include all EXCEPT:",
    "opt1": "Communication",
    "opt2": "Collaboration",
    "opt3": "Cramping",
    "opt4": "Creativity",
    "correct": 3
  },
  {
    "question": "Which of the following supports global competence among learners?",
    "opt1": "Ignoring multicultural perspectives",
    "opt2": "Rote learning",
    "opt3": "Exposure to diverse worldviews",
    "opt4": "Focus on local issues only",
    "correct": 3
  }
  ]


quests6 = [
  {
    "question": "Which of the following best defines anthropology?",
    "opt1": "The study of ancient texts and languages",
    "opt2": "The comparative, holistic study of humankind",
    "opt3": "The analysis of human genetic mutations",
    "opt4": "The examination of animal behavior",
    "correct": 2
  },
  {
    "question": "What is meant by the 'holistic' perspective in anthropology?",
    "opt1": "Focusing exclusively on biological aspects",
    "opt2": "Studying cultural, biological, linguistic, and archaeological facets together",
    "opt3": "Comparing only two societies at a time",
    "opt4": "Emphasizing material culture over beliefs",
    "correct": 2
  },
  {
    "question": "Anthropology’s comparative method involves:",
    "opt1": "Isolating a single cultural trait in one society",
    "opt2": "Comparing cultural phenomena across different societies",
    "opt3": "Studying evolutionary changes in a laboratory",
    "opt4": "Translating ancient manuscripts literally",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT one of anthropology’s four traditional subfields?",
    "opt1": "Cultural anthropology",
    "opt2": "Archaeology",
    "opt3": "Sociology",
    "opt4": "Linguistic anthropology",
    "correct": 3
  },
  {
    "question": "Cultural anthropology primarily focuses on:",
    "opt1": "Human biological evolution",
    "opt2": "Patterns of human behavior, belief, and social organization",
    "opt3": "The excavation of ancient sites",
    "opt4": "Animal communication systems",
    "correct": 2
  },
  {
    "question": "Archaeology as a subfield of anthropology is concerned with:",
    "opt1": "Living languages and their syntax",
    "opt2": "Material remains of past societies",
    "opt3": "Human skeletal variation",
    "opt4": "Modern social institutions",
    "correct": 2
  },
  {
    "question": "Biological (physical) anthropology includes the study of:",
    "opt1": "Artifacts and architectural remains",
    "opt2": "Primatology and human osteology",
    "opt3": "Folklore and myths",
    "opt4": "Linguistic structures",
    "correct": 2
  },
  {
    "question": "Linguistic anthropology investigates:",
    "opt1": "The evolution of human anatomy",
    "opt2": "Material culture patterns",
    "opt3": "Human communication and language use",
    "opt4": "Population genetics",
    "correct": 3
  },
  {
    "question": "Applied anthropology is best described as:",
    "opt1": "Theoretical speculation about early hominins",
    "opt2": "Using anthropological knowledge to solve real-world problems",
    "opt3": "Recording languages for preservation only",
    "opt4": "Conducting laboratory experiments on human cells",
    "correct": 2
  },
  {
    "question": "Ethnography primarily involves:",
    "opt1": "Statistical analysis of survey data",
    "opt2": "Long-term, immersive fieldwork and participant observation",
    "opt3": "Excavating burial sites",
    "opt4": "Comparing artifact typologies",
    "correct": 2
  },
  {
    "question": "What is the most fundamental characteristic of culture?",
    "opt1": "It is inherited biologically",
    "opt2": "It is static and unchanging",
    "opt3": "It is learned and shared",
    "opt4": "It exists only in modern societies",
    "correct": 3
  },
  {
    "question": "Which of the following is an example of a cultural symbol?",
    "opt1": "Blood type",
    "opt2": "National flag",
    "opt3": "DNA sequence",
    "opt4": "Muscle reflex",
    "correct": 2
  },
  {
    "question": "Cultural norms can best be described as:",
    "opt1": "Instinctive behaviors shared by animals",
    "opt2": "Genetic predispositions",
    "opt3": "Standards or rules about acceptable behavior",
    "opt4": "Scientific laws that apply globally",
    "correct": 3
  },
  {
    "question": "Which of the following statements is true about culture?",
    "opt1": "Culture is biologically transmitted",
    "opt2": "Culture is only found in industrial societies",
    "opt3": "Culture influences perception and behavior",
    "opt4": "Culture and society are the same thing",
    "correct": 3
  },
  {
    "question": "What term describes the tendency to view one's own culture as superior?",
    "opt1": "Cultural relativism",
    "opt2": "Ethnocentrism",
    "opt3": "Globalization",
    "opt4": "Acculturation",
    "correct": 2
  },
  {
    "question": "What does cultural relativism encourage us to do?",
    "opt1": "Judge other cultures by our own values",
    "opt2": "Ignore differences among societies",
    "opt3": "Evaluate cultures based on their own standards",
    "opt4": "Replace traditional values with Western values",
    "correct": 3
  },
  {
    "question": "Enculturation refers to:",
    "opt1": "Adapting to environmental changes",
    "opt2": "Learning one’s culture through growing up in it",
    "opt3": "Replacing one culture with another",
    "opt4": "The process of evolution",
    "correct": 2
  },
  {
    "question": "Which is NOT a function of culture?",
    "opt1": "Guiding behavior",
    "opt2": "Providing identity",
    "opt3": "Determining genetic traits",
    "opt4": "Establishing social norms",
    "correct": 3
  },
  {
    "question": "The idea that culture is integrated means:",
    "opt1": "All parts of culture operate independently",
    "opt2": "One cultural trait exists in isolation",
    "opt3": "Cultural elements are interrelated and affect each other",
    "opt4": "Culture resists change completely",
    "correct": 3
  },
  {
    "question": "Which of the following best demonstrates culture as adaptive?",
    "opt1": "Wearing thick clothing in cold climates",
    "opt2": "Sweating during exercise",
    "opt3": "Heart rate adjustment",
    "opt4": "Blinking in bright light",
    "correct": 1
  },
  {
    "question": "What is the primary method of data collection in anthropology fieldwork?",
    "opt1": "Television interviews",
    "opt2": "Online surveys",
    "opt3": "Participant observation",
    "opt4": "DNA sampling",
    "correct": 3
  },
  {
    "question": "Which term describes the long-term, immersive approach of living among a group to study their culture?",
    "opt1": "Content analysis",
    "opt2": "Participant observation",
    "opt3": "Secondary research",
    "opt4": "Controlled experiments",
    "correct": 2
  },
  {
    "question": "What is an ethnography?",
    "opt1": "A map of ancient ruins",
    "opt2": "A statistical analysis of human DNA",
    "opt3": "A written account of fieldwork and cultural description",
    "opt4": "A video documentary of a ceremony",
    "correct": 3
  },
  {
    "question": "Which of the following best defines informants in anthropology?",
    "opt1": "Government officials",
    "opt2": "People who supply personal data for experiments",
    "opt3": "Local individuals who help anthropologists understand their culture",
    "opt4": "Subjects of medical trials",
    "correct": 3
  },
  {
    "question": "Which is NOT a method commonly used in anthropological fieldwork?",
    "opt1": "Gene sequencing",
    "opt2": "Interviewing",
    "opt3": "Mapping",
    "opt4": "Genealogy",
    "correct": 1
  },
  {
    "question": "The reflexive approach in fieldwork emphasizes:",
    "opt1": "Staying objective and invisible",
    "opt2": "Ignoring personal biases",
    "opt3": "Considering the anthropologist’s own influence on research",
    "opt4": "Eliminating cultural context",
    "correct": 3
  },
  {
    "question": "What is a key ethical concern in anthropological research?",
    "opt1": "Securing funding",
    "opt2": "Maintaining objectivity at all costs",
    "opt3": "Protecting the dignity and rights of participants",
    "opt4": "Writing lengthy reports",
    "correct": 3
  },
  {
    "question": "Informed consent in fieldwork involves:",
    "opt1": "Getting participants to agree without telling them the purpose",
    "opt2": "Paying locals for their participation",
    "opt3": "Informing participants of their role and obtaining permission",
    "opt4": "Signing legal contracts",
    "correct": 3
  },
  {
    "question": "Anthropologists often keep detailed daily notes during fieldwork. These are called:",
    "opt1": "Field diaries",
    "opt2": "Testimonies",
    "opt3": "Reports",
    "opt4": "Scripts",
    "correct": 1
  },
  {
    "question": "Which skill is most crucial for successful fieldwork?",
    "opt1": "Translation",
    "opt2": "Cultural sensitivity",
    "opt3": "Photography",
    "opt4": "Cooking",
    "correct": 2
  },
  {
    "question": "A dialect is:",
    "opt1": "A separate language with its own alphabet",
    "opt2": "A regional or social variation of a language",
    "opt3": "An outdated version of speech",
    "opt4": "A mix of slang and formal words",
    "correct": 2
  },
  {
    "question": "Paralanguage includes all of the following EXCEPT:",
    "opt1": "Tone of voice",
    "opt2": "Pitch",
    "opt3": "Volume",
    "opt4": "Grammar rules",
    "correct": 4
  },
  {
    "question": "Kinesics is the study of:",
    "opt1": "Written communication",
    "opt2": "Body movement and gestures",
    "opt3": "Phonetic transcription",
    "opt4": "Language evolution",
    "correct": 2
  },
  {
    "question": "Which of the following is an example of proxemics?",
    "opt1": "The use of metaphor in poetry",
    "opt2": "Physical distance maintained during interaction",
    "opt3": "Language pronunciation errors",
    "opt4": "Written punctuation marks",
    "correct": 2
  },
  {
    "question": "What is a lexicon?",
    "opt1": "A book of grammar rules",
    "opt2": "The set of all morphemes in a culture",
    "opt3": "The vocabulary of a language",
    "opt4": "An index of body language cues",
    "correct": 3
  },
  {
    "question": "Syntax refers to:",
    "opt1": "The structure of bones in the mouth",
    "opt2": "Rules for arranging words in sentences",
    "opt3": "Language borrowing",
    "opt4": "The act of signing documents",
    "correct": 2
  },
  {
    "question": "Which field studies the structure of speech sounds?",
    "opt1": "Morphology",
    "opt2": "Semantics",
    "opt3": "Phonology",
    "opt4": "Symbolism",
    "correct": 3
  },
  {
    "question": "Which of the following can be considered a sociolinguistic study?",
    "opt1": "Analyzing ancient fossils",
    "opt2": "Measuring bones for speech capacity",
    "opt3": "Studying language use in social contexts",
    "opt4": "Studying monkey calls",
    "correct": 3
  },
  {
    "question": "Which is a key reason anthropologists value endangered languages?",
    "opt1": "They provide new economic opportunities",
    "opt2": "They are grammatically simpler",
    "opt3": "They preserve unique worldviews and knowledge",
    "opt4": "They replace dominant languages",
    "correct": 3
  },
  {
    "question": "Language is considered a cultural resource because it:",
    "opt1": "Cannot be taught or learned",
    "opt2": "Is genetically determined",
    "opt3": "Expresses and reinforces cultural meanings",
    "opt4": "Functions like biological inheritance",
    "correct": 3
  },
  {
    "question": "Which method is most often used to date fossils?",
    "opt1": "Oral tradition",
    "opt2": "Carbon-14 dating",
    "opt3": "X-ray photography",
    "opt4": "Thermal imaging",
    "correct": 2
  },
  {
    "question": "Which of the following is considered a hominin trait?",
    "opt1": "Knuckle-walking",
    "opt2": "Bipedalism",
    "opt3": "Sharp canine teeth",
    "opt4": "Quadrupedal motion",
    "correct": 2
  },
  {
    "question": "What is the significance of the foramen magnum position in human evolution?",
    "opt1": "It indicates diet preference",
    "opt2": "It shows vocal range",
    "opt3": "It reflects upright posture",
    "opt4": "It relates to brain size",
    "correct": 3
  },
  {
    "question": "Which of these species is considered the earliest known hominin?",
    "opt1": "Homo erectus",
    "opt2": "Australopithecus afarensis",
    "opt3": "Sahelanthropus tchadensis",
    "opt4": "Neanderthalensis",
    "correct": 3
  },
  {
    "question": "Australopithecus afarensis is best known from the fossil skeleton nicknamed:",
    "opt1": "Tom",
    "opt2": "Lucy",
    "opt3": "Ardi",
    "opt4": "Koko",
    "correct": 2
  },
  {
    "question": "What is a defining feature of Homo habilis?",
    "opt1": "Use of written symbols",
    "opt2": "Creation of fire",
    "opt3": "Use of stone tools",
    "opt4": "Burial of the dead",
    "correct": 3
  },
  {
    "question": "Which hominin species is known for migrating out of Africa first?",
    "opt1": "Homo habilis",
    "opt2": "Homo erectus",
    "opt3": "Homo neanderthalensis",
    "opt4": "Homo sapiens",
    "correct": 2
  },
  {
    "question": "What does the term 'Oldowan tools' refer to?",
    "opt1": "Weapons used by early kings",
    "opt2": "The oldest bronze artifacts",
    "opt3": "Simple stone tools made by Homo habilis",
    "opt4": "Pottery used in rituals",
    "correct": 3
  },
  {
    "question": "Which of the following traits distinguish Homo sapiens from earlier hominins?",
    "opt1": "Bipedal locomotion",
    "opt2": "Larger brain and symbolic thought",
    "opt3": "Thick brow ridges",
    "opt4": "Knuckle-walking",
    "correct": 2
  },
  {
    "question": "Neanderthals are thought to have:",
    "opt1": "Evolved in Australia",
    "opt2": "Lacked social cooperation",
    "opt3": "Used complex tools and buried their dead",
    "opt4": "Used only basic hand gestures",
    "correct": 3
  },
  {
    "question": "The evolutionary process by which new species arise is known as:",
    "opt1": "Enculturation",
    "opt2": "Speciation",
    "opt3": "Domestication",
    "opt4": "Globalization",
    "correct": 2
  },


]



quests7 = [
  {
    "question": "What was the main assumption of early evolutionism in anthropology?",
    "opt1": "All societies are static",
    "opt2": "Societies progress through fixed stages from 'primitive' to 'civilized'",
    "opt3": "Each culture is unique and incomparable",
    "opt4": "Human behavior is biologically determined",
    "correct": 2
  },
  {
    "question": "Who is associated with the development of cultural functionalism?",
    "opt1": "Franz Boas",
    "opt2": "E.B. Tylor",
    "opt3": "Bronisław Malinowski",
    "opt4": "Margaret Mead",
    "correct": 3
  },
  {
    "question": "Which of the following best describes Franz Boas' contribution to anthropology?",
    "opt1": "Support for racial classification",
    "opt2": "Promotion of unilineal evolution",
    "opt3": "Development of historical particularism",
    "opt4": "Belief in biological determinism",
    "correct": 3
  },
  {
    "question": "Structural functionalism views society as:",
    "opt1": "A collection of isolated individuals",
    "opt2": "A chaotic system",
    "opt3": "An integrated whole where parts serve social needs",
    "opt4": "A place without shared values",
    "correct": 3
  },
  {
    "question": "Which school of thought emphasizes the role of symbols in constructing meaning?",
    "opt1": "Cultural materialism",
    "opt2": "Symbolic anthropology",
    "opt3": "Neo-evolutionism",
    "opt4": "Functionalism",
    "correct": 2
  },
  {
    "question": "What is the main idea behind cultural materialism?",
    "opt1": "Religion is the primary driver of society",
    "opt2": "Material conditions determine social organization and ideology",
    "opt3": "Cultures evolve independently of environment",
    "opt4": "History has no influence on culture",
    "correct": 2
  },
  {
    "question": "Postmodernism in anthropology is characterized by:",
    "opt1": "Objectivity and grand theories",
    "opt2": "Rejecting ethnographic subjectivity",
    "opt3": "Questioning authority, objectivity, and the possibility of a single truth",
    "opt4": "Strict scientific quantification",
    "correct": 3
  },
  {
    "question": "Which theory emphasizes the dynamic interplay of power, inequality, and resistance in cultures?",
    "opt1": "Evolutionism",
    "opt2": "Structural functionalism",
    "opt3": "Conflict theory",
    "opt4": "Cultural relativism",
    "correct": 3
  },
  {
    "question": "Clifford Geertz is most associated with which anthropological perspective?",
    "opt1": "Cultural ecology",
    "opt2": "Interpretive anthropology",
    "opt3": "Neofunctionalism",
    "opt4": "Social Darwinism",
    "correct": 2
  },
  {
    "question": "Which theoretical approach critiques the neutrality of the researcher and emphasizes reflexivity?",
    "opt1": "Symbolic anthropology",
    "opt2": "Functionalism",
    "opt3": "Postmodernism",
    "opt4": "Cultural evolutionism",
    "correct": 3
  },
  {
    "question": "What is the primary critique of the biological concept of race in anthropology?",
    "opt1": "It accurately reflects human genetic diversity",
    "opt2": "It is based on clear, scientific classifications",
    "opt3": "It oversimplifies and distorts the complex reality of human variation",
    "opt4": "It is the only way to study human ancestry",
    "correct": 3
  },
  {
    "question": "Which factor best explains the physical differences observed among human populations?",
    "opt1": "Cultural rituals",
    "opt2": "Environmental adaptations over generations",
    "opt3": "Differences in intelligence",
    "opt4": "Language barriers",
    "correct": 2
  },
  {
    "question": "What does clinal variation in human biology refer to?",
    "opt1": "Sharp divisions between racial groups",
    "opt2": "Random mutations in DNA",
    "opt3": "Gradual changes in traits across geographic regions",
    "opt4": "Changes that follow national borders",
    "correct": 3
  },
  {
    "question": "Which of the following best represents an example of social construction of race?",
    "opt1": "Genetic differences in blood types",
    "opt2": "Classifying people based on perceived skin color and ancestry",
    "opt3": "Measuring height in children",
    "opt4": "Analyzing fingerprint patterns",
    "correct": 2
  },
  {
    "question": "How does anthropology understand the concept of race today?",
    "opt1": "As a valid biological classification",
    "opt2": "As a purely medical category",
    "opt3": "As a cultural and social concept with real consequences",
    "opt4": "As irrelevant to social life",
    "correct": 3
  },
  {
    "question": "Which statement reflects the current scientific consensus on race and genetics?",
    "opt1": "There are distinct racial gene pools",
    "opt2": "Most genetic variation exists between races",
    "opt3": "Race is a useful category for understanding genetic differences",
    "opt4": "There is more genetic variation within so-called races than between them",
    "correct": 4
  },
  {
    "question": "Which practice historically reinforced racial classification systems?",
    "opt1": "Multicultural education",
    "opt2": "Colonialism and slavery",
    "opt3": "Ethnographic fieldwork",
    "opt4": "Genetic counseling",
    "correct": 2
  },
  {
    "question": "Which term describes the belief that some races are inherently superior to others?",
    "opt1": "Racism",
    "opt2": "Clinalism",
    "opt3": "Biological essentialism",
    "opt4": "Cultural relativism",
    "correct": 1
  },
  {
    "question": "How does anthropology contribute to the fight against racism?",
    "opt1": "By proving cultural supremacy of some groups",
    "opt2": "By promoting eugenics",
    "opt3": "By showing that race is a cultural idea, not a biological reality",
    "opt4": "By restricting interracial interactions",
    "correct": 3
  },
  {
    "question": "Which of the following best illustrates institutional racism?",
    "opt1": "A personal insult based on race",
    "opt2": "Government policies that disadvantage certain racial groups",
    "opt3": "A one-time incident of racial bias",
    "opt4": "Genetic similarities across populations",
    "correct": 2
  },
  {
    "question": "What is the basic function of kinship in most societies?",
    "opt1": "To enforce religious beliefs",
    "opt2": "To determine social roles, rights, and obligations",
    "opt3": "To divide people by wealth",
    "opt4": "To eliminate marriage customs",
    "correct": 2
  },
  {
    "question": "What term describes a family that includes parents, children, and other relatives?",
    "opt1": "Nuclear family",
    "opt2": "Extended family",
    "opt3": "Isolated family",
    "opt4": "Sibling family",
    "correct": 2
  },
  {
    "question": "Which type of descent traces lineage through the mother’s line only?",
    "opt1": "Patrilineal descent",
    "opt2": "Bilineal descent",
    "opt3": "Matrilineal descent",
    "opt4": "Neolocal descent",
    "correct": 3
  },
  {
    "question": "What is endogamy?",
    "opt1": "Marriage outside the social group",
    "opt2": "Prohibition of all marriage",
    "opt3": "Marriage within a specific social or cultural group",
    "opt4": "Marriage between enemies",
    "correct": 3
  },
  {
    "question": "Polygyny refers to a marriage system where:",
    "opt1": "One man marries one woman",
    "opt2": "One woman marries multiple men",
    "opt3": "One man marries multiple women",
    "opt4": "All individuals marry each other equally",
    "correct": 3
  },
  {
    "question": "Which marriage practice involves the husband's family providing resources to the wife's family?",
    "opt1": "Bride service",
    "opt2": "Dowry",
    "opt3": "Bridewealth",
    "opt4": "Matriarchal exchange",
    "correct": 3
  },
  {
    "question": "Which term best describes post-marital residence with the husband's family?",
    "opt1": "Neolocal",
    "opt2": "Matrilocal",
    "opt3": "Avunculocal",
    "opt4": "Patrilocal",
    "correct": 4
  },
  {
    "question": "A clan differs from a lineage in that:",
    "opt1": "A clan has no known common ancestor",
    "opt2": "A clan is smaller and tightly knit",
    "opt3": "Lineages trace descent through both sides equally",
    "opt4": "Lineages do not affect inheritance",
    "correct": 1
  },
  {
    "question": "Which of the following is a function of marriage in most cultures?",
    "opt1": "Limiting human reproduction",
    "opt2": "Establishing legal paternity and family alliances",
    "opt3": "Promoting isolation",
    "opt4": "Preventing economic exchanges",
    "correct": 2
  },
  {
    "question": "Which family type is most associated with industrial societies?",
    "opt1": "Extended family",
    "opt2": "Patrilineal family",
    "opt3": "Nuclear family",
    "opt4": "Fraternal family",
    "correct": 3
  },
  {
    "question": "What distinguishes ethnographic fieldwork from other research methods in anthropology?",
    "opt1": "It relies entirely on surveys",
    "opt2": "It involves immersive, long-term observation of a cultural group",
    "opt3": "It avoids human subjects entirely",
    "opt4": "It is performed in laboratories",
    "correct": 2
  },
  {
    "question": "Which method best supports the anthropologist's goal of understanding insider perspectives?",
    "opt1": "Random sampling",
    "opt2": "Participant observation",
    "opt3": "Content analysis",
    "opt4": "Aerial photography",
    "correct": 2
  },
  {
    "question": "What is the key purpose of using interviews in ethnographic research?",
    "opt1": "To test medical hypotheses",
    "opt2": "To obtain local meanings, narratives, and interpretations",
    "opt3": "To identify bone structures",
    "opt4": "To record government data",
    "correct": 2
  },
  {
    "question": "Why is reflexivity important in cultural anthropology research?",
    "opt1": "It minimizes fieldwork time",
    "opt2": "It enhances statistical analysis",
    "opt3": "It helps researchers recognize their own influence on data",
    "opt4": "It ensures legal compliance",
    "correct": 3
  },
  {
    "question": "A ‘gatekeeper’ in field research refers to:",
    "opt1": "An official who denies access to researchers",
    "opt2": "A data analyst who processes findings",
    "opt3": "A local individual who facilitates community access for the researcher",
    "opt4": "A person who funds the research",
    "correct": 3
  },
  {
    "question": "Which of the following is a quantitative method in anthropology?",
    "opt1": "Mapping kinship systems",
    "opt2": "Recording oral histories",
    "opt3": "Counting the frequency of rituals",
    "opt4": "Writing ethnographic narratives",
    "correct": 3
  },
  {
    "question": "Which ethical responsibility must always be observed in anthropological research?",
    "opt1": "Publication in top journals",
    "opt2": "Informed consent from participants",
    "opt3": "Approval by politicians",
    "opt4": "Avoiding controversial topics",
    "correct": 2
  },
  {
    "question": "The term 'emic' perspective refers to:",
    "opt1": "The anthropologist's analytical viewpoint",
    "opt2": "An external observer’s view",
    "opt3": "The insider’s view and cultural understanding",
    "opt4": "The laboratory-based interpretation",
    "correct": 3
  },
  {
    "question": "Which of the following best exemplifies triangulation in fieldwork?",
    "opt1": "Using one method to validate data",
    "opt2": "Combining interviews, surveys, and observation for confirmation",
    "opt3": "Ignoring conflicting data sources",
    "opt4": "Calculating mean scores only",
    "correct": 2
  },
  {
    "question": "Why do anthropologists conduct genealogical studies?",
    "opt1": "To study DNA sequencing",
    "opt2": "To map power grids",
    "opt3": "To understand kinship systems and inheritance patterns",
    "opt4": "To determine IQ scores",
    "correct": 3
  },
  {
    "question": "What is the significance of bipedalism in human evolution?",
    "opt1": "It allowed for faster tree climbing",
    "opt2": "It enabled use of the mouth for carrying food",
    "opt3": "It freed the hands for tool use and environmental manipulation",
    "opt4": "It enhanced tail movement",
    "correct": 3
  },
  {
    "question": "Which hominin species is most directly associated with the first known use of stone tools?",
    "opt1": "Homo habilis",
    "opt2": "Australopithecus afarensis",
    "opt3": "Neanderthals",
    "opt4": "Homo sapiens sapiens",
    "correct": 1
  },
  {
    "question": "What does the term 'hominin' refer to?",
    "opt1": "Any extinct species of monkey",
    "opt2": "Modern humans and their immediate fossil ancestors",
    "opt3": "All great apes",
    "opt4": "Only Neanderthals",
    "correct": 2
  },
  {
    "question": "Which anatomical change is closely linked to speech development in humans?",
    "opt1": "Opposable thumbs",
    "opt2": "Expanded cranial capacity and descended larynx",
    "opt3": "Elongated arms",
    "opt4": "Shortened legs",
    "correct": 2
  },
  {
    "question": "What does the 'Out of Africa' model of human origins propose?",
    "opt1": "Humans originated in Europe",
    "opt2": "Humans evolved simultaneously on different continents",
    "opt3": "Homo sapiens evolved in Africa and then migrated globally",
    "opt4": "Homo sapiens interbred with chimpanzees",
    "correct": 3
  },
  {
    "question": "Why is the fossil record considered incomplete?",
    "opt1": "Because fossils decay too quickly",
    "opt2": "Because all fossils are too damaged to study",
    "opt3": "Because fossilization is rare and depends on specific conditions",
    "opt4": "Because anthropology avoids studying bones",
    "correct": 3
  },
  {
    "question": "What key evidence supports the idea that Neanderthals had symbolic thought?",
    "opt1": "Their skeletal structure",
    "opt2": "Their tools were simpler than those of Homo sapiens",
    "opt3": "They buried their dead with grave goods",
    "opt4": "They could not speak",
    "correct": 3
  },
  {
    "question": "Which species is thought to be the first to control fire?",
    "opt1": "Homo erectus",
    "opt2": "Australopithecus robustus",
    "opt3": "Homo sapiens",
    "opt4": "Paranthropus boisei",
    "correct": 1
  },
  {
    "question": "Which of the following best illustrates a behavioral adaptation in early hominins?",
    "opt1": "Development of thick fur",
    "opt2": "Creation of stone tools for hunting and defense",
    "opt3": "Elongated canine teeth",
    "opt4": "Nesting in trees",
    "correct": 2
  },
  {
    "question": "Genetic studies of mitochondrial DNA suggest that:",
    "opt1": "Humans evolved from chimpanzees directly",
    "opt2": "All modern humans share a common ancestor from Africa",
    "opt3": "Neanderthals and Homo sapiens are unrelated",
    "opt4": "Genetics has no role in human evolution",
    "correct": 2
  },
  {
    "question": "How does culture influence the biological functioning of humans?",
    "opt1": "By altering genetic inheritance",
    "opt2": "By shaping diet, behavior, and exposure to environments",
    "opt3": "Through DNA manipulation",
    "opt4": "By reducing the need for evolution",
    "correct": 2
  },
  {
    "question": "Which of the following statements best illustrates the dynamic nature of culture?",
    "opt1": "Culture is entirely inherited from parents",
    "opt2": "Culture remains unchanged across generations",
    "opt3": "Cultural practices evolve in response to internal and external factors",
    "opt4": "Only primitive cultures change with time",
    "correct": 3
  },
  {
    "question": "Which of the following best shows how culture is shared?",
    "opt1": "A solitary person creating a ritual",
    "opt2": "An invention passed silently through observation",
    "opt3": "Members of a society collectively performing a festival",
    "opt4": "An individual dreaming of ancestors",
    "correct": 3
  },
  {
    "question": "Which scenario best demonstrates cultural adaptation?",
    "opt1": "A baby learning to crawl",
    "opt2": "A community designing stilt houses in flood-prone areas",
    "opt3": "People genetically developing darker skin in sunny regions",
    "opt4": "A tiger adjusting to seasonal changes",
    "correct": 2
  },
  {
    "question": "In what way is culture considered symbolic?",
    "opt1": "Because it is genetically coded",
    "opt2": "Because its meanings depend on biological processes",
    "opt3": "Because humans assign arbitrary meaning to objects and behaviors",
    "opt4": "Because it is strictly rational and mathematical",
    "correct": 3
  },
  {
    "question": "Why is the concept of cultural integration important to anthropologists?",
    "opt1": "To isolate individual cultural traits",
    "opt2": "To understand how one cultural aspect affects others",
    "opt3": "To avoid comparative studies",
    "opt4": "To promote ethnocentrism",
    "correct": 2
  },
  {
    "question": "Which of the following can best explain cultural diversity?",
    "opt1": "Genetic mutations",
    "opt2": "Isolation, historical experiences, and environmental differences",
    "opt3": "Uniform global education",
    "opt4": "Biological uniformity",
    "correct": 2
  },
  {
    "question": "Why is culture considered uniquely human?",
    "opt1": "Because only humans learn through observation",
    "opt2": "Because only humans use tools",
    "opt3": "Because it involves complex systems of symbols and shared meanings",
    "opt4": "Because it evolves biologically",
    "correct": 3
  },
  {
    "question": "What does it mean that culture is 'superorganic'?",
    "opt1": "It is a living organism",
    "opt2": "It transcends individual behavior and exists as a collective reality",
    "opt3": "It is made up entirely of physical structures",
    "opt4": "It can be consumed or digested",
    "correct": 2
  },
  {
    "question": "How does cultural knowledge influence perception?",
    "opt1": "It blinds individuals to their surroundings",
    "opt2": "It forces uniform interpretations globally",
    "opt3": "It shapes how individuals interpret reality and interact with their world",
    "opt4": "It removes individual agency",
    "correct": 3
  }
]





quests8 = [
    { "question": "What is the molar mass of sodium hydrogen carbonate (NaHCO<sub>3</sub>)?", "opt1": "84 g/mol", "opt2": "100 g/mol", "opt3": "76 g/mol", "opt4": "68 g/mol", "correct": 1 },
  { "question": "In the reaction between NaHCO<sub>3</sub> and HCl, which gas is released?", "opt1": "Oxygen", "opt2": "Nitrogen", "opt3": "Carbon dioxide", "opt4": "Hydrogen", "correct": 3 },
  { "question": "What is the concentration of HCl solution used in the first question?", "opt1": "0.128 M", "opt2": "0.6441 M", "opt3": "0.190 M", "opt4": "0.250 M", "correct": 3 },
  { "question": "The volume of NaOH used in the titration of excess HCl is:", "opt1": "47.1 mL", "opt2": "53.07 mL", "opt3": "50.0 mL", "opt4": "25.0 mL", "correct": 1 },
  { "question": "What is the balanced equation for the reaction of NaHCO<sub>3</sub> with HCl?", "opt1": "NaHCO<sub>3</sub> + HCl → NaCl + H<sub>2</sub>CO<sub>3</sub>", "opt2": "NaHCO<sub>3</sub> + HCl → NaCl + H<sub>2</sub>O + CO<sub>2</sub>", "opt3": "NaHCO<sub>3</sub> + H<sub>2</sub>O → NaOH + CO<sub>2</sub>", "opt4": "NaHCO<sub>3</sub> → NaOH + H<sub>2</sub>O + CO<sub>2</sub>", "correct": 2 },
  { "question": "What is the primary function of NaOH in the titration of HCl?", "opt1": "Oxidation", "opt2": "Neutralization", "opt3": "Precipitation", "opt4": "Reduction", "correct": 2 },
  { "question": "How many moles of NaOH are present in 47.1 mL of 0.128 M solution?", "opt1": "0.0603 mol", "opt2": "0.00603 mol", "opt3": "0.602 mol", "opt4": "0.603 mol", "correct": 2 },
  { "question": "What type of acid is H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "Monoprotic", "opt2": "Diprotic", "opt3": "Triprotic", "opt4": "Polyprotic", "correct": 3 },
  { "question": "What is the molarity of NaOH solution used in the titration of H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "0.128 M", "opt2": "0.6441 M", "opt3": "0.190 M", "opt4": "0.250 M", "correct": 2 },
  { "question": "What is the oxidation state of arsenic in H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "+3", "opt2": "+5", "opt3": "+4", "opt4": "+1", "correct": 2 },
  { "question": "Which of the following has the highest entropy at 25°C?", "opt1": "Ne(g)", "opt2": "NaCl(s)", "opt3": "H<sub>2</sub>(g)", "opt4": "SO<sub>2</sub>(g)", "correct": 4 },
  { "question": "Which of the following processes has a positive entropy change?", "opt1": "2H<sub>2</sub>(g) → 2H<sub>2</sub>(l)", "opt2": "C(s) + O<sub>2</sub>(g) → CO<sub>2</sub>(g)", "opt3": "NaCl(s) → NaCl(aq)", "opt4": "2H<sub>2</sub>O(l) → 2H<sub>2</sub>(g) + O<sub>2</sub>(g)", "correct": 4 },
  { "question": "What is the half-life of phosphorus-32?", "opt1": "14.3 days", "opt2": "32.0 days", "opt3": "72 hours", "opt4": "2.69 days", "correct": 1 },
  { "question": "What is the atomic mass of gold (Au-198) used in the decay calculation?", "opt1": "198 amu", "opt2": "197 amu", "opt3": "200 amu", "opt4": "195 amu", "correct": 1 },
  { "question": "Which element is used as a radioactive tracer in the body for cancer treatment?", "opt1": "Gold-198", "opt2": "Phosphorus-32", "opt3": "Iodine-131", "opt4": "Cobalt-60", "correct": 3 },
  { "question": "What type of reaction occurs between H<sub>3</sub>AsO<sub>4</sub> and NaOH?", "opt1": "Acid-base", "opt2": "Redox", "opt3": "Precipitation", "opt4": "Decomposition", "correct": 1 },
  { "question": "How many moles of NaOH are needed to neutralize one mole of H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "1", "opt2": "2", "opt3": "3", "opt4": "4", "correct": 3 },
  { "question": "What is the gas produced when NaHCO<sub>3</sub> reacts with HCl?", "opt1": "Oxygen", "opt2": "Carbon dioxide", "opt3": "Hydrogen", "opt4": "Nitrogen", "correct": 2 },
  { "question": "Which of the following has the lowest entropy at 25°C?", "opt1": "Ne(g)", "opt2": "NaCl(s)", "opt3": "SO<sub>2</sub>(g)", "opt4": "H<sub>2</sub>(g)", "correct": 2 },
  { "question": "The purpose of adding NaOH in the titration of H<sub>3</sub>AsO<sub>4</sub> is to:", "opt1": "Increase acidity", "opt2": "Neutralize the acid", "opt3": "Produce a precipitate", "opt4": "Remove water", "correct": 2 },
  { "question": "What is the charge on the arsenic ion in H<sub>3</sub>AsO<sub>4</sub>?", "opt1": "-3", "opt2": "+3", "opt3": "+5", "opt4": "+1", "correct": 3 },
  { "question": "What is the function of the NaHCO<sub>3</sub> in the antacid?", "opt1": "Increases acidity", "opt2": "Acts as a buffer", "opt3": "Produces gas", "opt4": "Oxidizes acids", "correct": 2 },
  { "question": "Which of the following is a strong acid?", "opt1": "H<sub>3</sub>AsO<sub>4</sub>", "opt2": "HCl", "opt3": "NaHCO<sub>3</sub>", "opt4": "H<sub>2</sub>O", "correct": 2 },
  { "question": "In the titration of H<sub>3</sub>AsO<sub>4</sub>, the endpoint is determined by:", "opt1": "Color change", "opt2": "Gas release", "opt3": "Temperature rise", "opt4": "pH change", "correct": 4 },
  { "question": "What is the unit of molarity?", "opt1": "mol/g", "opt2": "g/mol", "opt3": "mol/L", "opt4": "g/L", "correct": 3 },
  {
    "question": "Radioactivity was discovered by which of the following scientists?",
    "opt1": "Marie Curie",
    "opt2": "Henri Becquerel",
    "opt3": "Ernest Rutherford",
    "opt4": "Niels Bohr",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a type of radioactive decay?",
    "opt1": "Alpha decay",
    "opt2": "Beta decay",
    "opt3": "Gamma decay",
    "opt4": "Proton decay",
    "correct": 4
  },
  {
    "question": "Alpha particles consist of:",
    "opt1": "Two protons and two neutrons",
    "opt2": "Two electrons and two protons",
    "opt3": "One electron and one proton",
    "opt4": "One neutron and one proton",
    "correct": 1
  },
  {
    "question": "The number of protons or atomic number is reduced by 2 by which form of radioactive decay?",
    "opt1": "Alpha decay",
    "opt2": "Beta decay",
    "opt3": "Gamma decay",
    "opt4": "Proton decay",
    "correct": 1
  },
  {
    "question": "The SI unit of radioactivity is:",
    "opt1": "Curie",
    "opt2": "Rutherford",
    "opt3": "Becquerel",
    "opt4": "Roentgen",
    "correct": 3
  },
  {
    "question": "Radioactivity that takes the form of high energy electromagnetic waves would be:",
    "opt1": "Alpha",
    "opt2": "Beta",
    "opt3": "Gamma",
    "opt4": "Zeta",
    "correct": 3
  },
  {
    "question": "A beta particle is:",
    "opt1": "A helium nucleus",
    "opt2": "A high-energy electron",
    "opt3": "An electromagnetic wave",
    "opt4": "A hydrogen nucleus",
    "correct": 2
  },
  {
    "question": "Which of the following statements about gamma radiation is true?",
    "opt1": "It has no charge and no mass",
    "opt2": "It has a positive charge",
    "opt3": "It consists of fast-moving electrons",
    "opt4": "It is deflected by an electric field",
    "correct": 1
  },
  {
    "question": "The half-life of a radioactive substance is:",
    "opt1": "The time taken for half of its atoms to decay",
    "opt2": "The time taken for all atoms to decay",
    "opt3": "The time taken for double the atoms to decay",
    "opt4": "The time taken for the activity to increase",
    "correct": 1
  },
  {
    "question": "Which of the following materials is most effective in stopping gamma radiation?",
    "opt1": "Paper",
    "opt2": "Aluminum",
    "opt3": "Lead",
    "opt4": "Plastic",
    "correct": 3
  },
  {
    "question": "Which of the following elements is commonly used in nuclear reactors as a fuel?",
    "opt1": "Uranium<sub>235</sub>",
    "opt2": "Carbon",
    "opt3": "Radium<sub>226</sub>",
    "opt4": "Potassium<sub>40</sub>",
    "correct": 1
  },
  {
    "question": "Which radiation is deflected by an electric field?",
    "opt1": "Alpha and beta",
    "opt2": "Beta and gamma",
    "opt3": "Gamma only",
    "opt4": "Alpha only",
    "correct": 1
  },
  {
    "question": "The half-life of a radioactive substance is 5 hours. If you start with 80 grams, how much will remain after 10 hours?",
    "opt1": "40 g",
    "opt2": "20 g",
    "opt3": "10 g",
    "opt4": "5 g",
    "correct": 2
  },
  {
    "question": "A sample of a radioactive element has a decay constant of 0.001 s. What is its half-life?",
    "opt1": "693 s",
    "opt2": "500 s",
    "opt3": "1000 s",
    "opt4": "6930 s",
    "correct": 1
  },
  {
    "question": "The activity of a radioactive sample is initially 800 Bq. After two half-lives, what is its activity?",
    "opt1": "400 Bq",
    "opt2": "200 Bq",
    "opt3": "100 Bq",
    "opt4": "50 Bq",
    "correct": 2
  },
  {
    "question": "A radioactive isotope has a half-life of 56.6 days. What fraction of the isotope remains after 449 days?",
    "opt1": "3.2 x 10<sup>-3</sup>",
    "opt2": "1.00",
    "opt3": "0.92",
    "opt4": "4.1 x 10<sup>-2</sup>",
    "correct": 1
  },
  {
    "question": "If a radioactive isotope has a half-life of 3 days, what fraction of the original sample remains after 9 days?",
    "opt1": "1/2",
    "opt2": "1/4",
    "opt3": "1/8",
    "opt4": "1/16",
    "correct": 3
  },
  {
    "question": "A radioactive sample has an initial mass of 40g. After 16 days, only 2.5g remains. What is its half-life?",
    "opt1": "4 days",
    "opt2": "5 days",
    "opt3": "6 days",
    "opt4": "8 days",
    "correct": 1
  },

  {
    "question": "The elements of group 14, 15, 16, and 17 are ________.",
    "opt1": "d block elements",
    "opt2": "s block elements",
    "opt3": "p block elements",
    "opt4": "f block elements",
    "correct": 3
  },
  {
    "question": "The following are the factors that affect ionization energy except ________.",
    "opt1": "Size of atom",
    "opt2": "Energy level",
    "opt3": "Shielding effect",
    "opt4": "Atomic orbital",
    "correct": 4
  },
  {
    "question": "Which of the following quantum numbers does not determine the wave properties of an electron in an atom?",
    "opt1": "<i>n</i>",
    "opt2": "<i>l</i>",
    "opt3": "<i>m</i>",
    "opt4": "<i>s</i>",
    "correct": 4
  },
  {
    "question": "Calculate the wavelength of light emitted when a hydrogen atom changes from <i>n</i> = 5 to <i>n</i> = 3. (R = 1.0968 × 10<sup>7</sup> m<sup>−1</sup>)",
    "opt1": "1.3 × 10<sup>−6</sup> m",
    "opt2": "1.6 × 10<sup>−6</sup> m",
    "opt3": "4.7 × 10<sup>−6</sup> m",
    "opt4": "2.3 × 10<sup>−6</sup> m",
    "correct": 1,
    "workings": "Using Rydberg formula: 1/λ = R(1/n₁² − 1/n₂²) = 1.0968×10⁷(1/9 − 1/25) = 1.0968×10⁷(16/225) ≈ 7.618×10⁵ ⇒ λ ≈ 1.2821×10<sup>−6</sup> m"
  },
  {
    "question": "What are the number of protons, neutrons and electrons (Z = 34, A = 79) respectively in Se?",
    "opt1": "32, 34, 79",
    "opt2": "34, 45, 36",
    "opt3": "34, 45, 34",
    "opt4": "34, 45, 32",
    "correct": 3
  },
  {
    "question": "In which pair of elements do the nuclei of the atoms contain the same number of neutrons?",
    "opt1": "Li and Ba",
    "opt2": "N and O",
    "opt3": "Na and Mg",
    "opt4": "S and Be",
    "correct": 3
  },
  {
    "question": "The number of nuclear disintegrations per unit time occurring in a radioactive material is known as:",
    "opt1": "Scintillation source",
    "opt2": "Activity of a radioactive source",
    "opt3": "Activity curie source",
    "opt4": "Disintegration source",
    "correct": 2
  },
#   {
#     "question": "A radioactive source has a half-life of 80 s. How long will it take for 7/8 of the source to decay?",
#     "opt1": "10 s",
#     "opt2": "70 s",
#     "opt3": "240 s",
#     "opt4": "640 s",
#     "correct": 3,
#     "workings": "To decay to 1/8, 3 half-lives are needed: (1/2)<sup>3</sup> = 1/8 ⇒ 3 × 80 s = 240 s"
#   },
  {
    "question": "A gas expands and does 325 J of work on the surroundings while absorbing 127 J of heat. What is the change in energy of the gas?",
    "opt1": "−198 J",
    "opt2": "+198 J",
    "opt3": "−425 J",
    "opt4": "+521 J",
    "correct": 1,
    "workings": "ΔU = Q − W = 127 J − 325 J = −198 J"
  },
  {
    "question": "Which of these molecules has the largest bond angle?",
    "opt1": "H<sub>2</sub>O",
    "opt2": "CO<sub>2</sub>",
    "opt3": "NH<sub>3</sub>",
    "opt4": "CH<sub>4</sub>",
    "correct": 2
  },
  {
    "question": "Which of the reactions below does not form a precipitate?",
    "opt1": "KI + Pb(NO<sub>3</sub>)<sub>2</sub>",
    "opt2": "BaCl<sub>2</sub> + Na<sub>2</sub>SO<sub>4</sub>",
    "opt3": "NaCl + AgNO<sub>3</sub>",
    "opt4": "NaCl + Fe(NO<sub>3</sub>)<sub>3</sub>",
    "correct": 4
  },
  {
    "question": "Which statement is true for all the three types of radioactive emissions?",
    "opt1": "They are deflected by electric fields",
    "opt2": "They ionize gases",
    "opt3": "They are completely absorbed by a thin aluminum sheet",
    "opt4": "They emit light",
    "correct": 2
  },
  {
    "question": "A nuclide of plutonium has a mass number of 242 and atomic number 94. How many neutrons are in its nucleus?",
    "opt1": "242",
    "opt2": "336",
    "opt3": "148",
    "opt4": "94",
    "correct": 3,
    "workings": "Neutrons = Mass number − Atomic number = 242 − 94 = 148"
  },

  {
    "question": "Across the period ionization potential is likely to increase because of.....",
    "opt1": "shielding effect",
    "opt2": "increase in nuclear charge",
    "opt3": "decrease in nuclear charge",
    "opt4": "all the mentioned",
    "correct": 2
  },
  {
    "question": "How many moles of Carbon(IV) oxide are likely to be present in butane after combustion?",
    "opt1": "2",
    "opt2": "3",
    "opt3": "8",
    "opt4": "10",
    "correct": 3
  },
  {
    "question": "Which of the following contain both ionic and covalent bonds in the same compound?",
    "opt1": "BaCO<sub>3</sub>",
    "opt2": "MgCl<sub>2</sub>",
    "opt3": "BaO",
    "opt4": "H<sub>2</sub>S",
    "correct": 1
  },
  {
    "question": "Which of the following statements about hydrogen atom is false?",
    "opt1": "An electron in n = 1 level of the hydrogen atom is in its ground state",
    "opt2": "On average, an electron in the n = 3 level is farther from the nucleus than one in n = 1",
    "opt3": "The wavelength of light emitted when the electron goes from n = 3 to n = 1 is the same as when it goes from n = 1 to n = 3",
    "opt4": "An electron in n = 1 level is higher in energy than one in the n = 4 level",
    "correct": 4
  },
  {
    "question": "A 25.0 ml sample of hydrochloric acid (HCl) was titrated with 0.150 M NaOH. The burette reading shows that 30.0 ml of NaOH was required to reach the equivalence point. What is the molarity of the HCl solution?",
    "opt1": "0.167 M",
    "opt2": "0.14 M",
    "opt3": "0.18 M",
    "opt4": "0.22 M",
    "correct": 3
  },
  {
    "question": "How many ml of 0.200 M NaOH are required to completely neutralize 50.0 ml of 0.100 M H<sub>2</sub>SO<sub>4</sub>?",
    "opt1": "50 ml",
    "opt2": "40 ml",
    "opt3": "30 ml",
    "opt4": "20 ml",
    "correct": 1
  }
]

quests10 = [
  {
    "question": "According to C. Wright Mills, what best defines the 'Sociological Imagination'?",
    "opt1": "A talent for remembering facts",
    "opt2": "A critical awareness of the link between individuals and the wider society",
    "opt3": "The ability to memorize statistics",
    "opt4": "An intuitive understanding of emotions",
    "correct": 2
  },
  {
    "question": "Which of the following best describes sociology as a scientific discipline?",
    "opt1": "It relies on natural laws to explain human behavior",
    "opt2": "It uses systematic observation and critical analysis of human interactions",
    "opt3": "It focuses mainly on physical traits of individuals",
    "opt4": "It is based on religious and moral guidance",
    "correct": 2
  },
  {
    "question": "Which of the following perspectives categorizes sociology based on current societal problems and issues?",
    "opt1": "Historical Perspective",
    "opt2": "Empirical Perspective",
    "opt3": "Analytical Perspective",
    "opt4": "Comparative Perspective",
    "correct": 2
  },
  {
    "question": "What did Auguste Comte refer to sociology as in the hierarchy of sciences?",
    "opt1": "A social experiment",
    "opt2": "The lowest science",
    "opt3": "The queen of sciences",
    "opt4": "A religious discipline",
    "correct": 3
  },
  {
    "question": "Herbert Spencer believed that social evolution occurs through:",
    "opt1": "Scientific experiments",
    "opt2": "Religious teachings",
    "opt3": "The survival of the fittest",
    "opt4": "Social planning by elites",
    "correct": 3
  },
  {
    "question": "What is the term Emile Durkheim used to refer to external societal forces that influence individual behavior?",
    "opt1": "Social norms",
    "opt2": "Social structure",
    "opt3": "Social facts",
    "opt4": "Group behavior",
    "correct": 3
  },
  {
    "question": "Max Weber's concept of 'Verstehen' emphasizes:",
    "opt1": "Statistical analysis of behavior",
    "opt2": "Economic productivity",
    "opt3": "Interpretive understanding of social actions",
    "opt4": "Literal interpretation of laws",
    "correct": 3
  },
  {
    "question": "What did Karl Marx identify as the main source of conflict in capitalist societies?",
    "opt1": "Religious differences",
    "opt2": "Family disagreements",
    "opt3": "Class struggle between the proletariat and the bourgeoisie",
    "opt4": "Political elections",
    "correct": 3
  },
  {
    "question": "Which sociological perspective views society as a stable and well-integrated system?",
    "opt1": "Conflict Perspective",
    "opt2": "Feminist Perspective",
    "opt3": "Functionalist Perspective",
    "opt4": "Interactionist Perspective",
    "correct": 3
  },
  {
    "question": "Robert Merton’s distinction between manifest and latent functions refers to:",
    "opt1": "Primary and secondary education",
    "opt2": "Expected and unexpected social outcomes",
    "opt3": "Traditional and modern cultures",
    "opt4": "Urban and rural life",
    "correct": 2
  },
  {
    "question": "Which sociologist is credited with founding the interactionist perspective?",
    "opt1": "Talcott Parsons",
    "opt2": "Herbert Spencer",
    "opt3": "George Herbert Mead",
    "opt4": "Robert Merton",
    "correct": 3
  },
  {
    "question": "In the context of socialization, the 'looking-glass self' was developed by:",
    "opt1": "Jean Piaget",
    "opt2": "Sigmund Freud",
    "opt3": "Erving Goffman",
    "opt4": "Charles Horton Cooley",
    "correct": 4
  },
  {
    "question": "Which of the following best defines a social institution?",
    "opt1": "A place for religious activities",
    "opt2": "A patterned and organized set of roles and norms focused on social needs",
    "opt3": "A symbolic interaction",
    "opt4": "A family unit only",
    "correct": 2
  },
  {
    "question": "Talcott Parsons' concept of 'social system' is based on:",
    "opt1": "Conflict theory",
    "opt2": "Religious unity",
    "opt3": "Interdependence of social parts for stability",
    "opt4": "Military governance",
    "correct": 3
  },
  {
    "question": "Which term refers to expectations attached to a social position?",
    "opt1": "Status",
    "opt2": "Role",
    "opt3": "Culture",
    "opt4": "Norm",
    "correct": 2
  },
  {
    "question": "What is meant by 'achieved status'?",
    "opt1": "A status inherited at birth",
    "opt2": "A social position gained through personal effort",
    "opt3": "An unchangeable identity",
    "opt4": "A biological position",
    "correct": 2
  },
  {
    "question": "Cultural acculturation occurs when:",
    "opt1": "A person lives in isolation",
    "opt2": "Two cultures interact and influence each other",
    "opt3": "People are born into a culture",
    "opt4": "Socialization fails",
    "correct": 2
  },
  {
    "question": "According to the conflict perspective, social order is maintained through:",
    "opt1": "Consensus and cooperation",
    "opt2": "Symbolic communication",
    "opt3": "Force and coercion by dominant groups",
    "opt4": "Religious beliefs",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT an agent of socialization?",
    "opt1": "Family",
    "opt2": "Peer group",
    "opt3": "Climate",
    "opt4": "Mass media",
    "correct": 3
  },
  {
    "question": "Which sociological theory focuses on small-scale, face-to-face interactions?",
    "opt1": "Functionalism",
    "opt2": "Conflict theory",
    "opt3": "Interactionism",
    "opt4": "Systems theory",
    "correct": 3
  },
  {
    "question": "Which theorist pioneered the concept of 'bureaucracy' as an ideal type?",
    "opt1": "Marx",
    "opt2": "Spencer",
    "opt3": "Weber",
    "opt4": "Freud",
    "correct": 3
  },
  {
    "question": "A series of social relationships linking an individual to others is called a:",
    "opt1": "Social structure",
    "opt2": "Social class",
    "opt3": "Social network",
    "opt4": "Social institution",
    "correct": 3
  },
  {
    "question": "What does 'socialization' primarily aim to achieve?",
    "opt1": "Assign individuals to political groups",
    "opt2": "Integrate individuals into social norms and values",
    "opt3": "Isolate individuals from society",
    "opt4": "Prepare individuals for warfare",
    "correct": 2
  },
  {
    "question": "An individual's 'master status' is:",
    "opt1": "Always achieved by academic performance",
    "opt2": "A role learned in childhood",
    "opt3": "The most dominant status that shapes identity",
    "opt4": "A short-term role in childhood",
    "correct": 3
  },
  {
    "question": "Which of the following is true about the relationship between sociology and other social sciences?",
    "opt1": "They have completely separate topics of interest",
    "opt2": "They overlap significantly and often use interdisciplinary approaches",
    "opt3": "Sociology is unrelated to psychology",
    "opt4": "Anthropology uses completely different methods",
    "correct": 2
  },
  {
    "question": "What distinguishes the empirical perspective in sociology?",
    "opt1": "Study of the supernatural",
    "opt2": "Focus on ancient civilizations only",
    "opt3": "Use of current data and real-world observation",
    "opt4": "Relying solely on intuition",
    "correct": 3
  },
  {
    "question": "Which of the following is a key assumption of functionalist theory?",
    "opt1": "Social change is constant and unresolvable",
    "opt2": "Each part of society contributes to its stability",
    "opt3": "Society is inherently chaotic",
    "opt4": "Social behavior is driven by unconscious forces",
    "correct": 2
  },
  {
    "question": "Who argued that society should be studied using the same scientific rigor as natural sciences?",
    "opt1": "Herbert Spencer",
    "opt2": "Sigmund Freud",
    "opt3": "Auguste Comte",
    "opt4": "Talcott Parsons",
    "correct": 3
  },
  {
    "question": "Which perspective emphasizes that power is unequally distributed and used to maintain dominance?",
    "opt1": "Functionalism",
    "opt2": "Interactionism",
    "opt3": "Feminism",
    "opt4": "Conflict theory",
    "correct": 4
  }
]


quests11 = [
  {
    "question": "Which scholar argued that sociology must study social facts as 'things'?",
    "opt1": "Max Weber",
    "opt2": "Herbert Spencer",
    "opt3": "Emile Durkheim",
    "opt4": "Karl Marx",
    "correct": 3
  },
  {
    "question": "The distinction between mechanical and organic solidarity was made by:",
    "opt1": "Auguste Comte",
    "opt2": "Herbert Spencer",
    "opt3": "Talcott Parsons",
    "opt4": "Emile Durkheim",
    "correct": 4
  },
  {
    "question": "According to Talcott Parsons, a well-functioning society must meet which of the following functions?",
    "opt1": "GDP growth",
    "opt2": "Economic stratification",
    "opt3": "AGIL system functions",
    "opt4": "Legal accountability",
    "correct": 3
  },
  {
    "question": "Which sociologist introduced the concept of 'ideal type' as a tool of analysis?",
    "opt1": "Robert Merton",
    "opt2": "Karl Marx",
    "opt3": "Max Weber",
    "opt4": "George Mead",
    "correct": 3
  },
  {
    "question": "The conflict perspective in sociology is primarily associated with:",
    "opt1": "Herbert Spencer",
    "opt2": "Karl Marx",
    "opt3": "Erving Goffman",
    "opt4": "Jean Piaget",
    "correct": 2
  },
  {
    "question": "Which of the following perspectives would most likely analyze inequality in access to education?",
    "opt1": "Functionalism",
    "opt2": "Symbolic interactionism",
    "opt3": "Conflict theory",
    "opt4": "Phenomenology",
    "correct": 3
  },
  {
    "question": "Robert Merton’s idea of 'dysfunction' refers to:",
    "opt1": "Elements that maintain equilibrium",
    "opt2": "Social processes that disrupt society's stability",
    "opt3": "Criminal behaviors only",
    "opt4": "Roles played by elites",
    "correct": 2
  },
  {
    "question": "According to Mead, the self develops through:",
    "opt1": "Isolation and meditation",
    "opt2": "Genetic inheritance only",
    "opt3": "Interaction and understanding roles of others",
    "opt4": "Formal education alone",
    "correct": 3
  },
  {
    "question": "What is the concept used to describe the total way of life of a people?",
    "opt1": "Social structure",
    "opt2": "Status",
    "opt3": "Culture",
    "opt4": "Ethnocentrism",
    "correct": 3
  },
  {
    "question": "Which of the following best explains 'role conflict'?",
    "opt1": "When one person shares the same role with others",
    "opt2": "When a person fails to perform any role",
    "opt3": "When expectations from multiple statuses contradict",
    "opt4": "When cultural norms are ignored",
    "correct": 3
  },
  {
    "question": "A set of socially defined positions within a society is called:",
    "opt1": "Values",
    "opt2": "Roles",
    "opt3": "Status",
    "opt4": "Customs",
    "correct": 3
  },
  {
    "question": "Which term refers to rules and expectations for behavior associated with a social position?",
    "opt1": "Values",
    "opt2": "Norms",
    "opt3": "Roles",
    "opt4": "Sanctions",
    "correct": 3
  },
  {
    "question": "Which agent of socialization is responsible for teaching formal knowledge and discipline?",
    "opt1": "Peer groups",
    "opt2": "Family",
    "opt3": "Religious groups",
    "opt4": "School",
    "correct": 4
  },
  {
    "question": "What is a master status?",
    "opt1": "A role that is performed in secret",
    "opt2": "The most dominant status a person holds",
    "opt3": "A temporary social position",
    "opt4": "An inherited position with no effect on behavior",
    "correct": 2
  },
  {
    "question": "The feminist perspective in sociology focuses on:",
    "opt1": "The symbolic meaning of rituals",
    "opt2": "Power and gender inequality in social structures",
    "opt3": "The economic impact of globalization",
    "opt4": "Rural versus urban conflict",
    "correct": 2
  },
  {
    "question": "Cultural pluralism refers to:",
    "opt1": "A society with only one dominant culture",
    "opt2": "Complete assimilation of minority groups",
    "opt3": "Multiple cultural groups coexisting while retaining their distinctiveness",
    "opt4": "Forcing a uniform national identity",
    "correct": 3
  },
  {
    "question": "An example of a non-material culture is:",
    "opt1": "A mobile phone",
    "opt2": "A religious belief",
    "opt3": "A factory building",
    "opt4": "A school bus",
    "correct": 2
  },
  {
    "question": "Which perspective focuses on how individuals create meaning through interaction?",
    "opt1": "Conflict theory",
    "opt2": "Functionalism",
    "opt3": "Interactionism",
    "opt4": "Evolutionism",
    "correct": 3
  },
  {
    "question": "The concept of 'dramaturgical approach' sees individuals as:",
    "opt1": "Scientists experimenting in society",
    "opt2": "Performers projecting images in social interactions",
    "opt3": "Passive agents of culture",
    "opt4": "Victims of social rules",
    "correct": 2
  },
  {
    "question": "Which sociological concept explains how societies survive by fulfilling core tasks like preserving order and producing goods?",
    "opt1": "Conflict theory",
    "opt2": "Ethnocentrism",
    "opt3": "Social institutions",
    "opt4": "Cultural relativism",
    "correct": 3
  },
  {
    "question": "What central idea did Karl Marx contribute to the understanding of society?",
    "opt1": "Societies function best through religious institutions",
    "opt2": "Human societies are shaped by environmental forces",
    "opt3": "Social conflict arises from class struggles over economic resources",
    "opt4": "Society should be understood through symbols",
    "correct": 3
  },
  {
    "question": "Which of the following correctly defines 'ascribed status'?",
    "opt1": "A social position earned through merit",
    "opt2": "A role acquired from education",
    "opt3": "A status assigned involuntarily at birth or later in life",
    "opt4": "A temporary professional title",
    "correct": 3
  },
  {
    "question": "What does the concept of 'anomie' describe in Durkheim’s theory?",
    "opt1": "A society where religion dominates politics",
    "opt2": "A condition of normlessness and loss of direction in society",
    "opt3": "A state of gender balance",
    "opt4": "A peaceful transition of power",
    "correct": 2
  },
  {
    "question": "Which of the following best describes a social institution?",
    "opt1": "A group of friends sharing interests",
    "opt2": "A formal school building",
    "opt3": "A structured system addressing basic societal needs",
    "opt4": "An individual's self-concept",
    "correct": 3
  },
  {
    "question": "Which sociologist emphasized the power of 'social facts' as external and coercive forces?",
    "opt1": "Weber",
    "opt2": "Durkheim",
    "opt3": "Spencer",
    "opt4": "Mead",
    "correct": 2
  },
  {
    "question": "The interpretative perspective in sociology emphasizes:",
    "opt1": "Conflict between elite groups",
    "opt2": "Objective measurement of social phenomena",
    "opt3": "Subjective meaning individuals attach to social action",
    "opt4": "Military control of social roles",
    "correct": 3
  },
  {
    "question": "Which of the following is a dysfunction of cultural pluralism?",
    "opt1": "Promotion of ethnic creativity",
    "opt2": "Increase in collective bargaining",
    "opt3": "Enhanced cultural diversity",
    "opt4": "Difficulty forging national unity",
    "correct": 4
  },
  {
    "question": "The interactionist perspective sees society primarily through the lens of:",
    "opt1": "Historical development",
    "opt2": "Ongoing power struggles",
    "opt3": "Symbolic exchanges in everyday life",
    "opt4": "Religious indoctrination",
    "correct": 3
  },
  {
    "question": "What is 'ethnomethodology' concerned with?",
    "opt1": "Power and hierarchy",
    "opt2": "Large-scale social structures",
    "opt3": "Methods people use in everyday interactions",
    "opt4": "Analysis of economic systems",
    "correct": 3
  },
  {
    "question": "Which of these is an example of a manifest function of education?",
    "opt1": "Reinforcement of gender inequality",
    "opt2": "Building informal friendships",
    "opt3": "Transmission of knowledge and skills",
    "opt4": "Hidden promotion of social class gaps",
    "correct": 3
  },
  {
    "question": "How does the feminist perspective interpret society?",
    "opt1": "Through economic models",
    "opt2": "Through competition between ethnic groups",
    "opt3": "Through power relations and gender inequality",
    "opt4": "Through biological predispositions",
    "correct": 3
  },
]

quests12 = [
  {
    "question": "Which of the following best describes the fundamental nature of electric charge?",
    "opt1": "It is created whenever a magnetic field is present",
    "opt2": "It is conserved and exists in discrete quantities",
    "opt3": "It can be destroyed under intense radiation",
    "opt4": "It varies continuously in atoms",
    "correct": 2
  },
  {
    "question": "Which of the following materials is the best example of an electrical insulator?",
    "opt1": "Aluminum",
    "opt2": "Copper",
    "opt3": "Glass",
    "opt4": "Iron",
    "correct": 3
  },
  {
    "question": "Two point charges of +3μC and -2μC are separated by a distance of 0.6 m in vacuum. Calculate the magnitude of the electrostatic force between them (take k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>).",
    "opt1": "0.15 N",
    "opt2": "2.7 N",
    "opt3": "0.9 N",
    "opt4": "3.0 N",
    "correct": 1
  },
  {
    "question": "What happens when a positively charged rod is brought near the knob of a neutral electroscope without touching it?",
    "opt1": "The leaves collapse",
    "opt2": "The leaves diverge due to induced negative charge on the knob",
    "opt3": "The electroscope becomes positively charged",
    "opt4": "The knob discharges to ground",
    "correct": 2
  },
  {
    "question": "Coulomb’s law is valid only when:",
    "opt1": "Charges are moving relative to each other",
    "opt2": "Charges are large",
    "opt3": "Charges are stationary and spherically symmetric",
    "opt4": "Charges are placed in metal containers",
    "correct": 3
  },
  {
    "question": "What is the direction of the electric field at a point due to a positive point charge?",
    "opt1": "Circular",
    "opt2": "Radially outward",
    "opt3": "Tangential",
    "opt4": "Radially inward",
    "correct": 2
  },
  {
    "question": "The SI unit of electric field is:",
    "opt1": "N/C",
    "opt2": "J/C",
    "opt3": "Nm",
    "opt4": "C/N",
    "correct": 1
  },
  {
    "question": "An electron is placed in a uniform electric field directed upward. What is the direction of the force on the electron?",
    "opt1": "Upward",
    "opt2": "Downward",
    "opt3": "Zero",
    "opt4": "Perpendicular to the field",
    "correct": 2
  },
  {
    "question": "What quantity represents the electric potential energy per unit charge at a point in an electric field?",
    "opt1": "Electric field",
    "opt2": "Potential difference",
    "opt3": "Electric potential",
    "opt4": "Electric flux",
    "correct": 3
  },
  {
    "question": "What phenomenon explains why a charged balloon can stick to a wall?",
    "opt1": "Polarization",
    "opt2": "Friction",
    "opt3": "Conduction",
    "opt4": "Grounding",
    "correct": 1
  },
  {
    "question": "Calculate the electric field at a distance of 0.5 m from a point charge of +4μC in vacuum. (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "1.44 × 10<sup>5</sup> N/C",
    "opt2": "7.2 × 10<sup>4</sup> N/C",
    "opt3": "9 × 10<sup>5</sup> N/C",
    "opt4": "6.0 × 10<sup>4</sup> N/C",
    "correct": 1
  },
  {
    "question": "Two identical spheres carry charges of +5μC and -5μC respectively. If they are brought into contact and then separated again, what will be the final charge on each?",
    "opt1": "0 μC",
    "opt2": "+5μC and -5μC",
    "opt3": "+2.5μC each",
    "opt4": "-2.5μC each",
    "correct": 1
  },
  {
    "question": "Which of these statements about electrostatic hazards is correct?",
    "opt1": "Electrostatic charges always neutralize themselves instantly",
    "opt2": "Only conductors can accumulate dangerous electrostatic charge",
    "opt3": "Static electricity can ignite flammable substances",
    "opt4": "There is no way to prevent electrostatic buildup",
    "correct": 3
  },
  {
    "question": "A proton is placed in an electric field of strength 2 × 10<sup>3</sup> N/C. What is the force experienced by the proton? (Charge of proton = 1.6 × 10<sup>-19</sup> C)",
    "opt1": "3.2 × 10<sup>-16</sup> N",
    "opt2": "1.6 × 10<sup>-16</sup> N",
    "opt3": "8.0 × 10<sup>-17</sup> N",
    "opt4": "2.0 × 10<sup>-16</sup> N",
    "correct": 1
  },
  {
    "question": "Which of the following best describes the concept of induced charge?",
    "opt1": "Charge transferred by contact",
    "opt2": "Charge generated by friction",
    "opt3": "Redistribution of charges without contact",
    "opt4": "Charge destroyed by grounding",
    "correct": 3
  },
  {
    "question": "The electric field inside a conductor in electrostatic equilibrium is:",
    "opt1": "Very high",
    "opt2": "Uniform",
    "opt3": "Zero",
    "opt4": "Infinite",
    "correct": 3
  },
  {
    "question": "A point charge Q = -3μC is placed at a point in space. In which direction does the electric field at a point 1m to the right of Q point?",
    "opt1": "Left, toward Q",
    "opt2": "Right, away from Q",
    "opt3": "Upward",
    "opt4": "No field exists",
    "correct": 1
  },
  {
    "question": "Which of these quantities depends on both magnitude of charge and distance between them?",
    "opt1": "Electric field",
    "opt2": "Electric potential",
    "opt3": "Electrostatic force",
    "opt4": "Charge density",
    "correct": 3
  },
  {
    "question": "Which statement is false about Coulomb’s law?",
    "opt1": "It obeys inverse square law",
    "opt2": "It depends on the medium between charges",
    "opt3": "It applies only to point charges",
    "opt4": "It applies even when charges are moving",
    "correct": 4
  },
  {
    "question": "If two equal charges placed 10 cm apart experience a force of 3.6 N, what is the magnitude of each charge? (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "1.0 × 10<sup>-6</sup> C",
    "opt2": "2.0 × 10<sup>-6</sup> C",
    "opt3": "3.0 × 10<sup>-6</sup> C",
    "opt4": "6.0 × 10<sup>-6</sup> C",
    "correct": 2
  },
  {
    "question": "The principle of charge conservation implies that:",
    "opt1": "Charge can disappear spontaneously",
    "opt2": "The total charge in an isolated system remains constant",
    "opt3": "Charges must always be negative",
    "opt4": "Charges can be created with energy",
    "correct": 2
  },
  {
    "question": "The field lines of a negative point charge:",
    "opt1": "Point outward",
    "opt2": "Form loops",
    "opt3": "Point inward",
    "opt4": "Are circular",
    "correct": 3
  },
  {
    "question": "If a charge of 5μC is moved from a point of 100V to 60V, the work done is:",
    "opt1": "0.2 J",
    "opt2": "2.0 × 10<sup>-4</sup> J",
    "opt3": "0.02 J",
    "opt4": "0.0002 J",
    "correct": 2
  }
]

chapter1 = [
  {
    "question": "What year did Nigeria gain political independence from Britain?",
    "opt1": "1957",
    "opt2": "1960",
    "opt3": "1963",
    "opt4": "1970",
    "correct": 2
  },
  {
    "question": "How many regions did Nigeria have immediately after independence?",
    "opt1": "Three",
    "opt2": "Four",
    "opt3": "Five",
    "opt4": "Six",
    "correct": 1
  },
  {
    "question": "Which region was carved out of the Western Region in 1963?",
    "opt1": "Eastern Region",
    "opt2": "Midwestern Region",
    "opt3": "Northern Region",
    "opt4": "Southwestern Region",
    "correct": 2
  },
  {
    "question": "What year did the Nigerian civil war break out?",
    "opt1": "1966",
    "opt2": "1967",
    "opt3": "1968",
    "opt4": "1970",
    "correct": 2
  },
  {
    "question": "Who renamed the Eastern Region the Republic of Biafra?",
    "opt1": "Yakubu Gowon",
    "opt2": "Chinua Achebe",
    "opt3": "Chukwuemeka Odumegwu Ojukwu",
    "opt4": "Philip Effiong",
    "correct": 3
  },
  {
    "question": "How long did the Nigerian civil war last?",
    "opt1": "12 months",
    "opt2": "18 months",
    "opt3": "24 months",
    "opt4": "30 months",
    "correct": 4
  },
  {
    "question": "What slogan did the federal government adopt after the civil war?",
    "opt1": "Unity in Diversity",
    "opt2": "No Victor, No Vanquished",
    "opt3": "One Nigeria",
    "opt4": "Peace and Unity",
    "correct": 2
  },
  {
    "question": "What does the '3Rs' policy stand for?",
    "opt1": "Recovery, Repair, Reform",
    "opt2": "Reconstruction, Reformation, Reunification",
    "opt3": "Rehabilitation, Reconstruction, Reconciliation",
    "opt4": "Rehabilitation, Reform, Rejuvenation",
    "correct": 3
  },
  {
    "question": "Which program was established as part of the 3Rs strategy?",
    "opt1": "NYSC",
    "opt2": "WAI",
    "opt3": "NDDC",
    "opt4": "FRSC",
    "correct": 1
  },
  {
    "question": "Who announced the Biafran surrender?",
    "opt1": "Yakubu Gowon",
    "opt2": "Chukwuemeka Odumegwu Ojukwu",
    "opt3": "Philip Effiong",
    "opt4": "Obasanjo",
    "correct": 3
  },

  {
    "question": "When did the Nigerian civil war end?",
    "opt1": "January 15, 1969",
    "opt2": "October 1, 1960",
    "opt3": "January 15, 1970",
    "opt4": "May 27, 1967",
    "correct": 3
  },
  {
    "question": "Who was Nigeria’s Head of State during the 3Rs policy era?",
    "opt1": "Obasanjo",
    "opt2": "Yakubu Gowon",
    "opt3": "Ibrahim Babangida",
    "opt4": "Goodluck Jonathan",
    "correct": 2
  },
  {
    "question": "Which of the following was NOT part of the 3Rs strategy?",
    "opt1": "Reconciliation",
    "opt2": "Rehabilitation",
    "opt3": "Reconstruction",
    "opt4": "Revolution",
    "correct": 4
  },
  {
    "question": "Which ethnic group was the major focus of the 3Rs policy?",
    "opt1": "Hausa",
    "opt2": "Yoruba",
    "opt3": "Igbo",
    "opt4": "Ijaw",
    "correct": 3
  },
  {
    "question": "What bridge was quickly reconstructed after the civil war?",
    "opt1": "Eko Bridge",
    "opt2": "Niger Bridge",
    "opt3": "Third Mainland Bridge",
    "opt4": "Bonny Bridge",
    "correct": 2
  },
  {
    "question": "What policy aimed to give Nigerians control over businesses?",
    "opt1": "Economic Recovery Plan",
    "opt2": "Indigenization Policy",
    "opt3": "Fiscal Devolution",
    "opt4": "Economic Adjustment Program",
    "correct": 2
  },
  {
    "question": "When was the Nigerian Enterprise Promotion Decree enacted?",
    "opt1": "1972",
    "opt2": "1960",
    "opt3": "1970",
    "opt4": "1975",
    "correct": 1
  },
  {
    "question": "What did Schedule 1 of the 1972 NEPD include?",
    "opt1": "Breweries",
    "opt2": "Soft drink bottling",
    "opt3": "Public Relations",
    "opt4": "Paint manufacturing",
    "correct": 3
  },
  {
    "question": "What proportion of Schedule 2 businesses were to be owned by Nigerians?",
    "opt1": "100%",
    "opt2": "70%",
    "opt3": "60%",
    "opt4": "40%",
    "correct": 4
  },
  {
    "question": "When was the third schedule added to the NEPD?",
    "opt1": "1972",
    "opt2": "1975",
    "opt3": "1977",
    "opt4": "1980",
    "correct": 3
  },

  {
    "question": "Which of these is an advantage of the Indigenization policy?",
    "opt1": "Promotes capital flight",
    "opt2": "Discourages entrepreneurship",
    "opt3": "Encourages foreign monopoly",
    "opt4": "Creates employment for Nigerians",
    "correct": 4
  },
  {
    "question": "What year was the NYSC scheme established?",
    "opt1": "1963",
    "opt2": "1970",
    "opt3": "1973",
    "opt4": "1975",
    "correct": 3
  },
  {
    "question": "What decree established the NYSC scheme?",
    "opt1": "Decree 15",
    "opt2": "Decree 20",
    "opt3": "Decree 24",
    "opt4": "Decree 31",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a goal of the NYSC scheme?",
    "opt1": "Promoting national unity",
    "opt2": "Encouraging foreign investment",
    "opt3": "Fostering self-reliance",
    "opt4": "Encouraging youth service",
    "correct": 2
  },
  {
    "question": "What is the minimum age to be eligible for NYSC?",
    "opt1": "25",
    "opt2": "18",
    "opt3": "30",
    "opt4": "35",
    "correct": 3
  },
  {
    "question": "What document is issued after successful completion of NYSC?",
    "opt1": "Exemption Letter",
    "opt2": "Certificate of Participation",
    "opt3": "Discharge Certificate",
    "opt4": "NYSC Testimonial",
    "correct": 3
  },
  {
    "question": "Which of these criticisms is associated with NYSC?",
    "opt1": "Too much foreign influence",
    "opt2": "Lack of discipline",
    "opt3": "Rising insecurity",
    "opt4": "Unemployment after service",
    "correct": 3
  },
  {
    "question": "Which of the following is a key objective of the 3Rs?",
    "opt1": "Territorial expansion",
    "opt2": "Punishment for secessionists",
    "opt3": "National integration",
    "opt4": "Regional segregation",
    "correct": 3
  },
  {
    "question": "Who was the military head of state during the 3Rs period?",
    "opt1": "Ibrahim Babangida",
    "opt2": "Muhammadu Buhari",
    "opt3": "Yakubu Gowon",
    "opt4": "Olusegun Obasanjo",
    "correct": 3
  },
  {
    "question": "What is the primary purpose of the indigenization policy?",
    "opt1": "Encourage rural migration",
    "opt2": "Promote local ownership of businesses",
    "opt3": "Reduce school dropouts",
    "opt4": "Rehabilitate ex-soldiers",
    "correct": 2
  }
]
chapter2 = [
  {
    "question": "What is apprenticeship primarily known for?",
    "opt1": "Obtaining university degrees",
    "opt2": "Hands-on skill acquisition and knowledge transfer",
    "opt3": "Passing professional exams",
    "opt4": "Learning foreign languages",
    "correct": 2
  },
  {
    "question": "Who are apprentices typically trained by?",
    "opt1": "Parents",
    "opt2": "Politicians",
    "opt3": "Experienced mentors or master craftsmen",
    "opt4": "Government workers",
    "correct": 3
  },
  {
    "question": "What two components make up traditional apprenticeship?",
    "opt1": "Training and certification",
    "opt2": "Work and play",
    "opt3": "On-the-job learning and theoretical instruction",
    "opt4": "Field trips and practicals",
    "correct": 3
  },
  {
    "question": "Which ethnic group’s apprenticeship system emphasizes entrepreneurship?",
    "opt1": "Efik/Ibibio",
    "opt2": "Igbo",
    "opt3": "Hausa",
    "opt4": "Yoruba",
    "correct": 2
  },
  {
    "question": "Which ethnic group’s apprenticeship model focuses on preserving traditional crafts?",
    "opt1": "Hausa",
    "opt2": "Yoruba",
    "opt3": "Igbo",
    "opt4": "Tiv",
    "correct": 2
  },
  {
    "question": "What is a major objective of apprenticeship?",
    "opt1": "Promote foreign investment",
    "opt2": "Acquire hands-on experience for employability",
    "opt3": "Explore tourism",
    "opt4": "Attend international conferences",
    "correct": 2
  },
  {
    "question": "What is a common feature of apprenticeship in Nigeria?",
    "opt1": "Online mentorship",
    "opt2": "Formal university lectures",
    "opt3": "Structured mentorship and cultural values",
    "opt4": "Distance learning",
    "correct": 3
  },
  {
    "question": "What economic function does apprenticeship promote?",
    "opt1": "Political awareness",
    "opt2": "Revenue allocation",
    "opt3": "Job creation and local economic development",
    "opt4": "Importation of foreign goods",
    "correct": 3
  },
  {
    "question": "How does apprenticeship support social inclusion?",
    "opt1": "By focusing on wealthy elites",
    "opt2": "By promoting exclusivity",
    "opt3": "By training marginalized youth and disadvantaged groups",
    "opt4": "By allowing migration",
    "correct": 3
  },
  {
    "question": "What is a challenge currently facing the Nigerian apprenticeship system?",
    "opt1": "Lack of international collaboration",
    "opt2": "Over-standardization",
    "opt3": "Perceived prestige of formal education",
    "opt4": "Excessive government funding",
    "correct": 3
  },

  {
    "question": "What does on-the-job training involve?",
    "opt1": "Watching videos",
    "opt2": "Reading textbooks",
    "opt3": "Practical training at the job site",
    "opt4": "Using apps",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT an apprenticeship sector mentioned in the chapter?",
    "opt1": "Agriculture",
    "opt2": "Education and Training",
    "opt3": "Telecommunications",
    "opt4": "Arts and Media",
    "correct": 3
  },
  {
    "question": "What is the benefit of progressive wage increases in apprenticeship?",
    "opt1": "Reduces cost of training",
    "opt2": "Motivates apprentices as they develop skills",
    "opt3": "Encourages absenteeism",
    "opt4": "Promotes competition between mentors",
    "correct": 2
  },
  {
    "question": "What caused the initial decline of apprenticeships in the 19th century?",
    "opt1": "High popularity",
    "opt2": "Workplace conditions and exploitation",
    "opt3": "Technological boom",
    "opt4": "Government bans",
    "correct": 2
  },
  {
    "question": "What apprenticeship reform was introduced in 1993?",
    "opt1": "Skill Migration Act",
    "opt2": "National Handcrafting Policy",
    "opt3": "Modern Apprenticeships",
    "opt4": "Digital Inclusion Act",
    "correct": 3
  },
  {
    "question": "Which apprenticeship type was introduced before the guilds?",
    "opt1": "Digital Apprenticeship",
    "opt2": "Time-served Apprenticeship",
    "opt3": "Informal Mentorship",
    "opt4": "Online Apprenticeship",
    "correct": 2
  },
  {
    "question": "Which act regulated apprenticeships in 1563 England?",
    "opt1": "Apprentice Code",
    "opt2": "Skill Promotion Act",
    "opt3": "Statute of Artificers",
    "opt4": "Laborers’ Decree",
    "correct": 3
  },
  {
    "question": "What did Schedule 3 of the 1977 Decree focus on?",
    "opt1": "Bakeries and small businesses",
    "opt2": "Highly technical businesses",
    "opt3": "Hospitality and tourism",
    "opt4": "Trading companies",
    "correct": 2
  },
  {
    "question": "Which statement is true about guild-based apprenticeship?",
    "opt1": "They discouraged social interaction",
    "opt2": "They were controlled by local churches",
    "opt3": "They regulated trades and trained apprentices",
    "opt4": "They promoted foreign domination",
    "correct": 3
  },
  {
    "question": "What led to the abolishment of guilds in many countries?",
    "opt1": "Improved tax policies",
    "opt2": "Democratic reforms",
    "opt3": "Decrees from national governments",
    "opt4": "Religious decline",
    "correct": 3
  },

  {
    "question": "What is a major criticism of apprenticeship in modern Nigeria?",
    "opt1": "Too many scholarships",
    "opt2": "Standardization is too strict",
    "opt3": "Lack of regulation and standardized curricula",
    "opt4": "It is run by foreigners",
    "correct": 3
  },
  {
    "question": "Which of the following industries offers apprenticeships in both indoor and outdoor settings?",
    "opt1": "Fashion",
    "opt2": "Agriculture",
    "opt3": "Education",
    "opt4": "Technology",
    "correct": 2
  },
  {
    "question": "What is a component of business involvement in apprenticeship?",
    "opt1": "Sponsoring games",
    "opt2": "Importing materials",
    "opt3": "Designing and structuring the program",
    "opt4": "Foreign exchange control",
    "correct": 3
  },
  {
    "question": "Which of the following is a form of formal apprenticeship?",
    "opt1": "Guild-based apprenticeship",
    "opt2": "YouTube learning",
    "opt3": "Online crash courses",
    "opt4": "Community debates",
    "correct": 1
  },
  {
    "question": "What type of apprenticeship integrates modern technology with traditional learning?",
    "opt1": "Virtual reality programs",
    "opt2": "Standard-based apprenticeship",
    "opt3": "Digital skill camps",
    "opt4": "Community theatre learning",
    "correct": 2
  },
  {
    "question": "Why is apprenticeship important for preserving cultural heritage?",
    "opt1": "Because it helps enforce tax laws",
    "opt2": "Because it’s recognized globally",
    "opt3": "Because it passes down traditional crafts and values",
    "opt4": "Because it funds federal universities",
    "correct": 3
  },
  {
    "question": "What trend reduces the sustainability of apprenticeship in rural Nigeria?",
    "opt1": "Cybersecurity awareness",
    "opt2": "Urban migration",
    "opt3": "Climate change",
    "opt4": "Telecommunication boom",
    "correct": 2
  },
  {
    "question": "Which of the following is a benefit of formalizing apprenticeship?",
    "opt1": "Promotes cultural conflicts",
    "opt2": "Discourages youth training",
    "opt3": "Enhances skill certification and credibility",
    "opt4": "Reduces mentorship engagement",
    "correct": 3
  },
  {
    "question": "Which sector includes apprenticeships in plumbing, construction, and electrical servicing?",
    "opt1": "Education",
    "opt2": "Construction",
    "opt3": "Hospitality",
    "opt4": "Agriculture",
    "correct": 2
  }
]
chapter3 = [
  {
    "question": "What are norms and values classified as in a cultural system?",
    "opt1": "Material culture",
    "opt2": "Economic principles",
    "opt3": "Non-material culture",
    "opt4": "Religious traditions",
    "correct": 3
  },
  {
    "question": "What does the absence of norms and values lead to?",
    "opt1": "Technological growth",
    "opt2": "Political stability",
    "opt3": "Moral decadence",
    "opt4": "Social mobility",
    "correct": 3
  },
  {
    "question": "Which of these is NOT listed as a benefit of teaching values in schools?",
    "opt1": "Respect for elders",
    "opt2": "Kindheartedness",
    "opt3": "Studying hard",
    "opt4": "Acquiring weapons",
    "correct": 4
  },
  {
    "question": "Which of the following is a cause of moral decline in Nigeria?",
    "opt1": "Religious unity",
    "opt2": "Political freedom",
    "opt3": "Dishonesty",
    "opt4": "Education reforms",
    "correct": 3
  },
  {
    "question": "Which category of norms carries harsh sanctions?",
    "opt1": "Traditions",
    "opt2": "Folkways",
    "opt3": "Conventions",
    "opt4": "Mores",
    "correct": 4
  },
  {
    "question": "What is a key characteristic of folkways?",
    "opt1": "Enforced by police",
    "opt2": "Backed by courts",
    "opt3": "Violations carry harsh punishment",
    "opt4": "Violations are generally overlooked",
    "correct": 4
  },
  {
    "question": "Which of the following is an example of a folkway in Nigeria?",
    "opt1": "Paying taxes",
    "opt2": "Taking another man's life",
    "opt3": "Prostrating to greet elders",
    "opt4": "Voting in elections",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a core Nigerian value?",
    "opt1": "Self-discipline",
    "opt2": "Honesty",
    "opt3": "Greed",
    "opt4": "Hard work",
    "correct": 3
  },
  {
    "question": "What is the Nigerian value that emphasizes love for the country?",
    "opt1": "Loyalty",
    "opt2": "Patriotism",
    "opt3": "Morality",
    "opt4": "Tolerance",
    "correct": 2
  },
  {
    "question": "What is the purpose of national values?",
    "opt1": "To encourage tribalism",
    "opt2": "To promote inequality",
    "opt3": "To guide citizens’ choices and behaviors",
    "opt4": "To support political elites",
    "correct": 3
  },

  {
    "question": "Which value discourages self-centeredness and encourages good behavior?",
    "opt1": "Religious tolerance",
    "opt2": "Moral values",
    "opt3": "Individualism",
    "opt4": "Consumerism",
    "correct": 2
  },
  {
    "question": "What does communal life emphasize in Nigeria?",
    "opt1": "Competition",
    "opt2": "Rugged individualism",
    "opt3": "Interpersonal bonding",
    "opt4": "Isolationism",
    "correct": 3
  },
  {
    "question": "What does the value of sacredness of human life promote?",
    "opt1": "War and conquest",
    "opt2": "Self-defense at all costs",
    "opt3": "Respect and dignity for life",
    "opt4": "Death penalty",
    "correct": 3
  },
  {
    "question": "What does the Nigerian family value system promote?",
    "opt1": "Marriage to foreigners",
    "opt2": "Individual success",
    "opt3": "Incest",
    "opt4": "Interdependence and moral codes",
    "correct": 4
  },
  {
    "question": "Which of the following is a value that supports working hard for wealth?",
    "opt1": "Luck",
    "opt2": "Hard work",
    "opt3": "Magic",
    "opt4": "Prayer alone",
    "correct": 2
  },
  {
    "question": "What does respect for elders reflect in traditional Nigerian society?",
    "opt1": "Fear of authority",
    "opt2": "Respect for money",
    "opt3": "Wisdom and experience",
    "opt4": "Political power",
    "correct": 3
  },
  {
    "question": "What is considered the foundation of integrity?",
    "opt1": "Loyalty",
    "opt2": "Honesty",
    "opt3": "Respect",
    "opt4": "Kindness",
    "correct": 2
  },
  {
    "question": "What does the value of cooperation help achieve?",
    "opt1": "Ethnic violence",
    "opt2": "Mutual understanding",
    "opt3": "Tribal war",
    "opt4": "Corruption",
    "correct": 2
  },
  {
    "question": "Which of these is a custodian of national values?",
    "opt1": "Football clubs",
    "opt2": "Music bands",
    "opt3": "Family and school",
    "opt4": "Banks",
    "correct": 3
  },
  {
    "question": "What role does the mass media play in promoting values?",
    "opt1": "Blocking education",
    "opt2": "Promoting violence",
    "opt3": "Transmitting national values",
    "opt4": "Suppressing culture",
    "correct": 3
  },

  {
    "question": "Which of the following is a sign of moral decadence?",
    "opt1": "Kindness",
    "opt2": "Accountability",
    "opt3": "Corruption",
    "opt4": "Respect",
    "correct": 3
  },
  {
    "question": "What is the societal tool used to enforce conformity?",
    "opt1": "Police brutality",
    "opt2": "Social sanction",
    "opt3": "Political appointment",
    "opt4": "Religious titles",
    "correct": 2
  },
  {
    "question": "What kind of sanction shows approval?",
    "opt1": "Negative sanction",
    "opt2": "Punishment",
    "opt3": "Positive sanction",
    "opt4": "Isolation",
    "correct": 3
  },
  {
    "question": "Who is expected to conform to norms and values?",
    "opt1": "Only elders",
    "opt2": "Only politicians",
    "opt3": "All members of society",
    "opt4": "Only teachers",
    "correct": 3
  },
  {
    "question": "Which value is linked to allegiance to one’s country?",
    "opt1": "Tolerance",
    "opt2": "Loyalty",
    "opt3": "Greed",
    "opt4": "Humor",
    "correct": 2
  },
  {
    "question": "What is the expected consequence of value deviation?",
    "opt1": "Promotion",
    "opt2": "Wealth",
    "opt3": "Sanction or punishment",
    "opt4": "Freedom",
    "correct": 3
  },
  {
    "question": "Why are norms and values important for a society?",
    "opt1": "To create confusion",
    "opt2": "To slow down change",
    "opt3": "To promote social integration",
    "opt4": "To reject modernity",
    "correct": 3
  },
  {
    "question": "Which of these is NOT a custodian of national values?",
    "opt1": "Government",
    "opt2": "Teachers",
    "opt3": "Criminals",
    "opt4": "Family",
    "correct": 3
  },
  {
    "question": "What is a characteristic of a transformed society?",
    "opt1": "Decline in morals",
    "opt2": "Strong cultural values",
    "opt3": "Increased crime",
    "opt4": "Collapse of education",
    "correct": 2
  },
  {
    "question": "What role do schools play in value transmission?",
    "opt1": "They discourage culture",
    "opt2": "They ignore morals",
    "opt3": "They serve as mediums of instruction and social structure",
    "opt4": "They promote disobedience",
    "correct": 3
  }
]
chapter4 = [
  {
    "question": "What does citizenship education primarily teach?",
    "opt1": "Military training",
    "opt2": "Geography and history",
    "opt3": "Rights, responsibilities, and patriotism",
    "opt4": "Science and technology",
    "correct": 3
  },
  {
    "question": "Which theory of citizenship defines ideal values and civic duties?",
    "opt1": "Empirical theory",
    "opt2": "Modern theory",
    "opt3": "Critical theory",
    "opt4": "Normative theory",
    "correct": 4
  },
  {
    "question": "What is the focus of empirical theory of citizenship?",
    "opt1": "Ideal moral standards",
    "opt2": "What citizenship should be",
    "opt3": "Real-world behavior and participation",
    "opt4": "Philosophical ideologies",
    "correct": 3
  },
  {
    "question": "What Latin word is related to the root of 'citizenship'?",
    "opt1": "Cultura",
    "opt2": "Civitas",
    "opt3": "Statua",
    "opt4": "Juris",
    "correct": 2
  },
  {
    "question": "According to Mfon Udokang, citizenship refers to:",
    "opt1": "Having a job in a city",
    "opt2": "Political party affiliation",
    "opt3": "Legal status in relation to a state",
    "opt4": "Right to vote",
    "correct": 3
  },
  {
    "question": "Which document outlines Nigerian citizenship laws?",
    "opt1": "National Pledge",
    "opt2": "1999 Constitution",
    "opt3": "Electoral Act",
    "opt4": "NYSC Decree",
    "correct": 2
  },
  {
    "question": "Which of these is a type of citizenship?",
    "opt1": "Citizenship by lawmaking",
    "opt2": "Citizenship by religion",
    "opt3": "Citizenship by birth",
    "opt4": "Citizenship by referendum",
    "correct": 3
  },
  {
    "question": "What type of citizenship applies to women married to Nigerian men?",
    "opt1": "By conferment",
    "opt2": "By law",
    "opt3": "By registration",
    "opt4": "By appointment",
    "correct": 3
  },
  {
    "question": "What is required for citizenship by naturalization?",
    "opt1": "Owning property in Nigeria",
    "opt2": "Being under 18 years",
    "opt3": "Presidential appointment",
    "opt4": "Fulfilling specified legal conditions",
    "correct": 4
  },
  {
    "question": "Which of the following is NOT a requirement for naturalization?",
    "opt1": "Renouncing previous citizenship",
    "opt2": "Approval by a traditional ruler",
    "opt3": "Taking an oath of allegiance",
    "opt4": "Presidential approval",
    "correct": 2
  },

  {
    "question": "Who grants citizenship by conferment in Nigeria?",
    "opt1": "The Senate",
    "opt2": "The Judiciary",
    "opt3": "The President",
    "opt4": "The Local Government Chairman",
    "correct": 3
  },
  {
    "question": "Which of the following best describes a good citizen?",
    "opt1": "Avoids community involvement",
    "opt2": "Breaks laws regularly",
    "opt3": "Contributes to societal development",
    "opt4": "Supports violence",
    "correct": 3
  },
  {
    "question": "What is a characteristic of a bad citizen?",
    "opt1": "Pays taxes",
    "opt2": "Participates in elections",
    "opt3": "Engages in criminal acts",
    "opt4": "Respects authority",
    "correct": 3
  },
  {
    "question": "What defines a passive citizen?",
    "opt1": "Always obeys the law",
    "opt2": "Actively supports governance",
    "opt3": "Disengages from civic responsibilities",
    "opt4": "Leads protests",
    "correct": 3
  },
  {
    "question": "Which of these is a civic obligation?",
    "opt1": "Owning a private company",
    "opt2": "Avoiding elections",
    "opt3": "Paying taxes",
    "opt4": "Joining opposition parties",
    "correct": 3
  },
  {
    "question": "How many years must a foreigner typically live in Nigeria before applying for naturalization?",
    "opt1": "5–10 years",
    "opt2": "15–20 years",
    "opt3": "2–3 years",
    "opt4": "30 years",
    "correct": 2
  },
  {
    "question": "What may cause revocation of naturalized citizenship?",
    "opt1": "Changing religion",
    "opt2": "Owning a foreign company",
    "opt3": "Committing a serious offense",
    "opt4": "Getting married",
    "correct": 3
  },
  {
    "question": "What duty involves participating in democratic processes?",
    "opt1": "Voting in elections",
    "opt2": "Avoiding national symbols",
    "opt3": "Relocating abroad",
    "opt4": "Boycotting polling units",
    "correct": 1
  },
  {
    "question": "Which of the following is NOT a civic responsibility?",
    "opt1": "Respecting national symbols",
    "opt2": "Obeying laws",
    "opt3": "Dodging taxes",
    "opt4": "Giving credible information to security agencies",
    "correct": 3
  },
  {
    "question": "Which value emphasizes allegiance to one’s country?",
    "opt1": "Creativity",
    "opt2": "Loyalty",
    "opt3": "Generosity",
    "opt4": "Innovation",
    "correct": 2
  },

  {
    "question": "Which of the following is a characteristic of an active citizen?",
    "opt1": "Ignorance of laws",
    "opt2": "Destruction of public property",
    "opt3": "Peaceful and law-abiding",
    "opt4": "Involvement in violence",
    "correct": 3
  },
  {
    "question": "Which type of citizen undermines national development?",
    "opt1": "Good citizen",
    "opt2": "Passive citizen",
    "opt3": "Bad citizen",
    "opt4": "Immigrant",
    "correct": 3
  },
  {
    "question": "What is the key difference between a good and passive citizen?",
    "opt1": "Age",
    "opt2": "Birthplace",
    "opt3": "Civic engagement",
    "opt4": "Religious views",
    "correct": 3
  },
  {
    "question": "Why is taking part in sanitation considered a civic duty?",
    "opt1": "It is fun",
    "opt2": "It promotes community health",
    "opt3": "It allows holidays",
    "opt4": "It is punishable by law",
    "correct": 2
  },
  {
    "question": "Which of the following promotes patriotism?",
    "opt1": "Avoiding taxes",
    "opt2": "Selling national secrets",
    "opt3": "Pledging loyalty to the nation",
    "opt4": "Joining opposition groups",
    "correct": 3
  },
  {
    "question": "What is a consequence of not obeying national laws?",
    "opt1": "Promotion",
    "opt2": "Immunity",
    "opt3": "Punishment or sanction",
    "opt4": "Salary increment",
    "correct": 3
  },
  {
    "question": "Which of the following promotes unity and shared responsibility?",
    "opt1": "Disrespecting laws",
    "opt2": "Community service",
    "opt3": "Cybercrime",
    "opt4": "Election boycott",
    "correct": 2
  },
  {
    "question": "What type of citizen behavior should be emulated for national progress?",
    "opt1": "Indifference",
    "opt2": "Selfishness",
    "opt3": "Civic responsibility",
    "opt4": "Tribalism",
    "correct": 3
  },
  {
    "question": "What does respecting national symbols signify?",
    "opt1": "Disregard for laws",
    "opt2": "Foreign allegiance",
    "opt3": "Patriotism",
    "opt4": "Religious tolerance",
    "correct": 3
  }
]
chapter5 = [
  {
    "question": "What is a linguistic group?",
    "opt1": "A group that studies languages",
    "opt2": "People who share political opinions",
    "opt3": "People identified by the language they speak",
    "opt4": "Relatives of linguists",
    "correct": 3
  },
  {
    "question": "How many languages are estimated to be spoken in Nigeria?",
    "opt1": "100",
    "opt2": "250",
    "opt3": "515",
    "opt4": "700",
    "correct": 3
  },
  {
    "question": "Which language is considered the most widely spoken in Nigeria?",
    "opt1": "English",
    "opt2": "Igbo",
    "opt3": "Yoruba",
    "opt4": "Hausa",
    "correct": 4
  },
  {
    "question": "Which linguistic group is most associated with the southwestern region of Nigeria?",
    "opt1": "Kanuri",
    "opt2": "Tiv",
    "opt3": "Yoruba",
    "opt4": "Igbo",
    "correct": 3
  },
  {
    "question": "Which language is noted for its tonal and expressive nature?",
    "opt1": "Igala",
    "opt2": "Yoruba",
    "opt3": "Efik",
    "opt4": "Nupe",
    "correct": 2
  },
  {
    "question": "What is a key criterion for classifying a linguistic group as 'major' in Nigeria?",
    "opt1": "Use in religion",
    "opt2": "Use in international diplomacy",
    "opt3": "Having over 3 million speakers and being taught in schools",
    "opt4": "Being spoken by traditional rulers",
    "correct": 3
  },
  {
    "question": "Which region is the Igbo linguistic group predominantly found?",
    "opt1": "North",
    "opt2": "South-East",
    "opt3": "West",
    "opt4": "Middle Belt",
    "correct": 2
  },
  {
    "question": "Which language is spoken by the Fulani people?",
    "opt1": "Kanuri",
    "opt2": "Fulfulde",
    "opt3": "Ijaw",
    "opt4": "Bura",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT among Nigeria's three major linguistic groups?",
    "opt1": "Hausa",
    "opt2": "Igbo",
    "opt3": "Yoruba",
    "opt4": "Tiv",
    "correct": 4
  },
  {
    "question": "What is a major challenge facing the use of indigenous languages in education?",
    "opt1": "Shortage of teachers",
    "opt2": "Absence of orthographies",
    "opt3": "High cost of books",
    "opt4": "Refusal by students",
    "correct": 2
  },

  {
    "question": "Which document encourages the use of local languages for the first three years of school?",
    "opt1": "Universal Basic Education Act",
    "opt2": "National Policy on Education (NPE)",
    "opt3": "Language Reform Act",
    "opt4": "UNESCO Convention",
    "correct": 2
  },
  {
    "question": "What is the goal of using mother tongue in early education?",
    "opt1": "To delay learning English",
    "opt2": "To prevent foreign influence",
    "opt3": "To make learning easier for children",
    "opt4": "To promote tourism",
    "correct": 3
  },
  {
    "question": "What benefit does using indigenous languages bring to marginalized communities?",
    "opt1": "Encourages tribalism",
    "opt2": "Promotes division",
    "opt3": "Empowers and includes them",
    "opt4": "Limits access to government",
    "correct": 3
  },
  {
    "question": "Which of the following is a minor linguistic group in Nigeria?",
    "opt1": "Hausa",
    "opt2": "Yoruba",
    "opt3": "Ijaw",
    "opt4": "Igbo",
    "correct": 3
  },
  {
    "question": "What makes Nigerian Pidgin a unique linguistic group?",
    "opt1": "It is an indigenous dialect of Hausa",
    "opt2": "It is purely foreign",
    "opt3": "It blends English with native languages",
    "opt4": "It is only spoken in rural areas",
    "correct": 3
  },
  {
    "question": "Where is Nigerian Pidgin most commonly spoken?",
    "opt1": "North-East Nigeria",
    "opt2": "South-West Nigeria",
    "opt3": "Niger Delta",
    "opt4": "Middle Belt",
    "correct": 3
  },
  {
    "question": "Which of these is NOT an advantage of indigenous language usage?",
    "opt1": "Cultural preservation",
    "opt2": "Promotion of unity",
    "opt3": "Global dominance",
    "opt4": "Identity formation",
    "correct": 3
  },
  {
    "question": "What role do indigenous languages play in national development?",
    "opt1": "Cause regionalism",
    "opt2": "Unify and empower citizens",
    "opt3": "Limit globalization",
    "opt4": "Impose colonial language",
    "correct": 2
  },
  {
    "question": "Which linguistic group includes speakers of Fulfulde?",
    "opt1": "Hausa",
    "opt2": "Fulani",
    "opt3": "Yoruba",
    "opt4": "Ijaw",
    "correct": 2
  },
  {
    "question": "Which major language is widely used in Nigerian trade?",
    "opt1": "Kanuri",
    "opt2": "Igbo",
    "opt3": "Yoruba",
    "opt4": "Hausa",
    "correct": 4
  },

  {
    "question": "Which of the following is a function of language in national unity?",
    "opt1": "Promotion of secrecy",
    "opt2": "Restriction of knowledge",
    "opt3": "Facilitation of communication and integration",
    "opt4": "Encouragement of mono-ethnicity",
    "correct": 3
  },
  {
    "question": "Which ethnic group speaks Tiv?",
    "opt1": "Middle Belt",
    "opt2": "South-East",
    "opt3": "South-West",
    "opt4": "North-Central",
    "correct": 1
  },
  {
    "question": "Which language group has over 20 million speakers?",
    "opt1": "Igbo",
    "opt2": "Yoruba",
    "opt3": "Hausa",
    "opt4": "Pidgin",
    "correct": 3
  },
  {
    "question": "Why is it hard to implement the NPE language policy?",
    "opt1": "Low student population",
    "opt2": "Lack of interest",
    "opt3": "Lack of developed orthographies",
    "opt4": "Too many universities",
    "correct": 3
  },
  {
    "question": "Which of the following is a benefit of using indigenous languages in media?",
    "opt1": "To restrict access",
    "opt2": "To promote foreign policies",
    "opt3": "To foster cultural identity",
    "opt4": "To censor information",
    "correct": 3
  },
  {
    "question": "Which language serves as a lingua franca in Nigeria?",
    "opt1": "English only",
    "opt2": "Yoruba",
    "opt3": "Nigerian Pidgin",
    "opt4": "French",
    "correct": 3
  },
  {
    "question": "How many major linguistic groups are there in Nigeria?",
    "opt1": "Three",
    "opt2": "Four",
    "opt3": "Five",
    "opt4": "Six",
    "correct": 1
  },
  {
    "question": "Which of these is NOT a reason to promote indigenous languages?",
    "opt1": "Fostering inclusion",
    "opt2": "Cultural preservation",
    "opt3": "Marginalization",
    "opt4": "Empowerment",
    "correct": 3
  },
  {
    "question": "Which major linguistic group is characterized by over twenty dialects?",
    "opt1": "Hausa",
    "opt2": "Yoruba",
    "opt3": "Igbo",
    "opt4": "Efik",
    "correct": 3
  },
  {
    "question": "Why is Nigerian Pidgin considered essential in daily interaction?",
    "opt1": "It is foreign",
    "opt2": "It is elitist",
    "opt3": "It bridges gaps among diverse groups",
    "opt4": "It is used only in schools",
    "correct": 3
  }
]
chapter6 = [
  {
    "question": "Which definition describes law as a system of rules enforced through institutions to regulate behavior?",
    "opt1": "American Constitution",
    "opt2": "Black’s Law Dictionary",
    "opt3": "UNICEF",
    "opt4": "Oxford Dictionary",
    "correct": 2
  },
  {
    "question": "According to the American Bar Association, law is primarily enforced by:",
    "opt1": "Cultural groups",
    "opt2": "Schools",
    "opt3": "The community and its institutions",
    "opt4": "Religious leaders",
    "correct": 3
  },
  {
    "question": "What does the United Nations emphasize in its definition of law?",
    "opt1": "Local customs only",
    "opt2": "Global recognition and enforcement",
    "opt3": "Religious compliance",
    "opt4": "Traditional rule",
    "correct": 2
  },
  {
    "question": "Which organization sees law as protecting individual rights and maintaining social order?",
    "opt1": "European Court of Human Rights",
    "opt2": "African Union",
    "opt3": "Nigerian Bar Association",
    "opt4": "Federal High Court",
    "correct": 1
  },
  {
    "question": "Ben Nwabueze views law as:",
    "opt1": "A flexible set of ideas",
    "opt2": "A set of moral doctrines",
    "opt3": "A comprehensive framework of rules",
    "opt4": "Traditional customs",
    "correct": 3
  },
  {
    "question": "Which legal scholar emphasized law as a dynamic system adapting to societal needs?",
    "opt1": "Akin Ibidapo-Obe",
    "opt2": "Thomas Hobbes",
    "opt3": "Karl Marx",
    "opt4": "John Locke",
    "correct": 1
  },
  {
    "question": "What does Itse Sagay underscore about law?",
    "opt1": "It must remain rigid",
    "opt2": "It is only for elites",
    "opt3": "It is an embodiment of norms and principles",
    "opt4": "It must be religious",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a classification of law?",
    "opt1": "Based on source",
    "opt2": "Based on cost",
    "opt3": "Based on jurisdiction",
    "opt4": "Based on subject matter",
    "correct": 2
  },
  {
    "question": "Statutory law is:",
    "opt1": "Based on dreams",
    "opt2": "Passed by kings",
    "opt3": "Enacted by legislatures",
    "opt4": "Used only in rural areas",
    "correct": 3
  },
  {
    "question": "Common law evolves through:",
    "opt1": "Rituals",
    "opt2": "Written statutes",
    "opt3": "Court precedents",
    "opt4": "Parliamentary debates",
    "correct": 3
  },

  {
    "question": "Which type of law governs the relationship between the state and individuals?",
    "opt1": "Contract law",
    "opt2": "Public law",
    "opt3": "Tort law",
    "opt4": "Family law",
    "correct": 2
  },
  {
    "question": "What does criminal law focus on?",
    "opt1": "Marriage ceremonies",
    "opt2": "Civil agreements",
    "opt3": "Offenses and punishments",
    "opt4": "Religious beliefs",
    "correct": 3
  },
  {
    "question": "Private law is also known as:",
    "opt1": "International law",
    "opt2": "Civil law",
    "opt3": "Military law",
    "opt4": "Economic law",
    "correct": 2
  },
  {
    "question": "Which area does tort law address?",
    "opt1": "Criminal sentencing",
    "opt2": "Civil wrongs",
    "opt3": "Business registration",
    "opt4": "Land tenure",
    "correct": 2
  },
  {
    "question": "What governs issues of marriage and divorce?",
    "opt1": "Property law",
    "opt2": "Family law",
    "opt3": "Corporate law",
    "opt4": "Banking law",
    "correct": 2
  },
  {
    "question": "What is domestic law?",
    "opt1": "Laws enforced at home",
    "opt2": "Rules for private schools",
    "opt3": "Laws within a country’s jurisdiction",
    "opt4": "Village laws",
    "correct": 3
  },
  {
    "question": "Which law governs the behavior of states with each other?",
    "opt1": "Common law",
    "opt2": "Administrative law",
    "opt3": "International law",
    "opt4": "Local law",
    "correct": 3
  },
  {
    "question": "Substantive law defines:",
    "opt1": "Only the duties of judges",
    "opt2": "Administrative rules",
    "opt3": "Rights and obligations of individuals",
    "opt4": "Courtroom arrangements",
    "correct": 3
  },
  {
    "question": "Procedural law deals with:",
    "opt1": "Lawmaking",
    "opt2": "Religious observance",
    "opt3": "How legal rights are enforced",
    "opt4": "Economic policy",
    "correct": 3
  },
  {
    "question": "Which of the following is an example of public law?",
    "opt1": "Criminal law",
    "opt2": "Tort law",
    "opt3": "Contract law",
    "opt4": "Marriage law",
    "correct": 1
  },

  {
    "question": "Which classification includes treaties and conventions?",
    "opt1": "Private law",
    "opt2": "Common law",
    "opt3": "International law",
    "opt4": "Family law",
    "correct": 3
  },
  {
    "question": "Which type of law ensures legal rights are enforced fairly?",
    "opt1": "Criminal law",
    "opt2": "Procedural law",
    "opt3": "Administrative law",
    "opt4": "Equity law",
    "correct": 2
  },
  {
    "question": "What is the aim of public law?",
    "opt1": "To privatize corporations",
    "opt2": "To resolve marital conflicts",
    "opt3": "To manage government-citizen relations",
    "opt4": "To train legal scholars",
    "correct": 3
  },
  {
    "question": "What classification of law is based on the nature and scope of relationships?",
    "opt1": "Public and private law",
    "opt2": "Natural and positive law",
    "opt3": "Oral and written law",
    "opt4": "Federal and state law",
    "correct": 1
  },
  {
    "question": "What ensures social justice and legal order?",
    "opt1": "Freedom of speech",
    "opt2": "Codified moral rules",
    "opt3": "Law",
    "opt4": "Religion",
    "correct": 3
  },
  {
    "question": "Which classification concerns the administration of justice?",
    "opt1": "Judicial law",
    "opt2": "Substantive law",
    "opt3": "Procedural law",
    "opt4": "Religious law",
    "correct": 3
  },
  {
    "question": "What is the focus of substantive law?",
    "opt1": "Dispute procedures",
    "opt2": "Legal theory",
    "opt3": "Enforcement systems",
    "opt4": "Legal rights and duties",
    "correct": 4
  },
  {
    "question": "Which law type applies to international negotiations?",
    "opt1": "Common law",
    "opt2": "Contract law",
    "opt3": "International law",
    "opt4": "Public law",
    "correct": 3
  },
  {
    "question": "Law serves as a tool for:",
    "opt1": "Economic inflation",
    "opt2": "Social disruption",
    "opt3": "Governance and justice",
    "opt4": "Religious debate",
    "correct": 3
  },
  {
    "question": "What is the role of judicial institutions in law?",
    "opt1": "To enact policies",
    "opt2": "To build roads",
    "opt3": "To enforce and interpret laws",
    "opt4": "To educate the youth",
    "correct": 3
  }
]
chapter7 = [
  {
    "question": "What is indigenous trade?",
    "opt1": "Trade involving only foreign goods",
    "opt2": "Exchange of goods between indigenous people",
    "opt3": "Online commercial transaction",
    "opt4": "Trade carried out by colonizers",
    "correct": 2
  },
  {
    "question": "Which of the following best describes intra-state trade?",
    "opt1": "Trade across national borders",
    "opt2": "Trade within the same region or state",
    "opt3": "Trade between countries",
    "opt4": "Trade across oceans",
    "correct": 2
  },
  {
    "question": "Trade between different cultural regions in Nigeria is called:",
    "opt1": "Intra-state trade",
    "opt2": "International trade",
    "opt3": "Inter-state trade",
    "opt4": "Local trade",
    "correct": 3
  },
  {
    "question": "The first form of indigenous trade was called:",
    "opt1": "Cash-based trade",
    "opt2": "E-commerce",
    "opt3": "Trade by barter",
    "opt4": "Export-import trade",
    "correct": 3
  },
  {
    "question": "Which was NOT a major commercial center in pre-colonial Nigeria?",
    "opt1": "Onitsha",
    "opt2": "Ibadan",
    "opt3": "Kano",
    "opt4": "London",
    "correct": 4
  },
  {
    "question": "Which trade route linked Nigeria to North Africa?",
    "opt1": "Atlantic trade route",
    "opt2": "Eastern route",
    "opt3": "Trans-Saharan trade route",
    "opt4": "River Niger trade route",
    "correct": 3
  },
  {
    "question": "What were the main items exported to North Africa?",
    "opt1": "Cars and electronics",
    "opt2": "Yam and garri",
    "opt3": "Gold, dyed clothes, leather goods, and slaves",
    "opt4": "Bananas and oranges",
    "correct": 3
  },
  {
    "question": "Which of the following was used as a means of exchange in indigenous Nigeria?",
    "opt1": "Naira",
    "opt2": "Euros",
    "opt3": "Cowries",
    "opt4": "Dollar",
    "correct": 3
  },
  {
    "question": "What is a key feature of trade by barter?",
    "opt1": "Using coins",
    "opt2": "Using bank cards",
    "opt3": "Exchanging goods for goods",
    "opt4": "Using online platforms",
    "correct": 3
  },
  {
    "question": "Which agricultural product was widely traded in pre-colonial Nigeria?",
    "opt1": "Wheat",
    "opt2": "Cassava",
    "opt3": "Rye",
    "opt4": "Olives",
    "correct": 2
  },

  {
    "question": "Palm oil was significant in pre-colonial Nigeria because:",
    "opt1": "It was a currency",
    "opt2": "It was not available",
    "opt3": "It served as cooking oil and income source",
    "opt4": "It was used as building material",
    "correct": 3
  },
  {
    "question": "Which of the following was a cash crop in pre-colonial Nigeria?",
    "opt1": "Maize",
    "opt2": "Cotton",
    "opt3": "Rice",
    "opt4": "Barley",
    "correct": 2
  },
  {
    "question": "Which item symbolized social status in trade?",
    "opt1": "Salt",
    "opt2": "Beads and ivory",
    "opt3": "Beans",
    "opt4": "Yam",
    "correct": 2
  },
  {
    "question": "Aso-oke and Adire are examples of:",
    "opt1": "Food crops",
    "opt2": "Metal goods",
    "opt3": "Textiles",
    "opt4": "Luxury items",
    "correct": 3
  },
  {
    "question": "Which of these helped the growth of indigenous trade?",
    "opt1": "Overpopulation",
    "opt2": "Increase in population and communication",
    "opt3": "Use of foreign goods only",
    "opt4": "Political conflict",
    "correct": 2
  },
  {
    "question": "Which of these hindered indigenous trade?",
    "opt1": "Rich culture",
    "opt2": "Good transport",
    "opt3": "Poor infrastructure",
    "opt4": "High literacy",
    "correct": 3
  },
  {
    "question": "Indigenous trade contributed to economic development through:",
    "opt1": "Cultural erosion",
    "opt2": "Job loss",
    "opt3": "Job creation and cultural preservation",
    "opt4": "Dependence on imports",
    "correct": 3
  },
  {
    "question": "Middlemen in indigenous trade:",
    "opt1": "Were irrelevant",
    "opt2": "Linked suppliers with buyers",
    "opt3": "Were chiefs only",
    "opt4": "Created markets",
    "correct": 2
  },
  {
    "question": "Which role did merchants play?",
    "opt1": "Road construction",
    "opt2": "Bulk trading and network control",
    "opt3": "Food storage",
    "opt4": "Water supply",
    "correct": 2
  },
  {
    "question": "Which of these items was traded as luxury in pre-colonial Nigeria?",
    "opt1": "Cassava",
    "opt2": "Salt",
    "opt3": "Beads",
    "opt4": "Onions",
    "correct": 3
  },

  {
    "question": "Trade helped in promoting cultural exchange by:",
    "opt1": "Hiding identities",
    "opt2": "Limiting interactions",
    "opt3": "Sharing ideas and customs",
    "opt4": "Blocking language flow",
    "correct": 3
  },
  {
    "question": "Which was a common difficulty of the barter system?",
    "opt1": "Too much money",
    "opt2": "Indivisibility of goods",
    "opt3": "Limited internet",
    "opt4": "Tax evasion",
    "correct": 2
  },
  {
    "question": "Which was NOT an indigenous means of exchange?",
    "opt1": "Manilas",
    "opt2": "Beads",
    "opt3": "ATM cards",
    "opt4": "Cowries",
    "correct": 3
  },
  {
    "question": "One way trade contributed to urbanization was by:",
    "opt1": "Spreading diseases",
    "opt2": "Draining labor",
    "opt3": "Creating market towns",
    "opt4": "Reducing population",
    "correct": 3
  },
  {
    "question": "Which city was a major coastal trade center?",
    "opt1": "Lagos",
    "opt2": "Sokoto",
    "opt3": "Maiduguri",
    "opt4": "Minna",
    "correct": 1
  },
  {
    "question": "Which of these helped link Nigeria with Europe in trade?",
    "opt1": "Trans-Saharan route",
    "opt2": "Coastal trade route",
    "opt3": "River trade route",
    "opt4": "Rail transport",
    "correct": 2
  },
  {
    "question": "Which metal goods were essential in pre-colonial agriculture?",
    "opt1": "Bracelets",
    "opt2": "Axes and hoes",
    "opt3": "Iron pots",
    "opt4": "Rings",
    "correct": 2
  },
  {
    "question": "Indigenous trade encouraged specialization by:",
    "opt1": "Promoting uniformity",
    "opt2": "Limiting skill development",
    "opt3": "Encouraging regions to focus on their strengths",
    "opt4": "Isolating communities",
    "correct": 3
  },
  {
    "question": "What caused the decline of barter in Nigeria?",
    "opt1": "The internet",
    "opt2": "Introduction of money",
    "opt3": "New cooking methods",
    "opt4": "Electricity supply",
    "correct": 2
  },
  {
    "question": "Which of these is a modern challenge for indigenous trade?",
    "opt1": "Too many traders",
    "opt2": "Excess roads",
    "opt3": "Fraudulent activities",
    "opt4": "Free education",
    "correct": 3
  }
]
chapter8 = [
  {
    "question": "What was the name of the first trade union in Nigeria?",
    "opt1": "Railway Workers Union",
    "opt2": "African Workers Congress",
    "opt3": "Southern Nigerian Civil Service Union",
    "opt4": "National Union of Teachers",
    "correct": 3
  },
  {
    "question": "Why was the Southern Nigerian Civil Service Union renamed in 1914?",
    "opt1": "To accommodate political parties",
    "opt2": "Because it joined the British Union",
    "opt3": "Due to the amalgamation of Nigeria",
    "opt4": "To include railway workers",
    "correct": 3
  },
  {
    "question": "Which prominent labor leader led the 1945 General Strike?",
    "opt1": "Herbert Macaulay",
    "opt2": "Nnamdi Azikiwe",
    "opt3": "Michael Imoudu",
    "opt4": "Obafemi Awolowo",
    "correct": 3
  },
  {
    "question": "What does COLA stand for in the context of Nigerian labor history?",
    "opt1": "Cost of Living Adjustment",
    "opt2": "Colonial Labour Alliance",
    "opt3": "Cost of Labour Allowance",
    "opt4": "Council of Labour Associations",
    "correct": 1
  },
  {
    "question": "In what year was the Railway Workers Union registered?",
    "opt1": "1912",
    "opt2": "1925",
    "opt3": "1931",
    "opt4": "1940",
    "correct": 4
  },
  {
    "question": "Who founded the Railway Workers Union?",
    "opt1": "Obafemi Awolowo",
    "opt2": "Michael Imoudu",
    "opt3": "Nnamdi Azikiwe",
    "opt4": "Herbert Macaulay",
    "correct": 2
  },
  {
    "question": "The 1945 General Strike lasted for how many days in Lagos?",
    "opt1": "30 days",
    "opt2": "44 days",
    "opt3": "60 days",
    "opt4": "52 days",
    "correct": 2
  },
  {
    "question": "What was the main reason behind the 1945 General Strike?",
    "opt1": "Religious conflict",
    "opt2": "Educational reforms",
    "opt3": "High cost of living and poor salaries",
    "opt4": "Political parties' formation",
    "correct": 3
  },
  {
    "question": "Which political party supported the labor movement during the 1945 strike?",
    "opt1": "APC",
    "opt2": "PDP",
    "opt3": "NCNC",
    "opt4": "NNDP",
    "correct": 3
  },
  {
    "question": "Which newspaper did Nnamdi Azikiwe use to support striking workers?",
    "opt1": "Daily Times",
    "opt2": "Nigerian Chronicle",
    "opt3": "The West African Pilot",
    "opt4": "Nigerian Standard",
    "correct": 3
  },

  {
    "question": "What year did Nigeria gain independence?",
    "opt1": "1950",
    "opt2": "1960",
    "opt3": "1945",
    "opt4": "1970",
    "correct": 2
  },
  {
    "question": "Which company’s workers in Warri protested in 1947?",
    "opt1": "Shell",
    "opt2": "NITEL",
    "opt3": "UAC",
    "opt4": "NEPA",
    "correct": 3
  },
  {
    "question": "The killings in Burutu in 1947 led to what response from nationalists?",
    "opt1": "Silence",
    "opt2": "Increased calls for independence",
    "opt3": "Ban on trade unions",
    "opt4": "Formation of a military group",
    "correct": 2
  },
  {
    "question": "What group was formed after the Enugu coal miners’ crisis?",
    "opt1": "National Coalition for Workers",
    "opt2": "National Union of Miners",
    "opt3": "National Emergency Committee",
    "opt4": "Nigerian Labour Front",
    "correct": 3
  },
  {
    "question": "What was the reaction of the British to the 1945 General Strike?",
    "opt1": "They granted full independence",
    "opt2": "They ignored it",
    "opt3": "They increased salaries",
    "opt4": "They arrested all workers",
    "correct": 3
  },
  {
    "question": "Michael Imoudu believed that labor should combine with what to fight for independence?",
    "opt1": "Military",
    "opt2": "Church",
    "opt3": "Politics",
    "opt4": "Education",
    "correct": 3
  },
  {
    "question": "Who was detained and banished by the British for his activism?",
    "opt1": "Herbert Macaulay",
    "opt2": "Nnamdi Azikiwe",
    "opt3": "Michael Imoudu",
    "opt4": "Obafemi Awolowo",
    "correct": 3
  },
  {
    "question": "Why did railway workers break away from NCSU?",
    "opt1": "To form a sports team",
    "opt2": "Because they wanted higher positions",
    "opt3": "Due to NCSU’s moderate approach",
    "opt4": "To join colonial authorities",
    "correct": 3
  },
  {
    "question": "Which union did the RWU later join to form a larger body?",
    "opt1": "NCNC",
    "opt2": "NLC",
    "opt3": "ACSTWU",
    "opt4": "UAC",
    "correct": 3
  },
  {
    "question": "What impact did the labor movement have on Nigerian independence?",
    "opt1": "It slowed it down",
    "opt2": "It had no impact",
    "opt3": "It accelerated nationalist movements",
    "opt4": "It caused division among parties",
    "correct": 3
  },

  {
    "question": "What issue did the 1945 COLA agitation address?",
    "opt1": "Marriage rights",
    "opt2": "Education reform",
    "opt3": "Wage increment due to inflation",
    "opt4": "Religious discrimination",
    "correct": 3
  },
  {
    "question": "Which event was described as an 'economic wing of nationalism'?",
    "opt1": "Amalgamation",
    "opt2": "1945 General Strike",
    "opt3": "Formation of NCNC",
    "opt4": "World War I",
    "correct": 2
  },
  {
    "question": "The Enugu miners’ protest was sparked by:",
    "opt1": "Political competition",
    "opt2": "Unpaid taxes",
    "opt3": "Wage disputes and dismissal",
    "opt4": "Religious conflict",
    "correct": 3
  },
  {
    "question": "How did the miners’ wives in Enugu respond to the crisis?",
    "opt1": "They left town",
    "opt2": "They demonstrated",
    "opt3": "They went on strike",
    "opt4": "They supported the British",
    "correct": 2
  },
  {
    "question": "What was a major consequence of the Enugu crisis?",
    "opt1": "More mining jobs",
    "opt2": "British withdrawal",
    "opt3": "Nationalist unity",
    "opt4": "Formation of the Red Cross",
    "correct": 3
  },
  {
    "question": "What term describes the period of increased political awareness and action from 1945–1950?",
    "opt1": "National disengagement",
    "opt2": "Colonial leisure",
    "opt3": "Nationalist movement",
    "opt4": "Labour peace",
    "correct": 3
  },
  {
    "question": "Which of these leaders was NOT mentioned as a nationalist in this chapter?",
    "opt1": "Herbert Macaulay",
    "opt2": "Michael Imoudu",
    "opt3": "Nnamdi Azikiwe",
    "opt4": "Yakubu Gowon",
    "correct": 4
  },
  {
    "question": "What did many workers demand during the post-WWII economic hardship?",
    "opt1": "Holidays abroad",
    "opt2": "Lower taxes",
    "opt3": "Higher wages",
    "opt4": "Religious education",
    "correct": 3
  },
  {
    "question": "What does the acronym NCSU stand for?",
    "opt1": "National Civil Society Union",
    "opt2": "Nigerian Civil Service Union",
    "opt3": "Nigerian Confederation of Student Unions",
    "opt4": "National Coalition of State Unions",
    "correct": 2
  },
  {
    "question": "Who founded the NCNC party?",
    "opt1": "Michael Imoudu",
    "opt2": "Nnamdi Azikiwe",
    "opt3": "Olusegun Obasanjo",
    "opt4": "Emeka Ojukwu",
    "correct": 2
  }
]
chapter9 = [
  {
    "question": "What was the mainstay of the pre-colonial Nigerian economy?",
    "opt1": "Mining",
    "opt2": "Agriculture",
    "opt3": "Manufacturing",
    "opt4": "Banking",
    "correct": 2
  },
  {
    "question": "What economic system came before the use of money in pre-colonial Nigeria?",
    "opt1": "Capitalism",
    "opt2": "Feudalism",
    "opt3": "Trade by barter",
    "opt4": "Colonial commerce",
    "correct": 3
  },
  {
    "question": "Intra-state trade involves:",
    "opt1": "Trading across the Sahara",
    "opt2": "Trade within the same state or cultural region",
    "opt3": "Foreign trade agreements",
    "opt4": "Digital trading platforms",
    "correct": 2
  },
  {
    "question": "Which item was NOT commonly traded in pre-colonial Nigerian local markets?",
    "opt1": "Cassava",
    "opt2": "Yams",
    "opt3": "Laptops",
    "opt4": "Millet",
    "correct": 3
  },
  {
    "question": "Regional trade networks allowed communities to:",
    "opt1": "Avoid trade entirely",
    "opt2": "Trade within families only",
    "opt3": "Specialize and exchange surplus goods",
    "opt4": "Use only digital currency",
    "correct": 3
  },
  {
    "question": "Middlemen in pre-colonial trade served primarily to:",
    "opt1": "Enforce laws",
    "opt2": "Link producers with consumers",
    "opt3": "Manage colonial taxes",
    "opt4": "Replace traders",
    "correct": 2
  },
  {
    "question": "Who controlled long-distance trading enterprises?",
    "opt1": "Farmers",
    "opt2": "Artisans",
    "opt3": "Merchants",
    "opt4": "Local chiefs",
    "correct": 3
  },
  {
    "question": "Which of these was a major coastal trade hub in pre-colonial Nigeria?",
    "opt1": "Benin City",
    "opt2": "Kano",
    "opt3": "Sokoto",
    "opt4": "Ilorin",
    "correct": 1
  },
  {
    "question": "The Trans-Saharan trade route connected Nigeria to:",
    "opt1": "Asia",
    "opt2": "South Africa",
    "opt3": "North Africa",
    "opt4": "The Caribbean",
    "correct": 3
  },
  {
    "question": "Which animal was vital for trans-Saharan trade?",
    "opt1": "Horse",
    "opt2": "Camel",
    "opt3": "Donkey",
    "opt4": "Cow",
    "correct": 2
  },

  {
    "question": "Which of these was a luxury item traded in pre-colonial Nigeria?",
    "opt1": "Yams",
    "opt2": "Millet",
    "opt3": "Cowrie shells",
    "opt4": "Palm kernels",
    "correct": 3
  },
  {
    "question": "What role did local markets play apart from commerce?",
    "opt1": "Military training",
    "opt2": "Colonial planning",
    "opt3": "Social bonding and cultural exchange",
    "opt4": "Education reforms",
    "correct": 3
  },
  {
    "question": "Merchants often dealt in:",
    "opt1": "Single household items",
    "opt2": "Minor domestic tools",
    "opt3": "Bulk trade across regions",
    "opt4": "Only religious artifacts",
    "correct": 3
  },
  {
    "question": "Which cities were notable for regional commerce?",
    "opt1": "Ibadan, Kano, Onitsha",
    "opt2": "Lagos, London, New York",
    "opt3": "Abuja, Port Harcourt, Uyo",
    "opt4": "Jos, Bauchi, Calabar",
    "correct": 1
  },
  {
    "question": "What economic concept explains exchange of goods without money?",
    "opt1": "Inflation",
    "opt2": "Trade by barter",
    "opt3": "Recession",
    "opt4": "Profit-making",
    "correct": 2
  },
  {
    "question": "Which of the following was a significant export item?",
    "opt1": "Television",
    "opt2": "Textiles",
    "opt3": "Plastic",
    "opt4": "Chalk",
    "correct": 2
  },
  {
    "question": "Which group helped circulate goods and ideas between communities?",
    "opt1": "Warriors",
    "opt2": "Traders",
    "opt3": "Colonists",
    "opt4": "Pastors",
    "correct": 2
  },
  {
    "question": "What impact did trade have on social status in pre-colonial Nigeria?",
    "opt1": "No effect",
    "opt2": "Decreased it",
    "opt3": "Increased wealth and influence",
    "opt4": "Reduced political power",
    "correct": 3
  },
  {
    "question": "What kind of trade occurred between Igbo and Hausa regions?",
    "opt1": "Intra-state",
    "opt2": "Digital",
    "opt3": "Inter-state",
    "opt4": "Prohibited",
    "correct": 3
  },
  {
    "question": "Palm oil served as:",
    "opt1": "Religious item",
    "opt2": "Food and trade commodity",
    "opt3": "Ornament",
    "opt4": "Construction tool",
    "correct": 2
  },

  {
    "question": "Which of these was not traded in the pre-colonial period?",
    "opt1": "Gold",
    "opt2": "Ivory",
    "opt3": "Smartphones",
    "opt4": "Kola nuts",
    "correct": 3
  },
  {
    "question": "Why was trade important for cultural interaction?",
    "opt1": "It reduced movement",
    "opt2": "It promoted isolation",
    "opt3": "It fostered exchange of ideas and customs",
    "opt4": "It restricted language spread",
    "correct": 3
  },
  {
    "question": "Which group controlled long-distance trade networks?",
    "opt1": "Chiefs",
    "opt2": "Farmers",
    "opt3": "Craftsmen",
    "opt4": "Merchants",
    "correct": 4
  },
  {
    "question": "Which market type was held on specific days in towns?",
    "opt1": "International market",
    "opt2": "Local market",
    "opt3": "Virtual market",
    "opt4": "Modern market",
    "correct": 2
  },
  {
    "question": "What effect did trade have on urbanization?",
    "opt1": "Created schools",
    "opt2": "Encouraged rural life",
    "opt3": "Led to formation of market towns",
    "opt4": "Discouraged movement",
    "correct": 3
  },
  {
    "question": "Which was used as currency?",
    "opt1": "Ivory",
    "opt2": "Yam tubers",
    "opt3": "Cowries",
    "opt4": "Salt blocks",
    "correct": 3
  },
  {
    "question": "Which trade route connected Nigeria with Europe?",
    "opt1": "Trans-Saharan",
    "opt2": "Inland trails",
    "opt3": "Coastal maritime routes",
    "opt4": "Forest tracks",
    "correct": 3
  },
  {
    "question": "Trade encouraged specialization based on:",
    "opt1": "Gender",
    "opt2": "Environmental conditions",
    "opt3": "Social class",
    "opt4": "Religious belief",
    "correct": 2
  },
  {
    "question": "Women in trade contributed significantly through:",
    "opt1": "Warrior roles",
    "opt2": "Metal forging",
    "opt3": "Craft production and food sales",
    "opt4": "Architectural design",
    "correct": 3
  },
  {
    "question": "What was a key limitation of the barter system?",
    "opt1": "Too much money",
    "opt2": "Lack of double coincidence of wants",
    "opt3": "Internet failure",
    "opt4": "Labor union resistance",
    "correct": 2
  }
]
chapter10 = [
  {
    "question": "When did Nigeria experience its first military coup?",
    "opt1": "October 1, 1960",
    "opt2": "January 15, 1966",
    "opt3": "July 29, 1975",
    "opt4": "December 31, 1983",
    "correct": 2
  },
  {
    "question": "Who led Nigeria's first military coup?",
    "opt1": "General Ironsi",
    "opt2": "Major Chukwuma Kaduna Nzeogwu",
    "opt3": "General Obasanjo",
    "opt4": "General Buhari",
    "correct": 2
  },
  {
    "question": "Which Nigerian leader was overthrown in the 1966 coup?",
    "opt1": "Obafemi Awolowo",
    "opt2": "Sir Ahmadu Bello",
    "opt3": "Alhaji Tafawa Balewa",
    "opt4": "General Yakubu Gowon",
    "correct": 3
  },
  {
    "question": "What major event followed the July 1966 counter-coup?",
    "opt1": "Democratic elections",
    "opt2": "Civil war",
    "opt3": "Independence",
    "opt4": "Oil boom",
    "correct": 2
  },
  {
    "question": "Who became Head of State after General Ironsi was killed?",
    "opt1": "General Murtala Mohammed",
    "opt2": "General Obasanjo",
    "opt3": "Lt. Col. Yakubu Gowon",
    "opt4": "General Buhari",
    "correct": 3
  },
  {
    "question": "Which leader was overthrown in the 1975 coup?",
    "opt1": "Yakubu Gowon",
    "opt2": "Murtala Mohammed",
    "opt3": "Shehu Shagari",
    "opt4": "Nnamdi Azikiwe",
    "correct": 1
  },
  {
    "question": "The 1976 coup resulted in the assassination of:",
    "opt1": "Obasanjo",
    "opt2": "Murtala Mohammed",
    "opt3": "Babangida",
    "opt4": "Shonekan",
    "correct": 2
  },
  {
    "question": "What justification is often used for military coups?",
    "opt1": "Promotion of tourism",
    "opt2": "Lack of military power",
    "opt3": "Corrective regime",
    "opt4": "Religious conversion",
    "correct": 3
  },
  {
    "question": "Which of these is NOT a reason for military intervention?",
    "opt1": "Tribalism",
    "opt2": "Economic mismanagement",
    "opt3": "Religious freedom",
    "opt4": "Corruption",
    "correct": 3
  },
  {
    "question": "Which military leader annulled the June 12, 1993 election?",
    "opt1": "Sani Abacha",
    "opt2": "Babangida",
    "opt3": "Shonekan",
    "opt4": "Obasanjo",
    "correct": 2
  },

  {
    "question": "Who led the 1983 coup that overthrew Shehu Shagari?",
    "opt1": "General Babangida",
    "opt2": "General Buhari",
    "opt3": "General Ironsi",
    "opt4": "General Abacha",
    "correct": 2
  },
  {
    "question": "The 1990 coup attempt was led by:",
    "opt1": "Mamman Vatsa",
    "opt2": "Sani Abacha",
    "opt3": "Gideon Orkar",
    "opt4": "Yakubu Gowon",
    "correct": 3
  },
  {
    "question": "Which of the following was a consequence of military rule?",
    "opt1": "Increased freedom of speech",
    "opt2": "Rule of law",
    "opt3": "Political suppression",
    "opt4": "Stable economy",
    "correct": 3
  },
  {
    "question": "What positive reform is credited to military rule?",
    "opt1": "Formation of ECOWAS",
    "opt2": "Execution of civil war",
    "opt3": "End of democracy",
    "opt4": "Dissolution of judiciary",
    "correct": 2
  },
  {
    "question": "What major economic policy was introduced under Babangida?",
    "opt1": "Trade liberalization",
    "opt2": "Structural Adjustment Programme",
    "opt3": "Free lunch policy",
    "opt4": "Nationalization of banks",
    "correct": 2
  },
  {
    "question": "The 1993 palace coup was led by:",
    "opt1": "Obasanjo",
    "opt2": "Abacha",
    "opt3": "Gowon",
    "opt4": "Murtala",
    "correct": 2
  },
  {
    "question": "Military rule discouraged what type of investment?",
    "opt1": "Foreign aid",
    "opt2": "Private investment",
    "opt3": "Donations",
    "opt4": "IMF loans",
    "correct": 2
  },
  {
    "question": "Which constitution did the military help implement in 1999?",
    "opt1": "1990 Constitution",
    "opt2": "1979 Constitution",
    "opt3": "2023 Constitution",
    "opt4": "1999 Constitution",
    "correct": 4
  },
  {
    "question": "What was General Ironsi accused of planning in 1966?",
    "opt1": "Return to British rule",
    "opt2": "Unification Decree No. 34",
    "opt3": "New educational policy",
    "opt4": "Relocation of capital",
    "correct": 2
  },
  {
    "question": "The 1985 coup that removed Buhari was led by:",
    "opt1": "Obasanjo",
    "opt2": "Gowon",
    "opt3": "Babangida",
    "opt4": "Orkar",
    "correct": 3
  },

  {
    "question": "Who succeeded General Murtala Mohammed?",
    "opt1": "General Buhari",
    "opt2": "General Obasanjo",
    "opt3": "General Babangida",
    "opt4": "General Ironsi",
    "correct": 2
  },
  {
    "question": "What type of governance did military rule eliminate?",
    "opt1": "Authoritarianism",
    "opt2": "Oligarchy",
    "opt3": "Democracy",
    "opt4": "Communism",
    "correct": 3
  },
  {
    "question": "Which officer was executed in 1985 over an abortive coup?",
    "opt1": "Yakubu Gowon",
    "opt2": "Mamman Vatsa",
    "opt3": "Sani Abacha",
    "opt4": "Olusegun Obasanjo",
    "correct": 2
  },
  {
    "question": "The military claimed to act as a ______ regime.",
    "opt1": "Progressive",
    "opt2": "Corrective",
    "opt3": "Repressive",
    "opt4": "Revolutionary",
    "correct": 2
  },
  {
    "question": "Military governments often suspended what?",
    "opt1": "Banking systems",
    "opt2": "University exams",
    "opt3": "Constitution and parliament",
    "opt4": "Electricity supply",
    "correct": 3
  },
  {
    "question": "One economic failure under military rule was:",
    "opt1": "Job creation",
    "opt2": "Infrastructure growth",
    "opt3": "Private investment encouragement",
    "opt4": "Resource mismanagement",
    "correct": 4
  },
  {
    "question": "Which Nigerian leader ruled as a self-appointed president?",
    "opt1": "Gowon",
    "opt2": "Obasanjo",
    "opt3": "Babangida",
    "opt4": "Shagari",
    "correct": 3
  },
  {
    "question": "The military era in Nigeria spanned from 1966 to:",
    "opt1": "1985",
    "opt2": "1993",
    "opt3": "1999",
    "opt4": "2003",
    "correct": 3
  },
  {
    "question": "One positive impact of military rule was:",
    "opt1": "Complete dictatorship",
    "opt2": "Creation of new states",
    "opt3": "Abolishment of education",
    "opt4": "Elimination of taxes",
    "correct": 2
  },
  {
    "question": "What major civil society challenge did military rule face?",
    "opt1": "Support from civil societies",
    "opt2": "Agitations from pressure groups",
    "opt3": "High voter turnout",
    "opt4": "International recognition",
    "correct": 2
  }
]
chapter11 = [
  {
    "question": "What is the central theme of Chapter 11?",
    "opt1": "Technology in Nigeria",
    "opt2": "Moral problems in post-colonial Nigeria",
    "opt3": "Economy of Nigeria",
    "opt4": "Nigeria’s independence struggle",
    "correct": 2
  },
  {
    "question": "Which of the following is NOT a moral problem identified in post-colonial Nigeria?",
    "opt1": "Corruption",
    "opt2": "Nepotism",
    "opt3": "Climate change",
    "opt4": "Cultism",
    "correct": 3
  },
  {
    "question": "What period is referred to as 'post-colonial Nigeria'?",
    "opt1": "Before British rule",
    "opt2": "After independence in 1960",
    "opt3": "During slave trade",
    "opt4": "During civil war",
    "correct": 2
  },
  {
    "question": "Which moral virtue was highly cherished in pre-colonial Nigeria?",
    "opt1": "Greed",
    "opt2": "Corruption",
    "opt3": "Honesty",
    "opt4": "Pride",
    "correct": 3
  },
  {
    "question": "What replaced communal values after colonialism?",
    "opt1": "Altruism",
    "opt2": "Socialism",
    "opt3": "Extreme individualism",
    "opt4": "Religious devotion",
    "correct": 3
  },
  {
    "question": "Which of the following values is NOT moral?",
    "opt1": "Justice",
    "opt2": "Honesty",
    "opt3": "Integrity",
    "opt4": "Dishonesty",
    "correct": 4
  },
  {
    "question": "What is the root cause of moral problems according to the chapter?",
    "opt1": "Religion",
    "opt2": "Education",
    "opt3": "Extreme individualism",
    "opt4": "Technology",
    "correct": 3
  },
  {
    "question": "What principle involves doing what is right regardless of consequences?",
    "opt1": "Cowardice",
    "opt2": "Courage",
    "opt3": "Greed",
    "opt4": "Fraud",
    "correct": 2
  },
  {
    "question": "What major vice affects schools in post-colonial Nigeria?",
    "opt1": "Indiscipline",
    "opt2": "Innovation",
    "opt3": "Overpopulation",
    "opt4": "Infrastructure",
    "correct": 1
  },
  {
    "question": "What is the purpose of the ‘War Against Indiscipline’ campaign?",
    "opt1": "Encourage protests",
    "opt2": "Fight tribalism",
    "opt3": "Promote discipline and moral values",
    "opt4": "Create jobs",
    "correct": 3
  },

  {
    "question": "Which administration launched MAMSER?",
    "opt1": "Goodluck Jonathan",
    "opt2": "Shehu Shagari",
    "opt3": "Ibrahim Babangida",
    "opt4": "Olusegun Obasanjo",
    "correct": 3
  },
  {
    "question": "Which agency was NOT created to fight corruption?",
    "opt1": "EFCC",
    "opt2": "ICPC",
    "opt3": "NCC",
    "opt4": "Code of Conduct Bureau",
    "correct": 3
  },
  {
    "question": "What does ICPC stand for?",
    "opt1": "Independent Corrupt Practices Commission",
    "opt2": "Internal Court for Public Cases",
    "opt3": "International Criminal Police",
    "opt4": "Integrated Corruption Prevention Commission",
    "correct": 1
  },
  {
    "question": "What is the main reason corruption persists in Nigeria?",
    "opt1": "Social condemnation",
    "opt2": "Low education",
    "opt3": "Lack of moral character among leaders",
    "opt4": "Foreign intervention",
    "correct": 3
  },
  {
    "question": "Which of these is considered a moral virtue?",
    "opt1": "Greed",
    "opt2": "Integrity",
    "opt3": "Fraud",
    "opt4": "Pride",
    "correct": 2
  },
  {
    "question": "What is a key strategy to solving moral problems in Nigeria?",
    "opt1": "Privatization",
    "opt2": "Moral re-education and sanctions",
    "opt3": "Emigration",
    "opt4": "Cultural isolation",
    "correct": 2
  },
  {
    "question": "What is the implication of moral decay on national development?",
    "opt1": "Rapid growth",
    "opt2": "Stable economy",
    "opt3": "Sustainable peace",
    "opt4": "Threat to development",
    "correct": 4
  },
  {
    "question": "What does TSA stand for in Nigeria’s financial system?",
    "opt1": "Total Savings Account",
    "opt2": "Treasury Single Account",
    "opt3": "Transport Security Act",
    "opt4": "Target Savings Allocation",
    "correct": 2
  },
  {
    "question": "Which moral virtue emphasizes putting others first?",
    "opt1": "Selfishness",
    "opt2": "Service to others",
    "opt3": "Pride",
    "opt4": "Greed",
    "correct": 2
  },
  {
    "question": "What principle ensures treating others fairly?",
    "opt1": "Justice",
    "opt2": "Power",
    "opt3": "Favoritism",
    "opt4": "Segregation",
    "correct": 1
  },

  {
    "question": "What moral lapse is widespread in education?",
    "opt1": "Exam honesty",
    "opt2": "Exam malpractice",
    "opt3": "Student activism",
    "opt4": "Healthy competition",
    "correct": 2
  },
  {
    "question": "What societal approach encourages corruption according to Maduagwu?",
    "opt1": "Religious discipline",
    "opt2": "Ethical modeling",
    "opt3": "Social acceptance of corruption",
    "opt4": "Judicial transparency",
    "correct": 3
  },
  {
    "question": "What does NEITI focus on?",
    "opt1": "Tourism",
    "opt2": "Oil and extractive transparency",
    "opt3": "Immigration",
    "opt4": "Education",
    "correct": 2
  },
  {
    "question": "Which principle refers to moral uprightness?",
    "opt1": "Honesty",
    "opt2": "Compromise",
    "opt3": "Fraud",
    "opt4": "Bribery",
    "correct": 1
  },
  {
    "question": "What factor has eroded Nigeria’s communal values?",
    "opt1": "Urban development",
    "opt2": "Western individualism",
    "opt3": "Traditional education",
    "opt4": "Colonial taxation",
    "correct": 2
  },
  {
    "question": "The 'Golden Rule' is an example of which principle?",
    "opt1": "Power",
    "opt2": "Reciprocal respect",
    "opt3": "Favoritism",
    "opt4": "Obedience",
    "correct": 2
  },
  {
    "question": "What vice is involved in ‘money for marks’?",
    "opt1": "Hard work",
    "opt2": "Academic fraud",
    "opt3": "Moral rearmament",
    "opt4": "Discipline",
    "correct": 2
  },
  {
    "question": "One major goal of moral education is to:",
    "opt1": "Encourage silence",
    "opt2": "Disregard history",
    "opt3": "Guide right and wrong choices",
    "opt4": "Promote selfish gain",
    "correct": 3
  },
  {
    "question": "What is the role of educational institutions in moral renewal?",
    "opt1": "Build schools",
    "opt2": "Promote tribalism",
    "opt3": "Model and teach virtues",
    "opt4": "Recruit politicians",
    "correct": 3
  },
  {
    "question": "What kind of punishment is recommended for moral offenses?",
    "opt1": "Rewards",
    "opt2": "Silence",
    "opt3": "Social sanctions",
    "opt4": "Compensation",
    "correct": 3
  }
]
chapter12 = [
  {
    "question": "What is one of the major environmental problems in Nigeria?",
    "opt1": "Snowfall",
    "opt2": "Erosion",
    "opt3": "Tornadoes",
    "opt4": "Earthquakes",
    "correct": 2
  },
  {
    "question": "Which agency defines environment as including water, air, land, and living beings?",
    "opt1": "NEMA",
    "opt2": "EFCC",
    "opt3": "Federal Environmental Protection Agency",
    "opt4": "Nigerian Meteorological Agency",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT a type of environmental issue discussed?",
    "opt1": "Pollution",
    "opt2": "Erosion",
    "opt3": "Deforestation",
    "opt4": "Volcanic eruption",
    "correct": 4
  },
  {
    "question": "Air pollution in Nigeria is mainly caused by:",
    "opt1": "Solar panels",
    "opt2": "Traffic emissions and agricultural burning",
    "opt3": "Clean energy",
    "opt4": "Fishing activities",
    "correct": 2
  },
  {
    "question": "What is a common effect of indiscriminate waste disposal?",
    "opt1": "Street beautification",
    "opt2": "Clean environment",
    "opt3": "Blocked drainage",
    "opt4": "Free flowing traffic",
    "correct": 3
  },
  {
    "question": "Which material significantly contributes to Nigeria’s refuse problem?",
    "opt1": "Metal",
    "opt2": "Plastic",
    "opt3": "Glass",
    "opt4": "Wood",
    "correct": 2
  },
  {
    "question": "What type of environmental issue involves the removal of topsoil?",
    "opt1": "Flooding",
    "opt2": "Erosion",
    "opt3": "Desertification",
    "opt4": "Bush burning",
    "correct": 2
  },
  {
    "question": "What disaster is worsened by blocked drainage in cities?",
    "opt1": "Erosion",
    "opt2": "Flooding",
    "opt3": "Drought",
    "opt4": "Earthquake",
    "correct": 2
  },
  {
    "question": "Which is NOT a cause of deforestation?",
    "opt1": "Tree planting",
    "opt2": "Logging",
    "opt3": "Urbanization",
    "opt4": "Agricultural expansion",
    "correct": 1
  },
  {
    "question": "Which of the following is a social issue in Nigeria?",
    "opt1": "Good governance",
    "opt2": "Poverty",
    "opt3": "Environmental sustainability",
    "opt4": "Flood control",
    "correct": 2
  },

  {
    "question": "According to 2023 data, what percentage of Nigerians were classified as poor?",
    "opt1": "10.1%",
    "opt2": "25.5%",
    "opt3": "40.1%",
    "opt4": "60.4%",
    "correct": 3
  },
  {
    "question": "Which university was associated with the origin of cultism in Nigeria?",
    "opt1": "University of Abuja",
    "opt2": "University of Nigeria",
    "opt3": "Obafemi Awolowo University",
    "opt4": "University of Lagos",
    "correct": 2
  },
  {
    "question": "Which substance is classified as a psychoactive drug?",
    "opt1": "Water",
    "opt2": "Vitamin C",
    "opt3": "Cocaine",
    "opt4": "Salt",
    "correct": 3
  },
  {
    "question": "Internet fraud in Nigeria is commonly referred to as:",
    "opt1": "Gmailing",
    "opt2": "Yahoo Yahoo",
    "opt3": "Web Walking",
    "opt4": "Net Theft",
    "correct": 2
  },
  {
    "question": "Which of these is an effect of corruption?",
    "opt1": "Economic growth",
    "opt2": "Public trust",
    "opt3": "Disinvestment",
    "opt4": "Public satisfaction",
    "correct": 3
  },
  {
    "question": "Deforestation increases the level of which harmful gas?",
    "opt1": "Oxygen",
    "opt2": "Nitrogen",
    "opt3": "Carbon dioxide",
    "opt4": "Hydrogen",
    "correct": 3
  },
  {
    "question": "What major social problem results in youth restiveness?",
    "opt1": "Employment",
    "opt2": "Entrepreneurship",
    "opt3": "Youth unemployment",
    "opt4": "Sports activities",
    "correct": 3
  },
  {
    "question": "Which of the following is a psychological effect of insecurity?",
    "opt1": "Joy",
    "opt2": "Fear and anxiety",
    "opt3": "Excitement",
    "opt4": "Confidence",
    "correct": 2
  },
  {
    "question": "A major consequence of oil pollution is:",
    "opt1": "Improved farming",
    "opt2": "Clean rivers",
    "opt3": "Environmental degradation",
    "opt4": "Increase in aquatic life",
    "correct": 3
  },
  {
    "question": "What is one major cause of flooding in Nigerian cities?",
    "opt1": "Street dancing",
    "opt2": "Blocked drainage",
    "opt3": "Low rainfall",
    "opt4": "Tree planting",
    "correct": 2
  },

  {
    "question": "What can help reduce plastic pollution?",
    "opt1": "Throwing plastics in rivers",
    "opt2": "Reusing and recycling plastics",
    "opt3": "Burning plastic openly",
    "opt4": "Burying plastics randomly",
    "correct": 2
  },
  {
    "question": "Which term best describes unequal access to social services?",
    "opt1": "Urbanization",
    "opt2": "Social equality",
    "opt3": "Socio-economic disparity",
    "opt4": "Technological development",
    "correct": 3
  },
  {
    "question": "What activity worsens desertification?",
    "opt1": "Rainfall",
    "opt2": "Tree planting",
    "opt3": "Bush burning",
    "opt4": "Cloud seeding",
    "correct": 3
  },
  {
    "question": "Which is a major contributor to environmental degradation in the North?",
    "opt1": "Overfishing",
    "opt2": "Oil spill",
    "opt3": "Land depletion and grazing conflicts",
    "opt4": "Ocean currents",
    "correct": 3
  },
  {
    "question": "A major cause of political instability is:",
    "opt1": "Food surplus",
    "opt2": "Transparency",
    "opt3": "Elite power struggles",
    "opt4": "Ethical leadership",
    "correct": 3
  },
  {
    "question": "Which region is mentioned as oil-rich but underdeveloped?",
    "opt1": "Middle Belt",
    "opt2": "Niger Delta",
    "opt3": "South West",
    "opt4": "North Central",
    "correct": 2
  },
  {
    "question": "Which of the following is a technological crime discussed?",
    "opt1": "Cyber-bullying",
    "opt2": "Internet fraud",
    "opt3": "Digital marketing",
    "opt4": "Network installation",
    "correct": 2
  },
  {
    "question": "The term 'Yahoo Yahoo' refers to:",
    "opt1": "Online learning",
    "opt2": "E-commerce",
    "opt3": "Cyber fraud",
    "opt4": "Programming language",
    "correct": 3
  },
  {
    "question": "What is the purpose of proper waste management?",
    "opt1": "Increase littering",
    "opt2": "Support pollution",
    "opt3": "Reduce environmental degradation",
    "opt4": "Encourage illegal dumping",
    "correct": 3
  },
  {
    "question": "A major solution to educational challenges in Nigeria is:",
    "opt1": "Increasing holidays",
    "opt2": "Curriculum review and funding",
    "opt3": "Reducing schools",
    "opt4": "Prohibiting private schools",
    "correct": 2
  },
  {
    "question": "What can be a direct result of deforestation?",
    "opt1": "Cool climate",
    "opt2": "Desertification",
    "opt3": "Fresh air",
    "opt4": "Biodiversity preservation",
    "correct": 2
  }
]
chapter13 = [
  {
    "question": "Who amalgamated Northern and Southern Nigeria in 1914?",
    "opt1": "Herbert Macaulay",
    "opt2": "Lord Lugard",
    "opt3": "Sir Macpherson",
    "opt4": "Obafemi Awolowo",
    "correct": 2
  },
  {
    "question": "What was the aim of the 1914 amalgamation?",
    "opt1": "Separate development",
    "opt2": "Unite diverse groups into one political entity",
    "opt3": "Increase British trade",
    "opt4": "Build railways",
    "correct": 2
  },
  {
    "question": "Nation-building involves all EXCEPT:",
    "opt1": "Creating a shared sense of purpose",
    "opt2": "Fostering division",
    "opt3": "Developing institutions",
    "opt4": "Replacing regional with national identity",
    "correct": 2
  },
  {
    "question": "What is the greatest challenge to nation-building in Nigeria?",
    "opt1": "Natural disasters",
    "opt2": "Ethno-religious differences",
    "opt3": "Border issues",
    "opt4": "Climate",
    "correct": 2
  },
  {
    "question": "Which group issued the 'quit notice' to the Igbos in 2017?",
    "opt1": "OPC",
    "opt2": "Arewa Youths",
    "opt3": "MASSOB",
    "opt4": "Boko Haram",
    "correct": 2
  },
  {
    "question": "Nation-building is considered a _____ endeavor.",
    "opt1": "Government-only",
    "opt2": "Military",
    "opt3": "People",
    "opt4": "Religious",
    "correct": 3
  },
  {
    "question": "Which of the following is a nation-building institution?",
    "opt1": "Nightclub",
    "opt2": "Judiciary",
    "opt3": "Market",
    "opt4": "Cinema",
    "correct": 2
  },
  {
    "question": "Ethnic relations in Nigeria are often marked by:",
    "opt1": "Unity",
    "opt2": "Love",
    "opt3": "Mistrust and hostility",
    "opt4": "Economic cooperation",
    "correct": 3
  },
  {
    "question": "The phrase 'divide and rule' refers to which colonial strategy?",
    "opt1": "Unification",
    "opt2": "Inclusive governance",
    "opt3": "Administrative segregation",
    "opt4": "Power sharing",
    "correct": 3
  },
  {
    "question": "The rise of Boko Haram is linked to what challenge?",
    "opt1": "Tourism development",
    "opt2": "Religious extremism",
    "opt3": "Infrastructure growth",
    "opt4": "Urbanization",
    "correct": 2
  },

  {
    "question": "Which three groups dominate Nigeria’s ethnic landscape?",
    "opt1": "Ijaw, Kanuri, Tiv",
    "opt2": "Yoruba, Igbo, Hausa-Fulani",
    "opt3": "Efik, Igala, Tiv",
    "opt4": "Gwari, Idoma, Ika",
    "correct": 2
  },
  {
    "question": "A significant cause of Nigeria’s internal disunity is:",
    "opt1": "Weather conditions",
    "opt2": "Ethnic nationalism",
    "opt3": "Road construction",
    "opt4": "Media control",
    "correct": 2
  },
  {
    "question": "Why has common nationality failed to emerge in Nigeria?",
    "opt1": "High birth rate",
    "opt2": "Shared language",
    "opt3": "Strong ethnic loyalty",
    "opt4": "Free education",
    "correct": 3
  },
  {
    "question": "Which body caused major disruption to Nigeria's democracy from 1966 to 1999?",
    "opt1": "Police force",
    "opt2": "Traditional rulers",
    "opt3": "Military",
    "opt4": "Legislature",
    "correct": 3
  },
  {
    "question": "Who was forced to step down in 1993 by the military?",
    "opt1": "Olusegun Obasanjo",
    "opt2": "Goodluck Jonathan",
    "opt3": "Ernest Shonekan",
    "opt4": "Shehu Shagari",
    "correct": 3
  },
  {
    "question": "Which terrorist group threatens Nigeria’s unity?",
    "opt1": "Al-Qaeda",
    "opt2": "MEND",
    "opt3": "Boko Haram",
    "opt4": "MOSSAD",
    "correct": 3
  },
  {
    "question": "The politicization of religion is evident in:",
    "opt1": "Introduction of VAT",
    "opt2": "Use of Sharia Law",
    "opt3": "NYSC postings",
    "opt4": "Food bans",
    "correct": 2
  },
  {
    "question": "Ethnic militias affect nation-building by:",
    "opt1": "Providing security",
    "opt2": "Teaching unity",
    "opt3": "Fueling distrust",
    "opt4": "Promoting elections",
    "correct": 3
  },
  {
    "question": "What is a key requirement for successful nation-building?",
    "opt1": "Dictatorship",
    "opt2": "Shared identity",
    "opt3": "Importation",
    "opt4": "Religious supremacy",
    "correct": 2
  },
  {
    "question": "Who emphasized the need to shift loyalty from tribes to central government?",
    "opt1": "Dare et al.",
    "opt2": "Lord Lugard",
    "opt3": "Almond & Powell",
    "opt4": "Obasanjo",
    "correct": 3
  },

  {
    "question": "Which of the following undermines Nigeria’s development?",
    "opt1": "Good leadership",
    "opt2": "Equal distribution of wealth",
    "opt3": "Corruption",
    "opt4": "Nationwide elections",
    "correct": 3
  },
  {
    "question": "The lack of consensus on development has led to:",
    "opt1": "Infrastructure growth",
    "opt2": "Unity",
    "opt3": "Ethnic harmony",
    "opt4": "National stagnation",
    "correct": 4
  },
  {
    "question": "Why do many Nigerians prioritize ethnic identity over national identity?",
    "opt1": "High GDP",
    "opt2": "Sports rivalry",
    "opt3": "Lack of trust and inclusion",
    "opt4": "Weather conditions",
    "correct": 3
  },
  {
    "question": "Which policy tool is ineffective without national unity?",
    "opt1": "Budget planning",
    "opt2": "Affirmative action",
    "opt3": "Food importation",
    "opt4": "Foreign policy",
    "correct": 2
  },
  {
    "question": "Which ethnic group is dominant in Northern Nigeria?",
    "opt1": "Yoruba",
    "opt2": "Hausa-Fulani",
    "opt3": "Igbo",
    "opt4": "Ijaw",
    "correct": 2
  },
  {
    "question": "Nation-building also includes development of what?",
    "opt1": "Arms",
    "opt2": "Religious centers",
    "opt3": "Institutions and infrastructure",
    "opt4": "Fashion industry",
    "correct": 3
  },
  {
    "question": "The 1982 and 1992 Kaduna crises were examples of:",
    "opt1": "Floods",
    "opt2": "Economic protests",
    "opt3": "Ethno-religious conflict",
    "opt4": "Student riots",
    "correct": 3
  },
  {
    "question": "What does the term 'nation' typically signify?",
    "opt1": "An area with a single religion",
    "opt2": "A collection of people with shared identity",
    "opt3": "An economic region",
    "opt4": "Only indigenous people",
    "correct": 2
  },
  {
    "question": "Who said nation-building must involve political, legal and civic institutions?",
    "opt1": "Smith",
    "opt2": "Walker",
    "opt3": "Gambari",
    "opt4": "Buhari",
    "correct": 3
  },
  {
    "question": "What is a key cause of leadership failure in Nigeria?",
    "opt1": "Bad weather",
    "opt2": "Too many educated people",
    "opt3": "Inability to manage diversity",
    "opt4": "Overseas investment",
    "correct": 3
  }
]
chapter14 = [
  {
    "question": "What is the main goal of reorientation strategies in Nigeria?",
    "opt1": "Promote tourism",
    "opt2": "Achieve food security only",
    "opt3": "Instill discipline, patriotism, and national development",
    "opt4": "Encourage emigration",
    "correct": 3
  },
  {
    "question": "Operation Feed the Nation (OFN) was launched in which year?",
    "opt1": "1970",
    "opt2": "1983",
    "opt3": "1999",
    "opt4": "1976",
    "correct": 4
  },
  {
    "question": "Who initiated the Operation Feed the Nation program?",
    "opt1": "Shehu Shagari",
    "opt2": "Olusegun Obasanjo",
    "opt3": "Ibrahim Babangida",
    "opt4": "Goodluck Jonathan",
    "correct": 2
  },
  {
    "question": "What was the central focus of OFN?",
    "opt1": "Military training",
    "opt2": "Oil exports",
    "opt3": "Agricultural self-sufficiency",
    "opt4": "Urbanization",
    "correct": 3
  },
  {
    "question": "Which campaign was launched by Buhari’s military government in 1983?",
    "opt1": "Operation Feed the Nation",
    "opt2": "MAMSER",
    "opt3": "War Against Indiscipline (WAI)",
    "opt4": "Green Revolution",
    "correct": 3
  },
  {
    "question": "What did MAMSER aim to achieve?",
    "opt1": "Build roads",
    "opt2": "Economic diversification",
    "opt3": "Moral and ethical reorientation",
    "opt4": "Privatize public firms",
    "correct": 3
  },
  {
    "question": "Which of these was a criticism of MAMSER?",
    "opt1": "Excessive funding",
    "opt2": "Focus on sports",
    "opt3": "Limited rural reach",
    "opt4": "Promotion of tribalism",
    "correct": 3
  },
  {
    "question": "Which agency replaced MAMSER?",
    "opt1": "EFCC",
    "opt2": "NEMA",
    "opt3": "National Orientation Agency (NOA)",
    "opt4": "NCC",
    "correct": 3
  },
  {
    "question": "When was the NOA established?",
    "opt1": "1976",
    "opt2": "1983",
    "opt3": "1993",
    "opt4": "2005",
    "correct": 3
  },
  {
    "question": "What is the primary function of the NOA?",
    "opt1": "Tax collection",
    "opt2": "Promoting national values and unity",
    "opt3": "Border control",
    "opt4": "Export management",
    "correct": 2
  },

  {
    "question": "Which major policy document did the NOA launch in 2024?",
    "opt1": "Green Charter",
    "opt2": "National Growth Plan",
    "opt3": "National Values Charter",
    "opt4": "Military Budget",
    "correct": 3
  },
  {
    "question": "Which of the following is NOT one of the seven values in the Nigerian Promise?",
    "opt1": "Patriotism",
    "opt2": "Integrity",
    "opt3": "Dishonesty",
    "opt4": "Hard work",
    "correct": 3
  },
  {
    "question": "What method does NOA use to spread its message?",
    "opt1": "Classroom lectures only",
    "opt2": "Mass media and community engagement",
    "opt3": "Billboard adverts only",
    "opt4": "Textbooks",
    "correct": 2
  },
  {
    "question": "Value reorientation workshops are mainly targeted at:",
    "opt1": "Expatriates",
    "opt2": "Students and community leaders",
    "opt3": "Foreign investors",
    "opt4": "Prisoners",
    "correct": 2
  },
  {
    "question": "WAI used public shaming to enforce:",
    "opt1": "Prayer",
    "opt2": "Discipline",
    "opt3": "Worship",
    "opt4": "Voting",
    "correct": 2
  },
  {
    "question": "A major flaw of WAI was:",
    "opt1": "Too many volunteers",
    "opt2": "Lack of military support",
    "opt3": "Superficial change via force",
    "opt4": "Lack of mass media",
    "correct": 3
  },
  {
    "question": "NOA's workshops aim to promote values like:",
    "opt1": "Rebellion",
    "opt2": "Luxury",
    "opt3": "Integrity and unity",
    "opt4": "Disobedience",
    "correct": 3
  },
  {
    "question": "Which program succeeded OFN to continue agricultural reorientation?",
    "opt1": "Green Revolution",
    "opt2": "Agro Export Boost",
    "opt3": "Rural Livelihood Project",
    "opt4": "MAMSER",
    "correct": 1
  },
  {
    "question": "A major communication method of NOA is:",
    "opt1": "International journals",
    "opt2": "Town hall meetings",
    "opt3": "Diplomatic visits",
    "opt4": "Music concerts",
    "correct": 2
  },
  {
    "question": "Which value is emphasized in the Citizen Codes?",
    "opt1": "Laziness",
    "opt2": "Exclusiveness",
    "opt3": "Diligence",
    "opt4": "Revenge",
    "correct": 3
  },

  {
    "question": "Strategic Program Plan II (2021–2026) by NOA emphasizes:",
    "opt1": "Trade unions",
    "opt2": "Digital voting",
    "opt3": "Addressing insecurity and declining trust",
    "opt4": "Military campaigns",
    "correct": 3
  },
  {
    "question": "The NOA’s efforts include all EXCEPT:",
    "opt1": "Mass mobilization",
    "opt2": "Reorientation workshops",
    "opt3": "Jingles and media programs",
    "opt4": "Tax auditing",
    "correct": 4
  },
  {
    "question": "Which policy aimed to stabilize Nigeria’s economy through spending cuts?",
    "opt1": "NYSC",
    "opt2": "WAI",
    "opt3": "Austerity Measures (AM)",
    "opt4": "OFN",
    "correct": 3
  },
  {
    "question": "AM strategies often involve:",
    "opt1": "Infrastructure expansion",
    "opt2": "Public spending reduction",
    "opt3": "Free education",
    "opt4": "Job creation programs",
    "correct": 2
  },
  {
    "question": "The core challenge with Austerity Measures is:",
    "opt1": "Increased salaries",
    "opt2": "Decline in public service quality",
    "opt3": "Low taxes",
    "opt4": "More holidays",
    "correct": 2
  },
  {
    "question": "The use of corporal punishment in WAI raised concerns about:",
    "opt1": "Religious bias",
    "opt2": "Media censorship",
    "opt3": "Human rights",
    "opt4": "Grammar accuracy",
    "correct": 3
  },
  {
    "question": "A successful reorientation strategy must combine discipline with:",
    "opt1": "Force",
    "opt2": "Patronage",
    "opt3": "Community participation",
    "opt4": "Punishment",
    "correct": 3
  },
  {
    "question": "Who were mainly tasked with enforcing WAI codes in public?",
    "opt1": "Teachers",
    "opt2": "Soldiers",
    "opt3": "Volunteer brigades",
    "opt4": "Elected officials",
    "correct": 3
  },
  {
    "question": "What does the NOA aim to cultivate?",
    "opt1": "Social media influencers",
    "opt2": "Responsible and patriotic citizenry",
    "opt3": "Traders union",
    "opt4": "Student councils",
    "correct": 2
  },
  {
    "question": "Which of the following was launched to encourage food production?",
    "opt1": "OFN",
    "opt2": "WAI",
    "opt3": "VAT Act",
    "opt4": "SAP",
    "correct": 1
  }
]
chapter15 = [
  {
    "question": "What does skill acquisition primarily promote?",
    "opt1": "Political activism",
    "opt2": "Religious tolerance",
    "opt3": "Self-reliance and economic productivity",
    "opt4": "Foreign aid dependence",
    "correct": 3
  },
  {
    "question": "According to the chapter, what is considered Nigeria’s biggest concern?",
    "opt1": "Electricity supply",
    "opt2": "Youth skill acquisition for self-reliance",
    "opt3": "Religious conflict",
    "opt4": "Climate change",
    "correct": 2
  },
  {
    "question": "Which theory was propounded by Becker in 1962?",
    "opt1": "Human Capital Theory",
    "opt2": "Niche Theory",
    "opt3": "Self-Determination Theory",
    "opt4": "Social Contract Theory",
    "correct": 1
  },
  {
    "question": "What does the Self-Determination Theory emphasize?",
    "opt1": "External control",
    "opt2": "Autonomy and psychological needs",
    "opt3": "Market competition",
    "opt4": "Religious harmony",
    "correct": 2
  },
  {
    "question": "Which of the following is a key attribute of self-reliance?",
    "opt1": "Dependence",
    "opt2": "Creativity",
    "opt3": "Excuses",
    "opt4": "Pessimism",
    "correct": 2
  },
  {
    "question": "Technical or hard skills are best described as:",
    "opt1": "Interpersonal habits",
    "opt2": "Job-specific practical abilities",
    "opt3": "Theoretical knowledge only",
    "opt4": "Religious practices",
    "correct": 2
  },
  {
    "question": "Soft skills include all EXCEPT:",
    "opt1": "Communication",
    "opt2": "Emotional intelligence",
    "opt3": "Cooking",
    "opt4": "Teamwork",
    "correct": 3
  },
  {
    "question": "Which method is NOT a form of skill acquisition?",
    "opt1": "Apprenticeship",
    "opt2": "Workshops",
    "opt3": "Prayer camps",
    "opt4": "Seminars",
    "correct": 3
  },
  {
    "question": "Which of the following is a step in acquiring skills?",
    "opt1": "Avoiding feedback",
    "opt2": "Learning with pseudo tools",
    "opt3": "Creating time to learn",
    "opt4": "Ignoring fundamentals",
    "correct": 3
  },
  {
    "question": "Skill acquisition is said to provide what kind of mechanism?",
    "opt1": "Offensive",
    "opt2": "Defensive",
    "opt3": "Deceptive",
    "opt4": "Reactive",
    "correct": 2
  },

  {
    "question": "Which attribute is NOT associated with self-reliance?",
    "opt1": "Commitment",
    "opt2": "Laziness",
    "opt3": "Diligence",
    "opt4": "Hard work",
    "correct": 2
  },
  {
    "question": "Who benefits most from skills acquisition programs?",
    "opt1": "Politicians",
    "opt2": "Youths",
    "opt3": "Tourists",
    "opt4": "Elderly",
    "correct": 2
  },
  {
    "question": "Which of the following is a technical skill?",
    "opt1": "Drawing",
    "opt2": "Greeting",
    "opt3": "Smiling",
    "opt4": "Punctuality",
    "correct": 1
  },
  {
    "question": "Skill acquisition helps reduce all EXCEPT:",
    "opt1": "Unemployment",
    "opt2": "Overdependence",
    "opt3": "Crime",
    "opt4": "Talent",
    "correct": 4
  },
  {
    "question": "According to the text, skills are described as:",
    "opt1": "Accidental gifts",
    "opt2": "Innate only",
    "opt3": "Learned through practice and experience",
    "opt4": "Unnecessary for youth",
    "correct": 3
  },
  {
    "question": "Which is a recognized form of acquiring skills?",
    "opt1": "Team training",
    "opt2": "Guesswork",
    "opt3": "Osmosis",
    "opt4": "Inactivity",
    "correct": 1
  },
  {
    "question": "A skill must have all EXCEPT:",
    "opt1": "Productivity",
    "opt2": "Expandability",
    "opt3": "Social relevance",
    "opt4": "Randomness",
    "correct": 4
  },
  {
    "question": "What is meant by ‘learning with actual tools’?",
    "opt1": "Using theoretical books only",
    "opt2": "Training with real equipment",
    "opt3": "Watching videos alone",
    "opt4": "Reading novels",
    "correct": 2
  },
  {
    "question": "A self-reliant individual should exhibit:",
    "opt1": "Blame shifting",
    "opt2": "Self-confidence",
    "opt3": "Ignorance",
    "opt4": "Apathy",
    "correct": 2
  },
  {
    "question": "Self-reliance includes independence in:",
    "opt1": "Health only",
    "opt2": "All life dimensions",
    "opt3": "Religion only",
    "opt4": "Politics only",
    "correct": 2
  },

  {
    "question": "A soft skill that enhances teamwork is:",
    "opt1": "Being aggressive",
    "opt2": "Isolation",
    "opt3": "Diplomacy",
    "opt4": "Neglect",
    "correct": 3
  },
  {
    "question": "What does the Human Capital Theory link skill acquisition to?",
    "opt1": "Spiritual growth",
    "opt2": "Productivity and wage levels",
    "opt3": "Health outcomes",
    "opt4": "Crime rate",
    "correct": 2
  },
  {
    "question": "Niche theory relates to:",
    "opt1": "Resource competition and survival",
    "opt2": "Internet usage",
    "opt3": "Religious belief",
    "opt4": "Climate awareness",
    "correct": 1
  },
  {
    "question": "Which is not a soft skill?",
    "opt1": "Empathy",
    "opt2": "Flexibility",
    "opt3": "Code writing",
    "opt4": "Team motivation",
    "correct": 3
  },
  {
    "question": "Which attribute helps a self-reliant person maintain long-term skill use?",
    "opt1": "Continuity",
    "opt2": "Pride",
    "opt3": "Isolation",
    "opt4": "Supervision",
    "correct": 1
  },
  {
    "question": "How should goals be set in skill acquisition?",
    "opt1": "Vague and limitless",
    "opt2": "Unrealistic and fast",
    "opt3": "Specific and measurable",
    "opt4": "Assigned by others",
    "correct": 3
  },
  {
    "question": "What is the purpose of feedback in skill acquisition?",
    "opt1": "To criticize learners",
    "opt2": "To improve and guide progress",
    "opt3": "To discourage effort",
    "opt4": "To delay training",
    "correct": 2
  },
  {
    "question": "What major challenge does skill acquisition address in Nigeria?",
    "opt1": "Religious bias",
    "opt2": "Overcrowding",
    "opt3": "Youth unemployment",
    "opt4": "Electricity shortage",
    "correct": 3
  },
  {
    "question": "Apprenticeship in Nigeria is significant because it:",
    "opt1": "Favors foreign skills",
    "opt2": "Preserves cultural heritage",
    "opt3": "Focuses on theory",
    "opt4": "Limits creativity",
    "correct": 2
  },
  {
    "question": "Which region is known for using apprenticeship for entrepreneurship?",
    "opt1": "North Central",
    "opt2": "South East",
    "opt3": "South West",
    "opt4": "North West",
    "correct": 2
  }
]


quests13 =  [
    {
    "question": "f(x) = (5x − 1)/2. Find f<sup>−1</sup>(4).",
    "opt1": "1.5",
    "opt2": "3.2",
    "opt3": "1.8",
    "opt4": "1.4",
    "correct": 3
},

{
    "question": "Evaluate lim x → 0 of tan(3x)/x.",
    "opt1": "1",
    "opt2": "3",
    "opt3": "0",
    "opt4": "undefined",
    "correct": 2
},

{
    "question": "Evaluate lim x → ∞ of (3x<sup>3</sup> + 4x<sup>2</sup> − 6) / (6x<sup>2</sup> + 5x<sup>4</sup> − 4).",
    "opt1": "0",
    "opt2": "1",
    "opt3": "∞",
    "opt4": "undefined",
    "correct": 1
},

{
    "question": "Evaluate lim x → 0 of sin(2x) / (3x + cos(x)).",
    "opt1": "2",
    "opt2": "0.5",
    "opt3": "1",
    "opt4": "0",
    "correct": 4
},

{
    "question": "Evaluate lim x → 2 of (x<sup>2</sup> − 4) / (x − 2).",
    "opt1": "5",
    "opt2": "2",
    "opt3": "4",
    "opt4": "3",
    "correct": 3
},

{
    "question": "Evaluate lim x → ∞ of (6x<sup>3</sup> − 2x + 1) / (3x<sup>3</sup> + 5x − 4).",
    "opt1": "1.5",
    "opt2": "3",
    "opt3": "1",
    "opt4": "2",
    "correct": 4
},

{
    "question": "Evaluate lim x → 1 of (x<sup>3</sup> − 1) / (x − 1).",
    "opt1": "1",
    "opt2": "3",
    "opt3": "2",
    "opt4": "5",
    "correct": 2
},

{
    "question": "f(x) = √(2x − 5). Find f<sup>−1</sup>(4).",
    "opt1": "5.5",
    "opt2": "10.5",
    "opt3": "3.5",
    "opt4": "-1.5",
    "correct": 2
},

{
    "question": "f(x) = (4x + 1)/3. Find f<sup>−1</sup>(x).",
    "opt1": "(3x - 1)/4",
    "opt2": "(5x - 1)/3",
    "opt3": "(4x + 1)/3",
    "opt4": "(3x + 1)/4",
    "correct": 1
},


{
    "question": "f(x) = 7(x − 3). Find f<sup>−1</sup>(x).",
    "opt1": "x / 10 + 3",
    "opt2": "x / 3 + 7",
    "opt3": "x / 7 + 3",
    "opt4": "(x + 3)/7",
    "correct": 3
}

]

quests15 = [
  {
    "question": "Differentiate y = x<sup>3</sup>e<sup>x</sup>.",
    "opt1": "x<sup>2</sup>e<sup>x</sup>",
    "opt2": "3x<sup>2</sup>e<sup>x</sup> + x<sup>3</sup>e<sup>x</sup>",
    "opt3": "e<sup>x</sup>",
    "opt4": "x<sup>3</sup> + e<sup>x</sup>",
    "correct": 2
  },
  {
    "question": "If h(x) = √x and g(x) = x + 3. Find (h ∘ g)(x).",
    "opt1": "√x + 3",
    "opt2": "x + √3",
    "opt3": "√(x + 3)",
    "opt4": "(√x)<sup>2</sup> + 3",
    "correct": 3
  },
  {
    "question": "Differentiate y = x<sup>2</sup>sin(x).",
    "opt1": "2xsin(x) + x<sup>2</sup>cos(x)",
    "opt2": "2xsin(x) - x<sup>2</sup>cos(x)",
    "opt3": "2xcos(x) + sin(x)",
    "opt4": "x<sup>2</sup>cos(x)",
    "correct": 1
  },
  {
    "question": "Find dy/dx if y = (ln(x))/(x<sup>2</sup>).",
    "opt1": "2ln(x) / x<sup>2</sup>",
    "opt2": "1/(x<sup>2</sup>ln(x))",
    "opt3": "(2ln(x) - 1) / x<sup>3</sup>",
    "opt4": "(1 - 2ln(x)) / x<sup>3</sup>",
    "correct": 4
  },
  {
    "question": "Let f(x) = ln(x), h(x) = x<sup>2</sup> - 1. Find (f ∘ h)(x).",
    "opt1": "ln(x<sup>2</sup> - 1)",
    "opt2": "ln(x) - 1",
    "opt3": "ln(x<sup>2</sup>) - 1",
    "opt4": "ln(1 - x<sup>2</sup>)",
    "correct": 1
  },
  {
    "question": "Differentiate y = tan(x)(x<sup>2</sup> + 1).",
    "opt1": "sec(x) + sec<sup>2</sup>(x)",
    "opt2": "tan(x)(2x + 1)",
    "opt3": "sec<sup>2</sup>x(x<sup>2</sup> + 1) + 2xtan(x)",
    "opt4": "tan(x) + 2x",
    "correct": 3
  },
  {
    "question": "Let f(x) = x<sup>2</sup>, g(x) = √x and h(x) = x + 2. Find (f ∘ h ∘ g)(x).",
    "opt1": "(x + 2)<sup>2</sup>",
    "opt2": "√(x<sup>2</sup> + 2)",
    "opt3": "x + 2",
    "opt4": "f(g(h(x)))",
    "correct": 3
  },
  {
    "question": "Differentiate y = (x + 3)<sup>3</sup>cos(x).",
    "opt1": "3(x + 3)cos(x) + (x + 3)<sup>3</sup>cos(x)",
    "opt2": "3(x + 3)<sup>2</sup>cos(x) - (x + 3)<sup>3</sup>sin(x)",
    "opt3": "cos(x) - sin(x)",
    "opt4": "None of the above",
    "correct": 2
  },
  {
    "question": "Differentiate y = (x + 1)<sup>2</sup> / x.",
    "opt1": "(2x + 2) / x<sup>2</sup>",
    "opt2": "(x + 1) / x<sup>2</sup>",
    "opt3": "x<sup>2</sup> - 1",
    "opt4": "(2x + 1) / x",
    "correct": 3
  },
  {
    "question": "If f(x) = 2x + 1 and g(x) = x<sup>2</sup>, find (f ∘ g)(x).",
    "opt1": "2x + x<sup>2</sup>",
    "opt2": "2x<sup>2</sup> + 1",
    "opt3": "(2x)<sup>2</sup> + 1",
    "opt4": "x<sup>2</sup> + 1",
    "correct": 2
  },
  {
    "question": "Differentiate y = (x<sup>2</sup> - 1)/(x<sup>2</sup> + 1).",
    "opt1": "(4x) / (x<sup>2</sup> + 1)<sup>2</sup>",
    "opt2": "(2x(x<sup>2</sup> + 1) - 2x(x<sup>2</sup> - 1)) / (x<sup>2</sup> + 1)<sup>2</sup>",
    "opt3": "(2x(x<sup>2</sup> - 1)) / (x<sup>2</sup> + 1)<sup>2</sup>",
    "opt4": "(2x) / (x<sup>2</sup> + 1)",
    "correct": 1
  },
  {
    "question": "If y = (x<sup>2</sup> + 3)/(x + 1), find dy/dx.",
    "opt1": "2x / (x + 1)",
    "opt2": "((x - 1) (x + 3)) / (x + 1)<sup>2</sup>",
    "opt3": "(x<sup>2</sup> - 3)/(x + 1)",
    "opt4": "x<sup>2</sup> + 3",
    "correct": 2
  },
  {
    "question": "Let f(x) = e<sup>x</sup>, g(x) = x<sup>2</sup>, h(x) = 3x. Find (f ∘ g ∘ h)(x).",
    "opt1": "e<sup>(3x)<sup>2</sup></sup>",
    "opt2": "e<sup>3x<sup>2</sup></sup>",
    "opt3": "e<sup>9x<sup>2</sup></sup>",
    "opt4": "e<sup>x<sup>2</sup></sup>",
    "correct": 3
  },
  {
    "question": "If h(x) = 1/x, g(x) = x<sup>2</sup>, and f(x) = x - 4, find (h ∘ g ∘ f)(x).",
    "opt1": "1/(x<sup>2</sup> - 4)",
    "opt2": "1/(x + 4)<sup>2</sup>",
    "opt3": "1/(x - 4)<sup>2</sup>",
    "opt4": "(x<sup>2</sup> - 4)<sup>-1</sup>",
    "correct": 3
  }
]

quests16 = [
  {
    "question": "What is the IUPAC name of CH<sub>3</sub>CH<sub>2</sub>CH<sub>3</sub>?",
    "opt1": "Methane",
    "opt2": "Ethane",
    "opt3": "Propane",
    "opt4": "Butane",
    "correct": 3
  },
  {
    "question": "What is the correct name for CH<sub>3</sub>CH<sub>2</sub>OH?",
    "opt1": "Ethanol",
    "opt2": "Methanol",
    "opt3": "Propanol",
    "opt4": "Ethanal",
    "correct": 1
  },
  {
    "question": "What is the IUPAC name for CH<sub>3</sub>CH(CH<sub>3</sub>)CH<sub>3</sub>?",
    "opt1": "Butane",
    "opt2": "Isobutane",
    "opt3": "2-Methylpropane",
    "opt4": "2-Propylbutane",
    "correct": 3
  },
  {
    "question": "Which of the following is named 2-butanol?",
    "opt1": "CH<sub>3</sub>CH(OH)CH<sub>2</sub>CH<sub>3</sub>",
    "opt2": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>OH",
    "opt3": "CH<sub>3</sub>CH<sub>2</sub>CH(OH)CH<sub>3</sub>",
    "opt4": "CH<sub>3</sub>CH(OH)CH<sub>3</sub>",
    "correct": 1
  },
  {
    "question": "The IUPAC name for HCOOH is:",
    "opt1": "Methanal",
    "opt2": "Formic acid",
    "opt3": "Methanoic acid",
    "opt4": "Methanol",
    "correct": 3
  },
  {
    "question": "What is the correct name of CH<sub>3</sub>CH=CH<sub>2</sub>?",
    "opt1": "Propene",
    "opt2": "Propyne",
    "opt3": "Propane",
    "opt4": "Butene",
    "correct": 1
  },
  {
    "question": "The IUPAC name for CH<sub>3</sub>COCH<sub>3</sub> is:",
    "opt1": "Propanol",
    "opt2": "Propanone",
    "opt3": "Acetone",
    "opt4": "Ethanal",
    "correct": 2
  },
  {
    "question": "What is the IUPAC name of CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>COOH?",
    "opt1": "Propanoic acid",
    "opt2": "Butanoic acid",
    "opt3": "Pentanoic acid",
    "opt4": "Butanal",
    "correct": 2
  },
  {
    "question": "Which compound is named ethanoic acid?",
    "opt1": "CH<sub>3</sub>CH<sub>2</sub>COOH",
    "opt2": "CH<sub>3</sub>CH<sub>2</sub>OH",
    "opt3": "CH<sub>3</sub>COOH",
    "opt4": "CH<sub>3</sub>CH<sub>2</sub>CHO",
    "correct": 3
  },
  {
    "question": "The correct IUPAC name of CH<sub>3</sub>CH<sub>2</sub>CHO is:",
    "opt1": "Propanone",
    "opt2": "Propanal",
    "opt3": "Ethanal",
    "opt4": "Propanol",
    "correct": 2
  },
  {
    "question": "What is the IUPAC name of CH≡CCH<sub>3</sub>?",
    "opt1": "Propyne",
    "opt2": "Propene",
    "opt3": "1-Propyne",
    "opt4": "2-Propyne",
    "correct": 1
  },
  {
    "question": "Name the compound: CH<sub>3</sub>CH<sub>2</sub>CH=CH<sub>2</sub>",
    "opt1": "Butene",
    "opt2": "1-Butene",
    "opt3": "2-Butene",
    "opt4": "Butyne",
    "correct": 2
  },
  {
    "question": "What is the correct name for CH<sub>3</sub>CH(OH)CH<sub>3</sub>?",
    "opt1": "2-Propanol",
    "opt2": "Propan-2-ol",
    "opt3": "Isopropyl alcohol",
    "opt4": "All of the above",
    "correct": 4
  },
  {
    "question": "What is the correct IUPAC name of CH<sub>3</sub>OCH<sub>3</sub>?",
    "opt1": "Methanol",
    "opt2": "Dimethyl ether",
    "opt3": "Methoxy methane",
    "opt4": "Methanal",
    "correct": 3
  },
  {
    "question": "What is the IUPAC name for CH<sub>3</sub>CH<sub>2</sub>CN?",
    "opt1": "Propanenitrile",
    "opt2": "Ethanenitrile",
    "opt3": "Acetonitrile",
    "opt4": "Propylamine",
    "correct": 1
  },
  {
    "question": "What is the correct IUPAC name of CH<sub>3</sub>CHBrCH<sub>3</sub>?",
    "opt1": "2-Bromopropane",
    "opt2": "1-Bromopropane",
    "opt3": "Bromopropanol",
    "opt4": "Bromomethane",
    "correct": 1
  },
  {
    "question": "Which of the following represents the structure of 3-methylpentane?",
    "opt1": "CH<sub>3</sub>CH(CH<sub>3</sub>)CH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub>",
    "opt2": "CH<sub>3</sub>CH<sub>2</sub>CH(CH<sub>3</sub>)CH<sub>2</sub>CH<sub>3</sub>",
    "opt3": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH(CH<sub>3</sub>)CH<sub>3</sub>",
    "opt4": "CH<sub>3</sub>CH(CH<sub>3</sub>)CH(CH<sub>3</sub>)CH<sub>3</sub>",
    "correct": 2
  },
  {
    "question": "What is the IUPAC name for CH<sub>2</sub>=CHCH<sub>2</sub>OH?",
    "opt1": "2-Propen-1-ol",
    "opt2": "Propenol",
    "opt3": "Allyl alcohol",
    "opt4": "1-Propen-2-ol",
    "correct": 1
  },
  {
    "question": "The compound CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>NH<sub>2</sub> is best named as:",
    "opt1": "Aminobutane",
    "opt2": "1-Butylamine",
    "opt3": "Propanamine",
    "opt4": "Propan-1-amine",
    "correct": 4
  },
  {
    "question": "What is the correct IUPAC name for CH<sub>3</sub>CH<sub>2</sub>CH(Cl)CH<sub>3</sub>?",
    "opt1": "2-Chlorobutane",
    "opt2": "3-Chlorobutane",
    "opt3": "Chloropropane",
    "opt4": "Butyl chloride",
    "correct": 1
  }
]

quests17 = [
  {
    "question": "A point charge of +2 μC is located at a distance of 0.5 m from a point. What is the electric potential at that point? (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "36 × 10<sup>-3</sup> V",
    "opt2": "18 × 10<sup>3</sup> V",
    "opt3": "36 × 10<sup>3</sup> V",
    "opt4": "27 × 10<sup>3</sup> V",
    "correct": 3
  },
  {
    "question": "Calculate the electric potential energy of two charges +3 μC and -2 μC separated by 0.2 m. (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "-2.7 J",
    "opt2": "-0.27 J",
    "opt3": "-0.54 J",
    "opt4": "0.54 J",
    "correct": 2
  },
  {
    "question": "What is the potential difference between two points 0.1 m apart in a uniform electric field of 200 V/m?",
    "opt1": "10 V",
    "opt2": "20 V",
    "opt3": "25 V",
    "opt4": "5 V",
    "correct": 2
  },
  {
    "question": "A proton is moved through a potential difference of 5 kV. What is the change in its potential energy? (Charge of proton = 1.6 × 10<sup>-19</sup> C)",
    "opt1": "8 × 10<sup>-16</sup> J",
    "opt2": "4 × 10<sup>-16</sup> J",
    "opt3": "2 × 10<sup>-15</sup> J",
    "opt4": "6 × 10<sup>-16</sup> J",
    "correct": 1
  },
  {
    "question": "If the electric field between two plates is 3000 V/m and the plates are 0.02 m apart, what is the potential difference?",
    "opt1": "30 V",
    "opt2": "60 V",
    "opt3": "45 V",
    "opt4": "75 V",
    "correct": 2
  },
  {
    "question": "Determine the magnitude of the electric field at a point 0.2 m away from a 5 μC point charge. (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "1.125 × 10<sup>6</sup> N/C",
    "opt2": "2.25 × 10<sup>6</sup> N/C",
    "opt3": "3.5 × 10<sup>6</sup> N/C",
    "opt4": "4.5 × 10<sup>6</sup> N/C",
    "correct": 1
  },
  {
    "question": "A charge of 4 μC moves a distance of 0.3 m in an electric field of strength 1500 V/m. Calculate the work done.",
    "opt1": "4.2 × 10<sup>-3</sup> J",
    "opt2": "2.0 × 10<sup>-3</sup> J",
    "opt3": "3.0 × 10<sup>-3</sup> J",
    "opt4": "1.8 × 10<sup>-3</sup> J",
    "correct": 4
  },
  {
    "question": "Find the electric potential at the center of a ring of charge 10 μC and radius 0.5 m. (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "180 kV",
    "opt2": "90 kV",
    "opt3": "50 kV",
    "opt4": "120 kV",
    "correct": 2
  },
  {
    "question": "Two infinite sheets carry surface charge densities +σ and -σ. What is the electric field between them?",
    "opt1": "σ/ε₀",
    "opt2": "σ/(2ε₀)",
    "opt3": "2σ/ε₀",
    "opt4": "σ/3ε₀",
    "correct": 1
  },
  {
    "question": "A 1 nC charge is placed in a uniform electric field of 500 N/C. What is the force on the charge?",
    "opt1": "5 × 10<sup>-4</sup> N",
    "opt2": "5 × 10<sup>-6</sup> N",
    "opt3": "5 × 10<sup>-9</sup> N",
    "opt4": "5 × 10<sup>-7</sup> N",
    "correct": 4
  },
  {
    "question": "A charge of 3 μC is located at the origin. What is the electric field at a point 1 m away? (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "2.7 × 10<sup>4</sup> N/C",
    "opt2": "9 × 10<sup>3</sup> N/C",
    "opt3": "2.7 × 10<sup>5</sup> N/C",
    "opt4": "9 × 10<sup>5</sup> N/C",
    "correct": 1
  },
  {
    "question": "A 1 μC charge experiences a force of 0.02 N in an electric field. What is the electric field strength?",
    "opt1": "200 N/C",
    "opt2": "20,000 N/C",
    "opt3": "2,000 N/C",
    "opt4": "20 N/C",
    "correct": 3
  },
  {
    "question": "The electric field inside a uniformly charged sphere of radius R at distance r is given by:",
    "opt1": "kQr/R<sup>3</sup>",
    "opt2": "kQ/R<sup>2</sup>",
    "opt3": "kQr<sup>2</sup>/R<sup>3</sup>",
    "opt4": "kQ/r<sup>2</sup>",
    "correct": 1
  },
  {
    "question": "A dipole of length 2 cm has charges ±2 μC. What is the dipole moment?",
    "opt1": "2 × 10<sup>-8</sup> Cm",
    "opt2": "4 × 10<sup>-8</sup> Cm",
    "opt3": "1 × 10<sup>-8</sup> Cm",
    "opt4": "8 × 10<sup>-8</sup> Cm",
    "correct": 2
  },
  {
    "question": "The electric field due to a dipole at a point on its axial line varies as:",
    "opt1": "1/r",
    "opt2": "1/r<sup>2</sup>",
    "opt3": "1/r<sup>3</sup>",
    "opt4": "1/r<sup>4</sup>",
    "correct": 3
  },
  {
    "question": "Electric field lines never:",
    "opt1": "Begin on negative charges",
    "opt2": "End on positive charges",
    "opt3": "Intersect",
    "opt4": "Point from + to -",
    "correct": 3
  },
  {
    "question": "What is the potential at a distance of 2 m from a -3 μC charge? (k = 9 × 10<sup>9</sup> Nm<sup>2</sup>/C<sup>2</sup>)",
    "opt1": "-13.5 × 10<sup>3</sup> V",
    "opt2": "13.5 × 10<sup>3</sup> V",
    "opt3": "-27 × 10<sup>3</sup> V",
    "opt4": "27 × 10<sup>3</sup> V",
    "correct": 1
  },
  {
    "question": "What is the work done in moving a charge of 2 μC through a potential difference of 12 V?",
    "opt1": "16 μJ",
    "opt2": "12 μJ",
    "opt3": "24 μJ",
    "opt4": "36 μJ",
    "correct": 3
  },
  {
    "question": "What is the energy stored in a 5 μC charge placed at a point with electric potential of 5000 V?",
    "opt1": "0.025 J",
    "opt2": "0.5 J",
    "opt3": "0.05 J",
    "opt4": "0.0005 J",
    "correct": 1
  },
]


