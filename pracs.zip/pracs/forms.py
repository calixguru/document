from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from .models import *
from django import forms
from django.core.exceptions import ValidationError
from pracs import views

class MyUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['firstname', 'lastname',
                  'email', 'password1', 'password2', 'ref']


class UserForm(ModelForm):
    class Meta:
        model = User
        fields = ['firstname', 'lastname', 'avatar', 'contact', 'whatsapp', 'has_downloaded']

    def clean_avatar(self):
        avatar = self.cleaned_data.get('avatar')
        if avatar:
            max_size_kb = views.prof_max
            if avatar.size > max_size_kb * 1024:
                raise ValidationError(f"Profile picture must be {max_size_kb} KB or less.")
        return avatar

class Pin(ModelForm):
    class Meta:
        model = Pins
        fields = ['pin']


class Request(ModelForm):
    class Meta:
        model = Req
        fields = '__all__'



class CoverPageForm(forms.ModelForm):
    class Meta:
        model = CoverPage
        fields = '__all__'
        widgets = {
            'date_of_submission': forms.SelectDateWidget(),
            'style_choice': forms.RadioSelect(),
        }

class FileUploadForm(forms.ModelForm):
    class Meta:
        model = UploadedFile
        fields = ['name', 'description', 'amount', 'file']

class BlogPostForm(forms.ModelForm):
    class Meta:
        model = BlogPost
        fields = ['title', 'thumbnail', 'content']


# class QuestionForm(forms.ModelForm):
#     class Meta:
#         model = Question
#         fields = ['question_text', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_answer', 'function_name', 'topic', 'course']




class AdvertiserForm(forms.ModelForm):
    class Meta:
        model = Advertise
        fields = ['business_name', 'description', 'whatsapp_profile', 'duration_days', 'display_duration']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Short description of the business'}),
            'whatsapp_profile': forms.URLInput(attrs={'placeholder': 'https://wa.me/234XXXXXXXXXX'}),
        }
        

class AdvertImageForm(forms.ModelForm):
    class Meta:
        model = AdvertImage
        fields = ['image', 'caption']

    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image:
            max_size_kb = 500
            if image.size > max_size_kb * 1024:
                raise ValidationError(f"Image must be {max_size_kb} KB or less.")
        return image

