
import random
import hashlib
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse
import random
from .models import *
from .assignment import uniuyo1, uniuyo11, uniuyo56, uniuyo566, uniuyo3, uniuyo567, uniuyo568, uniuyo569
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.core.mail import EmailMessage
from django.conf import settings
from io import BytesIO
from django.http import JsonResponse
from .models import *
from pracs.league import questions
from pracs.templatetags.languages import replace_asterisk
from .pins import CoverBorders
from .rplab_templates import rplab

import datetime
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from django.http import FileResponse


covers = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,27]
d_text = 'Please buy downloads from yor CBT room, then go back to download'
d_text2 = 'Please buy downloads from Calixguru in order to be able to download'
d_redirect = 'cbtroom'
cover_functions = {
                    "Blank": CoverBorders.draw_cover_border0,
                    "cover 1": CoverBorders.draw_cover_border1,
                    "cover 2": CoverBorders.draw_cover_border2,
                    "cover 3": CoverBorders.draw_cover_border3,
                    "cover 4": CoverBorders.draw_cover_border4,
                    "cover 5": CoverBorders.draw_cover_border5,
                    "cover 6": CoverBorders.draw_cover_border6,
                    "cover 7": CoverBorders.draw_cover_border7,
                    "cover 8": CoverBorders.draw_cover_border8,
                    "cover 9": CoverBorders.draw_cover_border9,
                    "cover 10": CoverBorders.draw_cover_border10,
                    "cover 11": CoverBorders.draw_cover_border11,
                    "cover 12": CoverBorders.draw_cover_border12,
                    "cover 13": CoverBorders.draw_cover_border13,
                    "cover 14": CoverBorders.draw_cover_border14,
                    "cover 15": CoverBorders.draw_cover_border15,
                    "cover 16": CoverBorders.draw_cover_border16,
                    "cover 17": CoverBorders.draw_cover_border17,
                    "cover 18": CoverBorders.draw_cover_border18,
                    "cover 19": CoverBorders.draw_cover_border19,
                    "cover 20": CoverBorders.draw_cover_border20,
                    "cover 21": CoverBorders.draw_cover_border21,
                    "cover 22": CoverBorders.draw_cover_border22,
                    "cover 23": CoverBorders.draw_cover_border23,
                    "cover 24": CoverBorders.draw_cover_border24,
                    "cover 25": CoverBorders.draw_cover_border25,
                    # "cover 26": pins.draw_cover_border25,
                    "cover 27": CoverBorders.draw_cover_border,
                }

@login_required(login_url='login')
def uniuyo_ass(request):
    # Define common context
    schools = {'uniuyo': 'UNIVERSITY OF UYO',
               'aksu': 'AKWA IBOM STATE UNIVERSITY',
               'akscoe': 'AKWA IBOM STATE COLLEGE OF EDUCATION'}
    name = request.GET.get('name').upper()
    reg = request.GET.get('reg').upper()
    ass = request.GET.get('ass')
    dept = request.GET.get('dept').upper()
    fac = request.GET.get('fac').upper()
    institution = schools[request.GET.get('inst')]
    room = request.GET.get('room')

    if ass.lower() == 'GST111'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = [1,3]
        context = {
            'list': list(range(1, 201)),
            'chapter': ["The Jungle of Betrayal", "Random Reels", "The Ibom Pilgrim"],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'book to review',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def random_column_wise_choice(list_of_lists):
                if not list_of_lists or not list_of_lists[0]:
                    return []

                num_positions = len(list_of_lists[0])  # Length of each sublist
                result = []

                for i in range(num_positions):
                    # Pick a random element from the ith position across all sublists
                    choice = random.choice([lst[i] for lst in list_of_lists])
                    result.append(choice)

                return result
            user = request.user
            books = uniuyo566
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                try:
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                chaps = int(request.POST.get("chapter"))
                if chaps not in allow:
                    messages.error(request, f"Not yet ready for download, an email will be sent to you once it is ready")
                else:
                    data = {
                        "Title": books.books[chaps]["Title"],
                        "Editors": books.books[chaps]["Editors"],
                        "Place": books.books[chaps]["Place"],
                        "Publishers": books.books[chaps]["Publishers"],
                        "Year": books.books[chaps]["Year"],
                        "Pages": books.books[chaps]["Pages"],

                        # Pick one random item from single lists
                        "Introduction": random.choice(books.books[chaps]["Introduction"]),
                        "Evaluation": random.choice(books.books[chaps]["Evaluation"]),
                        "Conclusion": random.choice(books.books[chaps]["Conclusion"]),
                        "Recommendation": random.choice(books.books[chaps]["Recommendation"]),

                        # Chapters: one random from each inner list
                        "Chapters": books.get_random_chapters(books.books[chaps]["Chapters"]),
                    }



                    student = {
                        'data': data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Dr IDARA THOMAS'.upper(),
                        'course': 'GST111: EFFECTIVE USE OF ENGLISH'.upper(),
                        'department': 'department of english'.upper(),
                        'faculty': 'arts'.upper()

                    }

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    my_dict = {3: 'Day', 2: 'Chapter', 1: 'Chapter'}
                    def get_label(key):
                        return my_dict.get(key, "Key not found")

                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(ParagraphStyle(name="SubTitle", fontSize=12, alignment=1, spaceAfter=12, textColor=colors.HexColor("#333333")))
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=11, leading=15, spaceAfter=10))
                        styles.add(ParagraphStyle(name="NormalText2", fontSize=11, leading=15, spaceAfter=5))

                        elements = []


                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))



                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("A BOOK REVIEW", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"<b>{data['Title'].upper()}</b>", styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['cor']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                        elements.append(PageBreak())
                        # ---- CONTENT PAGES ----
                        elements.append(Paragraph("BOOK REVIEW OVERVIEW", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>BOOK:</b> {data['Title']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>EDITORS:</b> {data['Editors']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PLACE OF PUBLICATION:</b> {data['Place']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PUBLISHERS:</b> {data['Publishers']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>YEAR OF PUBLICATION:</b> {data['Year']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>NUMBER OF PAGES:</b> {data['Pages']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>REVIEWER:</b> {student['name']}", styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("INTRODUCTION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Introduction"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("ORGANIZATION OF CONTENTS", styles["Chapter"]))
                        for idx, ch in enumerate(data["Chapters"], start=1):
                            elements.append(Paragraph(f"<b>{get_label(chaps)} {idx}:</b> {replace_asterisk(ch)}", styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("EVALUATION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Evaluation"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("RECOMMENDATION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Recommendation"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("CONCLUSION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Conclusion"]), styles["NormalText2"]))

                        def draw_content_border(canvas, doc):
                            width, height = A4

                            # === Footer line ===
                            canvas.setStrokeColor(colors.grey)
                            canvas.setLineWidth(0.5)
                            canvas.line(50, 40, width - 50, 40)

                            # === Clickable footer text ===
                            footer_text = f"Original owner of this book review is {student['name']} in {student['dept']}"
                            canvas.setFont("Times-Roman", 9)
                            canvas.setFillColor(colors.red)  # typical link color
                            text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            x_pos = (width - text_width) / 2
                            y_pos = 28
                            canvas.drawString(x_pos, y_pos, footer_text)

                            # Make it clickable
                            canvas.linkURL(
                                "https://calixguru.pythonanywhere.com/",
                                (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                                relative=0,
                            )

                            # === Watermark ===
                            canvas.saveState()
                            canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            canvas.translate(width / 2, height / 2)  # move origin to page center
                            canvas.rotate(45)  # rotate for slant
                            canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            canvas.restoreState()


                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        try:
                            pdf_data = buffer.getvalue()
                            email = EmailMessage(
                                subject=f'{name} {ass} Assignment PDF',
                                body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                to=[user.email],
                            )
                            email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                            email.send()
                        except:
                            pass
                        response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                        return response


                    # try:
                    #     pdf_buffer.seek(0)
                    #     pdf_data = pdf_buffer.getvalue()
                    #     email = EmailMessage(
                    #         subject=f'{name} Assignment PDF',
                    #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                    #         from_email=settings.DEFAULT_FROM_EMAIL,
                    #         to=[user.email],
                    #     )
                    #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    #     email.send()
                    # except:
                    #     pass
                    # user.has_downloaded -= 1
                    if user.email != 'calixotu@gmail.com':
                        user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                if int(room) != 0:
                    messages.error(request, d_text)
                    return redirect('cbtroom', room)
                else:
                    messages.error(request, d_text2)
                    return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'GST211'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = [1,2,3,4,5,6,7,8,9,10,11,12]
        context = {
            'list': list(range(1, 201)),
            'chapter': [1,2,3,4,5,6,7,8,9,10,11,12],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'chapter to review for GST211',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def pick_random_from_review_list(review_list):
                return [
                    random.choice(inner_list)
                    for inner_list in review_list
                    if isinstance(inner_list, list) and inner_list
                ]
            user = request.user
            books = uniuyo3.gst211
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                try:
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                chaps = int(request.POST.get("chapter"))
                if chaps not in allow:
                    messages.error(request, f"Invalid Chapter")
                else:
                    def get_chapter_data(chapter_number):
                        for ch in books:
                            if ch["chapter"] == chapter_number:
                                return {
                                    "Chapter": ch["chapter"],
                                    "Title": ch["title"],
                                    "Author": ch["author"],
                                    "Editors": "Imelda Icheji Lawrence Udoh",
                                    "Place": "Uyo, Akwa Ibom State",
                                    "Publishers": "Directorate of General Studies, University of Uyo",
                                    "Year": "2024",
                                    "Pages": "X + 217",
                                    # renamed from Introduction → Chapter
                                    "Chapters": pick_random_from_review_list(ch["review_list"]),
                                    "Introduction": random.choice(ch["mini"][0]),
                                    "Conclusion": random.choice(ch["mini"][1])
                                }
                        return None
                    data = get_chapter_data(chaps)

                    student = {
                        'data': data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Dr EMMANUEL INIOBONG ARCHIBONG'.upper(),
                        'course': 'GST211: PHILOSOPHY, LOGIC AND HUMAN EXISTENCE'.upper(),
                        'department': 'department of philosophy'.upper(),
                        'faculty': 'arts'.upper()

                    }

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    my_dict = {3: 'Day', 2: 'Chapter', 1: 'Chapter'}
                    def get_label(key):
                        return my_dict.get(key, "Key not found")

                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(ParagraphStyle(name="SubTitle", fontSize=12, alignment=1, spaceAfter=12, textColor=colors.HexColor("#333333")))
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=15, leading=15, spaceAfter=10))
                        styles.add(ParagraphStyle(name="NormalText2", fontSize=15, leading=15, spaceAfter=11))

                        elements = []


                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))



                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("A BOOK REVIEW", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"CHAPTER <b>{data['Chapter']} OF GST211 TEXT</b>", styles["Heading"]))
                        elements.append(Paragraph(f"<b>({data['Title']})</b>".upper(), styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['cor']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                        elements.append(PageBreak())
                        # ---- CONTENT PAGES ----
                        elements.append(Paragraph("BOOK REVIEW OVERVIEW", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>CHAPTER:</b> Chapter {data['Chapter']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>EDITORS:</b> {data['Editors']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PLACE OF PUBLICATION:</b> {data['Place']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PUBLISHERS:</b> {data['Publishers']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>YEAR OF PUBLICATION:</b> {data['Year']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>NUMBER OF PAGES:</b> {data['Pages']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>REVIEWER:</b> {student['name']}", styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("INTRODUCTION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Introduction"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph(f"<b>SUMMARY OF CHAPTER</b> {data['Chapter']}", styles["Chapter"]))
                        elements.append(Paragraph(f"({data['Title']})", styles['Chapter']))
                        for idx, ch in enumerate(data["Chapters"], start=1):
                            elements.append(Paragraph(f"{replace_asterisk(ch.replace('introduction', 'chapter'))}", styles["NormalText2"]))
                        elements.append(PageBreak())

                        # elements.append(Paragraph("EVALUATION", styles["Chapter"]))
                        # elements.append(Paragraph(replace_asterisk(data["Evaluation"]), styles["NormalText2"]))
                        # elements.append(PageBreak())

                        # elements.append(Paragraph("RECOMMENDATION", styles["Chapter"]))
                        # elements.append(Paragraph(replace_asterisk(data["Recommendation"]), styles["NormalText2"]))
                        # elements.append(PageBreak())

                        elements.append(Paragraph("CONCLUSION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Conclusion"]), styles["NormalText2"]))

                        def draw_content_border(canvas, doc):
                            width, height = A4

                            # === Footer line ===
                            canvas.setStrokeColor(colors.grey)
                            canvas.setLineWidth(0.5)
                            canvas.line(50, 40, width - 50, 40)

                            # === Clickable footer text ===
                            footer_text = f"Original owner of this book review is {student['name']} in {student['dept']}"
                            canvas.setFont("Times-Roman", 9)
                            canvas.setFillColor(colors.red)  # typical link color
                            text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            x_pos = (width - text_width) / 2
                            y_pos = 28
                            canvas.drawString(x_pos, y_pos, footer_text)

                            # Make it clickable
                            canvas.linkURL(
                                "https://calixguru.pythonanywhere.com/",
                                (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                                relative=0,
                            )

                            # === Watermark ===
                            canvas.saveState()
                            canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            canvas.translate(width / 2, height / 2)  # move origin to page center
                            canvas.rotate(45)  # rotate for slant
                            canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            canvas.restoreState()


                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        try:
                            pdf_data = buffer.getvalue()
                            email = EmailMessage(
                                subject=f'{name} {ass} Assignment PDF',
                                body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                to=[user.email],
                            )
                            email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                            email.send()
                        except:
                            pass
                        response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                        return response


                    # try:
                    #     pdf_buffer.seek(0)
                    #     pdf_data = pdf_buffer.getvalue()
                    #     email = EmailMessage(
                    #         subject=f'{name} Assignment PDF',
                    #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                    #         from_email=settings.DEFAULT_FROM_EMAIL,
                    #         to=[user.email],
                    #     )
                    #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    #     email.send()
                    # except:
                    #     pass
                    # user.has_downloaded -= 1
                    if user.email != 'calixotu@gmail.com':
                        user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                if int(room) != 0:
                    messages.error(request, d_text)
                    return redirect('cbtroom', room)
                else:
                    messages.error(request, d_text2)
                    return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'GST311'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = [1,2,3,4,5,6,7,8,9,10,11,12]
        context = {
            'list': list(range(1, 201)),
            'chapter': [1,2,3,4,5,6,7,8,9,10,11,12],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'chapter to review for GST311',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def pick_random_from_review_list(review_list):
                return [
                    random.choice(inner_list)
                    for inner_list in review_list
                    if isinstance(inner_list, list) and inner_list
                ]
            user = request.user
            books = uniuyo3.gst311
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                try:
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                chaps = int(request.POST.get("chapter"))
                if chaps not in allow:
                    messages.error(request, f"Invalid Chapter")
                else:
                    def get_chapter_data(chapter_number):
                        for ch in books:
                            if ch["chapter"] == chapter_number:
                                return {
                                    "Chapter": ch["chapter"],
                                    "Title": ch["title"],
                                    "Author": ch["author"],
                                    "Editors": "Imelda Icheji Lawrence Udoh",
                                    "Place": "Uyo, Akwa Ibom State",
                                    "Publishers": "Directorate of General Studies, University of Uyo",
                                    "Year": "2025",
                                    "Pages": "XVI + 180",
                                    # renamed from Introduction → Chapter
                                    "Chapters": pick_random_from_review_list(ch["review_list"]),
                                    "Introduction": random.choice(ch["mini"][0]),
                                    "Conclusion": random.choice(ch["mini"][1])
                                }
                        return None
                    data = get_chapter_data(chaps)

                    student = {
                        'data': data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Prof. Nsikan-abasi S. Nkana'.upper(),
                        'course': 'GST311: PEACE AND CONFLICT RESOLUTION'.upper(),
                        'department': 'department of peace studies and conflict resolution'.upper(),
                        'faculty': 'social science'.upper()

                    }

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    my_dict = {3: 'Day', 2: 'Chapter', 1: 'Chapter'}
                    def get_label(key):
                        return my_dict.get(key, "Key not found")

                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(ParagraphStyle(name="SubTitle", fontSize=12, alignment=1, spaceAfter=12, textColor=colors.HexColor("#333333")))
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=15, leading=15, spaceAfter=10))
                        styles.add(ParagraphStyle(name="NormalText2", fontSize=15, leading=15, spaceAfter=11))

                        elements = []


                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))



                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("A BOOK REVIEW", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"CHAPTER <b>{data['Chapter']} OF GST311 TEXT</b>", styles["Heading"]))
                        elements.append(Paragraph(f"<b>({data['Title']})</b>".upper(), styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['cor']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                        elements.append(PageBreak())
                        # ---- CONTENT PAGES ----
                        elements.append(Paragraph("BOOK REVIEW OVERVIEW", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>CHAPTER:</b> Chapter {data['Chapter']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>EDITORS:</b> {data['Editors']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PLACE OF PUBLICATION:</b> {data['Place']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PUBLISHERS:</b> {data['Publishers']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>YEAR OF PUBLICATION:</b> {data['Year']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>NUMBER OF PAGES:</b> {data['Pages']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>REVIEWER:</b> {student['name']}", styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("INTRODUCTION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Introduction"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph(f"<b>SUMMARY OF CHAPTER</b> {data['Chapter']}", styles["Chapter"]))
                        elements.append(Paragraph(f"({data['Title']})", styles['Chapter']))
                        for idx, ch in enumerate(data["Chapters"], start=1):
                            elements.append(Paragraph(f"{replace_asterisk(ch.replace('introduction', 'chapter'))}", styles["NormalText2"]))
                        elements.append(PageBreak())

                        # elements.append(Paragraph("EVALUATION", styles["Chapter"]))
                        # elements.append(Paragraph(replace_asterisk(data["Evaluation"]), styles["NormalText2"]))
                        # elements.append(PageBreak())

                        # elements.append(Paragraph("RECOMMENDATION", styles["Chapter"]))
                        # elements.append(Paragraph(replace_asterisk(data["Recommendation"]), styles["NormalText2"]))
                        # elements.append(PageBreak())

                        elements.append(Paragraph("CONCLUSION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Conclusion"]), styles["NormalText2"]))

                        def draw_content_border(canvas, doc):
                            width, height = A4

                            # === Footer line ===
                            canvas.setStrokeColor(colors.grey)
                            canvas.setLineWidth(0.5)
                            canvas.line(50, 40, width - 50, 40)

                            # === Clickable footer text ===
                            footer_text = f"Original owner of this book review is {student['name']} in {student['dept']}"
                            canvas.setFont("Times-Roman", 9)
                            canvas.setFillColor(colors.red)  # typical link color
                            text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            x_pos = (width - text_width) / 2
                            y_pos = 28
                            canvas.drawString(x_pos, y_pos, footer_text)

                            # Make it clickable
                            canvas.linkURL(
                                "https://calixguru.pythonanywhere.com/",
                                (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                                relative=0,
                            )

                            # === Watermark ===
                            canvas.saveState()
                            canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            canvas.translate(width / 2, height / 2)  # move origin to page center
                            canvas.rotate(45)  # rotate for slant
                            canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            canvas.restoreState()


                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        try:
                            pdf_data = buffer.getvalue()
                            email = EmailMessage(
                                subject=f'{name} {ass} Assignment PDF',
                                body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                to=[user.email],
                            )
                            email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                            email.send()
                        except:
                            pass
                        response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                        return response


                    # try:
                    #     pdf_buffer.seek(0)
                    #     pdf_data = pdf_buffer.getvalue()
                    #     email = EmailMessage(
                    #         subject=f'{name} Assignment PDF',
                    #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                    #         from_email=settings.DEFAULT_FROM_EMAIL,
                    #         to=[user.email],
                    #     )
                    #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    #     email.send()
                    # except:
                    #     pass
                    # user.has_downloaded -= 1
                    if user.email != 'calixotu@gmail.com':
                        user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                if int(room) != 0:
                    messages.error(request, d_text)
                    return redirect('cbtroom', room)
                else:
                    messages.error(request, d_text2)
                    return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'SOC112'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow =[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
        context = {
            'list': list(range(1, 201)),
            'chapter': [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'first chapter',
            'choice2': 'second chapter',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            user = request.user
            books = uniuyo568.anths
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                choice1 = int(request.POST.get("chapter"))
                choice2 = int(request.POST.get("chapter2"))

                # chaps = int(request.POST.get("chapter"))
                if 1 == 2:
                    messages.error(request, f"Invalid Chapter")
                else:
                    data1 = books[choice1-1]
                    data2 = books[choice2-1]
                    header1 = uniuyo568.chapters[choice1-1]
                    header2 = uniuyo568.chapters[choice2-1]
                    student = {
                        # 'data': data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Nsiskanabasi Wilson'.upper(),
                        'course': 'SOC112: Introduction to Anthropology'.upper(),
                        'department':  'Department of sociology'.upper(),
                        'faculty': 'Faculty of social science'.upper()

                    }

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(ParagraphStyle(name="SubTitle", fontSize=12, alignment=1, spaceAfter=12, textColor=colors.HexColor("#333333")))
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=15, leading=15, spaceAfter=10))
                        styles.add(ParagraphStyle(name="NormalText2", fontSize=12, leading=15, spaceAfter=10))

                        elements = []


                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))



                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("A BOOK REVIEW", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"<b>CHAPTERS {choice1} and {choice2} OF ANTHROPOLOGY TEXTBOOK</b>", styles["Heading"]))
                        #elements.append(Paragraph(f"<b>({data['Title']})</b>".upper(), styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['cor']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['faculty']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                        elements.append(PageBreak())
                        # ---- CONTENT PAGES ----
                        elements.append(Paragraph("BOOK REVIEW OVERVIEW", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>CHAPTERS:</b> {choice1} and {choice2}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>AUTHOR:</b> Abiodun Johnson Oluwabamide", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PLACE OF PUBLICATION:</b> Lagos, Nigeria", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PUBLISHERS:</b> Lisjohnson Resources Publishers", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>YEAR OF PUBLICATION:</b> 2019", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>NUMBER OF PAGES:</b> XIII + 265", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>REVIEWER:</b> {student['name']}", styles["NormalText"]))
                        #elements.append(Paragraph(f"<b>Feel free to add more details here like number of pages, author etc...</b>", styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("INTRODUCTION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data1[0])), styles["NormalText2"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data2[0])), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph(f"REVIEW OF CHAPTER {choice1}", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>{header1}</b>".upper(), styles['Chapter']))
                        datas1 = [random.choice(data1[1]),random.choice(data1[2]),random.choice(data1[3]),random.choice(data1[4]),random.choice(data1[5])]
                        for i in datas1:
                            elements.append(Paragraph(replace_asterisk(i.replace('paragraph', 'chapter')), styles["NormalText2"]))

                        elements.append(Paragraph(f"REVIEW OF CHAPTER {choice2}", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>{header2}</b>".upper(), styles['Chapter']))
                        datas2 = [random.choice(data2[1]),random.choice(data2[2]),random.choice(data2[3]),random.choice(data2[4]),random.choice(data2[5])]
                        for i in datas2:
                            elements.append(Paragraph(replace_asterisk(i.replace('paragraph', 'chapter')), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("EVALUATION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data1[6])), styles["NormalText2"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data2[6])), styles["NormalText2"]))

                        elements.append(Paragraph("RECOMMENDATION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data1[7])), styles["NormalText2"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data2[7])), styles["NormalText2"]))

                        elements.append(Paragraph("CONCLUSION", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data1[8])), styles["NormalText2"]))
                        elements.append(Paragraph(replace_asterisk(random.choice(data2[8])), styles["NormalText2"]))

                        def draw_content_border(canvas, doc):
                            width, height = A4

                            # === Footer line ===
                            canvas.setStrokeColor(colors.grey)
                            canvas.setLineWidth(0.5)
                            canvas.line(50, 40, width - 50, 40)

                            # === Clickable footer text ===
                            footer_text = f"Original owner of this book review is {student['name']} in {student['dept']}"
                            canvas.setFont("Times-Roman", 9)
                            canvas.setFillColor(colors.red)  # typical link color
                            text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            x_pos = (width - text_width) / 2
                            y_pos = 28
                            canvas.drawString(x_pos, y_pos, footer_text)

                            # Make it clickable
                            canvas.linkURL(
                                "https://calixguru.pythonanywhere.com/",
                                (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                                relative=0,
                            )

                            # === Watermark ===
                            canvas.saveState()
                            canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            canvas.translate(width / 2, height / 2)  # move origin to page center
                            canvas.rotate(45)  # rotate for slant
                            canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            canvas.restoreState()


                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        try:
                            pdf_data = buffer.getvalue()
                            email = EmailMessage(
                                subject=f'{name} {ass} Assignment PDF',
                                body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                to=[user.email],
                            )
                            email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                            email.send()
                        except:
                            pass
                        response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                        return response


                    # try:
                    #     pdf_buffer.seek(0)
                    #     pdf_data = pdf_buffer.getvalue()
                    #     email = EmailMessage(
                    #         subject=f'{name} Assignment PDF',
                    #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                    #         from_email=settings.DEFAULT_FROM_EMAIL,
                    #         to=[user.email],
                    #     )
                    #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    #     email.send()
                    # except:
                    #     pass
                    # user.has_downloaded -= 1
                    if user.email != 'calixotu@gmail.com':
                        user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                if int(room) != 0:
                    messages.error(request, d_text)
                    return redirect('cbtroom', room)
                else:
                    messages.error(request, d_text2)
                    return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'SED211'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = [1,2,3,4,5,6,7,8,9]
        context = {
            'list': [1, 2, 3, 4],
            'chapter': [
                        "Specific topics in chemistry that needs improvisation",
                        "Challenges of Improvisation in the 21st century in chemistry class",
                        "Barriers/factors affecting effective improvisation in chemistry education and possible solutions to the barriers",
                        "Strategies and skills needed for improvisation",
                        "Environment as a resource in teaching chemistry",
                        "Philosophy/concept of improvisation and rational of improvisation",
                        "PRINCIPLES AND SOURCING OF MATERIALS FOR IMPROVISATION IN CHEMISTRY",
                        "Safety practices improvisation and criteria for selection of material for improvisation",
                        "Industry as a resource in improvisation for teaching",
                        ],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'term paper topic',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def random_column_wise_choice2(list_of_lists):
                if not list_of_lists or not list_of_lists[0]:
                    return []

                num_positions = len(list_of_lists[0])  # Length of each sublist
                result = []

                for i in range(num_positions):
                    # Pick a random element from the ith position across all sublists
                    choice = random.sample([lst[i] for lst in list_of_lists], 2)
                    result.append(choice)

                return result
            user = request.user
            books = uniuyo567
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                try:
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                chaps = int(request.POST.get("chapter"))
                if chaps not in allow:
                    messages.error(request, f"Not yet ready for download, an email will be sent to you once it is ready")
                else:
                    data = {
                        "Title": books.books[chaps]["Title"],
                        # "Editors": books.books[chaps]["Editors"],
                        # "Place": books.books[chaps]["Place"],
                        # "Publishers": books.books[chaps]["Publishers"],
                        # "Year": books.books[chaps]["Year"],
                        "Headers": books.books[chaps]["Headers"][2:-2],

                        # Pick one random item from single lists
                        "Introduction": random.choice(books.books[chaps]["Introduction"]),
                        "Abstract": random.choice(books.books[chaps]["Abstract"]),
                        "Conclusion": random.choice(books.books[chaps]["Conclusion"]),
                        "Reference": random.sample(books.books[chaps]["Reference"], 15),

                        # Chapters: one random from each inner list
                        "Chapters": books.books[chaps]["Chapters"],
                    }



                    student = {
                        'data': data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Prof. Theresa Udofia'.upper(),
                        'course': 'SED211: IMPROVISATION IN SCIENCE EDUCATION'.upper(),
                        'department': 'department of science education (chemistry education unit)'.upper(),
                        'faculty': 'sciene education'.upper()

                    }

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    my_dict = {3: 'Day', 2: 'Chapter', 1: 'Chapter'}
                    def get_label(key):
                        return my_dict.get(key, "Key not found")

                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(
                            ParagraphStyle(
                                name="SubTitle",
                                parent=styles["Normal"],
                                fontSize=11,
                                leading=16,
                                spaceBefore=18,   # 👈 GAP ABOVE HEADER
                                spaceAfter=6,
                                fontName="Helvetica-Bold",
                            )
                        )
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=11, leading=15, spaceAfter=10))
                        styles.add(ParagraphStyle(
                            name="NormalText2",
                            fontName="Times-Roman",   # professional serif font
                            fontSize=14,              # standard readable size
                            leading=17,               # line spacing for readability
                            spaceBefore=0,            # spacing before paragraph
                            spaceAfter=6,             # spacing after paragraph
                            alignment=4,              # justified alignment (0=left, 1=center, 2=right, 4=justify)
                            textColor=colors.black,   # standard black text
                            leftIndent=0,             # no left indent
                            rightIndent=0,
                            firstLineIndent=20        # optional first-line indent for paragraphs
                        ))
                        styles.add(ParagraphStyle(
                            name="ReferenceStyle",
                            fontSize=11,
                            leading=15,
                            leftIndent=20,        # Indent for the body of the reference
                            firstLineIndent=-20,  # Hanging indent
                            spaceAfter=5
                        ))


                        elements = []


                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))



                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("A TERM PAPER", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"<b>{data['Title'].upper()}</b>", styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['cor']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>INTRODUCTION</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Introduction"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>ABSTRACT</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Abstract"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph(f"<b>{data['Title']}</b>".upper(), styles["Chapter"]))
                        for header, chapters in zip(data["Headers"], data["Chapters"]):
                            # Header
                            elements.append(
                                Paragraph(
                                    f"{random.choice(header).upper()}",
                                    styles["SubTitle"]
                                )
                            )

                            # Pick TWO UNIQUE chapter bodies
                            body = random.sample(chapters, 2)

                            # First write-up
                            for i in body:
                                elements.append(
                                    Paragraph(
                                        replace_asterisk(i),
                                        styles["NormalText2"]
                                    )
                                )
                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>CONCLUSION</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Conclusion"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>REFERENCE</b>", styles["Chapter"]))
                        for i in data["Reference"]:
                            elements.append(Paragraph(f"{replace_asterisk(i)}", styles["ReferenceStyle"]))
                        elements.append(PageBreak())

                        def draw_content_border(canvas, doc):
                            # width, height = A4

                            # # === Footer line ===
                            # canvas.setStrokeColor(colors.grey)
                            # canvas.setLineWidth(0.5)
                            # canvas.line(50, 40, width - 50, 40)

                            # # === Clickable footer text ===
                            # footer_text = f"Original owner of this book review is {student['name']} in {student['dept']}"
                            # canvas.setFont("Times-Roman", 9)
                            # canvas.setFillColor(colors.red)  # typical link color
                            # text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            # x_pos = (width - text_width) / 2
                            # y_pos = 28
                            # canvas.drawString(x_pos, y_pos, footer_text)

                            # # Make it clickable
                            # canvas.linkURL(
                            #     "https://calixguru.pythonanywhere.com/",
                            #     (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                            #     relative=0,
                            # )

                            # # === Watermark ===
                            # canvas.saveState()
                            # canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            # canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            # canvas.translate(width / 2, height / 2)  # move origin to page center
                            # canvas.rotate(45)  # rotate for slant
                            # canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            # canvas.restoreState()
                            pass


                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        try:
                            pdf_data = buffer.getvalue()
                            email = EmailMessage(
                                subject=f'{name} {ass} Assignment PDF',
                                body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                to=[user.email],
                            )
                            email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                            email.send()
                        except:
                            pass
                        response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                        return response


                    # try:
                    #     pdf_buffer.seek(0)
                    #     pdf_data = pdf_buffer.getvalue()
                    #     email = EmailMessage(
                    #         subject=f'{name} Assignment PDF',
                    #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                    #         from_email=settings.DEFAULT_FROM_EMAIL,
                    #         to=[user.email],
                    #     )
                    #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    #     email.send()
                    # except:
                    #     pass
                    # user.has_downloaded -= 1
                    if user.email != 'calixotu@gmail.com':
                        user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                if int(room) != 0:
                    messages.error(request, d_text)
                    return redirect('cbtroom', room)
                else:
                    messages.error(request, d_text2)
                    return redirect('buypin')
        return render(request, 'base/gst.html', context)
    
    elif ass.lower() == 'POL114'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = [1,2,3,4,5,6,7,8,9]
        context = {
            'list': [1, 2, 3, 4],
            'chapter': [
                        "Political obligations and civil disobedience",
                        ],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'mini project topic',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def random_column_wise_choice2(list_of_lists):
                if not list_of_lists or not list_of_lists[0]:
                    return []

                num_positions = len(list_of_lists[0])  # Length of each sublist
                result = []

                for i in range(num_positions):
                    # Pick a random element from the ith position across all sublists
                    choice = random.sample([lst[i] for lst in list_of_lists], 2)
                    result.append(choice)

                return result
            user = request.user
            books = uniuyo569
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                try:
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                chaps = int(request.POST.get("chapter"))
                if chaps not in allow:
                    messages.error(request, f"Not yet ready for download, an email will be sent to you once it is ready")
                else:
                    data = {
                        "Title": books.books[chaps]["Title"],
                        # Pick one random item from single lists
                        "Introduction": random.choice(books.books[chaps]["Introduction"]),
                        "Summary": random.choice(books.books[chaps]["Summary"]),
                        "Conclusion": random.choice(books.books[chaps]["Conclusion"]),
                        "Suggestion": random.choice(books.books[chaps]["Suggestion"]),
                        "Bibliography": random.choice(books.books[chaps]["Bibliography"]),
                        "Chapters": books.books[chaps]["Chapters"],
                    }



                    student = {
                        'data': data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'DR. Uko Uwak'.upper(),
                        'course': 'POL114: Introduction to Political Theories'.upper(),
                        'department': 'department of social sciences'.upper(),
                        'faculty': 'arts'.upper()

                    }

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    my_dict = {3: 'Day', 2: 'Chapter', 1: 'Chapter'}
                    def get_label(key):
                        return my_dict.get(key, "Key not found")

                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(
                            ParagraphStyle(
                                name="SubTitle",
                                parent=styles["Normal"],
                                fontSize=11,
                                leading=16,
                                spaceBefore=18,   # 👈 GAP ABOVE HEADER
                                spaceAfter=6,
                                fontName="Helvetica-Bold",
                            )
                        )
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=11, leading=15, spaceAfter=10))
                        styles.add(ParagraphStyle(
                            name="NormalText2",
                            fontName="Times-Roman",   # professional serif font
                            fontSize=14,              # standard readable size
                            leading=17,               # line spacing for readability
                            spaceBefore=0,            # spacing before paragraph
                            spaceAfter=6,             # spacing after paragraph
                            alignment=4,              # justified alignment (0=left, 1=center, 2=right, 4=justify)
                            textColor=colors.black,   # standard black text
                            leftIndent=0,             # no left indent
                            rightIndent=0,
                            firstLineIndent=20        # optional first-line indent for paragraphs
                        ))
                        styles.add(ParagraphStyle(
                            name="ReferenceStyle",
                            fontSize=11,
                            leading=15,
                            leftIndent=20,        # Indent for the body of the reference
                            firstLineIndent=-20,  # Hanging indent
                            spaceAfter=5
                        ))


                        elements = []


                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))



                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("A TERM PAPER", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"<b>{data['Title'].upper()}</b>", styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['cor']}", styles["Body"]))
                        elements.append(Paragraph(f"The Course Lecturer".upper(), styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>INTRODUCTION</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Introduction"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        
                        elements.append(Paragraph(f"<b>{data['Title']}</b>".upper(), styles["Chapter"]))
                        for chapters in data["Chapters"]:

                            # Pick TWO UNIQUE chapter bodies
                            body = random.sample(chapters, 2)

                            # First write-up
                            for i in body:
                                elements.append(
                                    Paragraph(
                                        replace_asterisk(i),
                                        styles["NormalText2"]
                                    )
                                )
                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>PERSONAL SUGGESTION</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Suggestion"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>SUMMARY</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Summary"]), styles["NormalText2"]))

                        elements.append(Paragraph("<b>CONCLUSION</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Conclusion"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("<b>BIBLIOGRAPHY</b>", styles["Chapter"]))
                        elements.append(Paragraph(replace_asterisk(data["Bibliography"]), styles["NormalText2"]))
                        elements.append(PageBreak())

                        def draw_content_border(canvas, doc):
                            # width, height = A4

                            # # === Footer line ===
                            # canvas.setStrokeColor(colors.grey)
                            # canvas.setLineWidth(0.5)
                            # canvas.line(50, 40, width - 50, 40)

                            # # === Clickable footer text ===
                            # footer_text = f"Original owner of this book review is {student['name']} in {student['dept']}"
                            # canvas.setFont("Times-Roman", 9)
                            # canvas.setFillColor(colors.red)  # typical link color
                            # text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            # x_pos = (width - text_width) / 2
                            # y_pos = 28
                            # canvas.drawString(x_pos, y_pos, footer_text)

                            # # Make it clickable
                            # canvas.linkURL(
                            #     "https://calixguru.pythonanywhere.com/",
                            #     (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                            #     relative=0,
                            # )

                            # # === Watermark ===
                            # canvas.saveState()
                            # canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            # canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            # canvas.translate(width / 2, height / 2)  # move origin to page center
                            # canvas.rotate(45)  # rotate for slant
                            # canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            # canvas.restoreState()
                            pass


                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        try:
                            pdf_data = buffer.getvalue()
                            email = EmailMessage(
                                subject=f'{name} {ass} Assignment PDF',
                                body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                                from_email=settings.DEFAULT_FROM_EMAIL,
                                to=[user.email],
                            )
                            email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                            email.send()
                        except:
                            pass
                        response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                        return response


                   
                    if user.email != 'calixotu@gmail.com':
                        user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                if int(room) != 0:
                    messages.error(request, d_text)
                    return redirect('cbtroom', room)
                else:
                    messages.error(request, d_text2)
                    return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'PHY117'.lower():
        allow = []
        context = {
            'list': list(range(1, 201)),
            'chapter': ["All chapters"],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'choice': 'chapter',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def random_column_wise_choice(list_of_lists):
                if not list_of_lists or not list_of_lists[0]:
                    return []

                num_positions = len(list_of_lists[0])  # Length of each sublist
                result = []

                for i in range(num_positions):
                    # Pick a random element from the ith position across all sublists
                    choice = random.choice([lst[i] for lst in list_of_lists])
                    result.append(choice)

                return result
            user = request.user
            books = uniuyo56

            cover = request.POST.get("cover")
            try:
                choice = 1
            except ValueError:
                return redirect(request.path)

            if choice in allow:
                messages.error(request, f"Review not yet ready for download")
            else:
                data = {
                        "Title": f"ENTREPRENEURSHIP AND INNOVATION",
                        "Editors": "PROF. FRIDAY E. UDE, PROF. NTIEDO J. UMOREN, SUNDAY S. AKPAN, PH.D",
                        "Place": "UYO, NIGERIA",
                        "Publishers": "DIRECTORATE OF GENERAL STUDIES, UNIVERSITY OF UYO",
                        "Year": "2025",
                        "Pages": "xvi + 323",
                        # Use sorted to ensure a list can be passed to random.sample
                        "Introduction": random.sample(books.intro, 2),
                        "Evaluation": random.sample(books.eval, 1),
                        "Conclusion": random.sample(books.conc, 3),
                        "Recommendation": random.sample(books.recom, 3),
                        "chapters": [random.choice(books.ch1),
                                    random.choice(books.ch2),
                                    random.choice(books.ch3),
                                    random.choice(books.ch4),
                                    random.choice(books.ch5),
                                    random.choice(books.ch6),
                                    random.choice(books.ch7),
                                    random.choice(books.ch8),
                                    random.choice(books.ch9),
                                    random.choice(books.ch10),
                                    random.choice(books.ch11),
                                    random.choice(books.ch12),
                                    random.choice(books.ch13),
                                    random.choice(books.ch14),
                                    random.choice(books.ch15),
                                    random.choice(books.ch16),
                                    random.choice(books.ch17),
                                    random.choice(books.ch18),]
                    }


                student = {
                    'data': data,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'cor': 'Dr Sunday S. Akpan, Ph.D'.upper(),
                    'course': 'ENT221: ENTREPRENEURSHIP AND INNOVATION'.upper(),
                    'department': 'department of insurance and risk management'.upper(),
                    'faculty': 'Management science'.upper()

                }

                # if user.has_downloaded < 1:
                #     messages.error(request, "You cannot download any material at the moment")
                #     return redirect(request.META.get('HTTP_REFERER', '/'))


                def generate_assignment_pdf():
                    buffer = BytesIO()
                    doc = SimpleDocTemplate(
                        buffer,
                        pagesize=A4,
                        rightMargin=50,
                        leftMargin=50,
                        topMargin=60,
                        bottomMargin=50,
                    )

                    # ---- Styles ----
                    styles = getSampleStyleSheet()
                    styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                    styles.add(ParagraphStyle(name="SubTitle", fontSize=12, alignment=1, spaceAfter=12, textColor=colors.HexColor("#333333")))
                    styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                    styles.add(ParagraphStyle(name="NormalText", fontSize=11, leading=15, spaceAfter=10))

                    elements = []


                    # styles = getSampleStyleSheet()
                    styles.add(ParagraphStyle(
                        name="CoverTitle",
                        fontName="Helvetica-Bold",
                        fontSize=22,
                        alignment=1,
                        leading=28,       # better line spacing
                        spaceAfter=30,
                    ))
                    styles.add(ParagraphStyle(
                        name="Heading",
                        fontName="Helvetica-Bold",
                        fontSize=14,
                        alignment=1,
                        leading=20,
                        spaceAfter=20,
                    ))
                    styles.add(ParagraphStyle(
                        name="Body",
                        fontName="Times-Roman",
                        fontSize=12,
                        alignment=1,
                        leading=18,       # adds breathing room if text wraps
                        spaceAfter=10,
                    ))
                    styles.add(ParagraphStyle(
                        name="FooterSemiRight",
                        fontName="Times-Roman",
                        fontSize=14,
                        alignment=2,      # start as right-aligned
                        rightIndent=100,  # pull it inward so it’s between center & right
                        spaceAfter=20,
                    ))



                    # === Cover Page ===
                    # elements.append(Spacer(1, 20))
                    # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                    elements.append(Spacer(1, 20))

                    elements.append(Paragraph("AN ASSIGNMENT", styles["Heading"]))
                    elements.append(Paragraph("ON", styles["Heading"]))
                    elements.append(Paragraph("PHY117", styles["Heading"]))
                    elements.append(Spacer(1, 20))

                    elements.append(Paragraph("BY", styles["Heading"]))
                    elements.append(Spacer(1, 10))

                    elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                    elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                    elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                    elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                    elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                    elements.append(Spacer(1, 20))

                    elements.append(Spacer(1, 80))
                    date_str = datetime.datetime.now().strftime("%B, %Y")
                    elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))



                    elements.append(PageBreak())
                    # ---- CONTENT PAGES ----
                    elements.append(Paragraph("PLEASE THE SLOPES AND INTERCEPTS ARE COMPLETELY COMPUTER GENERATED, PLEASE USE YOUR OWN VALUES" \
                    "TO COMPLETE THE CALCULATIONS WHERE GRAPH IS INVOLVED NECESSARY", styles["Chapter"]))

                    # Question 1 (Data/Graph, assumed from prior context, was in user's prompt history)
                    # The user provided input data for Q1 implicitly, I cannot access that original data.
                    # The helper function assumes standard data or takes parameters.
                    # We will assume get_question_1_elements() can run without extra parameters for this example.
                    elements.extend(rplab.get_question_1_elements(styles))

                    # Question 2 (Volume/Error)
                    elements.extend(rplab.get_question_2_elements(styles))

                    # Question 3 (T^2/h Graph)
                    elements.extend(rplab.get_question_3_elements(styles))

                    # Question 4 (SHM definitions)
                    elements.extend(rplab.get_question_4_elements(styles))

                    # Question 5 (SHM distance)
                    elements.extend(rplab.get_question_5_elements(styles))

                    # Question 6.A (Balancing rod, the one about the 10N weight)
                    elements.extend(rplab.get_question_6a_elements(styles))
                    elements.extend(rplab.get_question_6b_elements(styles))

                    # Question 7 (Cooling/Sound experiment)
                    elements.extend(rplab.get_question_7_elements(styles))

                    # Question 8 (Density error propagation)
                    elements.extend(rplab.get_question_8_elements(styles))

                    # Question 9 (Meter rule balancing)
                    elements.extend(rplab.get_question_9_elements(styles))

                    def draw_content_border(canvas, doc):
                        # width, height = A4

                        # # === Footer line ===
                        # canvas.setStrokeColor(colors.grey)
                        # canvas.setLineWidth(0.5)
                        # canvas.line(50, 40, width - 50, 40)

                        # # === Clickable footer text ===
                        # footer_text = "Calixguru Book Review System - Confidential"
                        # canvas.setFont("Times-Roman", 9)
                        # canvas.setFillColor(colors.red)  # typical link color
                        # text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                        # x_pos = (width - text_width) / 2
                        # y_pos = 28
                        # canvas.drawString(x_pos, y_pos, footer_text)
                        pass

                        # Make it clickable
                        # canvas.linkURL(
                        #     "https://calixguru.pythonanywhere.com/",
                        #     (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                        #     relative=0,
                        # )

                        # === Watermark ===
                        # canvas.saveState()
                        # canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                        # canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                        # canvas.translate(width / 2, height / 2)  # move origin to page center
                        # canvas.rotate(45)  # rotate for slant
                        # canvas.drawCentredString(0, 0, "C A L I X G U R U")
                        # canvas.restoreState()


                    # ---- Build PDF ----
                    doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                    buffer.seek(0)
                    try:
                        pdf_data = buffer.getvalue()
                        # email = EmailMessage(
                        #     subject=f'{name} {ass} Assignment PDF',
                        #     body=f'Hello {user.firstname}, please find your {ass} assignment PDF attached below.',
                        #     from_email=settings.DEFAULT_FROM_EMAIL,
                        #     to=[user.email],
                        # )
                        # email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                        # email.send()
                    except:
                        pass
                    response = FileResponse(buffer, as_attachment=True, filename=f"{name}_{ass}_assignment.pdf")
                    return response


                # try:
                #     pdf_buffer.seek(0)
                #     pdf_data = pdf_buffer.getvalue()
                #     email = EmailMessage(
                #         subject=f'{name} Assignment PDF',
                #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                #         from_email=settings.DEFAULT_FROM_EMAIL,
                #         to=[user.email],
                #     )
                #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                #     email.send()
                # except:
                #     pass
                # user.has_downloaded -= 1
                # if user.email != 'calixotu@gmail.com':
                #     user.has_downloaded -= 1
                # user.save()
                response = generate_assignment_pdf()
                return response

        return render(request, 'base/gst.html', context)


    elif ass.lower() == 'CUSTOM'.lower():
        types = ['Assignment', 'Term paper', 'Book review']
        months = ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"]

        if request.user.email != 'calixotu@gmail.com':
            messages.error(request, "Sorry you can't access that")
            return redirect('select-tournament')
        context = {
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'months': months,
            'institution': institution,
            'types': types,
        }

        if request.method == "POST":
            user = request.user
            if user.email == 'calixotu@gmail.com':
                try:
                    main_title = request.POST.get("main")
                    type = request.POST.get("type")
                    introduction = request.POST.get("introduction", "").strip() or ""
                    abstract = request.POST.get("abstract", "").strip() or ""

                    include_headers = request.POST.get("include_headers") == "on"
                    table_of_contents = request.POST.get("table_of_contents") == "on"

                    chap_headers = request.POST.get("chap_headers", "[]").strip()
                    chap_body = request.POST.get("chap_body", "[]").strip().replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ')
                    recommendation = request.POST.get("recommendation", "").strip() or ""
                    conclusion = request.POST.get("conclusion", "").strip() or ""
                    reference = request.POST.get("reference", "[]").strip()

                    lecturer_name = request.POST.get("lecturer_name", "").strip()
                    course_name = request.POST.get("course_name", "").strip()
                    month = request.POST.get("month", "").strip()
                    lecturer_dept = request.POST.get("lecturer_dept", "").strip()
                    hmm = []
                    for i, v in zip(eval(chap_headers), eval(chap_body)):
                        hmm.append({'head': i.upper(), 'body': v.replace('-', ' ')})

                    # chap_headers = [line.strip() for line in chap_headers.splitlines() if line.strip()]
                    # chap_body = [line.strip() for line in chap_body.splitlines() if line.strip()]
                    # reference = [line.strip() for line in reference.splitlines() if line.strip()]

                    body = []
                    if include_headers == 'on':
                        for u, v in zip(chap_headers, chap_body):
                            body.append({'head':'', 'title':u, 'body': v})
                    else:
                        start = 1
                        for u,v in zip(chap_headers, chap_body):
                            body.append({'head':f'Chapter {start}', 'title':u, 'body': v})
                            start = start + 1


                except ValueError:
                    messages.error(request, "Please enter valid details")
                    return redirect(request.path)



                html_string = render_to_string('pdf/custom.html', {
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'month': month.upper(),
                    "main_title": main_title.upper(),
                    "type": type.upper(),
                    "Introduction": introduction,
                    "Abstract": abstract,
                    # "Body": eval(chap_body),
                    "Body": hmm,
                    "Recommendation": recommendation,
                    "Conclusion": conclusion,
                    "Reference": reference,

                    'cor': lecturer_name.upper(),
                    'course': course_name.upper(),
                    'department': lecturer_dept.upper()
                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                return response
            else:
                messages.error(request, "You are not allowed to do that")
                return redirect(request.META.get('HTTP_REFERER', '/'))

        return render(request, 'base/gst_custom.html', context)

    elif ass.lower() == 'PRAAT'.lower():
        url = f"https://wa.me/2349071902185?text=Hi%20Calixguru,%20my%20name%20is%20{request.user.firstname}%20and%20I%20want%20to%20do%20Praat%20assignment%20"
        return redirect(url)
    else:
        messages.error(request, f'{ass} assignment is not available at the moment. Join a CBT room for more details')
        return redirect(d_redirect)


@login_required(login_url='login')
def akscoe_ass(request):
    # Define common context
    schools = {'uniuyo': 'UNIVERSITY OF UYO',
               'aksu': 'AKWA IBOM STATE UNIVERSITY',
               'akscoe': 'AKWA IBOM STATE COLLEGE OF EDUCATION'}
    name = request.GET.get('name').upper()
    reg = request.GET.get('reg').upper()
    ass = request.GET.get('ass')
    dept = request.GET.get('dept').upper()
    fac = request.GET.get('fac').upper()
    institution = schools[request.GET.get('inst')]

    if ass.lower() == 'GST111'.lower():
        pass
    else:
        messages.error(request, f'{ass} assignment is not available at the moment')
        return redirect('select-tournament')


from django.views.decorators.csrf import csrf_exempt
import json

sample_data = questions.sample_data


@login_required(login_url='login')
def assignment_view(request):
    masters = ['calixotu@gmail.com', 'ipenkojare97@gmail.com']
    if request.user and request.user.email not in masters:
        messages.error(request, 'You are not allowed here')
        return redirect('home')
    # pins = set()
    # while len(pins) < 100:
    #     pins.add(str(random.randint(100000, 999999)))  # always 6 digits

    # for code in pins:
    #     Asspin.objects.create(code=code)
    # code = Asspin.objects.all()


    return render(request, "assignment/task.html", {})

csrf_exempt  # remove if frontend sends CSRF correctly
def validate_pin(request):
    if request.method != "POST":
        return JsonResponse({"valid": False, "error": "POST required"}, status=400)

    try:
        data = json.loads(request.body.decode("utf-8"))
    except Exception:
        return JsonResponse({"valid": False, "error": "Invalid JSON"}, status=400)

    pin_code = data.get("pin", "")
    try:
        pin = Asspin.objects.get(code=pin_code, used=False)

        # Generate device_id only if first time use
        if not pin.device_id:
            device_id = str(uuid.uuid4())
            pin.device_id = device_id
            pin.save()
            request.session['device_id'] = device_id
        else:
            # If already used on another device, block
            if request.session.get("device_id") != pin.device_id:
                return JsonResponse({"valid": False, "error": "PIN already bound to another device"}, status=403)

        return JsonResponse({"valid": True, "progress": pin.current_index})
    except Asspin.DoesNotExist:
        return JsonResponse({"valid": False})


def get_data(request, index):
    pin = request.GET.get("pin")
    try:
        pin_obj = Asspin.objects.get(code=pin, used=False)

        # Check device binding
        if request.session.get("device_id") != pin_obj.device_id:
            return JsonResponse({"done": True, "error": "Unauthorized device"}, status=403)

        if index >= len(sample_data):
            pin_obj.used = True
            pin_obj.save()
            return JsonResponse({"done": True})

        return JsonResponse(sample_data[index])
    except Asspin.DoesNotExist:
        return JsonResponse({"done": True})


@csrf_exempt
def update_progress(request):
    try:
        data = json.loads(request.body)
    except Exception:
        return JsonResponse({"ok": False, "error": "Invalid JSON"}, status=400)

    try:
        pin = Asspin.objects.get(code=data['pin'], used=False)

        # Check device binding
        if request.session.get("device_id") != pin.device_id:
            return JsonResponse({"ok": False, "error": "Unauthorized device"}, status=403)

        pin.current_index = data['progress']
        if data['progress'] >= len(sample_data):
            pin.used = True
        pin.save()
        return JsonResponse({"ok": True})
    except Asspin.DoesNotExist:
        return JsonResponse({"ok": False})






