from django.shortcuts import render, get_object_or_404, redirect
from pracs.models import BlogPost, Pins
from pracs.forms import BlogPostForm
from django.contrib import messages
from pracs import views
from django.utils.text import slugify
from django.template.defaultfilters import slugify


categories = views.categories
def blog_list(request, category):
    posts = BlogPost.objects.filter(category=category).order_by('-created_at')
    context = {'posts': posts, 'category': category, 'categories': categories}
    return render(request, 'blog/blog_list.html', context)

def blog_detail(request, slug):
    subs = []
    for i in Pins.objects.all():
        subs.append(i.pin)
    post = get_object_or_404(BlogPost, slug=slug)
    related_posts = BlogPost.objects.filter(category=post.category).exclude(slug=slug)[:6]
    context = {'post': post, 'related_posts': related_posts, 'subs': subs}
    return render(request, 'blog/blog_detail.html', context)

def blog_create(request):
    if request.method == 'POST':
        try:
            thumbnail = request.POST.get('thumbnail')
            title = request.POST.get('title')
            category = request.POST.get('category')
            content = request.POST.get('content')
            BlogPost.objects.create(thumbnail=thumbnail, title=title,
                                    category=category, content=content)
            messages.success(request, 'Post created successfully')
            return redirect(request.META.get('HTTP_REFERER', '/'))
        except:
            messages.error(request, 'That title may already exist')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        form = BlogPostForm()
    return render(request, 'blog/blog_form.html', {'form': form, 'action': 'Create', 'categories': categories})

def blog_update(request, pk):
    post = get_object_or_404(BlogPost, pk=pk)
    if request.method == 'POST':
        post.thumbnail = request.POST.get('thumbnail')
        post.title = request.POST.get('title')
        post.category = request.POST.get('category')
        post.content = request.POST.get('content')
        post.slug = slugify(request.POST.get('title'))
        post.save()
        messages.success(request, 'Post modified successfully')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    return render(request, 'blog/blog_form.html', {'post': post, 'action': 'Update', 'categories': categories})

def blog_delete(request, pk):
    post = BlogPost.objects.get(id=pk)
    if request.method == 'POST':
        post.delete()
        messages.success(request, 'Post successfully deleted')
        return redirect('home')
    return render(request, 'blog/blog_confirm_delete.html', {'post': post})
