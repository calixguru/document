from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from datetime import timedelta, datetime
from django.utils import timezone
from django.db.models import Q, Count
from .models import *
import random
import math
import time
import ast
from django.http import JsonResponse, HttpResponse
from django.core.mail import EmailMessage
from .gst_questions import book1, book2
from .league import questions as qsss
from .views import categories, courses, uniuyo, akscoe, aksu

from django.contrib.auth.decorators import login_required
from . import quests, links

from django.shortcuts import render, redirect
from django.contrib.auth import logout
from django.utils.timezone import now
from django.contrib.auth.decorators import login_required
from django.contrib.auth.signals import user_logged_in
from django.dispatch import receiver

from django.core.files.base import ContentFile
from .forms import FileUploadForm

import datetime
from django.shortcuts import get_object_or_404
from django.http import FileResponse

from io import BytesIO
from django.http import FileResponse
from django.shortcuts import get_object_or_404
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak, Flowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch, cm
from django.utils import timezone
import datetime
from .decorators import cbt_room

import json
# import fitz  # PyMuPDF
import os
# from django.conf import settings

# from reportlab.pdfgen import canvas
# from reportlab.lib.colors import red
# from PyPDF2 import PdfReader, PdfWriter

code = 199757

owner = ['calixotu@gmail.com', 'charleseffiongwisdom@gmail.com', 'joyikpaisong@gmail.com', 
              'biqmartin11@gmail.com', 'princewilldaniel2009@gmail.com', 'editialex4@gmail.com',
              'messiagent3@gmail.com', 'timothyuwemedimo69@gmail.com', 'royalqueen450@gmail.com']

unit1 = 500
unit2 = 1200

COURSES = ['GST111', 'GST211', 'MTH111', 'PHY111', 'ANA211', 'AEB211', 'PHS211', 'PHS411', 'PHS412', 'PHS413', 'PHS414', 'PHS415', 'PHS416', 'MBC413',
               'CHM111', 'BIO112', 'GET211', 'GET214', 'EDU211', 'EDU111', 'ANA213', 'ANA212','MBC 211', 'UUY-PHS 212', 'ENG111', 'REL111', 
               'CHE 111', 'COS111', 'ENG119', 'RCS111', 'GST112(AKSU)',]

TOPICS = """{ 
    'PHS411': ["The 'Master gland' of the endocrine system", 'Historical origin of neuro-endocrine connections', 'Hypothalamic neurosecretions', 'Servo mechanisms between the hypothalamus, pituitary, and other endocrine organs', 'Functional anatomy of the hypothalamo-pituitary link', 'Pituitary secretions', 'Cytokines: the messengers of the immune system. Effect of cytokines and other immunomodulators on the brain and neuroendocrine system', 'Neural and endocrine regulation of the immune system. Hypothalamic integration of the neuroendocrine-immune system', 'Immunoendocrinology: The cells of immune system, the thymus gland and its hormones', 'Current concepts of channels of communication between the hypothalamus and the pituitary', 'Current concepts on the servo mechanisms between the hypothalamus, the pituitary and other endocrine organs'],
    'PHS412': ['Cellular mechanism underlying cardiac arrhythmias', 'Cardiopulmonary function in the fetus and in old age', 'Principles of servomechanism as applied to cardiopulmonary physiology', 'Cardiopulmonary responses at rest and in moderate to severe stress', 'Physiological basis of hypertension', 'Pathophysiology of the adult respiratory distress syndrome (ARDS)', 'Developmental milestones in cardiovascular and respiratory physiology'],
    'PHS413': ['Sources of Scientific Information', 'Orientation to Statistics and Basic Statistical Terminology', 'Common Errors in Text, Illustrations, References, Symbols, and Abbreviations', 'Design of Experiments', 'Writing Scientific Papers and Research Proposals'],
    'PHS414': ['The SI units of some variables in physiology: measurement instruments', 'Selected instruments used in the laboratory', 'Basic principles of experiment; essence of laboratory experiment/research; the general format or plan of research', 'Blood experiments: Full blood counts, haematological indices, osmotic fragility test', 'General introduction to laboratory work and health and safety in the laboratory', 'GIT experiments: salivary secretion, gastric acid secretion, gastric ulcer, intestinal motility, transit time', 'Basic principles of experiment; essence of laboratory experiment/research; the general format or plan of the research', 'Use of laboratory animals: ethical consideration, choice of animal, care of laboratory animals', 'Excitable tissue: nerve-muscle preparation, simple muscle twitch, action potential', 'General introduction to laboratory work, health and safety in the laboratory', "CVS experiments: BP measurements, PP, PR, MAP, ECG, isolated frog's heart", 'Separation techniques: physical methods, chromatography, centrifugation, etc., with examples', 'Respiratory physiology: static and dynamic lung function tests, PEFR, spirometry, stethograph'],
    'PHS415': ["Hospital visits to observe obese patients, precocious puberty, Parkinson's disease, cretinism, endemic goiter, and hyperthyroid patients", 'Laboratory tests for HIV/AIDS', 'Hospital recording of blood pressure, ECG, and CD4 counts', 'Measurement of visual acuity, visual fields (perimetry), and ophthalmoscopy', 'Hospital recording of blood pressure, ECG and CD4 counts'],
    'PHS416': ['Environmental Pollution', 'Aviation, Space, High Altitude, and Submarine Physiology', 'Human and animal physiological responses and adaptations to extreme conditions of heat, cold, altitude, pressure, and gravity', 'Circadian Rhythms', 'Effect of Environmental Pollutants on Specific Organs of the Body', 'Animal Senses'],
    'MBC413': ['Adulteration of foods, drinks, and drugs', 'Contamination of foods and drugs', 'Nutritional problems in developed and developing countries', 'Food poisoning', 'Nutritional disorders including obesity, Protein Energy Malnutrition, kwashiorkor, marasmus', 'Toxicants in food', 'Quality control of foods and drugs'],
    'ANA211': ['Principles of Kinesiology', 'Pectoral Region', 'Flexor Compartment of Forearm', 'Cutaneous Innervation of the Lower Limb', 'Axilla', 'General Organization of Body System', 'Cutaneous Innervation of the Upper Limb', 'Types of Muscles', 'Breast', 'Applied Anatomy of Nerves (Upper Limb)', 'Extensor Compartment of Forearm', 'Back of the Thigh', 'Movements of Joints', 'Osteology', 'Descriptive terms, planes and terms of relationship of the human body', 'Gluteal Region', 'Hand', 'Sole of the Foot', 'Peroneal and Flexor Compartments of the Leg', 'Arm and Cubital Fossa', 'Arches of the Foot', 'Femoral Triangle', 'Extensor Compartment of the Leg and Dorsum of the Foot', 'Shoulder Region', 'Popliteal Fossa', 'Attachment of Muscles',
    'Blood Supply of the Upper Limb', 'Terms of Comparison', 'Venous and Lymphatic Drainage of the Upper Limb', 'Adductor Canal and Medial Side of the Thigh'],
    'PHS211': ['Reticuloendothelial System', 'Structure and Functions of Cell Membranes', 'Plasma Proteins', 'Transport Process', 'Haemopoiesis', 'Blood Groups - ABO and Rh Systems', 'Biophysical Principles', 'Introduction and History of Physiology', 'Homeostasis and Control Systems including Temperature Regulation', 'Biological Rhythms', 'Blood Transfusion - Indications, Collection, Storage, and Hazards', 'Immunity, Immunodeficiency Diseases, and HIV', 'Special Transport Mechanisms in Amphibian Bladder, Kidney, Gall Bladder, Intestine, Astrocytes and Exocrine Glands', 'WBC and Differential Count', 'Coagulation, Fibrinolysis and Platelet Functions', 'Composition and Functions of Blood'],
    'GST211': ['Deduction, Induction and Inferences', 'Philosophy and Informal Logic', 'Ethics and Aesthetics', 'General Overview', 'Epistemology', 'Philosophy, Social and Scientific Values', 'Sociopolitical Philosophy', 'Informal Fallacies', 'Philosophy and Character Moulding', 'Current Trends in Philosophy', 'The Meaning, Nature and Scope of Philosophy', 'Philosophy of Education', 'Philosophy of Science', 'Philosophy, Religion and Human Co-existence', 'Metaphysics', 'Philosophy, Values and Human Conduct', 'Critical Thinking', 'Some Branches and Problems of Philosophy'],
    'GST111': ['SOUNDS OF ENGLISH', 'REPORT WRITING', 'BOOK REVIEW AND MINUTES WRITING', 'RHETORIC/PUBLIC SPEAKING', 'ETHICAL CONSIDERATIONS', 'WORD FORMATION PROCESSES', 'OTHER KINDS OF WRITING: LETTER WRITING', 'THE ART OF COMMUNICATION', 'LANGUAGE SKILLS AND EFFECTIVE COMMUNICATION', 'ESSAY WRITING', 'THE SENTENCE'],
    'CHM111': ['Electronic Configuration & Periodicity of Elements', 'Moles', 'Radioactivity and Lewis Structure', 'Properties and Behavior of Solids, Liquids, and Gases; and Solutions', 'Periodic Table and Chemical Reactions', 'Properties of Solids, Liquids, and Gases; Behavior of Gases; and Solutions', 'Atom', 'Atomic Structure', 'Quantum Theory of Atom', 'Colligative Properties of Solutions and Chemical Equilibrium', 'Types of Chemical Equations & Shapes of Covalent Molecules'],
    'BIO112': ['Diversity', 'Cell Structure and Organization', 'Elements of Ecology', 'Types of Habitat', 'General Reproduction', 'Interrelationship of Organisms', 'Characteristics and Classification of Living Things', 'Hereditary and Evolution', 'Functions of Cellular Organelles'],
    'GET211': ['Elementary Discussion of Semiconductors', 'Circuit Elements and Sources', 'Circuit Theorems and DC Circuits', 'Analysis of Simple Circuits', 'Illumination', 'Rectifiers', 'Electrostatics and Capacitance'],
    'EDU211': ['Evaluation', 'Developing the Lesson Plan', 'General Classroom Management', 'Curriculum Delivery, General Teaching Methods and Strategies', 'Definition and Types of Curriculum', 'Curriculum Development Process', 'Teaching in a 21st Century Classroom', 'Resources for Teaching with Improvisation', 'Attending to Students with Special Needs'],
    'EDU111': ['Concepts and Dimensions in Education', 'Teaching as a Noble Profession', 'Concept of Growth and Development', 'Basic Concepts and Dimensions in Education'],
    'ANA213': ['Macrophagic system; Cellular immunology; Lymphoid organs; Glands endocrine and exocrine', 'Derivatives of the germ layers, Folding of the embryo, Fetal membranes, Placenta, Development of limbs and Teratology', 'Spermatogenesis', 'Oogenesis', 'Molecular embryology and transgenesis, Gastrulation, Notochord & Neurulation', 'Ovulation', 'The Cardiovascular System, Skin, Structure of the Nails and Hair', 'Hormonal control of uterine cycle, Fertilization and Cleavage', 'Growth and Perinatology; Congenital Malformations - General Introduction', 'Respiratory system; Digestive system; Urinary and Genital systems', 'Ovarian Follicles', 'Electron micrograph studies of each organ', 'Implantation, Reproductive technologies (IVF/Surrogacy/Embryo transfer), Embryo manipulation & potency/twinning', 'Corpus luteum, Menstruation and Uterine cycle'],
    'UUY-PHS 212': ['Structure and functions of nerves', 'Cardiac muscle, smooth muscle and skeletal muscle', 'Membrane potentials', 'Synapses and synaptic transmission', 'Muscles: structure, excitation, theories of excitation-contraction', 'Nerve generation and conduction of impulse and its physiological properties'],
    'ANA212': ['Bone, Bone formation and Joints, Blood and Muscle', 'Microanatomy of the four basic tissues: epithelial, connective, muscular, and nervous tissues', 'Introduction to recombinant DNA, In situ hybridization histochemistry, and Cell dynamics and cycle', 'Introduction to histology', 'Nervous Tissue (PNS and CNS)', 'Cell Membrane, Cellular Organelles', 'Cardiovascular, Respiratory, and Integumentary Systems', 'Female reproductive system; Male reproductive system', 'Cytogenetics', 'Histochemistry, Cytochemistry & Recombinant DNA Techniques', 'Cell Dynamics and Cell Cycle', 'Method of study in histology', 'Bone, Bone Formation and Joints; Blood; Muscle', 'Basic tissues of the body: epithelial, connective, muscle, and nervous tissues', 'Lymphatic tissue and the Immune system; Endocrine system; Urinary system', 'Liver, Gallbladder and Pancreas, Gastro-intestinal system', 'Covering and Lining Epithelia, Glandular Epithelia, and Connective Tissue'],
    'MBC 211': ['The cell theory', 'Water, total body water and its distribution; regulation of water and electrolyte balance; disorders of water and electrolyte balance', 'The Cell Theory', 'Structures and Functions of Major Cell Components', 'Structures and functions of major cell components', 'Cell Organelles of Prokaryotes and Eukaryotes', 'Structure, function and fractionation of extra-cellular organelles', 'Chemical composition of cells, centrifugation and methods of cell fractionation', 'Cell Types, Constancy and Diversity'],
    'ENG111': ['What is Semantics', 'Meaning/Sense Relations – Sentence Level', 'The Nature of Meaning', 'Meaning/Sense Relations (Word Level)', 'Shades of Meaning'],
    'REL111': ['Vowels', 'Syllabification', 'Alphabets/Consonants', 'Introduction', 'Direct Article / Vocabulary Building'],
    'CHE 111': ['Material balances in single units', 'Recycle, bypass, purge', 'Conventions in the method of analysis and measurement', 'Physical and chemical properties and measurement', 'Chemical Equation, Stoichiometry and Material Balances (Single Units, Recycle, Bypass, Purge)', 'The role of the chemical engineer', 'The mole unit', 'Physical and Chemical Properties and Measurement', 'Pressure', 'Temperature', 'Units and dimensions', 'Temperature and Pressure'],
    'COS111': ['Computer concepts', 'Computer history', 'Computer Networks', 'Application of computer', 'Information Representation and Number System', 'Programming languages and programming process', 'Components of computer', 'Programming Languages and Programming Process'],
    'ENG119': ['Application of Theories/Approaches to Communication in an Organization', 'The Meaning of Communication', 'The Meaning and Definition of Organizational Communication', 'Theories and Approaches to Communication', 'Elements and Qualities of Effective Communication', 'Formal Letter and Report Writing in an Organization', 'Key Problems of Communication in an Organization'],
    'RCS111': ['The Theology of the Old Testament', 'The Relationship of the Old Testament to the New Testament', 'Stages in the Formation of the Old Testament', 'The Nature and Message of the Old Testament', 'The Divisions of the Old Testament', 'The Relevance of the Old Testament Today', 'The Place of the Old Testament', 'Meaning of Old Testament'],
    'MTH111': ['Real numbers, integers, rational and irrational numbers', 'Sequences and series', "De-Moivre's theorem", 'Addition and factor formulae', 'Sets', 'Quadratic equations', 'Complex numbers', 'Binomial theorem', 'Trigonometry'],
    'PHY111': ['Physical Quantities', 'Elementary Mechanics', 'Scalars and Vector Quantities', 'Thermal Physics', 'Gravitation Law', 'Scalars and Vector Quantities', 'Simple Harmonic Motion', 'Elasticity, Viscosity and Surface Tension', 'Heat, Temperature and Work', 'Properties of Matter', 'Heat Capacity', 'Dynamics and Equilibrium', 'Molecular Theory of Matter', 'Mechanical Properties of Matter', 'Types of Motions', 'Thermal Expansion of Liquids and Gases', 'Kinematics'],
    'GET214': ['Python Syntax, Input, Output, Variables, Operators, Errors, and Comments', 'Object Oriented Programming (OOP)', 'User Defined Functions', 'Python Expressions', 'Decisions', 'Introduction to Data Science', 'Loops', 'Python Data Structures', 'Introduction to Computing', 'Python Syntax, Input, Output, Variables, Operators, Errors and Comments'],
    'AEB211': ['Protozoa', 'Metazoans', 'Eumetazoa', 'Acoelomata', 'Pseudocoelomates'],
}"""

@login_required(login_url='login')
def cbt(request):
    for ad in Advertise.objects.all():
        ad.deactivate_if_expired()
    reset = User.objects.get(id = request.user.id)
    reset.cbt_details = []
    reset.cbt_quests = []
    reset.save()
    advertisers = Advertise.objects.filter(active=True)
    rooms = Cbtroom.objects.all()
    pins = []
    for i in Pins.objects.filter(duration='monthly'):
        pins.append(i.pin)
    if request.method == 'POST':
        q = request.POST.get('q')
        search1 = Cbtroom.objects.filter(name__icontains=q)
        search2 = Cbtroom.objects.filter(host__firstname__icontains=q)
        rooms = search1|search2
        context = {'rooms': rooms, 'pins': pins}
        return render(request, 'cbt/cbt_search.html', context)
    cutoff_date = timezone.now() - timedelta(days=30)
    idle_rooms = Cbtroom.objects.filter(updated__lt=cutoff_date)
    # count = idle_rooms.count()
    # idle_rooms.delete()
    context = {'rooms': rooms, 'pins': pins, 'advertisers': advertisers}
    return render(request, 'cbt/cbt.html', context)


@login_required(login_url='login')
def createcbt(request):
    def generate_unique_pins(num_pins=100):
        pins = set()  # Use a set to ensure uniqueness
        while len(pins) < num_pins:
            pin = random.randint(10000, 99999)  # Generate a random 5-digit number
            pins.add(pin)  # Add to the set (duplicates are automatically handled)
        return list(pins)

    ids = ['calixotu@gmail.com', 'calixguru@gmail.com', 'timothyuwemedimo69@gmail.com']
    if request.user.id != 'calixotu@gmail.com':
        if request.method == 'POST' and request.user.email in ids:
            name = request.POST.get('name')
            host = request.user
            Cbtroom.objects.create(
                name=name,
                host=host,
                notification=f'This room was created by {host.firstname} {host.lastname}',
                quiz=[],
                allowed = [],
                used_pins=[],
                performers=[],
                total = [],
                admins = [],
                all_time = [],
            )
            messages.success(request, "CBT room created successfully")
            return redirect('cbt')
        else:
            messages.error(request, "You can't create a room")
        return render(request, 'cbt/cbtform.html')
    else:
        messages.error(request, "You are not authorized to create a CBT room")
        return redirect(request.META.get('HTTP_REFERER', '/'))

@login_required(login_url='login')
def cbtroom(request, pk):
    # for i in User.objects.all():
    #     try:
    #         i.cbt_quests = []
    #         i.cbt_details = []
    #         i.save()
    #     except:
    #         i.cbt_quests = ''
    #         i.cbt_details = ''
    #         i.save()
    for ad in Advertise.objects.all():
        ad.deactivate_if_expired()
    advertisers = Advertise.objects.filter(active=True)
    room = Cbtroom.objects.get(id=pk)
    room_messages = room.message_set.all()
    ids = []
    members = room.chats.all()
    users= []
    for i in room.used_pins:
        users.append(i['id'])
    if request.method == 'POST':
        comment = request.POST.get('message')
        host = request.user
        message = Message.objects.create(
            user=request.user,
            room=room,
            chats = comment
        )
        room.chats.add(request.user)
        room.save()
        return redirect('cbtroom', pk=room.id)
    p = sorted(room.performers, key=lambda x: x['score'], reverse=True)
    unique_performers = {}
    unique_performers2 = {}
    for performer in p:
        if performer['id'] not in unique_performers:
            unique_performers[performer['id']] = performer

    # Convert dictionary back to list
    performers = list(unique_performers.values())
    performers2 = list(unique_performers.values())
    
    user_score = ['']
    for i in room.performers:
        ids.append(int(i['id']))
        if int(i['id']) == request.user.id:
            user_score.append(f"- You scored {i['score']}% in the last quiz")
        else:
            user_score.append('')
    if request.user.id not in ids:
        val = 'yes'
    else:
        val = 'no'
    # mail = request.user.email
    # if mail in room.allowed:
    #     user_index = room.pins[room.allowed.index(mail)+1]
    # else:
    #     user_index = ''
    user_index = code

    one = room.downloads

    data = room.all_time

    # Step 1: Flatten all sub-lists into one
    flat_list = [item for sublist in data for item in sublist]

    # Step 2: Aggregate scores by id
    scores = {}
    for item in flat_list:
        user_id = item['id']
        idy = int(item['id'])
        name = User.objects.get(id=idy)
        score = float(item['score'])
        if user_id not in scores:
            scores[user_id] = {
                "id": user_id,
                "name": f"{name.firstname} {name.lastname}",
                "avatar": item['avatar'],
                "total_score": 0.0
            }
        scores[user_id]["total_score"] += score

    # Step 3: Rank participants by score
    ranked = sorted(scores.values(), key=lambda x: x["total_score"], reverse=True)

    # Output
    # print("🏆 Ranking Results:")
    # for rank, participant in enumerate(ranked, 1):
    #     print(f"{rank}. {participant['name']} (ID: {participant['id']}) → {participant['total_score']} points")

    # If you want JSON for frontend
    ranked_json = ranked

    plan = {"label": f"₦{one} for 1 download", "amount": one, "name": "1 Download", "color": "#f97316"}
    context = {'room': room, 'room_messages': room_messages, 'users': users,
               'performers': performers, 'performers2': performers2, 'ids': ids, 'val': val,
               'user_score': user_score[-1], 'members': members, 'user_index': user_index,
               'categories': categories,'courses':courses, 'plan': plan, 'advertisers': advertisers,
               'uniuyo': uniuyo, 'aksu': aksu, 'akscoe': akscoe, 'ranked_json': ranked_json, 'COURSES': COURSES, 'TOPICS': TOPICS}
    return render(request, 'cbt/cbtroom.html', context)


# Track user IP
def get_client_ip(request):
    x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded_for:
        ip = x_forwarded_for.split(",")[0]
    else:
        ip = request.META.get("REMOTE_ADDR")
    return ip

# Track login history
@receiver(user_logged_in)
def track_ip(sender, request, user, **kwargs):
    ip = get_client_ip(request)
    user.last_login_ip = ip
    user.last_login_time = now()
    user.save()
    
# @login_required(login_url='login')
# def check_pin(request):
#     if request.method == "POST":
#         entered_pin = int(request.POST.get('pin'))
#         room_id = request.POST.get('id')
#         room = Cbtroom.objects.get(id=room_id)
#         used = next((item['id'] for item in room.used_pins if item['pin'] == entered_pin), None)
#         users= []
#         for i in room.used_pins:
#             users.append(i['id'])
#         if request.user.id in users:
#             return JsonResponse({"success": True})
#         elif used == None and entered_pin in room.pins:
#             room.used_pins.append({'id':request.user.id, 'pin':entered_pin})
#             room.save()
#             messages.success(request, 'Quiz time')
#             return JsonResponse({"success": True})
#         else:
#             return JsonResponse({"success": False, "message": "Invalid PIN"})

@login_required(login_url='login')
def check_pin(request):
    if request.method == "POST":
        entered_pin = int(request.POST.get('pin'))
        room_id = request.POST.get('id')
        room = Cbtroom.objects.get(id=room_id)
        if room.is_correct_active == False:
            if request.user.email in room.allowed or request.user == room.host:
                used = next((item['id'] for item in room.used_pins if item['pin'] == entered_pin), None)
                users= []
                for i in room.used_pins:
                    users.append(i['id'])
                if request.user.id in users:
                    return JsonResponse({"success": True})
                elif entered_pin == room.code:
                    room.used_pins.append({'id':request.user.id, 'pin':entered_pin})
                    room.save()
                    messages.success(request, 'Quiz time')
                    return JsonResponse({"success": True})
                else:
                    return JsonResponse({"success": False, "message": "Invalid PIN"})
            else:
                return JsonResponse({"success": False, "message": "You are not subscribed to this CBT room"})
        else:
            used = next((item['id'] for item in room.used_pins if item['pin'] == entered_pin), None)
            users= []
            for i in room.used_pins:
                users.append(i['id'])
            if request.user.id in users:
                return JsonResponse({"success": True})
            elif entered_pin == room.code:
                room.used_pins.append({'id':request.user.id, 'pin':entered_pin})
                room.save()
                messages.success(request, 'Quiz time')
                return JsonResponse({"success": True})
            else:
                return JsonResponse({"success": False, "message": "Invalid PIN"})

def cbtroom_score(request, pk):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        id = request.POST.get('room')
        user = request.POST.get('user')
        score = request.POST.get('score')
        response = request.POST.get('response')
        room = Cbtroom.objects.get(id=id)
        if score != '0.00':
            room.performers.append({'id': user_id, 'avatar':User.objects.get(id=int(user_id)).avatar.url,
                                    'name': user, 'score': score, 'response': response})
            room.save()
        else:
            return redirect('cbtroom', id)
        return redirect(request.META.get('HTTP_REFERER', '/'))

def del_cbtroom(request):
    idy = int(request.GET.get('id'))
    room = Cbtroom.objects.get(id=idy)
    if request.user.email != 'calixotu@gmail.com' and request.user != room.host:
        messages.error(request, 'You are not allowed here')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    if request.method == 'POST':
        Cbtroom.objects.get(id=idy).delete()
        messages.success(request, 'Room Deleted')
        return redirect('cbt')
    context = {'room': room}
    return render(request, 'cbt/del_cbtroom.html', context)

def delete_message(request):
    ass = request.GET.get('id')
    msg = Message.objects.get(id=ass)
    msg.delete()
    messages.success(request, '👍')
    return redirect(request.META.get('HTTP_REFERER', '/'))

def del_question(request):
    idy = int(request.GET.get('id'))
    index = int(request.GET.get('index'))-1
    rooms = Cbtroom.objects.get(id=idy)
    if request.user != rooms.host and request.user.email != 'calixotu@gmail.com':
        messages.error(request, 'You are not allowed here')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    room = rooms.quiz[index]
    if request.method == 'POST':
        rooms.quiz.remove(rooms.quiz[index])
        rooms.save()
        Cbtroom.objects.get(id=idy).save()
        messages.success(request, 'Deleted')
        return redirect('cbtroom', idy)
    context = {'room': room}
    return render(request, 'cbt/del_question.html', context)

def add_question(request):
    idy = request.GET.get('id')
    room = Cbtroom.objects.get(id=idy)
    if request.user != room.host and request.user.email != 'calixotu@gmail.com':
        messages.error(request, 'You are not allowed here')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    # if request.method == 'POST':
    #     return redirect('cbtroom', idy)
    context = {'room': room}
    return render(request, 'cbt/add_question.html', context)

def edit_question(request):
    idy = int(request.GET.get('id'))
    index = int(request.GET.get('index'))-1
    rooms = Cbtroom.objects.get(id=idy)
    opts = {'A':1, 'B':2, 'C':3, 'D':4}
    if request.user != rooms.host and request.user.email != 'calixotu@gmail.com':
        messages.error(request, 'You are not allowed here')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    room = rooms.quiz[index]
    if request.method == 'POST':
        question = request.POST.get('question')
        opt1 = request.POST.get('opt1')
        opt2 = request.POST.get('opt2')
        opt3 = request.POST.get('opt3')
        opt4 = request.POST.get('opt4')
        status = request.POST.get('status')
        correct = int(request.POST.get('correct'))-1
        options = [opt1, opt2, opt3, opt4]
        data = {'question': question, 'options': options, 'correct': options[correct], 'status': status}
        rooms.quiz[index] = data
        rooms.save()
        Cbtroom.objects.get(id=idy).save()
        messages.success(request, 'Question edited successfully')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    context = {'room': room, 'idy': idy}
    return render(request, 'cbt/edit_question.html', context)


def cbtinfo(request):
    idy = request.GET.get('id')
    room = Cbtroom.objects.get(id=idy)
    context = {'room': room, 'idy': idy}
    return render(request, 'cbt/cbtinfo.html', context)

def cbtallowed(request):
    idys = request.GET.get('id')
    reason = request.GET.get('reason')
    room = Cbtroom.objects.get(id=idys)
    if reason == 'sub':
        allowed = []
        allowed2 = room.allowed
        for i in allowed2:
            idy = User.objects.get(email=i)
            allowed.append({'id': idy.id, 'mail': idy.email, 
                            'fn': idy.firstname, 'ln': idy.lastname})
        if request.method == 'POST':
            mail = request.POST.get('mail')
            if mail not in allowed2 and room.additions > 0:
                try:
                    idy = User.objects.get(email=mail)
                    room.allowed.append(mail)
                    room.additions = room.additions - 1
                    room.total.append({'user': idy.id, 'amount': room.subscription-500, 'reason': 'subscription'})
                    room.save()
                    messages.success(request, 'Subscriber added successfully')
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                except:
                    messages.error(request, 'Such a user does not exist')
                    return redirect(request.META.get('HTTP_REFERER', '/'))
            else:
                messages.error(request, "Subscriber already exists or you can't add anymore persons")
                return redirect(request.META.get('HTTP_REFERER', '/'))
        
        context = {'allowed': allowed, 'room': room}
        return render(request, 'cbt/cbtallowed.html', context)
    elif reason == 'admin':
        additions = 5 - len(room.admins)
        admins = []
        allowed2 = admins
        for i in room.admins:
            idy = User.objects.get(email=i)
            admins.append({'id': idy.id, 'mail': idy.email, 
                            'fn': idy.firstname, 'ln': idy.lastname})
        if request.method == 'POST':
            mail = request.POST.get('mail')
            if mail not in room.admins and len(room.admins) < 5:
                try:
                    idy = User.objects.get(email=mail)
                    room.admins.append(mail)
                    room.save()
                    messages.success(request, f'{idy.firstname} is now an Admin')
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                except:
                    messages.error(request, 'Such a user does not exist')
                    return redirect(request.META.get('HTTP_REFERER', '/'))
            else:
                messages.error(request, "Admin already exists or you can't add anymore admin")
                return redirect(request.META.get('HTTP_REFERER', '/'))
        
        context = {'allowed': admins, 'room': room, 'additions': additions}
        return render(request, 'cbt/cbtadmins.html', context)
    else:
        messages.error(request, 'Invalid call')
        return redirect(request.META.get('HTTP_REFERER', '/'))


def remove_allowed(request):
    room_id = request.GET.get('id1')
    owner_id = request.GET.get('id2')
    user = User.objects.get(id=owner_id)
    room = Cbtroom.objects.get(id=room_id)
    room.allowed.remove(user.email)
    room.save()
    messages.success(request, 'Subscriber removed successfully')
    return redirect(request.META.get('HTTP_REFERER', '/'))

def remove_admin(request):
    room_id = request.GET.get('id1')
    owner_id = request.GET.get('id2')
    user = User.objects.get(id=owner_id)
    room = Cbtroom.objects.get(id=room_id)
    room.admins.remove(user.email)
    room.save()
    messages.success(request, 'Admin removed successfully')
    return redirect(request.META.get('HTTP_REFERER', '/'))


def questions(request):
    idy = request.POST.get('id')
    room = Cbtroom.objects.get(id=idy)
    question = request.POST.get('question')
    opt1 = request.POST.get('opt1')
    opt2 = request.POST.get('opt2')
    opt3 = request.POST.get('opt3')
    opt4 = request.POST.get('opt4')
    correct = int(request.POST.get('correct'))-1
    options = [opt1, opt2, opt3, opt4]
    data = {'question': question, 'options': options, 'correct': options[correct], 'status': 'Active'}
    room.quiz.append(data)
    room.save()
    messages.success(request, 'Question added')
    return redirect(request.META.get('HTTP_REFERER', '/'))

def notification(request):
    # for i in Cbtroom.objects.all():
    #     i.all_time = []
    #     i.save()
    # def generate_unique_pins(num_pins=100):
    #     pins = set()  # Use a set to ensure uniqueness
    #     while len(pins) < num_pins:
    #         pin = random.randint(10000, 99999)
    #         pins.add(pin)
    #     return list(pins)
    idy = request.GET.get('id')
    room = Cbtroom.objects.get(id=idy)
    # Get today's day name (e.g., "Monday")
    today = datetime.datetime.today().strftime('%A')

    # Define allowed days
    allowed_days = ["Monday", "Wednesday", "Friday", "Sunday"]
    
    status = room.is_active
    permit = room.admins+['calixotu@gmail.com']
    if request.user != room.host and request.user.email not in permit:
        messages.error(request, 'You are not allowed here')
    else:
        if request.method == 'POST':
            # room.notification = request.POST.get('notification')
            # room.name = request.POST.get('name')
            # room.duration = request.POST.get('duration')
            # is_active = request.POST.get('is_active') == 'on'
            # is_correct_active = request.POST.get('is_correct_active') == 'on'
            # room.is_active = is_active
            # room.is_correct_active = is_correct_active
            # if status == False and is_active == True:
            #     room.performers = []
            #     room.used_pins=[]
            #     room.pins = generate_unique_pins(100)
            #     to_email = room.host.email
            #     allowed = len(room.allowed)+2
            #     selected_pins = room.pins[allowed:]
            #     message = f'''These pins below will give your students access to join the quiz. 
            #     Your Pins for the next quiz session for your CBT room "{room.name}" are {selected_pins}'''
            #     email = EmailMessage('GENERATED PINS', f'Hello {room.host.firstname}, {message}', to=[to_email])
                
            #     email.send()
            #     messages.success(request, 'New set of pins for the next quiz have been sent to you')
            # room.save()
            # messages.success(request, 'Changes made')
            # return redirect(request.META.get('HTTP_REFERER', '/'))


            try:
                course = request.POST.get('course')
                topics = request.POST.get('topics').replace('[', '"').replace(']', '"')
                number = int(request.POST.get('number'))
                topic = topics
                formatted = "[" + topic + "]"
                result = ast.literal_eval(formatted)
                if result != []:
                    room.course = course
                    room.topics = result
                    room.number = number
                    room.quiz=[]
                    lowered_topics = [item.lower() for item in room.topics]
                    q = []
                    for members in qsss.quests:
                        for i in members:
                            if i['course'].lower() == room.course.lower() and i['topic'].lower() in lowered_topics:
                                q.append(i)
                    if len(q) < room.number:
                        rand = q
                        messages.error(request, f"We don't have that much questions for your topics, so we've set {len(q)} questions")
                    else:
                        rand = random.sample(q, room.number)
                    for i in rand:
                        options = [i['opt1'], i['opt2'], i['opt3'], i['opt4']]
                        data = {'question': i['question'], 'options': options, 'correct': options[i['correct']-1], 'status': 'Active'}
                        room.quiz.append(data)
                else:
                    # messages.error(request, f"toom's:{room.topics} and result: {result}")
                    pass
            except:
                pass

            if int(request.POST.get('additions')) > int(room.additions):
                Pays.objects.create(
                user=room.host,
                title = 'Offline subscription',
                trace = f"Offline subscription for {room.host.firstname}'s {room.name} - {room.id}",
                amount= 500*(int(request.POST.get('additions')) - room.additions),
                )
            room.notification = request.POST.get('notification')
            room.wagroup = request.POST.get('whatsapp_link')
            room.departments = request.POST.get('departments')
            room.name = request.POST.get('name')
            room.ac_name = request.POST.get('ac_name')
            room.ac_number = request.POST.get('ac_number')
            room.bank = request.POST.get('bank')
            room.additions = request.POST.get('additions')
            room.subscription = request.POST.get('subscription')
            room.downloads = request.POST.get('downloads')
            if int(room.subscription) < 500 or int(room.subscription) < 500:
                messages.error(request, f"Subscription or downloads fee can't be less than 500")
                return redirect(request.META.get('HTTP_REFERER', '/'))
            
            room.pending = request.POST.get('pending')
            room.duration = request.POST.get('duration')
            room.code = request.POST.get('code')
            is_active = request.POST.get('is_active') == 'on'
            is_correct_active = request.POST.get('is_correct_active') == 'on'
            save_score = request.POST.get('save_score') == 'on'
            cheated = request.POST.get('cheated') == 'on'
            room.is_active = is_active
            room.is_correct_active = is_correct_active
            room.cheated = cheated
            if status == False and is_active == True:
                if today in allowed_days:
                    room.performers = []
                    room.used_pins=[]
                
                    # room.pins = generate_unique_pins(100)
                    # to_email = room.host.email
                    # allowed = len(room.allowed)+2
                    # selected_pins = room.pins[allowed:]
                    # message = f'''These pins below will give your students access to join the quiz. 
                    # Your Pins for the next quiz session for your CBT room "{room.name}" are {selected_pins}'''
                    # email = EmailMessage('GENERATED PINS', f'Hello {room.host.firstname}, {message}', to=[to_email])
                    
                    # email.send()
                    # messages.success(request, 'New set of pins for the next quiz have been sent to you')
                else:
                    messages.error(request, f"You can't ON, today is not a CBT day")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
            
            
            if save_score == True:
                room.all_time.append(room.performers)
                room.save_score = False
                room.is_active = False
            allow = ['ENT121', 'GST121', 'GST211', 'GST111',]
            if room.course not in allow and room.is_correct_active != False:
                if room.free_slots < 1:
                    messages.error(request, f'Cannot be free')
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                else:
                    room.free_slots = room.free_slots - 1
                    # room.is_correct_active = False
                    room.save()
                    messages.success(request, f'Changes made')
            else:
                room.save()
                messages.success(request, f'Changes made')
                return redirect(request.META.get('HTTP_REFERER', '/'))
    courses = COURSES
    
    # c2 = ['BIO121', 'CHM121', 'ENT121', 'GST121', 'MBC221', 'MTH121', 'NSC124', 
    # 'PHS221', 'PHS222', 'PHY121', 'UYY-HMM 121', 'MTH122', 'PHY128', 'STA121', 'SOC 121', 
    # 'LAW123', 'PHY122', 'AMS102', 'ECO102', 'SED121', 'GST203(AKSU)', 
    # 'MEC232(AKSU)', 'POL125', 'POL121','ANA221']

    try:
        total = 0
        for i in room.total:
            total = total + i['amount']
    except:
        total = 0

    context = {'room': room, 'courses': courses, 'total': total, 'allowed_days': allowed_days, 'today': today}
    return render(request, 'cbt/cbtset.html', context)


@cbt_room
@login_required(login_url='login')
def cbt_personal(request, pk):
    if request.user.id != int(pk):
        messages.error(request, 'Please restart the process')
        return redirect('cbt')
    user = User.objects.get(id = int(pk))

    course = request.GET.get('course')
    topics_raw = request.GET.get('topics')
    number = request.GET.get('number')
    duration = request.GET.get('duration')

    if not (course and topics_raw and number and duration):
        messages.error(request, "Invalid CBT configuration")
        return redirect(request.META.get('HTTP_REFERER', '/'))

    try:
        topics = ast.literal_eval(topics_raw)
        number = int(number)
        duration = int(duration)
    except Exception:
        messages.error(request, "Invalid data format")
        return redirect(request.META.get('HTTP_REFERER', '/'))

    user.cbt_details = {
        "course": course,
        "topics": topics,
        "duration": duration,
        "number": number
    }
    user.save()
    cbt_quests = []
    lowered_topics = [t.lower() for t in topics]
    q = []
    for members in qsss.quests:
        for i in members:
            if (
                i['course'].lower() == course.lower()
                and i['topic'].lower() in lowered_topics
            ):
                q.append(i)
    if len(q) < number:
        rand = q
        messages.error(
            request,
            f"We don't have enough questions for these topics. Using {len(q)} instead."
        )
    else:
        rand = random.sample(q, number)
    for i in rand:
        options = [i['opt1'], i['opt2'], i['opt3'], i['opt4']]
        data = {
            "question": i['question'],
            "options": options,
            "correct": i['correct'],  # keep index (1–4)
            "status": "Active"
        }
        cbt_quests.append(data)
    user.cbt_quests = cbt_quests
    user.save()
    return render(request, 'cbt/personal.html', {'room': user})

@cbt_room
@login_required(login_url='login')
def personal_test(request, pk):
    user = User.objects.get(id=pk)
    return render(request, 'cbt/personal_test.html', {'user': user})


@login_required(login_url='login')
def cbtans(request):
    for ad in Advertise.objects.all():
        ad.deactivate_if_expired()
    advertisers = Advertise.objects.filter(active=True)
    idy = int(request.GET.get('room'))
    room = Cbtroom.objects.get(id=idy)
    search_id = int(request.GET.get('scorer'))
    owner = User.objects.get(id=search_id)
    # if request.user.email == 'calixotu@gmail.com' or request.user.id == int(search_id) or request.user == room.host:
        # try:
        # Pins.objects.get(pin=int(search_id))
    data = []
    search_result = []
    must = [0,1,2,3]
    score = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 5: f'{owner.firstname} did not answer this question'}
    null = 5
    for i in room.performers:
        if i['id'] == str(search_id):
            search_result.append(i)
    for i in eval(search_result[0]['response']):
        data.append(i['selected_option'])
    context = {'room': room, 'searchs': data, 'owner': owner, 'must': must, 'advertisers': advertisers,
                'sc':search_result[0]['score'], 'url': request.build_absolute_uri(),
                "title": f"{owner.firstname} scored {search_result[0]['score']}% in {room.course} test in {room.name} on Calixguru",
                "description": f"{owner.firstname} just took the {room.course} CBT on CalixGuru. Can you beat {owner.firstname} {owner.lastname}'s score!",
                "image_url": request.build_absolute_uri("/static/img/logo2.png"),
                "link": request.build_absolute_uri(),
                }
    return render(request, 'cbt/cbtans.html', context)
        # except:
        #     messages.error(request, 'You must be subscribed to view your performance')
        #     return redirect(request.META.get('HTTP_REFERER', '/'))
    # else:
    #     messages.error(request, f"You can't view another person's performance")
    #     return redirect('cbtroom', room.id)

@login_required(login_url='login')
def custom_downloads(request):
    owners = owner
    if request.user.email in owners:
        unit = unit1
    else:
        unit = unit2
    context = {'unit': unit}
    return render(request, 'cbt/custom_downloads.html', context)

# Small helper Flowable that renders a colored "pill" for correct answer
class AnswerPill(Flowable):
    def __init__(self, text, width=120, height=20, bgcolor=colors.HexColor("#DFF6E9"), textcolor=colors.HexColor("#0B6A3D")):
        Flowable.__init__(self)
        self.text = text
        self.width = width
        self.height = height
        self.bgcolor = bgcolor
        self.textcolor = textcolor

    def wrap(self, availWidth, availHeight):
        return self.width, self.height

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(self.bgcolor)
        c.roundRect(0, 0, self.width, self.height, radius=6, fill=1, stroke=0)
        c.setFillColor(self.textcolor)
        c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(self.width / 2, self.height / 2 - 4, self.text)
        c.restoreState()


def _draw_header_footer(canvas, doc):
    """Draw header banner and watermark on each page"""
    canvas.saveState()
    width, height = A4

    # Top banner (soft gradient look approximated by two rectangles)
    banner_h = 55
    canvas.setFillColor(colors.HexColor("#223a5e"))  # deep indigo
    canvas.rect(0, height - banner_h, width, banner_h, stroke=0, fill=1)
    canvas.setFillColor(colors.HexColor("#3b7bbf"))  # lighter indigo
    canvas.rect(0, height - banner_h, width * 0.45, banner_h, stroke=0, fill=1)

    # Title on banner (left)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 14)
    canvas.drawString(36, height - 39, "CALIXGURU CBT SOLUTIONS")

    # Timestamp (right)
    canvas.setFont("Helvetica", 8)
    now = datetime.datetime.now().strftime("%b %d, %Y %I:%M %p")
    canvas.drawRightString(width - 36, height - 34, f"Generated {now}")

    # Subtle footer line
    # canvas.setStrokeColor(colors.HexColor("#E6EEF8"))
    # canvas.setLineWidth(0.5)
    # canvas.line(36, 60, width - 36, 60)

    # Footer text
    canvas.setFont("Helvetica", 10)
    canvas.setFillColor(colors.grey)
    canvas.drawCentredString(width / 2, 60, "CALIXGURU — https://calixguru.pythonanywhere.com".upper())

    # Watermark (light, diagonal)
    canvas.setFont("Helvetica-Bold", 60)
    canvas.setFillColor(colors.Color(0.9, 0.9, 0.9, alpha=0.15))
    canvas.translate(width / 2, height / 2)
    canvas.rotate(30)
    canvas.drawCentredString(0, 0, "CALIXGURU")
    canvas.restoreState()


def download_solutions_pdf(request, room_id):
    """
    Generate a beautifully styled PDF that combines CBT solutions (questions + answers)
    and a 'Featured Sponsors' section (two adverts per row with images and links).
    """
    room = get_object_or_404(Cbtroom, id=room_id)
    if request.user == room.host or request.user.email in room.allowed or request.user.email in room.admins:

        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=36,
            leftMargin=36,
            topMargin=90,   # leave space for header
            bottomMargin=72,  # leave space for footer
        )

        # Styles
        base = getSampleStyleSheet()
        styles = {
            "title": ParagraphStyle(
                "title", parent=base["Heading1"], fontName="Helvetica-Bold", fontSize=18, alignment=1, spaceAfter=6, textColor=colors.HexColor("#1F3A5F")
            ),
            "subtitle": ParagraphStyle(
                "subtitle", parent=base["Normal"], fontSize=10, alignment=1, textColor=colors.HexColor("#6B7280")
            ),
            "question": ParagraphStyle(
                "question", parent=base["Normal"], fontSize=11, leading=14, spaceAfter=6, leftIndent=0, textColor=colors.HexColor("#1F2937")
            ),
            "answer_label": ParagraphStyle(
                "answer_label", parent=base["Normal"], fontSize=10, leading=12, spaceAfter=8, leftIndent=6, textColor=colors.HexColor("#065F46")
            ),
            "section": ParagraphStyle(
                "section", parent=base["Heading2"], fontName="Helvetica-Bold", fontSize=13, textColor=colors.HexColor("#0F172A"), spaceBefore=12, spaceAfter=8
            ),
            "ad_title": ParagraphStyle(
                "ad_title", parent=base["Normal"], fontSize=12, leading=14, fontName="Helvetica-Bold", textColor=colors.HexColor("#111827")
            ),
            "ad_desc": ParagraphStyle(
                "ad_desc", parent=base["Normal"], fontSize=10, leading=13, textColor=colors.HexColor("#374151")
            ),
            "ad_link": ParagraphStyle(
                "ad_link", parent=base["Normal"], fontSize=9, textColor=colors.HexColor("#075985")
            ),
            "small_grey": ParagraphStyle(
                "small_grey", parent=base["Normal"], fontSize=8, textColor=colors.HexColor("#6B7280")
            ),
        }

        elements = []

        # Title block
        elements.append(Paragraph(f"{room.name} — {room.course}".upper(), styles["title"]))
        elements.append(Paragraph("CBT Solutions PDF", styles["subtitle"]))
        elements.append(Spacer(1, 12))

        elements.append(Paragraph("<b>PAID ADVERTS</b>", styles["question"]))
        elements.append(Spacer(1, 10))
        
        # Prepare adverts (two per row)
        active_ads = Advertise.objects.filter(active=True)

        if not active_ads.exists():
            elements.append(Paragraph("No active adverts at the moment.", styles["small_grey"]))
        else:
            row_cells = []
            col_width = (doc.width - 12) / 2  # small gap between two columns

            for i, ad in enumerate(active_ads):
                ad_box = []

                # image (prefer first image)
                image_obj = AdvertImage.objects.filter(advertiser=ad).first()
                if image_obj and os.path.exists(image_obj.image.path):
                    try:
                        # scale to fit nicely in card
                        max_w = col_width - 12
                        max_h = 1.7 * inch
                        img = Image(image_obj.image.path)
                        img.drawHeight = max_h
                        # preserve aspect ratio for width
                        ratio = img.imageWidth / img.imageHeight
                        img.drawWidth = min(max_w, max_h * ratio)
                        img.hAlign = "CENTER"
                        ad_box.append(img)
                        ad_box.append(Spacer(1, 6))
                    except Exception:
                        # skip image if any issue
                        pass

                # Business name & description
                ad_box.append(Paragraph(ad.business_name, styles["ad_title"]))
                ad_box.append(Spacer(1, 4))
                ad_box.append(Paragraph(ad.description or "No description provided.", styles["ad_desc"]))
                ad_box.append(Spacer(1, 6))

                # WhatsApp clickable link (ReportLab supports simple <a href='...'>text</a>)
                if ad.whatsapp_profile:
                    # normalize: ensure full URL (assume stored properly)
                    link = ad.whatsapp_profile
                    ad_box.append(Paragraph(f"<a href='{link}'>CLICK TO WHATSAPP {ad.business_name}</a>".upper(), styles["ad_link"]))

                # Small separator inside card
                ad_box.append(Spacer(1, 6))

                # Wrap ad_box into a single cell table to give padding and background
                inner_table = Table([[ad_box]], colWidths=[col_width - 6])
                inner_table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, -1), colors.whitesmoke),
                    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#E8EEF6")),
                    ("LEFTPADDING", (0, 0), (-1, -1), 10),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                    ("TOPPADDING", (0, 0), (-1, -1), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                ]))

                row_cells.append(inner_table)

                # When we have 2 cells or last ad, append row as a table
                if len(row_cells) == 2 or i == len(active_ads) - 1:
                    # If only one in this row, add empty cell for balance
                    if len(row_cells) == 1:
                        row_cells.append(Paragraph("", styles["ad_desc"]))

                    table = Table([row_cells], colWidths=[col_width, col_width], hAlign="CENTER")
                    table.setStyle(TableStyle([
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 6),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ]))
                    elements.append(table)
                    elements.append(Spacer(1, 12))
                    row_cells = []
        
        elements.append(Spacer(1, 10))
        # -------------- Separator ---------------
        elements.append(Paragraph(f"<a href='https://wa.me/2349071902185'>CLICK HERE TO PLACE AN ADVERT</a>".upper(), styles["title"]))
        accent_color = colors.HexColor("#2563EB")
        sep = Table([[""]], colWidths=[doc.width])
        sep.setStyle(TableStyle([
            ("LINEABOVE",(0,0),(-1,-1),2,accent_color),
            ("LINEBELOW",(0,0),(-1,-1),2,accent_color)
        ]))
        elements.append(Spacer(1,6))
        elements.append(sep)
        elements.append(Spacer(1,12))


        elements.append(PageBreak())
        elements.append(Paragraph("<b>SOLUTIONS</b>", styles["question"]))
        elements.append(Spacer(1, 10))
        # Solutions - presented as "cards" (question then a green pill)
        for idx, quiz in enumerate(room.quiz, start=1):
            # Question container table to give card-like look
            q_text = Paragraph(f"<b>Q{idx}.</b> {quiz.get('question', '')}", styles["question"])
            # Green pill with correct answer
            correct = (quiz.get("correct", ""))
            pill = Paragraph(f"Answer: {correct}")
            # Assemble small table: left question, right pill
            t = Table([[q_text, pill]], colWidths=[doc.width - 160, 140])
            t.setStyle(TableStyle([
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("BACKGROUND", (0, 0), (0, 0), colors.Color(0.98, 0.99, 1)),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#E6EEF8")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]))
            elements.append(t)
            elements.append(Spacer(1, 8))

            # Put a page break for readability every 18 questions
            if idx % 18 == 0:
                elements.append(PageBreak())




        # After solutions, create a clean divider and new section
        # elements.append(Spacer(1, 18))
        # elements.append(Paragraph("Our Featured businesses on CALIXGURU", styles["section"]))
        # elements.append(Paragraph("Adverts — tap a WhatsApp link to reach them.", styles["small_grey"]))
        

        # Final footer note
        elements.append(Spacer(1, 18))
        elements.append(Paragraph("<para align=center><font size=12 color='grey'>© CALIXGURU — DIGITAL LEARNING AT IT'S FINEST</font></para>", base["Normal"]))

        # Build PDF with custom header/footer on every page
        doc.build(elements, onFirstPage=_draw_header_footer, onLaterPages=_draw_header_footer)

        buffer.seek(0)
        filename = f"{room.name}_solutions on {room.course}.pdf"
        return FileResponse(buffer, as_attachment=True, filename=filename)
    else:
        messages.error(request, 'Subscribe to this room to download')
        return redirect(request.META.get('HTTP_REFERER', '/'))

ALLOWED_USERS = ['calixotu@gmail.com',]# 'opaltutorials@gmail.com']

# def compress_pdf(input_path, output_path):
#     """Compress a PDF before saving."""
#     pdf_reader = PdfReader(input_path)
#     pdf_writer = PdfWriter()

#     for page in pdf_reader.pages:
#         pdf_writer.add_page(page)

#     with open(output_path, "wb") as compressed_file:
#         pdf_writer.write(compressed_file)

@login_required(login_url='login')
def upload_file(request):
    if request.user.email not in ALLOWED_USERS:
        return JsonResponse({"error": "Unauthorized"}, status=403)
    
    files = links.links[request.user.email]

    if request.method == "POST":
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                uploaded_file = form.save(commit=False)
                uploaded_file.user = request.user
                uploaded_file.requests = []
                uploaded_file.allowed = []

                # Save the uploaded file first
                uploaded_file.save()

                # Now we can safely access the file path
                # original_path = uploaded_file.file.path
                # compressed_path = original_path.replace(".pdf", "_compressed.pdf")

                # Compress PDF
                # compress_pdf(original_path, compressed_path)

                

                # # Replace with compressed file
                # with open(original_path, "rb") as f:
                #     uploaded_file.file.save(os.path.basename(original_path), ContentFile(f.read()), save=False)
                messages.success(request, f'You have successfully uploaded {uploaded_file.name}')

                # Remove temporary compressed file
                # os.remove(original_path)
                # os.remove(compressed_path)

                return redirect("file_list")
            except:
                messages.error(request, f"That material's name or file may already exist")
                return redirect("file_list")
    else:
        form = FileUploadForm()

    return render(request, "cbt/uploads.html", {"form": form, "file": files})

@login_required(login_url='login')
def file_list(request):
    files = UploadedFile.objects.filter(user=request.user)
    return render(request, "cbt/file_list.html", {"files": files})

@login_required
def all_docs(request):
    files = UploadedFile.objects.order_by('name')
    if request.method == 'POST':
        q = request.POST.get('q')
        search1 = UploadedFile.objects.filter(name__icontains=q)
        search2 = UploadedFile.objects.filter(user__firstname__icontains=q)
        search3 = UploadedFile.objects.filter(description__icontains=q)
        files2 = search1|search2|search3
        context = {'files': files2}
        return render(request, 'cbt/all_docs_search.html', context)
    return render(request, "cbt/all_docs.html", {"files": files})


@login_required(login_url='login')
def view_pdf(request, file_id):
    file_obj = get_object_or_404(UploadedFile, id=file_id)
    try:
        Pins.objects.get(name=request.user)
        return render(request, "cbt/view_pdf.html", {"file": file_obj})
    except:
        messages.error(request, f'You have to be subcribed to view any documents')
        return redirect('buypin')

@login_required(login_url='login')
def request_pdf(request, file_id):
    file_obj = get_object_or_404(UploadedFile, id=file_id)
    idy = request.user.id
    if idy not in file_obj.requests and idy not in file_obj.allowed:
        file_obj.requests.append(idy)
        file_obj.save()
        messages.success(request, f'Request to view {file_obj.name} has been made')
    else:
        file_obj.requests.remove(idy)
        file_obj.save()
        messages.success(request, f'Request cancelled')
    return redirect('all_docs')

@login_required(login_url='login')
def view_request_pdf(request, file_id):
    file_obj = get_object_or_404(UploadedFile, id=file_id)
    reqs = []
    for i in file_obj.requests:
        reqs.append({'name':User.objects.get(id=i).firstname,
                    'id':User.objects.get(id=i).id})
    return render(request, "cbt/request_pdf.html", {"reqs": reqs, 'file_obj': file_obj})

@login_required(login_url='login')
def accept_req(request):
    idy = request.GET.get('user')
    room = request.GET.get('room')
    file_obj = UploadedFile.objects.get(id=room)
    user = User.objects.get(id=idy)
    if user.id in file_obj.requests:
        file_obj.requests.remove(user.id)
        file_obj.allowed.append(user.id)
        file_obj.save()
        subject = f'{file_obj.name} APPROVAL STATUS'.upper()
        body = f'we want to inform you that your request to view {file_obj.name} have been approved succesfully. Visit https://calixguru.pythonanywhere.com/ to explore more'
        to_email = user.email
        email = EmailMessage(subject, f'Hello {user.firstname}, {body}', to=[to_email])
        # email.content_subtype = 'html'
        email.send()
        messages.success(request, f'Successfully approved {user.firstname} to view your {file_obj.name} material')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, f'That user may already be approved or cancelled their request')
        return redirect(request.META.get('HTTP_REFERER', '/'))

@login_required(login_url='login')
def decline_req(request):
    idy = request.GET.get('user')
    room = request.GET.get('room')
    file_obj = UploadedFile.objects.get(id=room)
    user = User.objects.get(id=idy)
    if user.id in file_obj.requests:
        file_obj.requests.remove(user.id)
        # file_obj.allowed.append(user.id)
        file_obj.save()
        subject = f'{file_obj.name} APPROVAL STATUS'.upper()
        body = f'we want to inform you that your request to view {file_obj.name} have been declined. Please ensure you have made payment and notified {file_obj.user.firstname} '
        to_email = user.email
        email = EmailMessage(subject, f'Hello {user.firstname}, {body}', to=[to_email])
        # email.content_subtype = 'html'
        email.send()
        messages.success(request, f'Successfully declined {user.firstname} from viewing your {file_obj.name} material')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, f'That user may already be approved or cancelled their request')
        return redirect(request.META.get('HTTP_REFERER', '/'))

@login_required(login_url='login')
def edit_pdf(request, file_id):
    file_obj = get_object_or_404(UploadedFile, id=file_id)
    if request.method == 'POST':
        file_obj.name = request.POST.get('name')
        file_obj.description = request.POST.get('description')
        file_obj.amount = request.POST.get('amount')
        file_obj.save()
        messages.success(request, 'Document edited successfully')
        return redirect('file_list')
    return render(request, "cbt/uploads2.html", {"file": file_obj})

@login_required(login_url='login')
def delete_pdf(request, file_id):
    file_obj = get_object_or_404(UploadedFile, id=file_id)

    # Ensure only the owner or an admin can delete
    if request.user != file_obj.user and not request.user.is_superuser:
        messages.success(request, "Unauthorized")

    # file_path = file_obj.file.path  # Get full path

    # # Delete the file from storage if it exists
    # if os.path.exists(file_path):
    #     os.remove(file_path)

    # Delete from the database
    file_obj.delete()

    messages.success(request, f'Succesfully deleted')
    return redirect(request.META.get('HTTP_REFERER', '/'))

def download_solutions_pdf_custom(request, pk):
    """
    Generate a beautifully styled PDF that combines CBT solutions (questions + answers)
    and a 'Featured Sponsors' section (two adverts per row with images and links).
    """
    room = get_object_or_404(User, id=pk)
    if request.user.id == room.id:

        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=36,
            leftMargin=36,
            topMargin=90,   # leave space for header
            bottomMargin=72,  # leave space for footer
        )

        # Styles
        base = getSampleStyleSheet()
        styles = {
            "title": ParagraphStyle(
                "title", parent=base["Heading1"], fontName="Helvetica-Bold", fontSize=18, alignment=1, spaceAfter=6, textColor=colors.HexColor("#1F3A5F")
            ),
            "subtitle": ParagraphStyle(
                "subtitle", parent=base["Normal"], fontSize=10, alignment=1, textColor=colors.HexColor("#6B7280")
            ),
            "question": ParagraphStyle(
                "question", parent=base["Normal"], fontSize=11, leading=14, spaceAfter=6, leftIndent=0, textColor=colors.HexColor("#1F2937")
            ),
            "answer_label": ParagraphStyle(
                "answer_label", parent=base["Normal"], fontSize=10, leading=12, spaceAfter=8, leftIndent=6, textColor=colors.HexColor("#065F46")
            ),
            "section": ParagraphStyle(
                "section", parent=base["Heading2"], fontName="Helvetica-Bold", fontSize=13, textColor=colors.HexColor("#0F172A"), spaceBefore=12, spaceAfter=8
            ),
            "ad_title": ParagraphStyle(
                "ad_title", parent=base["Normal"], fontSize=12, leading=14, fontName="Helvetica-Bold", textColor=colors.HexColor("#111827")
            ),
            "ad_desc": ParagraphStyle(
                "ad_desc", parent=base["Normal"], fontSize=10, leading=13, textColor=colors.HexColor("#374151")
            ),
            "ad_link": ParagraphStyle(
                "ad_link", parent=base["Normal"], fontSize=9, textColor=colors.HexColor("#075985")
            ),
            "small_grey": ParagraphStyle(
                "small_grey", parent=base["Normal"], fontSize=8, textColor=colors.HexColor("#6B7280")
            ),
        }

        elements = []

        # Title block
        elements.append(Paragraph(f"{room.cbt_details['course']}({room.cbt_details['topics'][0]})".upper(), styles["title"]))
        elements.append(Paragraph("CBT Solutions PDF", styles["subtitle"]))
        elements.append(Spacer(1, 12))

        elements.append(Paragraph("<b>PAID ADVERTS</b>", styles["question"]))
        elements.append(Spacer(1, 10))
        
        # Prepare adverts (two per row)
        active_ads = Advertise.objects.filter(active=True)

        if not active_ads.exists():
            elements.append(Paragraph("No active adverts at the moment.", styles["small_grey"]))
        else:
            row_cells = []
            col_width = (doc.width - 12) / 2  # small gap between two columns

            for i, ad in enumerate(active_ads):
                ad_box = []

                # image (prefer first image)
                image_obj = AdvertImage.objects.filter(advertiser=ad).first()
                if image_obj and os.path.exists(image_obj.image.path):
                    try:
                        # scale to fit nicely in card
                        max_w = col_width - 12
                        max_h = 1.7 * inch
                        img = Image(image_obj.image.path)
                        img.drawHeight = max_h
                        # preserve aspect ratio for width
                        ratio = img.imageWidth / img.imageHeight
                        img.drawWidth = min(max_w, max_h * ratio)
                        img.hAlign = "CENTER"
                        ad_box.append(img)
                        ad_box.append(Spacer(1, 6))
                    except Exception:
                        # skip image if any issue
                        pass

                # Business name & description
                ad_box.append(Paragraph(ad.business_name, styles["ad_title"]))
                ad_box.append(Spacer(1, 4))
                ad_box.append(Paragraph(ad.description or "No description provided.", styles["ad_desc"]))
                ad_box.append(Spacer(1, 6))

                # WhatsApp clickable link (ReportLab supports simple <a href='...'>text</a>)
                if ad.whatsapp_profile:
                    # normalize: ensure full URL (assume stored properly)
                    link = ad.whatsapp_profile
                    ad_box.append(Paragraph(f"<a href='{link}'>CLICK TO WHATSAPP {ad.business_name}</a>".upper(), styles["ad_link"]))

                # Small separator inside card
                ad_box.append(Spacer(1, 6))

                # Wrap ad_box into a single cell table to give padding and background
                inner_table = Table([[ad_box]], colWidths=[col_width - 6])
                inner_table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, -1), colors.whitesmoke),
                    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#E8EEF6")),
                    ("LEFTPADDING", (0, 0), (-1, -1), 10),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                    ("TOPPADDING", (0, 0), (-1, -1), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                ]))

                row_cells.append(inner_table)

                # When we have 2 cells or last ad, append row as a table
                if len(row_cells) == 2 or i == len(active_ads) - 1:
                    # If only one in this row, add empty cell for balance
                    if len(row_cells) == 1:
                        row_cells.append(Paragraph("", styles["ad_desc"]))

                    table = Table([row_cells], colWidths=[col_width, col_width], hAlign="CENTER")
                    table.setStyle(TableStyle([
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 6),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ]))
                    elements.append(table)
                    elements.append(Spacer(1, 12))
                    row_cells = []
        
        elements.append(Spacer(1, 10))
        # -------------- Separator ---------------
        elements.append(Paragraph(f"<a href='https://wa.me/2349071902185'>CLICK HERE TO PLACE AN ADVERT</a>".upper(), styles["title"]))
        accent_color = colors.HexColor("#2563EB")
        sep = Table([[""]], colWidths=[doc.width])
        sep.setStyle(TableStyle([
            ("LINEABOVE",(0,0),(-1,-1),2,accent_color),
            ("LINEBELOW",(0,0),(-1,-1),2,accent_color)
        ]))
        elements.append(Spacer(1,6))
        elements.append(sep)
        elements.append(Spacer(1,12))


        elements.append(PageBreak())
        elements.append(Paragraph("<b>SOLUTIONS</b>", styles["question"]))
        elements.append(Spacer(1, 10))
        # Solutions - presented as "cards" (question then a green pill)
        for idx, quiz in enumerate(room.cbt_quests, start=1):
            # Question container table to give card-like look
            q_text = Paragraph(f"<b>Q{idx}.</b> {quiz.get('question', '')}", styles["question"])
            # Green pill with correct answer
            correct = (quiz.get("correct", ""))
            pill = Paragraph(f"Answer: {correct}")
            # Assemble small table: left question, right pill
            t = Table([[q_text, pill]], colWidths=[doc.width - 160, 140])
            t.setStyle(TableStyle([
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("BACKGROUND", (0, 0), (0, 0), colors.Color(0.98, 0.99, 1)),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#E6EEF8")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]))
            elements.append(t)
            elements.append(Spacer(1, 8))

            # Put a page break for readability every 18 questions
            if idx % 18 == 0:
                elements.append(PageBreak())




        # After solutions, create a clean divider and new section
        # elements.append(Spacer(1, 18))
        # elements.append(Paragraph("Our Featured businesses on CALIXGURU", styles["section"]))
        # elements.append(Paragraph("Adverts — tap a WhatsApp link to reach them.", styles["small_grey"]))
        

        # Final footer note
        elements.append(Spacer(1, 18))
        elements.append(Paragraph("<para align=center><font size=12 color='grey'>© CALIXGURU — DIGITAL LEARNING AT IT'S FINEST</font></para>", base["Normal"]))

        # Build PDF with custom header/footer on every page
        doc.build(elements, onFirstPage=_draw_header_footer, onLaterPages=_draw_header_footer)

        buffer.seek(0)
        filename = f"{room.firstname} Personal CBT solutions on {room.cbt_details['course']}.pdf"
        return FileResponse(buffer, as_attachment=True, filename=filename)
    
