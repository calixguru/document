from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from .models import *
# import numpy as np
# import matplotlib.pyplot as plt
import math
from django.templatetags.static import static
from .decorators import cbt_room


# allowance = Room.objects.first().is_correct_active
# allowance = bool(allowance)
allowance = True

def p102(request):
    return render(request, 'practicals/b1con.html')
def p02(request):
    return render(request, 'practicals/b2con.html')
def p0(request):
    return render(request, 'practicals/p0con.html')
def p1(request):
    return render(request, 'practicals/p1con.html')
def p2(request):
    return render(request, 'practicals/p2con.html')
def p3(request):
    return render(request, 'practicals/p3con.html')
def p5(request):
    return render(request, 'practicals/p5con.html')
def p6(request):
    return render(request, 'practicals/p6con.html')
def p7(request):
    return render(request, 'practicals/p7con.html')
def p8(request):
    return render(request, 'practicals/p8con.html')
def p9(request):
    return render(request, 'practicals/p9con.html')
def p10(request):
    return render(request, 'practicals/p10con.html')
def p11(request):
    return render(request, 'practicals/p11con.html')
def p12(request):
    return render(request, 'practicals/p12con.html')
def c00(request):
    m = int(request.GET["u"])
    n = int(request.GET["v"])
    o = int(request.GET["x"])
    p = int(request.GET["y"])
    q = int(request.GET["z"])
    u = []
    v = []
    x = []
    y = []
    z = []
    w1, w2, w3, w4, w5 = 0, 0, 0, 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    while w2 < n:
        w2 = w2 + 1
        v.append(w2)
    while w3 < o:
        w3 = w3 + 1
        x.append(w3)
    while w4 < p:
        w4 = w4 + 1
        y.append(w4)
    while w5 < q:
        w5 = w5 + 1
        z.append(w5)

    return render(request, 'practicals/b1.html', {
        "u": u,
                                       "v": v,
                                       "x": x,
                                       "y": y,
                                       "z": z,
                                       "m": m,
                                       "n": n,
                                       "o": o,
                                       "p": p,
                                       "q": q,
                                       })

def c01(request):
    m = int(request.GET["x"])
    u = []
    w1 = 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/b2.html', {"u": u,
                                       "uu": uu,
                                       })



def c0(request):
    m = int(request.GET["u"])
    u = []
    w1 = 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p0.html', {"u": u,
                                       "uu": uu,
                                       })

def c1(request):
    m = int(request.GET["u"])
    u = []
    w1 = 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'p1.html', {"u": u,
                                       "uu": uu,
                                       })

def c2(request):
    m = int(request.GET["u"])
    u = []
    w1 = 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p2.html', {"u": u,
                                       "uu": uu,
                                       })

def c3(request):
    m = int(request.GET["u"])
    u = []
    w1 = 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p3.html', {"u": u,
                                       "uu": uu,
                                       })
def c4(request):
    m = int(request.GET["p"])
    v = []
    w = 0
    while w < m:
        w = w + 1
        v.append(w)
    return render(request, 'practicals/p4.html', {"v":v,})
def c5(request):
    m = int(request.GET["u"])
    u = []
    v = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    while w2 < m:
        w2 = w2 + 1
        v.append(w1)
    uu = max(u)
    vv = max(v)
    return render(request, 'practicals/p5.html', {"u": u,
                                       "uu": uu,
                                       "v": v,
                                       "vv": vv,
                                       })
def c6(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p6.html', {"u": u,
                                       "uu": uu,
                                       })
def c7(request):
    return render(request, 'practicals/p7.html')
def c8(request):
    return render(request, 'practicals/p8.html')
def c9(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p9.html', {"u": u,
                                       "uu": uu,
                                       })
def c10(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p10.html', {"u": u,
                                       "uu": uu,
                                       })

def c11(request):
    m = int(request.GET["u"])
    u = []
    w = 0
    while w < m:
        w = w + 1
        u.append(w)
    uu = max(u)
    return render(request, 'practicals/p11.html', {"u": u,
                                        "uu": uu,
                                        })
def c12(request):
    m = int(request.GET["u"])
    u = []
    v = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    while w2 < m:
        w2 = w2 + 1
        v.append(w1)
    uu = max(u)
    vv = max(v)
    return render(request, 'practicals/p12.html', {"u": u,
                                       "uu": uu,
                                       "v": v,
                                       "vv": vv,
                                       })

def c13(request):
    m = int(request.GET["u"])
    u = []
    v = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    while w2 < m:
        w2 = w2 + 1
        v.append(w1)
    uu = max(u)
    vv = max(v)
    return render(request, 'practicals/p13.html', {"u": u,
                                        "uu": uu,
                                        "v": v,
                                        "vv": vv,
                                        })
def c14(request):
    m = int(request.GET["u"])
    u = []
    w = 0
    while w < m:
        w = w + 1
        u.append(w)
    uu = max(u)
    return render(request, 'practicals/p14.html', {"u": u,
                                        "uu": uu,
                                        })
def c15(request):
    m = int(request.GET["u"])
    u = []
    w = 0
    while w < m:
        w = w + 1
        u.append(w)
    uu = max(u)
    return render(request, 'practicals/p15.html', {"u": u,
                                        "uu": uu,
                                        })
def c16(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p16.html', {"u": u,
                                        "uu": uu,
                                        })


def c17(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p17.html', {"u": u,
                                        "uu": uu,
                                        })


def c18(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p18.html', {"u": u,
                                        "uu": uu,
                                        })


def c19(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p19.html', {"u": u,
                                        "uu": uu,
                                        })


def c20(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p20.html', {"u": u,
                                        "uu": uu,
                                        })


def c21(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p21.html', {"u": u,
                                        "uu": uu,
                                        })


def c22(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p22.html', {"u": u,
                                        "uu": uu,
                                        })


def c23(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p23.html', {"u": u,
                                        "uu": uu,
                                        })

def c24(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p24.html', {"u": u,
                                        "uu": uu,
                                        })

def c25(request):
    return render(request, 'practicals/p25.html')

def c26(request):
    m = int(request.GET["u"])
    n = int(request.GET["v"])
    u, v = [], []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    while w2 < n:
        w2 = w2 + 1
        v.append(w2)
    vv = max(v)
    return render(request, 'practicals/p26.html', {"u": u,
                                        "uu": uu,
                                        "v": v,
                                        "vv": vv,
                                        })
def c27(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p27.html', {"u": u,
                                        "uu": uu,
                                        })

def c28(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p28.html', {"u": u,
                                        "uu": uu,
                                        })

def c29(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)

    return render(request, 'practicals/p29.html', {"u": u,
                                        "uu": uu,
                                        })

def c30(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p30.html', {"u": u,
                                        "uu": uu,
                                        })

def c31(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p31.html', {"u": u,
                                        "uu": uu,
                                        })

def c32(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p32.html', {"u": u,
                                        "uu": uu,
                                        })

def c33(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p33.html', {"u": u,
                                        "uu": uu,
                                        })

def c34(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p34.html', {"u": u,
                                        "uu": uu,
                                        })

def c35(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p35.html', {"u": u,
                                        "uu": uu,
                                        })

def c36(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p36.html', {"u": u,
                                        "uu": uu,
                                        })

def c37(request):
    return render(request, 'practicals/p37.html')

def c38(request):
    m = int(request.GET["u"])
    u = []
    w1, w2 = 0, 0
    while w1 < m:
        w1 = w1 + 1
        u.append(w1)
    uu = max(u)
    return render(request, 'practicals/p38.html', {"u": u,
                                        "uu": uu,
                                        })

@cbt_room
def L01(request):
    user = request.user
    l = (float(request.GET["l"]))
    a2 = (float(request.GET["m1"]))
    a3 = (float(request.GET["n1"]))
    a4 = (float(request.GET["o1"]))
    a5 = (float(request.GET["p0"]))
    n = (float(request.GET["n"]))
    a11, a12, a13, a14, a15 = [], [], [], [], []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1, w2, w3, w4, w5 = 0, 0, 0, 0, 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    while w2 < a3:
        w2 = w2 + 1
        a12.append(w2)
    while w3 < a4:
        w3 = w3 + 1
        a13.append(w3)
    while w4 < a5:
        w4 = w4 + 1
        a14.append(w4)
    for i in a11:
        b11.append(float(request.GET[f"t{i}"]))
    for i in a12:
        b12.append(float(request.GET[f"w{i}"]))
    for i in a13:
        b13.append(float(request.GET[f"d{i}"]))
    for i in a14:
        b14.append(float(request.GET[f"ti{i}"]))
    j = -1
    while j < (len(b14) - 1):
        j = j + 1
        b16.append(b14[j]/n)
    uav = round(np.average(b11),2)
    vav = round(np.average(b12),2)
    xav = round(np.average(b13),2)
    yav = round(np.average(b16),2)
    zav = round(np.average(b15),2)
    xmx, ymx = max(b13), max(b16)
    xmn, ymn = min(b13), min(b16)
    xstt, ystt = max(b13)-min(b13), round(max(b16)-min(b16), 3)
    xst, yst = round((xstt/a4), 3), round((ystt/a5), 3)
    vol = l * uav * vav
    pi = 3.142
    xav2 = round((xav**2),2)
    aup = round(xav2*pi,2)
    a = round(aup/4,2)
    gup = round((4*(pi**2)*l),2)
    gdown = round(yav**2,2)
    g = round(gup/gdown,2)
    gconv = g/100
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/bs1.html', {
                "vol": vol,
                "b13": b13,
                "b14": b14,
                "b16": b16,
                "a4": a4,
                "a5": a5,
                "uav": uav,
                "vav": vav,
                "xav": xav,
                "xav2": xav2,
                "yav": yav,
                "xmx": xmx,
                "ymx": ymx,
                "xmn": xmn,
                "ymn": ymn,
                "xst": xst,
                "yst": yst,
                "xstt": xstt,
                "ystt": ystt,
                "aup": aup,
                "a": a,
                "l": l,
                "pi": pi,
                "gup": gup,
                "gdown": gdown,
                "g": g,
                "gconv": gconv,
                                                       })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L02(request):
    user = request.user
    l = float(request.GET["l"])
    lc = l/100
    w = float(request.GET["w"])
    wc = w/100
    tt = float(request.GET["t"])
    ttc = tt/100
    m = float(request.GET["m"])
    h = float(request.GET["h"])
    hc = h/100
    d = float(request.GET["d"])
    dc = d/100
    a1 = (float(request.GET["a2"]))
    a11, b11 = [], []
    w1 = 0
    while w1 < a1:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"d{i}"]))
    v1 = round((lc * wc * ttc), 5)
    pi = 3.142
    v2 = round((pi * (dc ** 2) * hc), 5) / 4
    p = round((m / v1), 5)
    md = round(np.average(b11) ,2)
    mx, mn = max(b11), min(b11)
    mxn = mx-mn
    se = round(mxn/a1, 3)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/bs2.html', {
                "a1": a1,
                "mx": mx,
                "mn": mn,
                "mxn": mxn,
                "se": se,
                "b11": b11,
                "m": m,
                "l": l,
                "w": w,
                "h": h,
                "d": d,
                "tt": tt,
                "lc": lc,
                "wc": wc,
                "hc": hc,
                "dc": dc,
                "ttc": ttc,
                "v1": v1,
                "v2": v2,
                "p": p,
                "md": md,
            })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L0(request):
    user = request.user
    tm = (int(request.GET["n"]))
    dp = (float(request.GET["dp"]))
    a2 = (int(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"l{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round((b12[j] + b13[j]) / 2, dpp))
        b15.append(round(b14[j] / tm, dpp))
        b16.append(round(b15[j] ** 2, dpp))
        ch.append([b16[j], b11[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b16)
    yax = np.array(b11)
    #plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    pi = 3.142
    pi2 = pi ** 2
    g = round((4 * bc * pi2), dpp)
    p4 = round(g/100, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s0.html', {
                                               "bc": bc,
                                               "ac": ac,
                                                "pi": pi,
                                                "pi2": pi2,
                                                "p4": p4,
                                                "g": g,
                                               "chh": chh,
                                               "b11": b11,
                                               "b12": b12,
                                               "b13": b13,
                                               "b14": b14,
                                               "b15": b15,
                                               "b16": b16,
                                               })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, f'You must be activated to access this access- {allowance}')
        return redirect('buypin')

@cbt_room
def L1(request):
    user = request.user
    tm = (float(request.GET["n"]))
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    t1 = (float(request.GET["t1"]))
    t2 = (float(request.GET["t2"]))
    dpp = round(dp)
    a11 = []
    meant = round((t1 + t2) / 2, dpp)
    pt = meant/tm
    pt2 = round(pt**2, dpp)
    b11, b12, b13, b14, b15, b16, b17 = [], [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"y{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round((b12[j] + b13[j]) / 2, dpp))
        b15.append(round(b14[j] / tm, dpp))
        b16.append(round(b15[j] ** 2, dpp))
        b17.append(round(pt2-b16[j], dpp))
        ch.append([b11[j], b17[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b11)
    yax = np.array(b17)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    bcc = round((bc*100), dpp)
    pi = 3.142
    pi2 = round((pi ** 2), dpp)
    up = round((-4 * pi2), dpp)
    g = round(up/bcc, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 's1.html', {
                "bc": bc,
                "bcc": bcc,
                "ac": ac,
                "chh": chh,
                "pt": pt,
                "pt2": pt2,
                "t1": t1,
                "t2": t2,
                "meant": meant,
                'tm': tm,
                "b11": b11,
                "b12": b12,
                "b13": b13,
                "b14": b14,
                "b15": b15,
                "b16": b16,
                "b17": b17,
                "pi": pi,
                "pi2": pi2,
                "up": up,
                "g": g,
            })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L2(request):
    user = request.user
    tm = (float(request.GET["n"]))
    dp = (float(request.GET["dp"]))
    po = (float(request.GET["po"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16, b17, b18 = [], [], [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"m{i}"]))
        b12.append(float(request.GET[f"p{i}"]))
        b14.append(float(request.GET[f"t1{i}"]))
        b15.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    ch2 = []
    while j < (len(b11) - 1):
        j = j + 1
        b16.append(round((b14[j] + b15[j]) / 2, dpp))
        b17.append(round(b16[j] / tm, dpp))
        b13.append(round(b12[j] - po, dpp))
        b18.append(round(b17[j] ** 2, dpp))
        ch.append([b12[j], b11[j]])
        ch2.append([b18[j], b11[j]])
        chh = (','.join(map(str, ch)))
        chh2 = (','.join(map(str, ch2)))
    xax = np.array(b12)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    x2ax = np.array(b18)
    y2ax = np.array(b11)
    plt.plot(x2ax, y2ax, 'o')
    b2, a2 = np.polyfit(x2ax, y2ax, 1)
    plt.plot(x2ax, b2 * x2ax + a2, color="r", lw=2.5, label='Tsquare')
    bc2 = round(b2, dpp)
    ac2 = round(a2, 1)
    pi = 3.142
    pi2 = pi ** 2
    up = round((4 * pi2 * bc2), dpp)
    g = round(up / bc, dpp)
    gc = round(g/100, dpp)
    mo = -1*ac2
    er = round(abs(9.8-gc), dpp)
    error = round((er/9.8)*100, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s2.html', {
                "bc": bc,
                "ac": ac,
                "bc2": bc2,
                "ac2": ac2,
                "chh": chh,
                "chh2": chh2,
                "b11": b11,
                "b12": b12,
                "b13": b13,
                "b14": b14,
                "b15": b15,
                "b16": b16,
                "b17": b17,
                "b18": b18,
                "pi": pi,
                "pi2": pi2,
                "up": up,
                "g": g,
                "mo": mo,
                "gc": gc,
                "error": error,
                "er": er,
            })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L3(request):
    user = request.user
    tm = (float(request.GET["n"]))
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"h{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round((b12[j]+b13[j])/2, dpp))
        b15.append(round(b14[j]/tm, dpp))
        b16.append(round(b15[j]**2, dpp))
        ch.append([b16[j], b11[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b16)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    pi = 3.142
    pi2 = round(pi ** 2, dpp)
    g = -1 * round((4 * pi2 * bc), dpp)
    gc = round(g/100, dpp)
    er = round(abs(9.8 - gc), dpp)
    error = round((er / 9.8) * 100, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s3.html', {
                                               "bc": bc,
                                               "ac": ac,
                                               "chh": chh,
                                               "b11": b11,
                                               "b12": b12,
                                               "b13": b13,
                                               "b14": b14,
                                               "b15": b15,
                                               "b16": b16,
                "pi": pi,
                "pi2": pi2,
                "g": g,
                "gc": gc,
                "error": error,
                "er": er,
                                               })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L4(request):
    a = float(request.GET["a"])
    b = float(request.GET["b"])
    c = float(request.GET["c"])
    bs = -1*b
    b2 = b**2
    r2 = 4*a*c
    d = 2*a
    b3 = b2-r2
    b7 = b3/d
    b4 = round((b3**0.5), 1)
    b5 = (b + b4)
    b6 = (b - b4)
    ss1 = round(((-(b) + b4) / d), 1)
    ss2 = round(((-(b) - b4) / d), 1)
    s1 = round((-b + ((b ** 2) - (4 * a * c))**0.5) / (2 * a), 1)
    s2 = round((-b - ((b ** 2) - (4 * a * c))**0.5) / (2 * a), 1)

    return render(request, 'practicals/s4.html', {
        "a": a,
        "b": b,
        "c": c,
                                            "b2": b2,
                                            "r2": r2,
        "b7": b7,
        "bs": bs,
                                            "d": d,
        "b3": b3,
        "b4": b4,
        "b5": b5,
        "b6": b6,
        "ss1": ss1,
        "ss2": ss2,
        "s1": s1,
        "s2": s2,

                                        })

@cbt_room
def L5(request):
    user = request.user
    tm = float(request.GET["n"])
    dp = (float(request.GET["dp"]))
    sg = (float(request.GET["sg"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16, b17, b18 = [], [], [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"sp{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    ch2 = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round(((b12[j]+b13[j]) / 2), dpp))
        b15.append(round(b14[j] / tm, dpp))
        b16.append(round(sg-b11[j], dpp))
        b17.append(round(b16[j] ** 2, dpp))
        b18.append(round(b16[j]*(b15[j]**2), dpp))
        ch.append([b17[j], b18[j]])
        chh = (','.join(map(str, ch)))
        ch2.append([b16[j], b15[j]])
        chh2 = (','.join(map(str, ch2)))
    xax = np.array(b17)
    yax = np.array(b18)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    x2ax = np.array(b16)
    y2ax = np.array(b15)
    plt.plot(x2ax, y2ax, 'o')
    b2, a2 = np.polyfit(x2ax, y2ax, 1)
    plt.plot(x2ax, b2 * x2ax + a2, color="r", lw=2.5, label='Tsquare')
    bc2 = round(b2, dpp)
    ac2 = round(a2, 1)
    pi = 3.142
    pi2 = round(pi ** 2, dpp)
    g = round(((4 * pi2) / bc), dpp)
    gc = round(g / 100, dpp)
    er = round(abs(9.8 - gc), dpp)
    error = round((er / 9.8) * 100, dpp)
    ag = round(ac*g, dpp)
    kk = round(4 * pi2, dpp)
    k = round((ag/kk)**0.5, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s5.html', {"bc": bc,
                                               "ac": ac,
                                               "chh": chh,
                                               "bc2": bc2,
                                               "ac2": ac2,
                                               "chh2": chh2,
                                               "b11": b11,
                                               "b12": b12,
                                               "b13": b13,
                                               "b14": b14,
                                               "b15": b15,
                                               "b16": b16,
                                               "b17": b17,
                                               "b18": b18,
                                               "pi": pi,
                                               "pi2": pi2,
                                               "g": g,
                                               "gc": gc,
                                               "error": error,
                                               "er": er,
                                               "ag": ag,
                                               "kk": kk,
                                               "k": k,

                                    })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L6(request):
    user = request.user
    tm = float(request.GET["n"])
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    # tm = 20
    a11 = []
    b11, b12, b13, b14, b15, b16, b17 = [], [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"l{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round((b12[j] + b13[j]), dpp))
        b15.append(round(b14[j]/tm, dpp))
        b16.append(round(math.log(b11[j], 10), dpp))
        b17.append(round(math.log(b15[j], 10), dpp))
        ch.append([b16[j], b17[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b16)
    yax = np.array(b17)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    aq = round(10**ac, dpp)
    pi = 3.142
    pi2 = round(pi ** 2, dpp)
    g = round(((4 * pi2) * bc), dpp)
    gc = round(g / 100, dpp)
    er = round(abs(9.8 - gc), dpp)
    error = round((er / 9.8) * 100, dpp)
    ag = round(ac*g, dpp)
    kk = round(4 * pi2, dpp)
    k = round((ag/kk)**0.5, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s6.html', {
                "bc": bc,
                "ac": ac,
                "chh": chh,
                "b11": b11,
                "b12": b12,
                "b13": b13,
                "b14": b14,
                "b15": b15,
                "b16": b16,
                "b17": b17,
                "aq": aq,
                "pi": pi,
                "pi2": pi2,
                "g": g,
                "gc": gc,
                "error": error,
                "er": er,
                "ag": ag,
                "kk": kk,
                "k": k,
    })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L7(request):
    br = float(request.GET["b"])
    w = float(request.GET["w"])
    l1 = float(request.GET["l1"])
    l2 = float(request.GET["l2"])
    po1 = float(request.GET["po1"])
    po2 = float(request.GET["po2"])
    po3 = float(request.GET["po3"])
    po4 = float(request.GET["po4"])
    user = request.user
    u1 = float(request.GET["u1"])
    u2 = float(request.GET["u2"])
    u3 = float(request.GET["u3"])
    u4 = float(request.GET["u4"])
    u5 = float(request.GET["u5"])
    u6 = float(request.GET["u6"])
    v1 = float(request.GET["v1"])
    v2 = float(request.GET["v2"])
    v3 = float(request.GET["v3"])
    v4 = float(request.GET["v4"])
    v5 = float(request.GET["v5"])
    v6 = float(request.GET["v6"])
    w1 = float(request.GET["w1"])
    w2 = float(request.GET["w2"])
    w3 = float(request.GET["w3"])
    w4 = float(request.GET["w4"])
    w5 = float(request.GET["w5"])
    w6 = float(request.GET["w6"])
    x1 = float(request.GET["x1"])
    x2 = float(request.GET["x2"])
    x3 = float(request.GET["x3"])
    x4 = float(request.GET["x4"])
    x5 = float(request.GET["x5"])
    x6 = float(request.GET["x6"])
    y1 = float(request.GET["y1"])
    y2 = float(request.GET["y2"])
    y3 = float(request.GET["y3"])
    y4 = float(request.GET["y4"])
    y5 = float(request.GET["y5"])
    y6 = float(request.GET["y6"])
    ex1 = round((x1 - po1), 1)
    ex2 = round((x2 - po1), 1)
    ex3 = round((x3 - po1), 1)
    ex4 = round((x4 - po1), 1)
    ex5 = round((x5 - po1), 1)
    ex6 = round((x6 - po1), 1)
    ex11 = round((u1 - po2), 1)
    ex12 = round((u2 - po2), 1)
    ex13 = round((u3 - po2), 1)
    ex14 = round((u4 - po2), 1)
    ex15 = round((u5 - po2), 1)
    ex16 = round((u6 - po2), 1)
    ex21 = round((v1 - po3), 1)
    ex22 = round((v2 - po3), 1)
    ex23 = round((v3 - po3), 1)
    ex24 = round((v4 - po3), 1)
    ex25 = round((v5 - po3), 1)
    ex26 = round((v6 - po3), 1)
    ex31 = round((w1 - po4), 1)
    ex32 = round((w2 - po4), 1)
    ex33 = round((w3 - po4), 1)
    ex34 = round((w4 - po4), 1)
    ex35 = round((w5 - po4), 1)
    ex36 = round((w6 - po4), 1)
    exm1 = round(((ex1 + ex11) / 2), 1)
    exm2 = round(((ex2 + ex12) / 2), 1)
    exm3 = round(((ex3 + ex13) / 2), 1)
    exm4 = round(((ex4 + ex14) / 2), 1)
    exm5 = round(((ex5 + ex15) / 2), 1)
    exm6 = round(((ex6 + ex16) / 2), 1)
    exm11 = round(((ex21 + ex31) / 2), 1)
    exm12 = round(((ex22 + ex32) / 2), 1)
    exm13 = round(((ex23 + ex33) / 2), 1)
    exm14 = round(((ex24 + ex34) / 2), 1)
    exm15 = round(((ex25 + ex35) / 2), 1)
    exm16 = round(((ex26 + ex36) / 2), 1)

    y = [y1, y2, y3, y4, y5, y6]
    x = [exm1, exm2, exm3, exm4, exm5, exm6]
    ys = [y1, y2, y3, y4, y5, y6]
    xs = [exm11, exm12, exm13, exm14, exm15, exm16]
    xax = np.array(x)
    yax = np.array(y)
    xsax = np.array(xs)
    ysax = np.array(ys)
    # plt.plot(xax, yax, 'o')
    # plt.plot(xsax, ysax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5)
    d, c = np.polyfit(xsax, ysax, 1)
    plt.plot(xsax, d * xsax + c, color="r", lw=2.5)
    d = round((d), 3)
    b = round((b), 3)
    a = round((a))
    c = round((c))
    lis = [y5, y2]
    lis2 = [y5, y2]
    y22 = round((max(lis)), 2)
    y11 = round((min(lis)), 2)
    x22 = round(((y22 - a) / b), 2)
    x11 = round(((y11 - a) / b), 2)
    yans = round((y22 - y11), 4)
    xans = round((x22 - x11), 4)
    mslope = round((yans / xans), 3)
    mslopec = round((mslope / 10), 3)
    y222 = round((max(lis2)), 2)
    y111 = round((min(lis2)), 2)
    x222 = round(((y222 - c) / d), 2)
    x111 = round(((y111 - c) / d), 2)
    yans2 = round((y222 - y111), 4)
    xans2 = round((x222 - x111), 4)
    mslope2 = round((yans2 / xans2), 3)
    mslopec2 = round((mslope2 / 10), 3)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s7.html', {
                "mslope": mslope,
                "yans": yans,
                "xans": xans,
                "x11": x11,
                "x22": x22,
                "y11": y11,
                "y22": y22,
                "mslope2": mslope2,
                "yans2": yans,
                "xans2": xans2,
                "x111": x111,
                "x222": x222,
                "y111": y111,
                "y222": y222,
                "mslopec": mslopec,
                "mslopec2": mslopec2,
                "br": br,
                "a": a,
                "c": c,
                "d": d,
                "b": b,
                "w": w,
                "po1": po1,
                "po2": po2,
                "po3": po3,
                "po4": po4,
                "l1": l1,
                "l2": l2,
                "u1": u1,
                "u2": u2,
                "u3": u3,
                "u4": u4,
                "u5": u5,
                "u6": u6,
                "exm11": exm11,
                "exm12": exm12,
                "exm13": exm13,
                "exm14": exm14,
                "exm15": exm15,
                "exm16": exm16,
                "exm1": exm1,
                "exm2": exm2,
                "exm3": exm3,
                "exm4": exm4,
                "exm5": exm5,
                "exm6": exm6,
                "ex1": ex1,
                "ex2": ex2,
                "ex3": ex3,
                "ex4": ex4,
                "ex5": ex5,
                "ex6": ex6,
                "ex11": ex11,
                "ex12": ex12,
                "ex13": ex13,
                "ex14": ex14,
                "ex15": ex15,
                "ex16": ex16,
                "ex21": ex21,
                "ex22": ex22,
                "ex23": ex23,
                "ex24": ex24,
                "ex25": ex25,
                "ex26": ex26,
                "ex31": ex31,
                "ex32": ex32,
                "ex33": ex33,
                "ex34": ex34,
                "ex35": ex35,
                "ex36": ex36,
                "v1": v1,
                "v2": v2,
                "v3": v3,
                "v4": v4,
                "v5": v5,
                "v6": v6,
                "w1": w1,
                "w2": w2,
                "w3": w3,
                "w4": w4,
                "w5": w5,
                "w6": w6,
                "x1": x1,
                "x2": x2,
                "x3": x3,
                "x4": x4,
                "x5": x5,
                "x6": x6,
                "y1": y1,
                "y2": y2,
                "y3": y3,
                "y4": y4,
                "y5": y5,
                "y6": y6,
            })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L8(request):
    user = request.user
    x1 = float(request.GET["x1"])
    x2 = float(request.GET["x2"])
    x3 = float(request.GET["x3"])
    x4 = float(request.GET["x4"])
    x5 = float(request.GET["x5"])
    x6 = float(request.GET["x6"])
    x7 = float(request.GET["x7"])
    x8 = float(request.GET["x8"])
    x9 = float(request.GET["x9"])
    x10 = float(request.GET["x10"])
    x11 = float(request.GET["x11"])
    y1 = float(request.GET["y1"])
    y2 = float(request.GET["y2"])
    y3 = float(request.GET["y3"])
    y4 = float(request.GET["y4"])
    y5 = float(request.GET["y5"])
    y6 = float(request.GET["y6"])
    y7 = float(request.GET["y7"])
    y8 = float(request.GET["y8"])
    y9 = float(request.GET["y9"])
    y10 = float(request.GET["y10"])
    y11 = float(request.GET["y11"])
    z1 = float(request.GET["z1"])
    z2 = float(request.GET["z2"])
    z3 = float(request.GET["z3"])
    z4 = float(request.GET["z4"])
    z5 = float(request.GET["z5"])
    z6 = float(request.GET["z6"])
    z7 = float(request.GET["z7"])
    z8 = float(request.GET["z8"])
    z9 = float(request.GET["z9"])
    z10 = float(request.GET["z10"])
    z11 = float(request.GET["z11"])
    x1m = round(((x2 + x4 + x6 + x8 + x10) / 5), 2)
    h1m = round(((x3 + x5 + x7 + x9 + x11) / 5), 2)
    x2m = round(((y2 + y4 + y6 + y8 + y10) / 5), 2)
    h2m = round(((y3 + y5 + y7 + y9 + y11) / 5), 2)
    x3m = round(((z2 + z4 + z6 + z8 + z10) / 5), 2)
    h3m = round(((z3 + z5 + z7 + z9 + z11) / 5), 2)
    x1conv = x1 / 1000
    x1mconv = x1m / 100
    t1 = round((h1m / x1m), 2)
    t2 = round((h2m / x2m), 2)
    t3 = round((h3m / x3m), 2)
    t1sq = round((t1 ** 2), 3)
    x1mconvsq = round((x1mconv ** 2), 5)
    x1convsq = round((x1conv ** 2), 5)
    up = round((x1mconvsq * (t1sq + 1)), 5)
    down = round((x1conv ** 2), 5)
    g = round((up / down), 3)
    greal = round((g ** 0.5), 3)
    list = [t1, t2, t3]
    maxi = max(list)
    mini = min(list)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:


            return render(request, 'practicals/s8.html', {
                "x1": x1,
                "x2": x2,
                "x3": x3,
                "x4": x4,
                "x5": x5,
                "x1conv": x1conv,
                "x1convsq": x1convsq,
                "x1mconv": x1mconv,
                "t1sq": t1sq,
                "x1mconvsq": x1mconvsq,
                "up": up,
                "down": down,
                "greal": greal,
                "g": g,
                "x6": x6,
                "x7": x7,
                "x8": x8,
                "x9": x9,
                "x10": x10,
                "x11": x11,
                "y1": y1,
                "y2": y2,
                "y3": y3,
                "y4": y4,
                "y5": y5,
                "y6": y6,
                "y7": y7,
                "y8": y8,
                "y9": y9,
                "y10": y10,
                "y11": y11,
                "z1": z1,
                "z2": z2,
                "z3": z3,
                "z4": z4,
                "z5": z5,
                "z6": z6,
                "z7": z7,
                "z8": z8,
                "z9": z9,
                "z10": z10,
                "z11": z11,

                "x1m": x1m,
                "x2m": x2m,
                "x3m": x3m,
                "h1m": h1m,
                "h2m": h2m,
                "h3m": h3m,
                "t1": t1,
                "t2": t2,
                "t3": t3,
                "maxi": maxi,
                "mini": mini,
            })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L9(request):
    user = request.user
    tm = float(request.GET["n"])
    dp = (float(request.GET["dp"]))
    l1 = float(request.GET["l1"])
    l2 = (float(request.GET["l2"]))
    a2 = (int(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16, b17, b18 = [], [], [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"th{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round(b11[j] / 2, dpp))
        b15.append(round(math.cos(math.radians((b14[j]))), dpp))
        b16.append(round((b12[j] + b13[j])/2, dpp))
        b17.append(round(b16[j] / tm, dpp))
        b18.append(round(b17[j]**2, dpp))
        ch.append([b15[j], b18[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b15)
    yax = np.array(b18)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    pi = 3.142
    pi2 = round(pi ** 2, dpp)
    g1 = round(((4 * pi2 * l1) / (2*bc)), dpp)
    g2 = g1/100
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s9.html', {"bc": bc,
                                                "ac": ac,
                                                "chh": chh,
                                               "l1": l1,
                                               "l2": l2,
                                               "pi": pi,
                                               "pi2": pi2,
                                               "g1": g1,
                                               "g2": g2,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                               "b16": b16,
                                               "b17": b17,
                                               "b18": b18,
    })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L10(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    po = (float(request.GET["po"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"m{i}"]))
        b12.append(float(request.GET[f"p1{i}"]))
        b13.append(float(request.GET[f"p2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round(b12[j] - po, dpp))
        b15.append(round(b13[j] - po, dpp))
        b16.append(round((b14[j] + b15[j]) / 2, dpp))
        ch.append([b16[j], b11[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b16)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1) #this is slope and intercept. Remove matplotlib library
    #plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s10.html', {"bc": bc,
                                               "ac": ac,
                                                "po": po,
                                               "chh": chh,
                                               "b11": b11,
                                               "b12": b12,
                                               "b13": b13,
                                               "b14": b14,
                                               "b15": b15,
                                               "b16": b16,
                                               })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L11(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"D{i}"]))
        b12.append(float(request.GET[f"d1{i}"]))
        b13.append(float(request.GET[f"d2{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round((b12[j] - b13[j]), dpp))
        ch.append([b14[j], b12[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b12)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s11.html', {"bc": bc,
                                               "ac": ac,
                                               "chh": chh,
                                               "b11": b11,
                                               "b12": b12,
                                               "b13": b13,
                                               "b14": b14,
                                               })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


@cbt_room
def L12(request):
    user = request.user
    po = float(request.GET["po"])
    tt = float(request.GET["t"])
    ttc = tt/100
    w = float(request.GET["w"])
    wc = w/100
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"l{i}"]))
        b12.append(float(request.GET[f"p{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b13.append(round(b12[j] - po, dpp))
        b14.append(round(b11[j] ** 3, dpp))
        ch.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b13)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b*10000, dpp)
    ac = round(a, dpp)
    k = 39.3
    m = 0.2
    up = round(k*m, dpp)
    down = round(wc*(ttc**3)*bc, dpp)
    e = round(up/down, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s12.html', {"bc": bc,
                                                "b": b,
                                               "ac": ac,
                                                "tt": tt,
                                                "w": w,
                                                "ttc": ttc,
                                                "wc": wc,
                                                "po": po,
                                                "k": k,
                                                "m": m,
                                                "up": up,
                                                "down": down,
                                                "e": e,
                                               "chh": chh,
                                               "b11": b11,
                                               "b12": b12,
                                               "b13": b13,
                                               "b14": b14,
                                               })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


def p13(request):
    return render(request, 'practicals/p13con.html')

@cbt_room
def L13(request):
    user = request.user
    x = float(request.GET["x"])
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13 = [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"w{i}"]))
        b12.append(float(request.GET[f"l{i}"]))

    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b13.append(round(b12[j] - x, dpp))
        ch.append([b13[j], b11[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b13)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s13.html', {"bc": bc,
                                                "ac": ac,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


def p14(request):
    return render(request, 'practicals/p14con.html')

@cbt_room
def L14(request):
    user = request.user
    wa = float(request.GET["wa"])
    wl = float(request.GET["wl"])
    ww = float(request.GET["ww"])
    xa = float(request.GET["xa"])
    xl = float(request.GET["xl"])
    xw = float(request.GET["xw"])
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"wa{i}"]))
        b12.append(float(request.GET[f"ww{i}"]))
        b13.append(float(request.GET[f"xa{i}"]))
        b14.append(float(request.GET[f"xw{i}"]))
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s14.html', {
                                                "wa": wa,
                                                "wl": wl,
                                                "ww": ww,
                                                "xa": xa,
                                                "xl": xl,
                                                "xw": xw,
                                                "a11": a11,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p15(request):
    return render(request, 'practicals/p15con.html')

@cbt_room
def L15(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12 = [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"r{i}"]))
        b12.append(float(request.GET[f"f{i}"]))

    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        ch.append([b11[j], b12[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b11)
    yax = np.array(b12)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s15.html', {"bc": bc,
                                                "ac": ac,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p16(request):
    return render(request, 'practicals/p16con.html')

@cbt_room
def L16(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"f{i}"]))
        b12.append(float(request.GET[f"w{i}"]))
        b13.append(float(request.GET[f"h{i}"]))
        b14.append(float(request.GET[f"x{i}"]))
    j = -1
    ch = []
    ch2 = []
    while j < (len(b11) - 1):
        j = j + 1
        ch.append([b12[j], b11[j]])
        ch2.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
        chh2 = (','.join(map(str, ch2)))
    xax = np.array(b12)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    x2ax = np.array(b14)
    y2ax = np.array(b13)
    plt.plot(x2ax, y2ax, 'o')
    b2, a2 = np.polyfit(x2ax, y2ax, 1)
    plt.plot(x2ax, b2 * x2ax + a2, color="r", lw=2.5, label='Tsquare')
    bc2 = round(b2, dpp)
    ac2 = round(a2, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s16.html', {"ac": ac,
                                                "bc": bc,
                                                "bc2": bc2,
                                                "ac2": ac2,
                                                "chh": chh,
                                                "chh2": chh2,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p17(request):
    return render(request, 'practicals/p17con.html')

@cbt_room
def L17(request):
    m = float(request.GET["m"])
    return render(request, 'practicals/s17.html', {

                 })

def p18(request):
    return render(request, 'practicals/p18con.html')


def L18(request):

    return render(request, 'practicals/s18.html', {

                 })
def p19(request):
    return render(request, 'practicals/p19con.html')


@cbt_room
def L19(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15 = [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"th{i}"]))
        b12.append(float(request.GET[f"n{i}"]))
        b13.append(float(request.GET[f"r{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round(math.cos(math.radians((b11[j]))), dpp))
        b15.append(round(b12[j] / b13[j], dpp))
        ch.append([b15[j], b14[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b15)
    yax = np.array(b14)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s19.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


def p20(request):
    return render(request, 'practicals/p20con.html')


@cbt_room
def L20(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15 = [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"e{i}"]))
        b12.append(float(request.GET[f"f{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round(math.sin(math.radians((b11[j]))), dpp))
        b15.append(round(math.sin(math.radians((b12[j]))), dpp))
        ch.append([b15[j], b14[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b15)
    yax = np.array(b14)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s20.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p21(request):
    return render(request, 'practicals/p21con.html')


@cbt_room
def L21(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13 = [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"i{i}"]))
        b12.append(float(request.GET[f"d{i}"]))
        b13.append(float(request.GET[f"e{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        ch.append([b11[j], b12[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b11)
    yax = np.array(b12)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    minD = min(b12)
    inci = b12.index(minD)
    inc = b11[inci]
    aa = 60
    au = (aa+minD)/2
    au2 = (aa/2)
    up = round(math.sin(math.radians((au))), dpp)
    down = round(math.sin(math.radians(au2)), dpp)
    n = round(up/down, dpp)

    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s21.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "minD": minD,
                                                "inc": inc,
                                                "aa": aa,
                                                "up": up,
                                                "down": down,
                                                "n": n,
                                                "au": au,
                                                "au2": au2,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p22(request):
    return render(request, 'practicals/p22con.html')


@cbt_room
def L22(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"hw{i}"]))
        b12.append(float(request.GET[f"lw{i}"]))
        b13.append(float(request.GET[f"hl{i}"]))
        b14.append(float(request.GET[f"ll{i}"]))
    j = -1
    ch = []
    ch2 = []
    while j < (len(b11) - 1):
        j = j + 1
        b15.append(round(b11[j] / b12[j], dpp))
        b16.append(round(b13[j] / b14[j], dpp))
        ch.append([b12[j], b11[j]])
        chh = (','.join(map(str, ch)))
        ch2.append([b14[j], b13[j]])
        chh2 = (','.join(map(str, ch2)))
    xax = np.array(b12)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    x2ax = np.array(b14)
    y2ax = np.array(b13)
    plt.plot(x2ax, y2ax, 'o')
    b2, a2 = np.polyfit(x2ax, y2ax, 1)
    plt.plot(x2ax, b2 * x2ax + a2, color="r", lw=2.5, label='Tsquare')
    bc2 = round(b2, dpp)
    ac2 = round(a2, dpp)
    n = round(40/3, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s22.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "ac2": ac2,
                                                "bc2": bc2,
                                                "chh2": chh2,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                "b16": b16,
                                                "n": n,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p23(request):
    return render(request, 'practicals/p23con.html')


@cbt_room
def L23(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15 = [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"u{i}"]))
        b12.append(float(request.GET[f"v{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b13.append(round(1 / b11[j], dpp))
        b14.append(round(1 / b12[j], dpp))
        b15.append(round((b11[j]+b12[j])/(b11[j]*b12[j]), dpp))
        ch.append([b13[j], b14[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b13)
    yax = np.array(b14)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    f = round(1/ac, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s23.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                "f": f,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p24(request):
    return render(request, 'practicals/p24con.html')


@cbt_room
def L24(request):
    user = request.user
    f = (float(request.GET["f"]))
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15 = [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"p1{i}"]))
        b12.append(float(request.GET[f"p2{i}"]))
        b13.append(float(request.GET[f"d{i}"]))
    j = -1
    ch = []
    while j < (len(b11) - 1):
        j = j + 1
        b14.append(round(b11[j] - b12[j], dpp))
        b15.append(round((b13[j]**2) - (b14[j]**2), dpp))
        ch.append([b13[j], b15[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b13)
    yax = np.array(b15)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    fc = bc/4
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s24.html', {"ac": ac,
                                                "f": f,
                                                "fc": fc,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p25(request):
    return render(request, 'practicals/p25con.html')

@cbt_room
def L25(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    f1 = (float(request.GET["f1"]))
    fc = (float(request.GET["fc"]))
    dpp = round(dp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s25.html', {"fc": fc,
                                                "f1": f1,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


def p26(request):
    return render(request, 'practicals/p26con.html')

@cbt_room
def L26(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    w = (float(request.GET["w"]))
    a2 = (float(request.GET["nu"]))
    a1 = (float(request.GET["mu"]))
    dpp = round(dp)
    a11, a12 = [], []
    b11, b12, b13, b14 = [], [], [], []
    w1, w2 = 0, 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    while w2 < a1:
        w2 = w2 + 1
        a12.append(w2)
    for i in a12:
        amax = max(a12)
        b11.append(float(request.GET[f"d{i}"]))
        dav = round(np.average(b11), dpp)
        b111 = (','.join(map(str, b11)))
        rr = dav / 2
        rrc = rr/1000
    for i in a11:
        b12.append(float(request.GET[f"f{i}"]))
        b13.append(float(request.GET[f"l{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((1 / b13[j]), dpp))
        ch.append([b14[j], b12[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b12)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    mu = round(((w**0.5)/(bc**2))**2, dpp)
    area = round((math.pi)*(rrc**2), dpp)
    density = round(mu/area, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s26.html', {"ac": ac,
                                                "dav": dav,
                                                "w": w,
                                                "rr": rr,
                                                "rrc": rrc,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b111": b111,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "amax": amax,
                                                "mu": mu,
                                                "area": area,
                                                "density": density,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')


def p27(request):
    return render(request, 'practicals/p27con.html')

@cbt_room
def L27(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    rr = (float(request.GET["r"]))
    w = (float(request.GET["w"]))
    rrc = rr/1000
    f = (float(request.GET["f"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    m = round(w / 9.8, dpp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"m{i}"]))
        b12.append(round(float(request.GET[f"m{i}"])*9.8, dpp))
        b13.append(float(request.GET[f"l{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((b12[j]**0.5), dpp))
        ch.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b13)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    down = round(2*f*bc, dpp)
    downsq = round(down**2, dpp)
    mu = round(1/downsq, dpp)
    v = round(2*3.142*(rrc**2)*f, dpp)
    density = round(m/v, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s27.html', {"ac": ac,
                                                "f": f,
                                                "w": w,
                                                "rr": rr,
                                                "rrc": rrc,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "down": down,
                                                "downsq": downsq,
                                                "mu": mu,
                                                "m": m,
                                                "v": v,
                                                "density": density,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

def p28(request):
    return render(request, 'practicals/p28con.html')
def p29(request):
    return render(request, 'practicals/p29con.html')
def p30(request):
    return render(request, 'practicals/p30con.html')
def p31(request):
    return render(request, 'practicals/p31con.html')
def p32(request):
    return render(request, 'practicals/p32con.html')
def p33(request):
    return render(request, 'practicals/p33con.html')
def p34(request):
    return render(request, 'practicals/p34con.html')
def p35(request):
    return render(request, 'practicals/p35con.html')
def p36(request):
    return render(request, 'practicals/p36con.html')
def p37(request):
    return render(request, 'practicals/p37con.html')
def p38(request):
    return render(request, 'practicals/p38con.html')

@cbt_room
def L28(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    rr = (float(request.GET["r"]))
    f = (float(request.GET["f"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"m{i}"]))
        b12.append(float(request.GET[f"t{i}"]))
        b13.append(float(request.GET[f"l{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((b12[j]**0.5), dpp))
        ch.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b13)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s28.html', {"ac": ac,
                                                "f": f,
                                                "rr": rr,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L29(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    rr = (float(request.GET["r"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"f{i}"]))
        b12.append(float(request.GET[f"t1{i}"]))
        b13.append(float(request.GET[f"t2{i}"]))
        b14.append(float(request.GET[f"t3{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b15.append(round((1/b11[j]), dpp))
        b16.append(round((b12[j]+b13[j]+b14[j])/3, dpp))
        ch.append([b15[j], b16[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b15)
    yax = np.array(b16)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    v = 4*bc
    side = round(rr/273, dpp)
    brac = 1+side
    brac2 = round(brac**0.5, dpp)
    ans = round(340*brac2, dpp)
    c = round(-ac, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s29.html', {"ac": ac,
                                                "rr": rr,
                                                "v": v,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                "b16": b16,
                                                "c": c,
                                                "side": side,
                                                "brac": brac,
                                                "brac2": brac2,
                                                "ans": ans,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L30(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    f = (float(request.GET["r"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15, b16 = [], [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"f{i}"]))
        b12.append(float(request.GET[f"l1{i}"]))
        b13.append(float(request.GET[f"l2{i}"]))
    j = -1
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((b13[j] - b12[j]), dpp))
        b15.append(round((2*b11[j]*b14[j]), dpp))
        b16.append(round(b13[j] - (1.5*b12[j]), dpp))
    vav = round(np.average(b15), dpp)
    wav = round(np.average(b16), dpp)
    vmax = max(b15)
    vmin = min(b15)
    up = vmax-vmin
    ans = round(up/a2, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s30.html', {
                                                "f": f,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                "b16": b16,
                "vav": vav,
                "wav": wav,
                "vmax": vmax,
                "vmin": vmin,
                "ans": ans,
                "a2": a2,
                "up": up,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')
    
@cbt_room
def L31(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    rr = (float(request.GET["r"]))
    f = (float(request.GET["f"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"m{i}"]))
        b12.append(float(request.GET[f"t{i}"]))
        b13.append(float(request.GET[f"l{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((b12[j]**0.5), dpp))
        ch.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b13)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s31.html', {"ac": ac,
                                                "f": f,
                                                "rr": rr,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')
    
@cbt_room
def L32(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    rr = (float(request.GET["r"]))
    f = (float(request.GET["f"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"m{i}"]))
        b12.append(float(request.GET[f"t{i}"]))
        b13.append(float(request.GET[f"l{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((b12[j]**0.5), dpp))
        ch.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b13)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s32.html', {"ac": ac,
                                                "f": f,
                                                "rr": rr,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L33(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13 = [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"v{i}"]))
        b12.append(float(request.GET[f"i{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b13.append(round((b11[j]/b12[j]), dpp))
        ch.append([b12[j], b11[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b12)
    yax = np.array(b11)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s33.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L34(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    r1 = (float(request.GET["r1"]))
    r2 = (float(request.GET["r2"]))
    rs = r1+r2
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13 = [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"v{i}"]))
        b12.append(float(request.GET[f"i{i}"]))
    j = -1
    while j < (len(b12) - 1):
        j = j + 1
        b13.append(round((b11[j] / b12[j]), dpp))
        vav = round(np.average(b13), dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s34.html', {"r1": r1,
                                                "r2": r2,
                                                "rs": rs,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "vav": vav,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L35(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b14 = [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"r{i}"]))
        b12.append(float(request.GET[f"i{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((1/b12[j]), dpp))
        ch.append([b11[j], b14[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b11)
    yax = np.array(b14)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    bige = round(1/bc, dpp)
    r = round(ac*bige, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s35.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b14": b14,
                                                "bige": bige,
                                                "r": r,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')
    
@cbt_room
def L36(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14, b15 = [], [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"r{i}"]))
        b12.append(float(request.GET[f"i1{i}"]))
        b13.append(float(request.GET[f"i2{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b14.append(round((b12[j] + b13[j]), dpp))
        b15.append(round((b12[j] - b13[j]), dpp))
        ch.append([b15[j], b14[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b15)
    yax = np.array(b14)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s36.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "b15": b15,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')
    
@cbt_room
def L37(request):
    user = request.user
    dp = round(int(request.GET["dp"]))
    e1 = (float(request.GET["e1"]))
    l1 = (float(request.GET["l1"]))
    l11 = l1/1000
    l2 = (float(request.GET["l2"]))
    l22 = l2/1000
    pdl = round(e1/l11, dp)
    e2 = round(pdl*l22, dp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:

            return render(request, 'practicals/s37.html', {"e1": e1,
                                                "e2": e2,
                                                "l1": l1,
                                                "l2": l2,
                                                "l11": l11,
                                                "l22": l22,
                                                "pdl": pdl,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')

@cbt_room
def L38(request):
    user = request.user
    dp = (float(request.GET["dp"]))
    a2 = (float(request.GET["nu"]))
    dpp = round(dp)
    a11 = []
    b11, b12, b13, b14 = [], [], [], []
    w1 = 0
    while w1 < a2:
        w1 = w1 + 1
        a11.append(w1)
    for i in a11:
        b11.append(float(request.GET[f"i{i}"]))
        b12.append(float(request.GET[f"v{i}"]))
    j = -1
    ch = []
    while j < (len(b12) - 1):
        j = j + 1
        b13.append(round(math.log(b11[j], 10), dpp))
        b14.append(round(math.log(b12[j], 10), dpp))
        ch.append([b14[j], b13[j]])
        chh = (','.join(map(str, ch)))
    xax = np.array(b14)
    yax = np.array(b13)
    plt.plot(xax, yax, 'o')
    b, a = np.polyfit(xax, yax, 1)
    plt.plot(xax, b * xax + a, color="r", lw=2.5, label='Tsquare')
    bc = round(b, dpp)
    ac = round(a, 1)
    k = round(10**ac, dpp)
    if Pins.objects.filter(pin=user.id) or allowance == True:
        try:
            return render(request, 'practicals/s38.html', {"ac": ac,
                                                "bc": bc,
                                                "chh": chh,
                                                "b11": b11,
                                                "b12": b12,
                                                "b13": b13,
                                                "b14": b14,
                                                "k": k,
                                                })
        except:
            messages.error(request, 'Some values may be inputted wrongly')
            return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.error(request, 'You must be activated to access this access')
        return redirect('buypin')
def pdfdownload(request):
    user = request.user
    topic = str(request.GET["topic"])
    if Pins.objects.filter(pin=user.id):
        try:
            # pdf_path = f'static/pdf/{topic}.pdf'
            # response = FileResponse(open(pdf_path, 'rb'), content_type='application/pdf')
            # response['Content-Disposition'] = f'attachment; filename="Term Paper({topic}).pdf"'
            # return response
            text = "You are eligible to download, we'll send you an email once the materials are ready"
        except FileNotFoundError:
            text = "Sorry this file isn't available at the moment"
    else:
        text2 = "You may not be able to download because you are not activated to access this service"
        messages.error(request, text2)
    messages.error(request, text)
    #return response
        # workbook.save(hmm)
        #     shutil.rmtree(hmm)



def mathscores1(request):
    user = request.user
    score = request.POST.get("score")
    values = Mth1.objects.create(firstname=user.firstname, lastname=user.lastname, department=user.department, score=score)
    values.save()
    return redirect('select-tournament')

