from django.shortcuts import render, redirect
from django.contrib import messages
from pracs.models import Pins
import random
import math
from . import quiz


def lessons(request):
    mathematics = quiz.mth
    chemistry = quiz.chm
    biology = quiz.bio
    physics = quiz.phy
    government = quiz.government
    # eng = quiz.english
    subject = request.session.get('subject')
    names = request.session.get('lessons', "")
    dict = {'physics':physics, 'biology':biology,'chemistry':chemistry,'government':government,'mathematics':mathematics,}
    to_learn = []

    for i in dict[subject]:
        if i['topic'] in names and i['correct'] != 'E':
            to_learn.append({'question':i['question'], 'options': i['options'], 'correct':i['correct'], 'explanation':i['explanation'], 'index': dict[subject].index(i)})
    
    # to_learn = random.shuffle(to_learn)

    context = {'math': to_learn, 'test':[1,2,3,4], 'subject': subject, 'lessons': names}
    return render(request, 'base/quiz.html', context)

