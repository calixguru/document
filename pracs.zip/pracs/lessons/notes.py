


notes = [{'topic': 'algebra', 'notes': r'''
<body>
    <h1>Algebra: A Simple Explanation</h1>
    <p>Algebra is a branch of mathematics that deals with symbols and the rules for manipulating those symbols. These symbols (often letters) represent numbers in equations and formulas. Algebra allows us to solve problems where we don't know the exact numbers but want to find them. Let’s break it down.</p>

    <h2>1. Variables and Constants</h2>
    <p>In algebra, we use letters like <em>x</em>, <em>y</em>, or <em>z</em> to represent unknown numbers. These letters are called <strong>variables</strong>. For example, in the equation:</p>
    <p>
        $$ x + 5 = 12 $$
    </p>
    <p>Here, <em>x</em> is the unknown number, and we want to find its value.</p>

    <h2>2. Solving Simple Equations</h2>
    <p>To solve an equation means finding the value of the variable that makes the equation true. Let’s solve the equation from above:</p>
    
    <div class="example">
        <p><strong>Example 1:</strong> Solve \( x + 5 = 12 \)</p>
        <p>Step 1: To isolate <em>x</em>, we need to get rid of the <em>+5</em>. We do this by subtracting 5 from both sides of the equation:</p>
        <p>
            $$ x + 5 - 5 = 12 - 5 $$
        </p>
        <p>Step 2: This simplifies to:</p>
        <p>
            $$ x = 7 $$
        </p>
        <p>So, the solution is <em>x = 7</em>.</p>
    </div>

    <h2>3. Working with Negative Numbers</h2>
    <p>Algebra also involves negative numbers. Let’s solve an equation with a negative value:</p>
    
    <div class="example">
        <p><strong>Example 2:</strong> Solve \( x - 3 = -7 \)</p>
        <p>Step 1: To isolate <em>x</em>, we need to add 3 to both sides of the equation:</p>
        <p>
            $$ x - 3 + 3 = -7 + 3 $$
        </p>
        <p>Step 2: This simplifies to:</p>
        <p>
            $$ x = -4 $$
        </p>
        <p>So, the solution is <em>x = -4</em>.</p>
    </div>

    <h2>4. Multiplication and Division in Algebra</h2>
    <p>Sometimes, you’ll need to multiply or divide both sides of an equation to solve for a variable.</p>
    
    <div class="example">
        <p><strong>Example 3:</strong> Solve \( 3x = 15 \)</p>
        <p>Step 1: To isolate <em>x</em>, divide both sides by 3:</p>
        <p>
            $$ \frac{3x}{3} = \frac{15}{3} $$
        </p>
        <p>Step 2: This simplifies to:</p>
        <p>
            $$ x = 5 $$
        </p>
        <p>So, the solution is <em>x = 5</em>.</p>
    </div>

    <h2>5. Working with Fractions</h2>
    <p>Fractions can appear in algebra too. Let’s solve an equation with a fraction:</p>
    
    <div class="example">
        <p><strong>Example 4:</strong> Solve \( \frac{x}{4} = 3 \)</p>
        <p>Step 1: To isolate <em>x</em>, multiply both sides by 4:</p>
        <p>
            $$ \frac{x}{4} \times 4 = 3 \times 4 $$
        </p>
        <p>Step 2: This simplifies to:</p>
        <p>
            $$ x = 12 $$
        </p>
        <p>So, the solution is <em>x = 12</em>.</p>
    </div>

    <h2>6. Solving Equations with Multiple Steps</h2>
    <p>Some equations require more than one step to solve. Let’s look at an example:</p>
    
    <div class="example">
        <p><strong>Example 5:</strong> Solve \( 2x + 3 = 11 \)</p>
        <p>Step 1: Subtract 3 from both sides:</p>
        <p>
            $$ 2x + 3 - 3 = 11 - 3 $$
        </p>
        <p>Step 2: This simplifies to:</p>
        <p>
            $$ 2x = 8 $$
        </p>
        <p>Step 3: Now, divide both sides by 2:</p>
        <p>
            $$ \frac{2x}{2} = \frac{8}{2} $$
        </p>
        <p>Step 4: This simplifies to:</p>
        <p>
            $$ x = 4 $$
        </p>
        <p>So, the solution is <em>x = 4</em>.</p>
    </div>

    <h2>7. Algebraic Expressions</h2>
    <p>In algebra, you’ll also come across expressions like \( 3x + 5 \), which are called <strong>algebraic expressions</strong>. These expressions don’t have an equal sign. You can simplify them, combine like terms, or factor them.</p>

    <div class="example">
        <p><strong>Example 6:</strong> Simplify \( 4x + 2x - 3 \)</p>
        <p>Step 1: Combine the like terms (<em>4x</em> and <em>2x</em>):</p>
        <p>
            $$ (4x + 2x) - 3 = 6x - 3 $$
        </p>
        <p>So, the simplified expression is \( 6x - 3 \).</p>
    </div>
</body>
'''}, {'topic': 'indices', 'notes': r'''
<body>
    <h1>Indices: A Simple Explanation</h1>
    <p><strong>Indices</strong> (also called exponents or powers) tell us how many times to multiply a number by itself. For example, in \( 2^3 \), the number 2 is the base, and 3 is the index or exponent, which tells us to multiply 2 by itself 3 times:</p>
    <p>
        $$ 2^3 = 2 \times 2 \times 2 = 8 $$
    </p>

    <h2>1. Basic Rules of Indices</h2>
    <p>There are several basic rules to remember when working with indices:</p>
    <ul>
        <li><strong>Multiplication Rule:</strong> When multiplying numbers with the same base, you add the exponents.</li>
        <li><strong>Division Rule:</strong> When dividing numbers with the same base, you subtract the exponents.</li>
        <li><strong>Power of a Power Rule:</strong> When raising a power to another power, you multiply the exponents.</li>
        <li><strong>Zero Index Rule:</strong> Any number raised to the power of 0 is 1.</li>
        <li><strong>Negative Index Rule:</strong> A negative exponent represents the reciprocal of the number with a positive exponent.</li>
    </ul>

    <h2>2. Multiplication Rule</h2>
    <p>When you multiply two numbers with the same base, you add the exponents:</p>
    <p>
        $$ a^m \times a^n = a^{m+n} $$
    </p>

    <div class="example">
        <p><strong>Example 1:</strong> Simplify \( 2^3 \times 2^4 \)</p>
        <p>Step 1: Since the base is the same, add the exponents:</p>
        <p>
            $$ 2^3 \times 2^4 = 2^{3+4} = 2^7 $$
        </p>
        <p>Step 2: Simplify further if needed:</p>
        <p>
            $$ 2^7 = 128 $$
        </p>
    </div>

    <h2>3. Division Rule</h2>
    <p>When you divide two numbers with the same base, you subtract the exponents:</p>
    <p>
        $$ \frac{a^m}{a^n} = a^{m-n} $$
    </p>

    <div class="example">
        <p><strong>Example 2:</strong> Simplify \( \frac{5^6}{5^2} \)</p>
        <p>Step 1: Subtract the exponents:</p>
        <p>
            $$ \frac{5^6}{5^2} = 5^{6-2} = 5^4 $$
        </p>
        <p>Step 2: Simplify further if needed:</p>
        <p>
            $$ 5^4 = 625 $$
        </p>
    </div>

    <h2>4. Power of a Power Rule</h2>
    <p>When you raise a power to another power, you multiply the exponents:</p>
    <p>
        $$ (a^m)^n = a^{m \times n} $$
    </p>

    <div class="example">
        <p><strong>Example 3:</strong> Simplify \( (3^2)^3 \)</p>
        <p>Step 1: Multiply the exponents:</p>
        <p>
            $$ (3^2)^3 = 3^{2 \times 3} = 3^6 $$
        </p>
        <p>Step 2: Simplify further if needed:</p>
        <p>
            $$ 3^6 = 729 $$
        </p>
    </div>

    <h2>5. Zero Index Rule</h2>
    <p>Any number raised to the power of 0 is equal to 1:</p>
    <p>
        $$ a^0 = 1 $$
    </p>

    <div class="example">
        <p><strong>Example 4:</strong> Simplify \( 7^0 \)</p>
        <p>Step 1: Apply the zero index rule:</p>
        <p>
            $$ 7^0 = 1 $$
        </p>
    </div>

    <h2>6. Negative Index Rule</h2>
    <p>A negative exponent represents the reciprocal of the number with a positive exponent:</p>
    <p>
        $$ a^{-n} = \frac{1}{a^n} $$
    </p>

    <div class="example">
        <p><strong>Example 5:</strong> Simplify \( 4^{-2} \)</p>
        <p>Step 1: Apply the negative index rule:</p>
        <p>
            $$ 4^{-2} = \frac{1}{4^2} = \frac{1}{16} $$
        </p>
    </div>

    <h2>7. Combining the Rules</h2>
    <p>Sometimes, you may need to apply more than one rule to simplify an expression.</p>

    <div class="example">
        <p><strong>Example 6:</strong> Simplify \( \frac{2^5 \times 2^3}{2^4} \)</p>
        <p>Step 1: Apply the multiplication rule to the numerator:</p>
        <p>
            $$ 2^5 \times 2^3 = 2^{5+3} = 2^8 $$
        </p>
        <p>Step 2: Apply the division rule:</p>
        <p>
            $$ \frac{2^8}{2^4} = 2^{8-4} = 2^4 $$
        </p>
        <p>Step 3: Simplify further if needed:</p>
        <p>
            $$ 2^4 = 16 $$
        </p>
    </div>
 
</body>'''}, {'topic': 'logarithms', 'notes': r'''
<body>
    <h1>Logarithms: A Simple Explanation</h1>
    <p><strong>Logarithms</strong> are the inverse of exponents. A logarithm tells us how many times we need to multiply a number (called the base) to get another number. In other words, if we know the result of a power but not the exponent, we can use a logarithm to find it.</p>
    <p>For example, if we know \( 2^3 = 8 \), then the logarithm will help us find that exponent 3:</p>
    <p>
        $$ \log_2(8) = 3 $$
    </p>
    <p>This means that 2 raised to the power of 3 equals 8.</p>

    <h2>1. The General Logarithm Formula</h2>
    <p>The logarithm formula is written as:</p>
    <p>
        $$ \log_b(a) = c $$
    </p>
    <p>This means that \( b^c = a \), where \( b \) is the base, \( a \) is the result, and \( c \) is the exponent.</p>

    <div class="example">
        <p><strong>Example 1:</strong> What is \( \log_5(25) \)?</p>
        <p>Step 1: We're asking, "5 raised to what power gives 25?"</p>
        <p>Since \( 5^2 = 25 \), we know that:</p>
        <p>
            $$ \log_5(25) = 2 $$
        </p>
    </div>

    <h2>2. Common Logarithms</h2>
    <p><strong>Common logarithms</strong> are logarithms with a base of 10. They are written as \( \log_{10}(x) \) or simply \( \log(x) \).</p>

    <div class="example">
        <p><strong>Example 2:</strong> What is \( \log(1000) \)?</p>
        <p>Step 1: We're asking, "10 raised to what power gives 1000?"</p>
        <p>Since \( 10^3 = 1000 \), we know that:</p>
        <p>
            $$ \log(1000) = 3 $$
        </p>
    </div>

    <h2>3. Natural Logarithms</h2>
    <p><strong>Natural logarithms</strong> have a base of \( e \) (Euler's number), which is approximately 2.718. Natural logarithms are written as \( \ln(x) \).</p>

    <div class="example">
        <p><strong>Example 3:</strong> What is \( \ln(e^2) \)?</p>
        <p>Step 1: We're asking, "e raised to what power gives \( e^2 \)?"</p>
        <p>Since \( e^2 = e^2 \), we know that:</p>
        <p>
            $$ \ln(e^2) = 2 $$
        </p>
    </div>

    <h2>4. Basic Properties of Logarithms</h2>
    <p>There are several important properties to remember when working with logarithms:</p>
    <ul>
        <li><strong>Product Rule:</strong> The logarithm of a product is the sum of the logarithms.</li>
        <li><strong>Quotient Rule:</strong> The logarithm of a quotient is the difference of the logarithms.</li>
        <li><strong>Power Rule:</strong> The logarithm of a number raised to a power is the power times the logarithm of the number.</li>
        <li><strong>Logarithm of 1:</strong> The logarithm of 1 is always 0, no matter the base.</li>
    </ul>

    <h2>5. Product Rule</h2>
    <p>The product rule states that the logarithm of a product is the sum of the logarithms:</p>
    <p>
        $$ \log_b(xy) = \log_b(x) + \log_b(y) $$
    </p>

    <div class="example">
        <p><strong>Example 4:</strong> Simplify \( \log_3(27 \times 9) \).</p>
        <p>Step 1: Apply the product rule:</p>
        <p>
            $$ \log_3(27 \times 9) = \log_3(27) + \log_3(9) $$
        </p>
        <p>Step 2: Simplify each term:</p>
        <p>
            $$ \log_3(27) = 3 \quad \text{(since \( 3^3 = 27 \))} $$
        </p>
        <p>
            $$ \log_3(9) = 2 \quad \text{(since \( 3^2 = 9 \))} $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ \log_3(27 \times 9) = 3 + 2 = 5 $$
        </p>
    </div>

    <h2>6. Quotient Rule</h2>
    <p>The quotient rule states that the logarithm of a quotient is the difference of the logarithms:</p>
    <p>
        $$ \log_b\left( \frac{x}{y} \right) = \log_b(x) - \log_b(y) $$
    </p>

    <div class="example">
        <p><strong>Example 5:</strong> Simplify \( \log_2\left( \frac{16}{4} \right) \).</p>
        <p>Step 1: Apply the quotient rule:</p>
        <p>
            $$ \log_2\left( \frac{16}{4} \right) = \log_2(16) - \log_2(4) $$
        </p>
        <p>Step 2: Simplify each term:</p>
        <p>
            $$ \log_2(16) = 4 \quad \text{(since \( 2^4 = 16 \))} $$
        </p>
        <p>
            $$ \log_2(4) = 2 \quad \text{(since \( 2^2 = 4 \))} $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ \log_2\left( \frac{16}{4} \right) = 4 - 2 = 2 $$
        </p>
    </div>

    <h2>7. Power Rule</h2>
    <p>The power rule states that the logarithm of a number raised to a power is the power times the logarithm of the number:</p>
    <p>
        $$ \log_b(x^n) = n \log_b(x) $$
    </p>

    <div class="example">
        <p><strong>Example 6:</strong> Simplify \( \log_2(8^4) \).</p>
        <p>Step 1: Apply the power rule:</p>
        <p>
            $$ \log_2(8^4) = 4 \log_2(8) $$
        </p>
        <p>Step 2: Simplify further:</p>
        <p>
            $$ \log_2(8) = 3 \quad \text{(since \( 2^3 = 8 \))} $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ 4 \log_2(8) = 4 \times 3 = 12 $$
        </p>
    </div>

    <h2>8. Logarithm of 1</h2>
    <p>The logarithm of 1 is always 0, no matter the base:</p>
    <p>
        $$ \log_b(1) = 0 $$
    </p>

</body> '''}, {'topic': 'surds', 'notes': r'''
<body>
    <h1>Surds: A Simple Explanation</h1>
    <p><strong>Surds</strong> are expressions that include a square root, cube root, or any other root that cannot be simplified to a whole number. They are often used in mathematics to represent irrational numbers.</p>
    <p>For example, the square root of 2 (\( \sqrt{2} \)) is a surd because it cannot be simplified to a whole number or a simple fraction.</p>

    <h2>1. Understanding Surds</h2>
    <p>A surd is typically represented in the form \( \sqrt{a} \), where \( a \) is a positive number that is not a perfect square. The value of \( \sqrt{a} \) cannot be expressed as a simple fraction.</p>

    <div class="example">
        <p><strong>Example 1:</strong> Simplify \( \sqrt{8} \).</p>
        <p>Step 1: Find the prime factors of 8:</p>
        <p>8 can be factored into \( 2 \times 2 \times 2 \) or \( 2^3 \).</p>
        <p>Step 2: Simplify \( \sqrt{8} \):</p>
        <p>
            $$ \sqrt{8} = \sqrt{2 \times 2 \times 2} = \sqrt{2^2 \times 2} = 2\sqrt{2} $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ \sqrt{8} = 2\sqrt{2} $$
        </p>
    </div>

    <h2>2. Adding and Subtracting Surds</h2>
    <p>You can only add or subtract surds if they have the same radicand (the number under the square root). This is similar to combining like terms in algebra.</p>

    <div class="example">
        <p><strong>Example 2:</strong> Simplify \( \sqrt{5} + 2\sqrt{5} \).</p>
        <p>Step 1: Combine like terms:</p>
        <p>
            $$ \sqrt{5} + 2\sqrt{5} = (1 + 2)\sqrt{5} = 3\sqrt{5} $$
        </p>
    </div>

    <h2>3. Multiplying and Dividing Surds</h2>
    <p>When multiplying surds, you multiply the numbers inside the roots. When dividing surds, you divide the numbers inside the roots.</p>

    <div class="example">
        <p><strong>Example 3:</strong> Simplify \( \sqrt{3} \times \sqrt{12} \).</p>
        <p>Step 1: Multiply inside the roots:</p>
        <p>
            $$ \sqrt{3} \times \sqrt{12} = \sqrt{3 \times 12} = \sqrt{36} $$
        </p>
        <p>Step 2: Simplify:</p>
        <p>
            $$ \sqrt{36} = 6 $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ \sqrt{3} \times \sqrt{12} = 6 $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 4:</strong> Simplify \( \frac{\sqrt{18}}{\sqrt{2}} \).</p>
        <p>Step 1: Divide inside the roots:</p>
        <p>
            $$ \frac{\sqrt{18}}{\sqrt{2}} = \sqrt{\frac{18}{2}} = \sqrt{9} $$
        </p>
        <p>Step 2: Simplify:</p>
        <p>
            $$ \sqrt{9} = 3 $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ \frac{\sqrt{18}}{\sqrt{2}} = 3 $$
        </p>
    </div>

    <h2>4. Rationalizing the Denominator</h2>
    <p>To rationalize the denominator of a fraction that contains a surd, you multiply both the numerator and denominator by the surd in the denominator.</p>

    <div class="example">
        <p><strong>Example 5:</strong> Rationalize the denominator of \( \frac{1}{\sqrt{5}} \).</p>
        <p>Step 1: Multiply by \( \sqrt{5}/\sqrt{5} \):</p>
        <p>
            $$ \frac{1}{\sqrt{5}} \times \frac{\sqrt{5}}{\sqrt{5}} = \frac{\sqrt{5}}{5} $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ \frac{1}{\sqrt{5}} = \frac{\sqrt{5}}{5} $$
        </p>
    </div>

    <h2>5. Simplifying Complex Surds</h2>
    <p>Sometimes surds may appear in more complex forms. You can simplify them by breaking them into simpler surds or using the rules of surds.</p>

    <div class="example">
        <p><strong>Example 6:</strong> Simplify \( \sqrt{50} - \sqrt{18} \).</p>
        <p>Step 1: Break into simpler surds:</p>
        <p>
            $$ \sqrt{50} = \sqrt{25 \times 2} = 5\sqrt{2} $$
        </p>
        <p>
            $$ \sqrt{18} = \sqrt{9 \times 2} = 3\sqrt{2} $$
        </p>
        <p>Step 2: Combine like terms:</p>
        <p>
            $$ \sqrt{50} - \sqrt{18} = 5\sqrt{2} - 3\sqrt{2} = 2\sqrt{2} $$
        </p>
    </div>

    </body>'''}, {'topic': 'sets', 'notes': r'''
    
<body>
    <h1>Sets: A Simple Explanation</h1>
    <p>A <strong>set</strong> is a collection of distinct objects, considered as an object in its own right. The objects in a set are called <strong>elements</strong> or <strong>members</strong>.</p>
    <p>Sets are usually denoted by curly braces. For example, the set of natural numbers less than 5 can be written as:</p>
    <p>
        $$ A = \{1, 2, 3, 4\} $$
    </p>

    <h2>1. Set Notation</h2>
    <p>Sets can be described in two ways:</p>
    <ul>
        <li><strong>Roster Form:</strong> Lists all the elements explicitly.</li>
        <li><strong>Set-builder Form:</strong> Describes the properties of the elements.</li>
    </ul>

    <div class="example">
        <p><strong>Example 1:</strong> Describe the set of even numbers between 1 and 10.</p>
        <p>Roster Form:</p>
        <p>
            $$ B = \{2, 4, 6, 8\} $$
        </p>
        <p>Set-builder Form:</p>
        <p>
            $$ B = \{ x \mid x \text{ is an even number and } 1 < x < 10 \} $$
        </p>
    </div>

    <h2>2. Set Operations</h2>
    <p>Common set operations include:</p>
    <ul>
        <li><strong>Union:</strong> Combines all elements from both sets.</li>
        <li><strong>Intersection:</strong> Contains elements common to both sets.</li>
        <li><strong>Difference:</strong> Contains elements in the first set but not in the second.</li>
        <li><strong>Complement:</strong> Contains elements not in the set.</li>
    </ul>

    <div class="example">
        <p><strong>Example 2:</strong> Given sets \( A = \{1, 2, 3\} \) and \( B = \{2, 3, 4\} \), find:</p>
        <p><strong>Union:</strong></p>
        <p>
            $$ A \cup B = \{1, 2, 3, 4\} $$
        </p>
        <p><strong>Intersection:</strong></p>
        <p>
            $$ A \cap B = \{2, 3\} $$
        </p>
        <p><strong>Difference:</strong></p>
        <p>
            $$ A - B = \{1\} $$
        </p>
        <p>
            $$ B - A = \{4\} $$
        </p>
    </div>

    <h2>3. Subsets</h2>
    <p>A set \( A \) is a subset of \( B \) if all elements of \( A \) are also in \( B \). This is written as:</p>
    <p>
        $$ A \subseteq B $$
    </p>

    <div class="example">
        <p><strong>Example 3:</strong> If \( A = \{1, 2\} \) and \( B = \{1, 2, 3\} \), then:</p>
        <p>
            $$ A \subseteq B $$
        </p>
        <p>Since all elements of \( A \) are in \( B \).</p>
    </div>

    <h2>4. Venn Diagrams</h2>
    <p>Venn diagrams are used to visually represent sets and their relationships.</p>
    <p>For example, a Venn diagram for sets \( A \) and \( B \) shows their union, intersection, and difference.</p>

    <div class="example">
        <p><strong>Example 4:</strong> Draw a Venn diagram for sets \( A = \{1, 2\} \) and \( B = \{2, 3\} \).</p>
        <p>The diagram would show two overlapping circles, where the overlap represents \( \{2\} \) (the intersection), and the areas outside the overlap represent \( \{1\} \) and \( \{3\} \) (the differences).</p>
    </div>
</body>
'''}, {'topic': 'variations', 'notes': r'''
<body>
    <h1>Variations: A Simple Explanation</h1>
    <p><strong>Variation</strong> refers to the relationship between two variables. There are two main types of variations: direct variation and inverse variation.</p>

    <h2>1. Direct Variation</h2>
    <p>In direct variation, as one variable increases, the other variable also increases. This is expressed as:</p>
    <p>
        $$ y = kx $$
    </p>
    <p>where \( k \) is the constant of variation.</p>

    <div class="example">
        <p><strong>Example 1:</strong> If \( y \) varies directly with \( x \) and \( y = 10 \) when \( x = 2 \), find the constant of variation \( k \).</p>
        <p>Using the formula:</p>
        <p>
            $$ y = kx $$
        </p>
        <p>Substitute the values:</p>
        <p>
            $$ 10 = k \times 2 $$
        </p>
        <p>Solve for \( k \):</p>
        <p>
            $$ k = \frac{10}{2} = 5 $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ y = 5x $$
        </p>
    </div>

    <h2>2. Inverse Variation</h2>
    <p>In inverse variation, as one variable increases, the other variable decreases. This is expressed as:</p>
    <p>
        $$ y = \frac{k}{x} $$
    </p>
    <p>where \( k \) is the constant of variation.</p>

    <div class="example">
        <p><strong>Example 2:</strong> If \( y \) varies inversely with \( x \) and \( y = 4 \) when \( x = 3 \), find the constant of variation \( k \).</p>
        <p>Using the formula:</p>
        <p>
            $$ y = \frac{k}{x} $$
        </p>
        <p>Substitute the values:</p>
        <p>
            $$ 4 = \frac{k}{3} $$
        </p>
        <p>Solve for \( k \):</p>
        <p>
            $$ k = 4 \times 3 = 12 $$
        </p>
        <p>Therefore:</p>
        <p>
            $$ y = \frac{12}{x} $$
        </p>
    </div>

    <h2>3. Solving Variation Problems</h2>
    <p>To solve problems involving variation, use the formula that matches the type of variation (direct or inverse) and substitute the known values to find the constant \( k \). Then use the constant to solve for unknown values.</p>

    <div class="example">
        <p><strong>Example 3:</strong> If \( y \) varies directly with \( x \) and \( y = 8 \) when \( x = 4 \), find \( y \) when \( x = 6 \).</p>
        <p>First, find \( k \):</p>
        <p>
            $$ y = kx $$
        </p>
        <p>
            $$ 8 = k \times 4 $$
        </p>
        <p>
            $$ k = \frac{8}{4} = 2 $$
        </p>
        <p>Then, use \( k \) to find \( y \) when \( x = 6 \):</p>
        <p>
            $$ y = 2 \times 6 = 12 $$
        </p>
    </div>
</body>'''}, {'topic': 'polynomials', 'notes': r'''
<body>
    <h1>Polynomials: A Simple Explanation</h1>
    <p>A <strong>polynomial</strong> is an algebraic expression consisting of terms combined using addition, subtraction, and multiplication. Each term is a product of a constant (called a coefficient) and a variable raised to a non-negative integer power.</p>
    <p>Polynomials are written in the form:</p>
    <p>
        $$ a_n x^n + a_{n-1} x^{n-1} + \cdots + a_1 x + a_0 $$
    </p>
    <p>where \( a_n, a_{n-1}, \ldots, a_0 \) are constants and \( x \) is the variable.</p>

    <h2>1. Types of Polynomials</h2>
    <p>Polynomials can be classified based on their degree:</p>
    <ul>
        <li><strong>Constant Polynomial:</strong> A polynomial of degree 0. For example, \( 5 \).</li>
        <li><strong>Linear Polynomial:</strong> A polynomial of degree 1. For example, \( 2x + 3 \).</li>
        <li><strong>Quadratic Polynomial:</strong> A polynomial of degree 2. For example, \( x^2 - 4x + 4 \).</li>
        <li><strong>Cubic Polynomial:</strong> A polynomial of degree 3. For example, \( x^3 + 3x^2 - 2x - 5 \).</li>
    </ul>

    <div class="example">
        <p><strong>Example 1:</strong> Identify the type of the polynomial \( 3x^3 - 2x^2 + x - 7 \).</p>
        <p>This is a <strong>cubic polynomial</strong> because the highest power of \( x \) is 3.</p>
    </div>

    <h2>2. Adding and Subtracting Polynomials</h2>
    <p>To add or subtract polynomials, combine like terms (terms with the same variable and exponent).</p>

    <div class="example">
        <p><strong>Example 2:</strong> Add \( 2x^2 + 3x - 5 \) and \( x^2 - x + 4 \).</p>
        <p>Combine like terms:</p>
        <p>
            $$ (2x^2 + 3x - 5) + (x^2 - x + 4) = (2x^2 + x^2) + (3x - x) + (-5 + 4) $$
        </p>
        <p>
            $$ = 3x^2 + 2x - 1 $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 3:</strong> Subtract \( 4x^3 - x^2 + 2x - 6 \) from \( 5x^3 + 3x^2 - 2x + 4 \).</p>
        <p>Combine like terms:</p>
        <p>
            $$ (5x^3 + 3x^2 - 2x + 4) - (4x^3 - x^2 + 2x - 6) $$
        </p>
        <p>
            $$ = (5x^3 - 4x^3) + (3x^2 + x^2) + (-2x - 2x) + (4 + 6) $$
        </p>
        <p>
            $$ = x^3 + 4x^2 - 4x + 10 $$
        </p>
    </div>

    <h2>3. Multiplying Polynomials</h2>
    <p>To multiply polynomials, use the distributive property (also known as the FOIL method for binomials).</p>

    <div class="example">
        <p><strong>Example 4:</strong> Multiply \( (x + 2) \) and \( (x - 3) \).</p>
        <p>Use the distributive property:</p>
        <p>
            $$ (x + 2)(x - 3) = x(x - 3) + 2(x - 3) $$
        </p>
        <p>
            $$ = x^2 - 3x + 2x - 6 $$
        </p>
        <p>
            $$ = x^2 - x - 6 $$
        </p>
    </div>

    <h2>4. Factoring Polynomials</h2>
    <p>Factoring involves writing a polynomial as a product of its factors. Common techniques include factoring out the greatest common factor (GCF) and factoring by grouping.</p>

    <div class="example">
        <p><strong>Example 5:</strong> Factor \( x^2 - 5x + 6 \).</p>
        <p>Find two numbers that multiply to 6 and add to -5. These numbers are -2 and -3:</p>
        <p>
            $$ x^2 - 5x + 6 = (x - 2)(x - 3) $$
        </p>
    </div>
</body>'''}, {'topic': 'progressions', 'notes': r'''

<body>
    <h1>Progressions: A Simple Explanation</h1>
    <p>A <strong>progression</strong> is a sequence of numbers where each term is derived from the previous term using a specific rule. There are two main types of progressions: arithmetic and geometric.</p>

    <h2>1. Arithmetic Progression (AP)</h2>
    <p>In an arithmetic progression, the difference between consecutive terms is constant. This difference is called the <strong>common difference</>.</p>
    <p>The nth term of an AP can be calculated using:</p>
    <p>
        $$ a_n = a_1 + (n - 1)d $$
    </p>
    <p>where \( a_n \) is the nth term, \( a_1 \) is the first term, \( d \) is the common difference, and \( n \) is the term number.</p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the 5th term of the AP where \( a_1 = 3 \) and \( d = 4 \).</p>
        <p>Use the formula:</p>
        <p>
            $$ a_n = a_1 + (n - 1)d $$
        </p>
        <p>
            $$ a_5 = 3 + (5 - 1) \times 4 $$
        </p>
        <p>
            $$ a_5 = 3 + 16 = 19 $$
        </p>
    </div>

    <h2>2. Sum of Arithmetic Progression</h2>
    <p>The sum of the first \( n \) terms of an AP can be found using:</p>
    <p>
        $$ S_n = \frac{n}{2} \left(2a_1 + (n - 1)d \right) $$
    </p>
    <p>where \( S_n \) is the sum of the first \( n \) terms.</p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the sum of the first 4 terms of the AP where \( a_1 = 2 \) and \( d = 5 \).</p>
        <p>Use the formula:</p>
        <p>
            $$ S_n = \frac{n}{2} \left(2a_1 + (n - 1)d \right) $$
        </p>
        <p>
            $$ S_4 = \frac{4}{2} \left(2 \times 2 + (4 - 1) \times 5 \right) $$
        </p>
        <p>
            $$ S_4 = 2 \left(4 + 15 \right) $$
        </p>
        <p>
            $$ S_4 = 2 \times 19 = 38 $$
        </p>
    </div>

    <h2>3. Geometric Progression (GP)</h2>
    <p>In a geometric progression, each term is found by multiplying the previous term by a constant called the <strong>common ratio</>.</p>
    <p>The nth term of a GP can be calculated using:</p>
    <p>
        $$ a_n = a_1 \cdot r^{(n - 1)} $$
    </p>
    <p>where \( a_n \) is the nth term, \( a_1 \) is the first term, \( r \) is the common ratio, and \( n \) is the term number.</p>

    <div class="example">
        <p><strong>Example 3:</strong> Find the 4th term of the GP where \( a_1 = 2 \) and \( r = 3 \).</p>
        <p>Use the formula:</p>
        <p>
            $$ a_n = a_1 \cdot r^{(n - 1)} $$
        </p>
        <p>
            $$ a_4 = 2 \cdot 3^{(4 - 1)} $$
        </p>
        <p>
            $$ a_4 = 2 \cdot 27 = 54 $$
        </p>
    </div>

    <h2>4. Sum of Geometric Progression</h2>
    <p>The sum of the first \( n \) terms of a GP can be found using:</p>
    <p>
        $$ S_n = a_1 \frac{1 - r^n}{1 - r} $$
    </p>
    <p>for \( r \neq 1 \), where \( S_n \) is the sum of the first \( n \) terms.</p>

    <div class="example">
        <p><strong>Example 4:</strong> Find the sum of the first 3 terms of the GP where \( a_1 = 3 \) and \( r = 2 \).</p>
        <p>Use the formula:</p>
        <p>
            $$ S_n = a_1 \frac{1 - r^n}{1 - r} $$
        </p>
        <p>
            $$ S_3 = 3 \frac{1 - 2^3}{1 - 2} $$
        </p>
        <p>
            $$ S_3 = 3 \frac{1 - 8}{-1} $$
        </p>
        <p>
            $$ S_3 = 3 \times 7 = 21 $$
        </p>
    </div>
</body>
</html>
'''}, {'topic': 'mensuration', 'notes': r'''
<body>
    <h1>Mensuration: A Simple Explanation</h1>
    <p><strong>Mensuration</strong> deals with the measurement of geometric figures, such as finding their areas, volumes, and surface areas. Here, we will cover the basic formulas for different shapes.</p>

    <h2>1. Area of Common Shapes</h2>

    <h3>Rectangle</h3>
    <p>The area of a rectangle is given by:</p>
    <p>
        $$ \text{Area} = \text{length} \times \text{width} $$
    </p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the area of a rectangle with length 8 units and width 5 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = 8 \times 5 = 40 \text{ square units} $$
        </p>
    </div>

    <h3>Triangle</h3>
    <p>The area of a triangle is given by:</p>
    <p>
        $$ \text{Area} = \frac{1}{2} \times \text{base} \times \text{height} $$
    </p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the area of a triangle with base 6 units and height 4 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = \frac{1}{2} \times 6 \times 4 = 12 \text{ square units} $$
        </p>
    </div>

    <h3>Circle</h3>
    <p>The area of a circle is given by:</p>
    <p>
        $$ \text{Area} = \pi r^2 $$
    </p>
    <p>where \( r \) is the radius of the circle.</p>

    <div class="example">
        <p><strong>Example 3:</strong> Find the area of a circle with radius 3 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = \pi \times 3^2 = 9\pi \approx 28.27 \text{ square units} $$
        </p>
    </div>

    <h2>2. Volume of Common Solids</h2>

    <h3>Cube</h3>
    <p>The volume of a cube is given by:</p>
    <p>
        $$ \text{Volume} = a^3 $$
    </p>
    <p>where \( a \) is the length of a side.</p>

    <div class="example">
        <p><strong>Example 4:</strong> Find the volume of a cube with side length 4 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Volume} = 4^3 = 64 \text{ cubic units} $$
        </p>
    </div>

    <h3>Cylinder</h3>
    <p>The volume of a cylinder is given by:</p>
    <p>
        $$ \text{Volume} = \pi r^2 h $$
    </p>
    <p>where \( r \) is the radius and \( h \) is the height.</p>

    <div class="example">
        <p><strong>Example 5:</strong> Find the volume of a cylinder with radius 3 units and height 7 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Volume} = \pi \times 3^2 \times 7 = 63\pi \approx 197.92 \text{ cubic units} $$
        </p>
    </div>

    <h2>3. Surface Area of Common Solids</h2>

    <h3>Cube</h3>
    <p>The surface area of a cube is given by:</p>
    <p>
        $$ \text{Surface Area} = 6a^2 $$
    </p>

    <div class="example">
        <p><strong>Example 6:</strong> Find the surface area of a cube with side length 4 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Surface Area} = 6 \times 4^2 = 96 \text{ square units} $$
        </p>
    </div>

    <h3>Cylinder</h3>
    <p>The surface area of a cylinder is given by:</p>
    <p>
        $$ \text{Surface Area} = 2\pi r(h + r) $$
    </p>

    <div class="example">
        <p><strong>Example 7:</strong> Find the surface area of a cylinder with radius 3 units and height 7 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Surface Area} = 2\pi \times 3 \times (7 + 3) = 60\pi \approx 188.40 \text{ square units} $$
        </p>
    </div>
</body>'''}, {'topic': 'areas', 'notes': r'''
<body>
    <h1>Areas: A Simple Explanation</h1>
    <p>The <strong>area</strong> of a shape is the amount of space inside it. The formula to find the area depends on the type of shape.</p>

    <h2>1. Rectangle</h2>
    <p>The area of a rectangle is given by:</p>
    <p>
        $$ \text{Area} = \text{length} \times \text{width} $$
    </p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the area of a rectangle with length 10 units and width 4 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = 10 \times 4 = 40 \text{ square units} $$
        </p>
    </div>

    <h2>2. Square</h2>
    <p>The area of a square is given by:</p>
    <p>
        $$ \text{Area} = \text{side}^2 $$
    </p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the area of a square with side length 5 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = 5^2 = 25 \text{ square units} $$
        </p>
    </div>

    <h2>3. Triangle</h2>
    <p>The area of a triangle is given by:</p>
    <p>
        $$ \text{Area} = \frac{1}{2} \times \text{base} \times \text{height} $$
    </p>

    <div class="example">
        <p><strong>Example 3:</strong> Find the area of a triangle with base 8 units and height 6 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = \frac{1}{2} \times 8 \times 6 = 24 \text{ square units} $$
        </p>
    </div>

    <h2>4. Circle</h2>
    <p>The area of a circle is given by:</p>
    <p>
        $$ \text{Area} = \pi r^2 $$
    </p>
    <p>where \( r \) is the radius of the circle.</p>

    <div class="example">
        <p><strong>Example 4:</strong> Find the area of a circle with radius 7 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = \pi \times 7^2 = 49\pi \approx 153.94 \text{ square units} $$
        </p>
    </div>

    <h2>5. Parallelogram</h2>
    <p>The area of a parallelogram is given by:</p>
    <p>
        $$ \text{Area} = \text{base} \times \text{height} $$
    </p>

    <div class="example">
        <p><strong>Example 5:</strong> Find the area of a parallelogram with base 9 units and height 5 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = 9 \times 5 = 45 \text{ square units} $$
        </p>
    </div>
</body>'''}, {'topic': 'volumes', 'notes': r'''
<body>
    <h1>Volumes: A Simple Explanation</h1>
    <p><strong>Volume</strong> measures the amount of space inside a three-dimensional object. Here are formulas for some common solids.</p>

    <h2>1. Cube</h2>
    <p>The volume of a cube is given by:</p>
    <p>
        $$ \text{Volume} = a^3 $$
    </p>
    <p>where \( a \) is the length of a side.</p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the volume of a cube with side length 5 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Volume} = 5^3 = 125 \text{ cubic units} $$
        </p>
    </div>

    <h2>2. Rectangular Prism</h2>
    <p>The volume of a rectangular prism is given by:</p>
    <p>
        $$ \text{Volume} = \text{length} \times \text{width} \times \text{height} $$
    </p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the volume of a rectangular prism with length 4 units, width 3 units, and height 2 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Volume} = 4 \times 3 \times 2 = 24 \text{ cubic units} $$
        </p>
    </div>

    <h2>3. Cylinder</h2>
    <p>The volume of a cylinder is given by:</p>
    <p>
        $$ \text{Volume} = \pi r^2 h $$
    </p>
    <p>where \( r \) is the radius and \( h \) is the height.</p>

    <div class="example">
        <p><strong>Example 3:</strong> Find the volume of a cylinder with radius 3 units and height 7 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Volume} = \pi \times 3^2 \times 7 = 63\pi \approx 197.92 \text{ cubic units} $$
        </p>
    </div>

    <h2>4. Sphere</h2>
    <p>The volume of a sphere is given by:</p>
    <p>
        $$ \text{Volume} = \frac{4}{3} \pi r^3 $$
    </p>
    <p>where \( r \) is the radius.</p>

    <div class="example">
        <p><strong>Example 4:</strong> Find the volume of a sphere with radius 4 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Volume} = \frac{4}{3} \pi \times 4^3 = \frac{256}{3}\pi \approx 268.08 \text{ cubic units} $$
        </p>
    </div>
</body>'''}, {'topic': 'circles', 'notes': r'''
<body>
    <h1>Circles: A Simple Explanation</h1>
    <p>A <strong>circle</strong> is a shape where all points are equidistant from a central point. Here are some important properties and formulas for circles.</p>

    <h2>1. Circumference</h2>
    <p>The circumference of a circle is the distance around the circle. It is given by:</p>
    <p>
        $$ \text{Circumference} = 2 \pi r $$
    </p>
    <p>where \( r \) is the radius of the circle.</p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the circumference of a circle with radius 6 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Circumference} = 2 \pi \times 6 = 12\pi \approx 37.70 \text{ units} $$
        </p>
    </div>

    <h2>2. Area</h2>
    <p>The area of a circle measures the space inside the circle. It is given by:</p>
    <p>
        $$ \text{Area} = \pi r^2 $$
    </p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the area of a circle with radius 5 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Area} = \pi \times 5^2 = 25\pi \approx 78.54 \text{ square units} $$
        </p>
    </div>

    <h2>3. Diameter</h2>
    <p>The diameter of a circle is the distance across the circle through its center. It is given by:</p>
    <p>
        $$ \text{Diameter} = 2r $$
    </p>

    <div class="example">
        <p><strong>Example 3:</strong> Find the diameter of a circle with radius 8 units.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Diameter} = 2 \times 8 = 16 \text{ units} $$
        </p>
    </div>
</body>'''}, {'topic': 'calculus', 'notes': r'''
<body>
    <h1>Calculus: A Simple Explanation</h1>
    <p><strong>Calculus</strong> is the branch of mathematics that studies continuous change. It has two main areas: differentiation and integration.</p>

    <h2>1. Differentiation</h2>
    <p><strong>Differentiation</strong> finds the rate at which a quantity changes. It involves finding the derivative of a function.</p>
    <p>For a function \( f(x) \), the derivative \( f'(x) \) represents the slope of the function at any point.</p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the derivative of the function \( f(x) = x^2 \).</p>
        <p>Using differentiation rules:</p>
        <p>
            $$ f'(x) = 2x $$
        </p>
    </div>

    <h2>2. Integration</h2>
    <p><strong>Integration</strong> is the reverse process of differentiation. It finds the total accumulation of a quantity. It involves finding the integral of a function.</p>
    <p>For a function \( f(x) \), the integral \( \int f(x) \, dx \) represents the area under the curve of the function.</p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the integral of the function \( f(x) = x \).</p>
        <p>Using integration rules:</p>
        <p>
            $$ \int x \, dx = \frac{x^2}{2} + C $$
        </p>
    </div>
</body>'''}, {'topic': 'differentiation', 'notes': r'''
<body>
    <h1>Differentiation: A Simple Explanation</h1>
    <p><strong>Differentiation</strong> is a key concept in calculus that deals with finding the rate of change of a function. It involves calculating the derivative of a function.</p>

    <h2>1. What is a Derivative?</h2>
    <p>The derivative of a function \( f(x) \) measures how \( f(x) \) changes as \( x \) changes. It represents the slope of the function at any point.</p>

    <h2>2. Basic Rules</h2>
    <ul>
        <li><strong>Constant Rule:</strong> The derivative of a constant is 0.</li>
        <li><strong>Power Rule:</strong> The derivative of \( x^n \) is \( nx^{n-1} \).</li>
        <li><strong>Sum Rule:</strong> The derivative of \( f(x) + g(x) \) is \( f'(x) + g'(x) \).</li>
        <li><strong>Product Rule:</strong> The derivative of \( f(x) \times g(x) \) is \( f'(x)g(x) + f(x)g'(x) \).</li>
        <li><strong>Quotient Rule:</strong> The derivative of \( \frac{f(x)}{g(x)} \) is \( \frac{f'(x)g(x) - f(x)g'(x)}{(g(x))^2} \).</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Find the derivative of \( f(x) = 3x^3 \).</p>
        <p>Using the power rule:</p>
        <p>
            $$ f'(x) = 3 \times 3x^{3-1} = 9x^2 $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Find the derivative of \( f(x) = x^2 + 5x \).</p>
        <p>Using the sum rule and power rule:</p>
        <p>
            $$ f'(x) = 2x + 5 $$
        </p>
    </div>
</body>'''}, {'topic': 'integration', 'notes': r'''
<body>
    <h1>Integration: A Simple Explanation</h1>
    <p><strong>Integration</strong> is the process of finding the total accumulation of a quantity. It is the reverse of differentiation and involves finding the integral of a function.</p>

    <h2>1. What is an Integral?</h2>
    <p>The integral of a function \( f(x) \) represents the area under the curve of \( f(x) \) from one point to another.</p>

    <h2>2. Basic Rules</h2>
    <ul>
        <li><strong>Power Rule:</strong> The integral of \( x^n \) is \( \frac{x^{n+1}}{n+1} + C \) where \( n \neq -1 \).</li>
        <li><strong>Sum Rule:</strong> The integral of \( f(x) + g(x) \) is \( \int f(x) \, dx + \int g(x) \, dx \).</li>
        <li><strong>Constant Multiple Rule:</strong> The integral of \( k \cdot f(x) \) is \( k \int f(x) \, dx \).</li>
        <li><strong>Integration by Substitution:</strong> Use when integrating functions that are a product of a function and its derivative.</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Find the integral of \( f(x) = x^3 \).</p>
        <p>Using the power rule:</p>
        <p>
            $$ \int x^3 \, dx = \frac{x^4}{4} + C $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Find the integral of \( f(x) = 2x \).</p>
        <p>Using the power rule:</p>
        <p>
            $$ \int 2x \, dx = x^2 + C $$
        </p>
    </div>
</body>'''}, {'topic': 'statistics', 'notes': r'''
<body>
    <h1>Statistics: A Simple Explanation</h1>
    <p><strong>Statistics</strong> is the study of data and how to interpret it. It involves collecting, analyzing, and interpreting data to understand and make decisions.</p>

    <h2>1. Mean</h2>
    <p>The <strong>mean</strong> (or average) of a set of numbers is found by adding all the numbers together and dividing by the count of numbers.</p>
    <p>For a set of numbers \( x_1, x_2, \ldots, x_n \), the mean is:</p>
    <p>
        $$ \text{Mean} = \frac{x_1 + x_2 + \cdots + x_n}{n} $$
    </p>

    <div class="example">
        <p><strong>Example 1:</strong> Find the mean of the numbers 4, 8, 6, 5, and 7.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Mean} = \frac{4 + 8 + 6 + 5 + 7}{5} = \frac{30}{5} = 6 $$
        </p>
    </div>

    <h2>2. Median</h2>
    <p>The <strong>median</strong> is the middle value in a set of numbers arranged in order. If the set has an even number of values, the median is the average of the two middle numbers.</p>

    <div class="example">
        <p><strong>Example 2:</strong> Find the median of the numbers 3, 1, 4, 2, and 5.</p>
        <p>First, arrange the numbers in order: 1, 2, 3, 4, 5. The median is the middle value:</p>
        <p>
            $$ \text{Median} = 3 $$
        </p>
    </div>

    <h2>3. Mode</h2>
    <p>The <strong>mode</strong> is the number that appears most frequently in a set of numbers.</p>

    <div class="example">
        <p><strong>Example 3:</strong> Find the mode of the numbers 2, 3, 4, 2, 5, 2, 6.</p>
        <p>The mode is the number that appears most frequently:</p>
        <p>
            $$ \text{Mode} = 2 $$
        </p>
    </div>

    <h2>4. Range</h2>
    <p>The <strong>range</strong> is the difference between the highest and lowest values in a set of numbers.</p>
    <p>For a set of numbers, the range is:</p>
    <p>
        $$ \text{Range} = \text{Maximum} - \text{Minimum} $$
    </p>

    <div class="example">
        <p><strong>Example 4:</strong> Find the range of the numbers 7, 2, 9, 5, 12.</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{Range} = 12 - 2 = 10 $$
        </p>
    </div>
</body>'''}, {'topic': 'probability', 'notes': r'''
<body>
    <h1>Probability: A Simple Explanation</h1>
    <p><strong>Probability</strong> measures how likely an event is to happen. It is a number between 0 and 1, where 0 means the event will not happen and 1 means the event will definitely happen.</p>

    <h2>1. Basic Probability</h2>
    <p>The probability of an event \( E \) is given by:</p>
    <p>
        $$ P(E) = \frac{\text{Number of favorable outcomes}}{\text{Total number of outcomes}} $$
    </p>

    <div class="example">
        <p><strong>Example 1:</strong> What is the probability of rolling a 3 on a fair six-sided die?</p>
        <p>There is 1 favorable outcome (rolling a 3) and 6 possible outcomes:</p>
        <p>
            $$ P(\text{rolling a 3}) = \frac{1}{6} $$
        </p>
    </div>

    <h2>2. Compound Probability</h2>
    <p>For multiple events, you can calculate the combined probability. If events \( A \) and \( B \) are independent, then:</p>
    <p>
        $$ P(A \text{ and } B) = P(A) \times P(B) $$
    </p>

    <div class="example">
        <p><strong>Example 2:</strong> What is the probability of rolling a 2 and then a 4 on two rolls of a fair die?</p>
        <p>Each roll is independent:</p>
        <p>
            $$ P(\text{rolling a 2}) = \frac{1}{6} $$
            $$ P(\text{rolling a 4}) = \frac{1}{6} $$
            $$ P(\text{rolling a 2 and then a 4}) = \frac{1}{6} \times \frac{1}{6} = \frac{1}{36} $$
        </p>
    </div>

    <h2>3. Conditional Probability</h2>
    <p>Conditional probability is the probability of an event occurring given that another event has already occurred:</p>
    <p>
        $$ P(A \mid B) = \frac{P(A \text{ and } B)}{P(B)} $$
    </p>

    <div class="example">
        <p><strong>Example 3:</strong> If a card is drawn from a deck and it is known to be a heart, what is the probability that it is the Queen of Hearts?</p>
        <p>There are 13 hearts and 1 Queen of Hearts:</p>
        <p>
            $$ P(\text{Queen of Hearts} \mid \text{Heart}) = \frac{1}{13} $$
        </p>
    </div>
</body>'''},





{'topic': 'science of living things', 'notes': '<body>\n<h1>Science of Living Things: A Simple Explanation</h1>\n<p>The science of living things, also known as biology, is the study of life and living organisms. It includes understanding their structure, function, growth, evolution, and interactions with their environment.</p>\n<h2>1. Characteristics of Living Things</h2>\n<p>Living things share several characteristics, including:</p>\n<ul>\n<li>Organization: Living organisms are organized into cells.</li>\n<li>Metabolism: They have chemical processes that convert energy.</li>\n<li>Growth: They can grow and develop over time.</li>\n<li>Reproduction: They can produce offspring.</li>\n<li>Response to Stimuli: They respond to environmental changes.</li>\n<li>Adaptation: They adapt to their environment to survive.</li>\n</ul>\n<h2>2. Branches of Biology</h2>\n<p>Biology is divided into various branches such as:</p>\n<ul>\n<li>Botany: Study of plants.</li>\n<li>Zoology: Study of animals.</li>\n<li>Microbiology: Study of microorganisms.</li>\n<li>Genetics: Study of heredity and variation.</li>\n<li>Ecology: Study of organisms and their interactions with the environment.</li>\n</ul>\n</body>'}, {'topic': 'classification or organisation of life', 'notes': '<body>\n<h1>Classification or Organisation of Life: A Simple Explanation</h1>\n<p>The classification of life involves organizing living organisms into groups based on their similarities and differences. This helps scientists understand the relationships between different organisms and their evolutionary history.</p>\n<h2>1. Taxonomy</h2>\n<p>Taxonomy is the science of classifying organisms. It includes several levels:</p>\n<ul>\n<li><strong>Domain:</strong> The highest level, includes Bacteria, Archaea, and Eukarya.</li>\n<li><strong>Kingdom:</strong> Includes groups like Animalia, Plantae, Fungi, and Protista.</li>\n<li><strong>Phylum:</strong> Groups organisms based on major body plans.</li>\n<li><strong>Class:</strong> Further divides organisms within a phylum.</li>\n<li><strong>Order:</strong> Groups organisms within a class.</li>\n<li><strong>Family:</strong> Groups organisms within an order.</li>\n<li><strong>Genus:</strong> Groups organisms within a family.</li>\n<li><strong>Species:</strong> The most specific level, identifying individual organisms.</li>\n</ul>\n<h2>2. Examples of Classification</h2>\n<div class="example">\n<p><strong>Example 1:</strong> Classification of a Dog</p>\n<p>Domain: Eukarya</p>\n<p>Kingdom: Animalia</p>\n<p>Phylum: Chordata</p>\n<p>Class: Mammalia</p>\n<p>Order: Carnivora</p>\n<p>Family: Canidae</p>\n<p>Genus: Canis</p>\n<p>Species: Canis lupus (Gray Wolf)</p>\n</div>\n</body>'}, {'topic': 'cell 1 living unit structure', 'notes': '<body>\n<h1>Cell Structure: A Simple Explanation</h1>\n<p>The cell is the basic structural and functional unit of all living organisms. Cells can be classified into two main types: prokaryotic and eukaryotic.</p>\n<h2>1. Prokaryotic Cells</h2>\n<p>Prokaryotic cells are simple cells without a nucleus. They include bacteria and archaea. Key features include:</p>\n<ul>\n<li><strong>Cell Wall:</strong> Provides structure and protection.</li>\n<li><strong>Cell Membrane:</strong> Controls the movement of substances in and out of the cell.</li>\n<li><strong>Cytoplasm:</strong> Gel-like substance where cellular processes occur.</li>\n<li><strong>Nucleoid:</strong> Region where genetic material is located.</li>\n</ul>\n<h2>2. Eukaryotic Cells</h2>\n<p>Eukaryotic cells have a nucleus and are more complex. They include plant, animal, fungal, and protist cells. Key features include:</p>\n<ul>\n<li><strong>Nucleus:</strong> Contains genetic material and controls cell activities.</li>\n<li><strong>Cell Membrane:</strong> Controls the movement of substances in and out of the cell.</li>\n<li><strong>Cytoplasm:</strong> Gel-like substance where cellular processes occur.</li>\n<li><strong>Organelles:</strong> Specialized structures like mitochondria, endoplasmic reticulum, and Golgi apparatus.</li>\n<li><strong>Cell Wall (in plants):</strong> Provides structure and protection.</li>\n<li><strong>Chloroplasts (in plants):</strong> Site of photosynthesis.</li>\n</ul>\n</body>'}, {'topic': 'cell 2 properties and functions', 'notes': "<body>\n<h1>Cell Properties and Functions: A Simple Explanation</h1>\n<p>Cells are the basic building blocks of life, and they have unique properties and functions that allow them to perform vital roles within an organism.</p>\n<h2>1. Properties of Cells</h2>\n<ul>\n<li><strong>Cell Membrane:</strong> A lipid bilayer that encloses the cell, providing structural support and regulating the movement of substances in and out of the cell.</li>\n<li><strong>Cytoplasm:</strong> The gel-like substance inside the cell membrane, excluding the nucleus, where organelles are suspended and various cellular processes occur.</li>\n<li><strong>Nucleus:</strong> Contains the cell's genetic material (DNA) and controls cellular activities, including growth, metabolism, and reproduction.</li>\n<li><strong>Organelles:</strong> Specialized structures within the cell that perform distinct functions, such as mitochondria for energy production and ribosomes for protein synthesis.</li>\n</ul>\n<h2>2. Functions of Cells</h2>\n<ul>\n<li><strong>Metabolism:</strong> The set of chemical reactions that occur within the cell to maintain life, including catabolic and anabolic processes.</li>\n<li><strong>Growth and Development:</strong> Cells divide and differentiate to allow organisms to grow and develop from a single cell to a complex structure.</li>\n<li><strong>Reproduction:</strong> Cells replicate their DNA and divide to produce new cells, ensuring the continuation of the organism.</li>\n<li><strong>Homeostasis:</strong> Cells maintain internal stability by regulating their internal environment to stay within optimal conditions for function.</li>\n</ul>\n</body>"}, {'topic': 'basic ecological concepts', 'notes': '<body>\n<h1>Basic Ecological Concepts: A Simple Explanation</h1>\n<p>Ecology is the study of interactions between organisms and their environment. It includes understanding how living organisms interact with each other and their surroundings.</p>\n<h2>1. Ecosystem</h2>\n<p>An ecosystem is a community of living organisms interacting with each other and their physical environment. It includes both biotic (living) and abiotic (non-living) components.</p>\n<h2>2. Biotic and Abiotic Factors</h2>\n<ul>\n<li><strong>Biotic Factors:</strong> The living components of an ecosystem, including plants, animals, and microorganisms.</li>\n<li><strong>Abiotic Factors:</strong> The non-living components, such as climate, soil, water, and sunlight.</li>\n</ul>\n<h2>3. Food Chain and Food Web</h2>\n<p>The food chain shows the flow of energy from one organism to another. A food web is a complex network of interconnected food chains in an ecosystem.</p>\n<h2>4. Habitat and Niche</h2>\n<ul>\n<li><strong>Habitat:</strong> The physical environment where an organism lives.</li>\n<li><strong>Niche:</strong> The role and position an organism has in its environment, including how it gets its food and interacts with other organisms.</li>\n</ul>\n</body>'}, {'topic': 'functioning ecosystem', 'notes': '<body>\n<h1>Functioning Ecosystem: A Simple Explanation</h1>\n<p>A functioning ecosystem operates through complex interactions between its biotic and abiotic components. It maintains balance and supports diverse forms of life.</p>\n<h2>1. Energy Flow</h2>\n<p>Energy flows through an ecosystem via the food chain. Producers (plants) convert sunlight into energy through photosynthesis. Consumers (herbivores, carnivores) obtain energy by consuming other organisms.</p>\n<h2>2. Nutrient Cycling</h2>\n<p>Nutrients cycle through ecosystems via processes such as decomposition. Dead organisms are broken down by decomposers, returning nutrients to the soil, which plants use to grow.</p>\n<h2>3. Biodiversity</h2>\n<p>Biodiversity refers to the variety of life in an ecosystem. It includes the number of species, genetic diversity, and ecosystem diversity. High biodiversity contributes to ecosystem stability and resilience.</p>\n<h2>4. Human Impact</h2>\n<p>Human activities such as deforestation, pollution, and climate change can disrupt ecosystems. It is essential to manage these impacts to maintain ecosystem health and functionality.</p>\n</body>'}, {'topic': 'ecological management', 'notes': '<body>\n<h1>Ecological Management: A Simple Explanation</h1>\n<p>Ecological management involves the practices and strategies used to conserve and restore ecosystems, ensuring their sustainability and health for future generations.</p>\n<h2>1. Conservation Strategies</h2>\n<ul>\n<li><strong>Protected Areas:</strong> Establishing national parks and reserves to protect natural habitats and species.</li>\n<li><strong>Restoration Projects:</strong> Rehabilitating degraded ecosystems by replanting vegetation and removing invasive species.</li>\n<li><strong>Sustainable Practices:</strong> Implementing methods that meet current needs without compromising future generations, such as sustainable agriculture and fishing.</li>\n</ul>\n<h2>2. Monitoring and Assessment</h2>\n<p>Regular monitoring and assessment of ecosystems are crucial for effective management. It involves tracking changes in biodiversity, habitat quality, and environmental conditions.</p>\n<h2>3. Community Involvement</h2>\n<p>Engaging local communities in conservation efforts can enhance the success of ecological management. Community-based projects and education programs raise awareness and encourage sustainable practices.</p>\n<h2>4. Policy and Legislation</h2>\n<p>Governments and organizations implement policies and regulations to protect ecosystems. These include laws on wildlife conservation, pollution control, and land use management.</p>\n</body>'}, {'topic': 'ecology of population', 'notes': '<body>\n<h1>Ecology of Population: A Simple Explanation</h1>\n<p>Population ecology is the study of populations of organisms, their interactions with the environment, and how they change over time.</p>\n<h2>1. Population Dynamics</h2>\n<p>Population dynamics refers to the changes in population size and composition over time. Factors influencing population dynamics include birth rates, death rates, immigration, and emigration.</p>\n<h2>2. Growth Models</h2>\n<ul>\n<li><strong>Exponential Growth:</strong> Occurs when resources are unlimited, and populations grow rapidly.</li>\n<li><strong>Logistic Growth:</strong> Occurs when resources are limited, and population growth slows as it approaches the carrying capacity of the environment.</li>\n</ul>\n<h2>3. Carrying Capacity</h2>\n<p>The carrying capacity of an environment is the maximum population size that it can support sustainably. It is influenced by factors such as food availability, habitat space, and environmental conditions.</p>\n<h2>4. Population Interactions</h2>\n<p>Populations interact with each other and their environment in various ways, including competition, predation, and symbiosis (mutualism, commensalism, and parasitism).</p>\n</body>'}, {'topic': 'aquatic and terrestrial habitat', 'notes': '<body>\n<h1>Aquatic and Terrestrial Habitat: A Simple Explanation</h1>\n<p>Habitats are the environments where organisms live. They can be broadly classified into aquatic and terrestrial habitats, each with unique characteristics and challenges.</p>\n<h2>1. Aquatic Habitat</h2>\n<p>Aquatic habitats include environments in water bodies such as oceans, rivers, lakes, and wetlands. They can be further categorized into:</p>\n<ul>\n<li><strong>Marine:</strong> Saltwater environments like oceans and coral reefs.</li>\n<li><strong>Freshwater:</strong> Low salinity environments like rivers, lakes, and ponds.</li>\n<li><strong>Estuarine:</strong> Where freshwater meets saltwater, creating brackish environments like estuaries and mangroves.</li>\n</ul>\n<h2>2. Terrestrial Habitat</h2>\n<p>Terrestrial habitats are land-based environments, including:</p>\n<ul>\n<li><strong>Forests:</strong> Dense areas with a variety of trees and plants, such as tropical rainforests and temperate forests.</li>\n<li><strong>Grasslands:</strong> Areas dominated by grasses, including savannas and prairies.</li>\n<li><strong>Deserts:</strong> Arid environments with low rainfall, such as the Sahara and the Mojave.</li>\n<li><strong>Mountains:</strong> High-altitude regions with cooler temperatures and varying vegetation zones.</li>\n</ul>\n</body>'}, {'topic': 'introduction to micro organisms', 'notes': '<body>\n<h1>Introduction to Microorganisms: A Simple Explanation</h1>\n<p>Microorganisms, or microbes, are tiny living organisms that are too small to be seen with the naked eye. They include bacteria, viruses, fungi, and protozoa.</p>\n<h2>1. Types of Microorganisms</h2>\n<ul>\n<li><strong>Bacteria:</strong> Single-celled organisms that can be found in various environments. They can be beneficial (e.g., gut flora) or pathogenic.</li>\n<li><strong>Viruses:</strong> Smaller than bacteria, viruses are not considered living organisms. They require a host cell to replicate.</li>\n<li><strong>Fungi:</strong> Includes yeasts, molds, and mushrooms. They can be unicellular or multicellular and play roles in decomposition and symbiosis.</li>\n<li><strong>Protozoa:</strong> Single-celled eukaryotes that can be found in aquatic environments. They can be free-living or parasitic.</li>\n</ul>\n<h2>2. Importance of Microorganisms</h2>\n<p>Microorganisms play crucial roles in various processes:</p>\n<ul>\n<li><strong>Decomposition:</strong> Breaking down organic matter and recycling nutrients.</li>\n<li><strong>Symbiosis:</strong> Forming mutualistic relationships with other organisms (e.g., mycorrhizal fungi with plants).</li>\n<li><strong>Human Health:</strong> Beneficial bacteria in the gut aid digestion and produce vitamins.</li>\n<li><strong>Biotechnology:</strong> Used in fermentation, medicine production, and genetic engineering.</li>\n</ul>\n</body>'}, {'topic': 'micro organisms and health', 'notes': '<body>\n<h1>Microorganisms and Health: A Simple Explanation</h1>\n<p>Microorganisms can have both beneficial and harmful effects on human health. Understanding these effects is essential for managing health and disease.</p>\n<h2>1. Beneficial Microorganisms</h2>\n<p>Some microorganisms contribute positively to human health:</p>\n<ul>\n<li><strong>Probiotics:</strong> Beneficial bacteria that support gut health by maintaining a healthy balance of microflora.</li>\n<li><strong>Fermentation:</strong> Microorganisms are used in the production of foods like yogurt, cheese, and sauerkraut, enhancing their nutritional value.</li>\n<li><strong>Vitamin Production:</strong> Certain gut bacteria produce essential vitamins such as B12 and K.</li>\n</ul>\n<h2>2. Harmful Microorganisms</h2>\n<p>Some microorganisms can cause diseases:</p>\n<ul>\n<li><strong>Bacteria:</strong> Pathogenic bacteria like Salmonella and Escherichia coli can cause infections and illnesses.</li>\n<li><strong>Viruses:</strong> Viruses such as influenza and HIV can lead to severe diseases and health complications.</li>\n<li><strong>Fungi:</strong> Some fungi can cause infections like athlete\'s foot and ringworm.</li>\n</ul>\n<h2>3. Preventing Infections</h2>\n<p>Good hygiene practices and vaccines can help prevent infections caused by harmful microorganisms:</p>\n<ul>\n<li><strong>Handwashing:</strong> Regular washing of hands helps remove pathogens.</li>\n<li><strong>Vaccination:</strong> Vaccines protect against viral and bacterial infections by priming the immune system to recognize and fight pathogens.</li>\n<li><strong>Food Safety:</strong> Proper handling, cooking, and storage of food can prevent the spread of harmful bacteria.</li>\n<li><strong>Antibiotics:</strong> These medications are used to treat bacterial infections but should be used responsibly to avoid antibiotic resistance.</li>\n</ul>\n<h2>4. Microbial Resistance</h2>\n<p>A growing concern in healthcare is the development of microbial resistance, where microorganisms evolve to become resistant to treatments:</p>\n<ul>\n<li><strong>Antibiotic Resistance:</strong> The overuse and misuse of antibiotics can lead to the development of "superbugs" that are resistant to current treatments.</li>\n<li><strong>Viral Mutations:</strong> Viruses, like the flu, can mutate rapidly, requiring new vaccines each year.</li>\n</ul>\n<h2>5. Conclusion</h2>\n<p>Microorganisms play a dual role in health, offering both benefits and risks. While beneficial microorganisms are essential for digestion, immunity, and food production, harmful microbes pose health risks. By understanding and managing these microbes through hygiene, vaccines, and antibiotics, we can mitigate the risks while maximizing the benefits.</p>\n</body>'},

{'topic': 'matter and separation techniques', 'notes': '<body>\n<h1>Matter and Separation Techniques</h1>\n<p>Matter is anything that has mass and occupies space. It exists in three main states: solid, liquid, and gas.</p>\n<h2>States of Matter</h2>\n<p><strong>Solid:</strong> Has a definite shape and volume.</p>\n<p><strong>Liquid:</strong> Has a definite volume but takes the shape of its container.</p>\n<p><strong>Gas:</strong> Has neither a definite shape nor volume, expanding to fill any container.</p>\n<h2>Separation Techniques</h2>\n<p>In chemistry, separating mixtures into their individual components is essential. Here are some common techniques:</p>\n<ul>\n<li><strong>Filtration:</strong> Used to separate insoluble solids from liquids.</li>\n<li><strong>Distillation:</strong> Used to separate liquids based on differences in boiling points.</li>\n<li><strong>Evaporation:</strong> Used to recover a solute from a solution by evaporating the solvent.</li>\n<li><strong>Chromatography:</strong> Used to separate components of a mixture based on their movement through a stationary phase.</li>\n</ul>\n</body>'}, {'topic': 'particulate nature of matter', 'notes': '<body>\n<h1>Particulate Nature of Matter</h1>\n<p>All matter is made up of tiny particles that are constantly in motion. These particles are atoms, molecules, or ions.</p>\n<h2>Key Concepts</h2>\n<ul>\n<li><strong>Atoms:</strong> The basic unit of an element, consisting of protons, neutrons, and electrons.</li>\n<li><strong>Molecules:</strong> Two or more atoms bonded together.</li>\n<li><strong>Ions:</strong> Charged particles formed when atoms gain or lose electrons.</li>\n</ul>\n<h2>Kinetic Theory of Matter</h2>\n<p>The kinetic theory explains the behavior of particles in different states of matter:</p>\n<ul>\n<li>In solids, particles are tightly packed and vibrate in fixed positions.</li>\n<li>In liquids, particles are close together but move freely.</li>\n<li>In gases, particles are far apart and move rapidly.</li>\n</ul>\n</body>'}, {'topic': 'basic chemistry', 'notes': '<body>\n<h1>Basic Chemistry</h1>\n<p><strong>Chemistry</strong> is the branch of science that deals with the properties, composition, and behavior of matter. It explores the way substances interact with each other and the changes they undergo during chemical reactions.</p>\n<h2>Branches of Chemistry</h2>\n<ul>\n<li><strong>Physical Chemistry:</strong> Deals with the physical properties and changes of matter.</li>\n<li><strong>Organic Chemistry:</strong> Focuses on compounds that contain carbon.</li>\n<li><strong>Inorganic Chemistry:</strong> Studies compounds that do not contain carbon.</li>\n<li><strong>Analytical Chemistry:</strong> Involves analyzing the composition of substances.</li>\n<li><strong>Biochemistry:</strong> Studies the chemical processes in living organisms.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> A water molecule (H₂O) is composed of two hydrogen atoms and one oxygen atom chemically bonded together.</p>\n</div>\n</body>'}, {'topic': 'chemical combinations', 'notes': '<body>\n<h1>Chemical Combinations</h1>\n<p><strong>Chemical combinations</strong> involve the bonding of atoms or molecules to form new compounds. These combinations occur based on the chemical properties of the elements involved and can result in different types of bonds.</p>\n<h2>Types of Chemical Bonds</h2>\n<ul>\n<li><strong>Ionic Bonding:</strong> Occurs when one atom donates an electron to another, creating positively and negatively charged ions.</li>\n<li><strong>Covalent Bonding:</strong> Involves the sharing of electrons between atoms to form molecules.</li>\n<li><strong>Metallic Bonding:</strong> Involves a "sea" of electrons that are free to move around, allowing metals to conduct electricity.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> Sodium (Na) and chlorine (Cl) combine to form sodium chloride (NaCl) through ionic bonding, where sodium loses an electron, and chlorine gains one.</p>\n</div>\n</body>'}, {'topic': 'properties of gases gas laws', 'notes': '<body>\n<h1>Properties of Gases and Gas Laws</h1>\n<p><strong>Gases</strong> are a state of matter characterized by their ability to expand and fill any container they occupy. The behavior of gases is explained by the gas laws, which describe the relationships between pressure, volume, and temperature.</p>\n<h2>Properties of Gases</h2>\n<ul>\n<li><strong>Compressibility:</strong> Gases can be compressed because the particles are far apart.</li>\n<li><strong>Expandability:</strong> Gases expand to fill any container.</li>\n<li><strong>Low Density:</strong> Gases have low density compared to solids and liquids.</li>\n</ul>\n<h2>Gas Laws</h2>\n<ul>\n<li><strong>Boyle\'s Law:</strong> The pressure of a gas is inversely proportional to its volume at constant temperature.</li>\n<li><strong>Charles\'s Law:</strong> The volume of a gas is directly proportional to its temperature at constant pressure.</li>\n<li><strong>Ideal Gas Law:</strong> Combines the relationships of pressure, volume, and temperature into one equation: \\( PV = nRT \\), where \\( R \\) is the gas constant.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> When you inflate a balloon, the gas inside expands to fill the balloon. If you squeeze the balloon, the gas inside compresses.</p>\n</div>\n</body>'}, {'topic': 'properties of solids and liquids', 'notes': '<body>\n<h1>Properties of Solids and Liquids</h1>\n<p><strong>Solids</strong> and <strong>liquids</strong> are two states of matter that have distinct physical properties based on the arrangement of their particles.</p>\n<h2>Properties of Solids</h2>\n<ul>\n<li><strong>Definite Shape:</strong> Solids have a fixed shape and volume.</li>\n<li><strong>Incompressibility:</strong> Solids cannot be easily compressed due to tightly packed particles.</li>\n<li><strong>High Density:</strong> Solids typically have a higher density than liquids and gases.</li>\n<li><strong>Rigidity:</strong> Solids resist forces that try to change their shape.</li>\n</ul>\n<h2>Properties of Liquids</h2>\n<ul>\n<li><strong>Indefinite Shape:</strong> Liquids take the shape of the container they occupy.</li>\n<li><strong>Fixed Volume:</strong> Liquids have a fixed volume but no fixed shape.</li>\n<li><strong>Moderate Compressibility:</strong> Liquids are less compressible than gases but more than solids.</li>\n<li><strong>Flowability:</strong> Liquids can flow and are described as having a viscosity, which measures resistance to flow.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> Ice (solid) retains its shape when placed on a surface, while water (liquid) flows to take the shape of its container.</p>\n</div>\n</body>'}, {'topic': 'acids bases and salts', 'notes': '<body>\n<h1>Acids Bases and Salts</h1>\n<p><strong>Acids, bases,</strong> and <strong>salts</strong> are three classes of compounds that have distinct properties and play important roles in chemical reactions.</p>\n<h2>Acids</h2>\n<ul>\n<li><strong>Properties:</strong> Sour taste, pH less than 7, turn blue litmus paper red.</li>\n<li><strong>Common Examples:</strong> Hydrochloric acid (HCl), sulfuric acid (H₂SO₄).</li>\n<li><strong>Reactions:</strong> React with metals to produce hydrogen gas and salts.</li>\n</ul>\n<h2>Bases</h2>\n<ul>\n<li><strong>Properties:</strong> Bitter taste, slippery feel, pH greater than 7, turn red litmus paper blue.</li>\n<li><strong>Common Examples:</strong> Sodium hydroxide (NaOH), potassium hydroxide (KOH).</li>\n<li><strong>Reactions:</strong> React with acids to form water and salts (neutralization).</li>\n</ul>\n<h2>Salts</h2>\n<ul>\n<li><strong>Formation:</strong> Formed by the reaction of an acid and a base (neutralization).</li>\n<li><strong>Common Examples:</strong> Sodium chloride (NaCl), potassium nitrate (KNO₃).</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> When hydrochloric acid (HCl) reacts with sodium hydroxide (NaOH), they form water (H₂O) and sodium chloride (NaCl).</p>\n</div>\n</body>'}, {'topic': 'periodic table', 'notes': '<body>\n<h1>Periodic Table</h1>\n<p>The <strong>Periodic Table</strong> is a chart that organizes all known elements based on their atomic number, electron configurations, and recurring chemical properties. It is one of the most important tools in chemistry.</p>\n<h2>Organization</h2>\n<ul>\n<li><strong>Groups:</strong> Vertical columns, elements in the same group have similar chemical properties.</li>\n<li><strong>Periods:</strong> Horizontal rows, properties of elements change progressively across a period.</li>\n<li><strong>Metals, Nonmetals, and Metalloids:</strong> The periodic table is divided into these categories based on an element’s properties.</li>\n</ul>\n<h2>Key Features</h2>\n<ul>\n<li><strong>Atomic Number:</strong> The number of protons in an atom\'s nucleus, increases across periods.</li>\n<li><strong>Groups:</strong> Elements in the same group have the same number of valence electrons.</li>\n<li><strong>Trends:</strong> Atomic size decreases across a period and increases down a group.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> Group 1 elements (alkali metals) like sodium (Na) and potassium (K) are highly reactive and form strong bases with water.</p>\n</div>\n</body>'}, {'topic': 'air and air pollution', 'notes': '<body>\n<h1>Air and Air Pollution</h1>\n<h2>Effects of Air Pollution (Continued)</h2>\n<ul>\n<li><strong>Global Warming:</strong> Greenhouse gases like CO₂ trap heat in the atmosphere, leading to climate change.</li>\n<li><strong>Health Problems:</strong> Pollutants can cause respiratory issues, heart disease, and other health complications.</li>\n<li><strong>Acid Rain:</strong> Sulfur dioxide (SO₂) and nitrogen oxides (NOₓ) combine with water vapor to form acidic compounds, which can damage ecosystems, buildings, and aquatic life.</li>\n<li><strong>Ozone Layer Depletion:</strong> Certain chemicals, like chlorofluorocarbons (CFCs), contribute to the depletion of the ozone layer, which protects the Earth from harmful UV radiation.</li>\n</ul>\n<h2>Solutions to Air Pollution</h2>\n<ul>\n<li><strong>Renewable Energy Sources:</strong> Switching to solar, wind, and other renewable energy sources can reduce reliance on fossil fuels.</li>\n<li><strong>Regulations:</strong> Governments can enforce strict air quality standards to limit industrial emissions.</li>\n<li><strong>Reforestation:</strong> Planting more trees helps absorb CO₂ and purify the air.</li>\n<li><strong>Public Awareness:</strong> Educating people on reducing carbon footprints and using cleaner transportation options like electric cars or public transit.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> The Clean Air Act in the United States has helped reduce air pollution by enforcing strict emissions limits on vehicles and industries.</p>\n</div>\n</body>'}, {'topic': 'water and solubility concept', 'notes': '<body>\n<h1>Water and Solubility Concept</h1>\n<p><strong>Water</strong> is known as the "universal solvent" because it can dissolve many substances. The solubility of a substance refers to the maximum amount of it that can dissolve in a solvent at a given temperature and pressure.</p>\n<h2>Properties of Water</h2>\n<ul>\n<li><strong>Polar Molecule:</strong> Water has a partial positive charge on hydrogen atoms and a partial negative charge on the oxygen atom, making it a polar molecule.</li>\n<li><strong>Hydrogen Bonding:</strong> Water molecules can form hydrogen bonds with each other and with other polar molecules, leading to high boiling points and surface tension.</li>\n</ul>\n<h2>Factors Affecting Solubility</h2>\n<ul>\n<li><strong>Temperature:</strong> Solubility generally increases with temperature for solids but decreases for gases.</li>\n<li><strong>Pressure:</strong> For gases, solubility increases with pressure.</li>\n<li><strong>Nature of Solvent and Solute:</strong> "Like dissolves like" — polar solvents dissolve polar solutes, while non-polar solvents dissolve non-polar solutes.</li>\n</ul>\n<h2>Saturation</h2>\n<ul>\n<li><strong>Unsaturated Solution:</strong> A solution that can still dissolve more solute.</li>\n<li><strong>Saturated Solution:</strong> A solution in which no more solute can dissolve at a given temperature and pressure.</li>\n<li><strong>Supersaturated Solution:</strong> A solution that contains more dissolved solute than it would normally hold at a certain temperature.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> When table salt (NaCl) is added to water, it dissolves because water is a polar solvent, and NaCl dissociates into Na⁺ and Cl⁻ ions.</p>\n</div>\n</body>'}, {'topic': 'mass volume concepts', 'notes': '<body>\n<h1>Mass Volume Concepts</h1>\n<p><strong>Mass</strong> is a measure of the amount of matter in an object, while <strong>volume</strong> refers to the amount of space the object occupies.</p>\n<h2>Mass</h2>\n<ul>\n<li><strong>Unit of Measurement:</strong> The standard unit of mass is the kilogram (kg).</li>\n<li><strong>Inertia:</strong> Mass is a measure of an object\'s inertia, or resistance to changes in its motion.</li>\n</ul>\n<h2>Volume</h2>\n<ul>\n<li><strong>Unit of Measurement:</strong> The standard unit of volume is the cubic meter (m³), though liters (L) are also commonly used for liquids.</li>\n<li><strong>Volume of Regular Shapes:</strong> For objects with regular shapes, volume can be calculated using formulas (e.g., Volume of a cube = side³).</li>\n<li><strong>Displacement Method:</strong> The volume of an irregular object can be measured by submerging it in water and measuring the displaced volume.</li>\n</ul>\n<h2>Density</h2>\n<p>Density is the mass of a substance per unit volume and is calculated using the formula:</p>\n<p><strong>Density = Mass / Volume</strong></p>\n<div class="example">\n<p><strong>Example 1:</strong> A block of aluminum has a mass of 270 g and occupies a volume of 100 cm³. The density of the aluminum is:</p>\n<p><strong>Density = 270 g / 100 cm³ = 2.7 g/cm³</strong></p>\n</div>\n</body>'}, {'topic': 'quantitative and qualitative analyses', 'notes': '<body>\n<h1>Quantitative and Qualitative Analyses</h1>\n<p>In chemistry, <strong>qualitative analysis</strong> refers to identifying the chemical components of a substance, while <strong>quantitative analysis</strong> involves determining the amount or concentration of these components.</p>\n<h2>Qualitative Analysis</h2>\n<ul>\n<li><strong>Purpose:</strong> To identify the presence of certain chemical elements or compounds.</li>\n<li><strong>Methods:</strong> Techniques include flame tests, precipitation reactions, and color changes. For example, a flame test can identify the presence of metal ions based on the color of the flame (e.g., sodium gives a yellow flame).</li>\n<li><strong>Indicators:</strong> Chemical indicators such as litmus paper or pH indicators can be used to identify the presence of acids or bases.</li>\n</ul>\n<h2>Quantitative Analysis</h2>\n<ul>\n<li><strong>Purpose:</strong> To determine the exact quantity of a substance or element in a mixture.</li>\n<li><strong>Gravimetric Analysis:</strong> Involves measuring the mass of a substance after it has been isolated in a pure form. For example, the mass of a precipitate formed in a chemical reaction can be measured to determine the concentration of an ion in a solution.</li>\n<li><strong>Volumetric Analysis (Titration):</strong> Involves using a solution of known concentration (titrant) to react with a solution of unknown concentration. The volume of titrant needed to complete the reaction helps determine the concentration of the unknown solution.</li>\n<li><strong>Spectrophotometry:</strong> Involves measuring the intensity of light absorbed by a sample at a specific wavelength to determine the concentration of a substance. This is often used for colorimetric analysis.</li>\n</ul>\n<h2>Applications of Quantitative and Qualitative Analysis</h2>\n<ul>\n<li><strong>Pharmaceuticals:</strong> Both types of analyses are used to ensure the correct composition and concentration of active ingredients in medicines.</li>\n<li><strong>Environmental Testing:</strong> Water and air quality assessments rely on these analyses to detect pollutants and their concentrations.</li>\n<li><strong>Food Industry:</strong> Quantitative analysis is crucial for determining nutritional content, such as the amount of fat, protein, or carbohydrates in food products.</li>\n</ul>\n<div class="example">\n<p><strong>Example 1:</strong> In a titration, 25.0 mL of HCl solution was neutralized by 30.0 mL of 0.1 M NaOH. The concentration of the HCl solution can be calculated using the equation:</p>\n<p><strong>NaOH + HCl → NaCl + H₂O</strong></p>\n<p>Using the formula:</p>\n<p><strong>M₁V₁ = M₂V₂</strong></p>\n<p>Where M₁ and V₁ are the molarity and volume of HCl, and M₂ and V₂ are the molarity and volume of NaOH.</p>\n<p><strong>M₁ = (M₂ × V₂) / V₁ = (0.1 M × 30.0 mL) / 25.0 mL = 0.12 M </strong></p>\n</div>\n</body>'},

{'topic': 'motion', 'notes': r'''<body>
    <h1>Motion: A Simple Explanation</h1>
    <p><strong>Motion</strong> refers to the change in position of an object with respect to time. It is described in terms of displacement, velocity, and acceleration.</p>

    <h2>1. Types of Motion</h2>
    <ul>
        <li><strong>Linear Motion:</strong> Movement in a straight line. Example: A car moving on a straight road.</li>
        <li><strong>Rotational Motion:</strong> Movement around an axis. Example: The Earth rotating on its axis.</li>
        <li><strong>Oscillatory Motion:</strong> Movement back and forth repeatedly. Example: A pendulum swinging.</li>
    </ul>

    <h2>2. Key Concepts</h2>
    <ul>
        <li><strong>Displacement:</strong> The change in position of an object. It is a vector quantity.</li>
        <li><strong>Velocity:</strong> The rate of change of displacement. It is a vector quantity and is calculated as \( v = \frac{dx}{dt} \).</li>
        <li><strong>Acceleration:</strong> The rate of change of velocity. It is also a vector quantity and is calculated as \( a = \frac{dv}{dt} \).</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A car travels 100 meters north in 10 seconds. Calculate its velocity.</p>
        <p>Using the formula \( v = \frac{d}{t} \):</p>
        <p>
            $$ v = \frac{100 \text{ meters}}{10 \text{ seconds}} = 10 \text{ m/s} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A ball accelerates from 0 to 20 m/s in 5 seconds. Calculate its acceleration.</p>
        <p>Using the formula \( a = \frac{v - u}{t} \):</p>
        <p>
            $$ a = \frac{20 \text{ m/s} - 0 \text{ m/s}}{5 \text{ seconds}} = 4 \text{ m/s}^2 $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'work energy and power', 'notes': r'''<body>
    <h1>Work, Energy, and Power: A Simple Explanation</h1>
    <p><strong>Work</strong>, <strong>Energy</strong>, and <strong>Power</strong> are fundamental concepts in physics related to the movement of objects.</p>

    <h2>1. Work</h2>
    <p>Work is done when a force causes an object to move in the direction of the force. It is calculated as:</p>
    <p>
        $$ W = F \times d \times \cos(\theta) $$
    </p>
    <p>where \( W \) is work, \( F \) is force, \( d \) is displacement, and \( \theta \) is the angle between the force and displacement.</p>

    <h2>2. Energy</h2>
    <p>Energy is the capacity to do work. It exists in various forms such as kinetic energy and potential energy.</p>
    <ul>
        <li><strong>Kinetic Energy:</strong> The energy of an object in motion. Calculated as:</li>
        <p>
            $$ E_k = \frac{1}{2} m v^2 $$
        </p>
        <li><strong>Potential Energy:</strong> The energy stored in an object due to its position. Calculated as:</li>
        <p>
            $$ E_p = mgh $$
        </p>
    </ul>

    <h2>3. Power</h2>
    <p>Power is the rate at which work is done or energy is transferred. It is calculated as:</p>
    <p>
        $$ P = \frac{W}{t} $$
    </p>
    <p>where \( P \) is power, \( W \) is work, and \( t \) is time.</p>

    <h2>4. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the work done when a force of 10 N moves an object 5 meters in the direction of the force.</p>
        <p>Using the formula:</p>
        <p>
            $$ W = 10 \text{ N} \times 5 \text{ meters} = 50 \text{ J} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A car of mass 1000 kg is moving at 20 m/s. Calculate its kinetic energy.</p>
        <p>Using the formula:</p>
        <p>
            $$ E_k = \frac{1}{2} \times 1000 \text{ kg} \times (20 \text{ m/s})^2 = 200{,}000 \text{ J} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'heat energy', 'notes': r'''<body>
    <h1>Heat Energy: A Simple Explanation</h1>
    <p><strong>Heat Energy</strong> is the energy transferred between objects due to a difference in temperature. It flows from a hotter object to a cooler one.</p>

    <h2>1. Specific Heat Capacity</h2>
    <p>Specific heat capacity is the amount of heat required to raise the temperature of 1 kilogram of a substance by 1 degree Celsius. It is calculated as:</p>
    <p>
        $$ Q = mc\Delta T $$
    </p>
    <p>where \( Q \) is the heat energy, \( m \) is the mass, \( c \) is the specific heat capacity, and \( \Delta T \) is the temperature change.</p>

    <h2>2. Heat Transfer Methods</h2>
    <ul>
        <li><strong>Conduction:</strong> Heat transfer through direct contact. Example: A metal spoon heating up in a hot cup of coffee.</li>
        <li><strong>Convection:</strong> Heat transfer through fluid movement. Example: Boiling water in a pot.</li>
        <li><strong>Radiation:</strong> Heat transfer through electromagnetic waves. Example: Feeling warmth from the sun.</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the heat energy required to raise the temperature of 2 kg of water by 10°C. The specific heat capacity of water is 4186 J/(kg·°C).</p>
        <p>Using the formula:</p>
        <p>
            $$ Q = 2 \text{ kg} \times 4186 \text{ J/(kg·°C)} \times 10 \text{°C} = 83{,}720 \text{ J} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A metal rod of mass 0.5 kg absorbs 5000 J of heat and its temperature increases by 10°C. Find its specific heat capacity.</p>
        <p>Rearranging the formula:</p>
        <p>
            $$ c = \frac{Q}{m \Delta T} = \frac{5000 \text{ J}}{0.5 \text{ kg} \times 10 \text{°C}} = 1000 \text{ J/(kg·°C)} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'electrical energy', 'notes': r'''<body>
    <h1>Electrical Energy: A Simple Explanation</h1>
    <p><strong>Electrical Energy</strong> is the energy associated with electric charges and their movement through a conductor.</p>

    <h2>1. Electrical Power</h2>
    <p>Electrical power is the rate at which electrical energy is transferred or converted. It is calculated as:</p>
    <p>
        $$ P = V \times I $$
    </p>
    <p>where \( P \) is power, \( V \) is voltage, and \( I \) is current.</p>

    <h2>2. Energy Consumption</h2>
    <p>The energy consumed by an electrical device is calculated using:</p>
    <p>
        $$ E = P \times t $$
    </p>
    <p>where \( E \) is energy, \( P \) is power, and \( t \) is time.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the power consumed by a light bulb with a voltage of 120 V and a current of 0.5 A.</p>
        <p>Using the formula:</p>
        <p>
            $$ P = 120 \text{ V} \times 0.5 \text{ A} = 60 \text{ W} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A heater with a power rating of 2000 W is used for 3 hours. Calculate the energy consumed.</p>
        <p>Using the formula:</p>
        <p>
            $$ E = 2000 \text{ W} \times 3 \text{ hours} = 6000 \text{ Wh} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'current electricity', 'notes': r'''<body>
    <h1>Current Electricity: A Simple Explanation</h1>
    <p><strong>Current Electricity</strong> refers to the flow of electric charge through a conductor.</p>

    <h2>1. Electric Current</h2>
    <p>Electric current is the rate of flow of electric charge. It is measured in amperes (A) and calculated as:</p>
    <p>
        $$ I = \frac{Q}{t} $$
    </p>
    <p>where \( I \) is current, \( Q \) is charge, and \( t \) is time.</p>

    <h2>2. Ohm's Law</h2>
    <p>Ohm's Law relates voltage (V), current (I), and resistance (R) in an electrical circuit. It is expressed as:</p>
    <p>
        $$ V = I \times R $$
    </p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the current flowing through a resistor of 10 ohms with a voltage of 5 V.</p>
        <p>Using Ohm's Law:</p>
        <p>
            $$ I = \frac{V}{R} = \frac{5 \text{ V}}{10 \text{ ohms}} = 0.5 \text{ A} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Calculate the voltage across a resistor if the current is 2 A and the resistance is 4 ohms.</p>
        <p>Using Ohm's Law:</p>
        <p>
            $$ V = I \times R = 2 \text{ A} \times 4 \text{ ohms} = 8 \text{ V} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'elastic properties of solid', 'notes': r'''<body>
    <h1>Elastic Properties of Solids: A Simple Explanation</h1>
    <p><strong>Elastic Properties</strong> refer to how a material deforms and returns to its original shape when forces are applied and then removed.</p>

    <h2>1. Hooke's Law</h2>
    <p>Hooke's Law states that the force required to extend or compress a spring is directly proportional to the displacement of the spring. It is given by:</p>
    <p>
        $$ F = k \times x $$
    </p>
    <p>where \( F \) is the force, \( k \) is the spring constant, and \( x \) is the displacement.</p>

    <h2>2. Young's Modulus</h2>
    <p>Young's Modulus measures the stiffness of a material. It is defined as the ratio of stress to strain:</p>
    <p>
        $$ E = \frac{\sigma}{\epsilon} $$
    </p>
    <p>where \( E \) is Young's Modulus, \( \sigma \) is stress, and \( \epsilon \) is strain.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A spring with a spring constant of 50 N/m is stretched by 0.1 meters. Calculate the force.</p>
        <p>Using Hooke's Law:</p>
        <p>
            $$ F = 50 \text{ N/m} \times 0.1 \text{ m} = 5 \text{ N} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A steel rod with a length of 2 meters and a cross-sectional area of 0.01 m² is subjected to a force of 1000 N. If the Young's Modulus of steel is \(2 \times 10^{11} \text{ N/m}^2\), calculate the strain.</p>
        <p>Using the formula for Young's Modulus:</p>
        <p>
            $$ \text{Stress} = \frac{F}{A} = \frac{1000 \text{ N}}{0.01 \text{ m}^2} = 10^5 \text{ N/m}^2 $$
        </p>
        <p>
            $$ \text{Strain} = \frac{\text{Stress}}{E} = \frac{10^5 \text{ N/m}^2}{2 \times 10^{11} \text{ N/m}^2} = 5 \times 10^{-7} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'vector', 'notes': r'''<body>
    <h1>Vector: A Simple Explanation</h1>
    <p><strong>Vector</strong> is a quantity that has both magnitude and direction. Unlike scalar quantities, vectors cannot be described by a single value alone.</p>

    <h2>1. Representing Vectors</h2>
    <p>Vectors are often represented graphically by arrows. The length of the arrow represents the magnitude, and the direction of the arrow represents the direction.</p>

    <h2>2. Vector Operations</h2>
    <ul>
        <li><strong>Addition:</strong> Vectors can be added using the head-to-tail method or by adding their components.</li>
        <li><strong>Subtraction:</strong> Subtracting a vector is equivalent to adding its negative.</li>
        <li><strong>Dot Product:</strong> The dot product of two vectors is calculated as:</li>
        <p>
            $$ \mathbf{A} \cdot \mathbf{B} = |\mathbf{A}| |\mathbf{B}| \cos(\theta) $$
        </p>
        <li><strong>Cross Product:</strong> The cross product of two vectors is calculated as:</li>
        <p>
            $$ \mathbf{A} \times \mathbf{B} = |\mathbf{A}| |\mathbf{B}| \sin(\theta) \mathbf{n} $$
        </p>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Given vectors \( \mathbf{A} = 3\hat{i} + 4\hat{j} \) and \( \mathbf{B} = 1\hat{i} - 2\hat{j} \), find their sum.</p>
        <p>Using vector addition:</p>
        <p>
            $$ \mathbf{A} + \mathbf{B} = (3\hat{i} + 4\hat{j}) + (1\hat{i} - 2\hat{j}) = 4\hat{i} + 2\hat{j} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Calculate the dot product of vectors \( \mathbf{A} = 2\hat{i} + 3\hat{j} \) and \( \mathbf{B} = 4\hat{i} - \hat{j} \).</p>
        <p>Using the dot product formula:</p>
        <p>
            $$ \mathbf{A} \cdot \mathbf{B} = (2 \times 4) + (3 \times (-1)) = 8 - 3 = 5 $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'projectiles', 'notes': r'''<body>
    <h1>Projectiles: A Simple Explanation</h1>
    <p><strong>Projectiles</strong> are objects that are thrown into the air with an initial velocity and are subject to gravity and air resistance. They follow a curved path called a trajectory.</p>

    <h2>1. Equations of Motion</h2>
    <p>For a projectile launched with an initial velocity \( v_0 \) at an angle \( \theta \), the equations of motion are:</p>
    <ul>
        <li><strong>Horizontal Range:</strong> \( R = \frac{v_0^2 \sin(2\theta)}{g} \)</li>
        <li><strong>Maximum Height:</strong> \( H = \frac{v_0^2 \sin^2(\theta)}{2g} \)</li>
        <li><strong>Time of Flight:</strong> \( T = \frac{2 v_0 \sin(\theta)}{g} \)</li>
    </ul>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A projectile is launched with an initial velocity of 20 m/s at an angle of 30°. Calculate the horizontal range.</p>
        <p>Using the range formula:</p>
        <p>
            $$ R = \frac{(20 \text{ m/s})^2 \sin(60^\circ)}{9.8 \text{ m/s}^2} \approx 40.8 \text{ meters} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Calculate the maximum height reached by the projectile.</p>
        <p>Using the height formula:</p>
        <p>
            $$ H = \frac{(20 \text{ m/s})^2 \sin^2(30^\circ)}{2 \times 9.8 \text{ m/s}^2} \approx 10.2 \text{ meters} $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'equilibrium of forces', 'notes': r'''<body>
    <h1>Equilibrium of Forces: A Simple Explanation</h1>
    <p><strong>Equilibrium of Forces</strong> occurs when all the forces acting on an object are balanced, resulting in no net force and no acceleration.</p>

    <h2>1. Types of Equilibrium</h2>
    <ul>
        <li><strong>Static Equilibrium:</strong> An object is at rest and remains at rest.</li>
        <li><strong>Dynamic Equilibrium:</strong> An object is moving with constant velocity.</li>
    </ul>

    <h2>2. Conditions for Equilibrium</h2>
    <ul>
        <li><strong>First Condition:</strong> The sum of all horizontal forces must be zero:</li>
        <p>
            $$ \sum F_x = 0 $$
        </p>
        <li><strong>Second Condition:</strong> The sum of all vertical forces must be zero:</li>
        <p>
            $$ \sum F_y = 0 $$
        </p>
        <li><strong>Third Condition:</strong> The sum of all torques (moments) about any point must be zero:</li>
        <p>
            $$ \sum \tau = 0 $$
        </p>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A block is on a horizontal table. The weight of the block is 10 N downward, and the normal force from the table is 10 N upward. Verify if the block is in equilibrium.</p>
        <p>Since the sum of the vertical forces is zero:</p>
        <p>
            $$ \sum F_y = 10 \text{ N (up)} - 10 \text{ N (down)} = 0 $$
        </p>
        <p>The block is in equilibrium.</p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A seesaw is balanced with two weights, 5 kg on one side and 10 kg on the other side, 2 meters from the pivot point. Find the distance required on the other side to balance the seesaw.</p>
        <p>Using the torque equilibrium condition:</p>
        <p>
            $$ (5 \text{ kg} \times 9.8 \text{ m/s}^2 \times 2 \text{ m}) = (10 \text{ kg} \times 9.8 \text{ m/s}^2 \times d) $$
        </p>
        <p>
            $$ d = \frac{5 \times 2}{10} = 1 \text{ meter} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'pressure in fluids', 'notes': r'''<body>
    <h1>Pressure in Fluids: A Simple Explanation</h1>
    <p><strong>Pressure in Fluids</strong> is the force per unit area exerted by a fluid (liquid or gas) on the walls of its container or on objects immersed in it.</p>

    <h2>1. Definition and Formula</h2>
    <p>Pressure \( P \) is defined as:</p>
    <p>
        $$ P = \frac{F}{A} $$
    </p>
    <p>where \( F \) is the force applied perpendicular to the surface and \( A \) is the area of the surface.</p>

    <h2>2. Pressure in Liquids</h2>
    <p>The pressure at a certain depth in a liquid is given by:</p>
    <p>
        $$ P = \rho g h $$
    </p>
    <p>where \( \rho \) is the density of the liquid, \( g \) is the acceleration due to gravity, and \( h \) is the height of the liquid column above the point where pressure is measured.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the pressure at a depth of 5 meters in water. Assume the density of water is \( 1000 \text{ kg/m}^3 \) and \( g = 9.8 \text{ m/s}^2 \).</p>
        <p>Using the pressure formula:</p>
        <p>
            $$ P = 1000 \text{ kg/m}^3 \times 9.8 \text{ m/s}^2 \times 5 \text{ m} = 49000 \text{ Pa} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A cylindrical tank has a base area of \( 2 \text{ m}^2 \) and a water column of height 10 meters. Calculate the force exerted by the water on the base of the tank.</p>
        <p>First, calculate the pressure:</p>
        <p>
            $$ P = 1000 \text{ kg/m}^3 \times 9.8 \text{ m/s}^2 \times 10 \text{ m} = 98000 \text{ Pa} $$
        </p>
        <p>Then, calculate the force:</p>
        <p>
            $$ F = P \times A = 98000 \text{ Pa} \times 2 \text{ m}^2 = 196000 \text{ N} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'simple harmonic motion', 'notes': r'''<body>
    <h1>Simple Harmonic Motion: A Simple Explanation</h1>
    <p><strong>Simple Harmonic Motion (SHM)</strong> is a type of periodic motion where the restoring force is directly proportional to the displacement from the equilibrium position.</p>

    <h2>1. Characteristics of SHM</h2>
    <ul>
        <li><strong>Restoring Force:</strong> The force that brings the object back to its equilibrium position is proportional to the displacement.</li>
        <li><strong>Period:</strong> The time taken to complete one cycle of motion.</li>
        <li><strong>Frequency:</strong> The number of cycles per second.</li>
    </ul>

    <h2>2. Mathematical Formulation</h2>
    <p>The equation of motion for SHM can be written as:</p>
    <p>
        $$ F = -kx $$
    </p>
    <p>where \( k \) is the force constant and \( x \) is the displacement from the equilibrium position.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A spring with a force constant \( k = 200 \text{ N/m} \) is stretched by \( 0.1 \text{ m} \). Find the restoring force.</p>
        <p>Using the formula:</p>
        <p>
            $$ F = -kx = -200 \text{ N/m} \times 0.1 \text{ m} = -20 \text{ N} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A pendulum of length 2 meters oscillates with a period of 2 seconds. Find the acceleration due to gravity.</p>
        <p>The period \( T \) of a simple pendulum is given by:</p>
        <p>
            $$ T = 2 \pi \sqrt{\frac{L}{g}} $$
        </p>
        <p>Solving for \( g \):</p>
        <p>
            $$ g = \frac{4 \pi^2 L}{T^2} = \frac{4 \pi^2 \times 2}{2^2} = 9.8 \text{ m/s}^2 $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'newtons laws of motion', 'notes': r'''<body>
    <h1>Newton's Laws of Motion: A Simple Explanation</h1>
    <p><strong>Newton's Laws of Motion</strong> are three fundamental principles that describe the relationship between the motion of an object and the forces acting on it.</p>

    <h2>1. Newton's First Law (Law of Inertia)</h2>
    <p>An object will remain at rest or in uniform motion unless acted upon by an external force.</p>

    <h2>2. Newton's Second Law</h2>
    <p>The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass:</p>
    <p>
        $$ F = ma $$
    </p>
    <p>where \( F \) is the net force, \( m \) is the mass, and \( a \) is the acceleration.</p>

    <h2>3. Newton's Third Law</h2>
    <p>For every action, there is an equal and opposite reaction.</p>

    <h2>4. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the force required to accelerate a 10 kg object at \( 2 \text{ m/s}^2 \).</p>
        <p>Using Newton's Second Law:</p>
        <p>
            $$ F = ma = 10 \text{ kg} \times 2 \text{ m/s}^2 = 20 \text{ N} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A car of mass 1000 kg experiences a force of 2000 N. What is its acceleration?</p>
        <p>Using Newton's Second Law:</p>
        <p>
            $$ a = \frac{F}{m} = \frac{2000 \text{ N}}{1000 \text{ kg}} = 2 \text{ m/s}^2 $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'machines', 'notes': r'''<body>
    <h1>Machines: A Simple Explanation</h1>
    <p><strong>Machines</strong> are devices that help us to do work by changing the direction or magnitude of a force.</p>

    <h2>1. Mechanical Advantage</h2>
    <p>Mechanical advantage is the ratio of the output force to the input force:</p>
    <p>
        $$ \text{MA} = \frac{F_{\text{out}}}{F_{\text{in}}} $$
    </p>

    <h2>2. Types of Machines</h2>
    <ul>
        <li><strong>Levers:</strong> A rigid bar that rotates around a fixed point.</li>
        <li><strong>Pulleys:</strong> Wheels with a groove for a rope or cable.</li>
        <li><strong>Inclined Planes:</strong> A flat surface tilted at an angle.</li>
        <li><strong>Wheels and Axles:</strong> A wheel attached to a smaller axle.</li>
        <li><strong>Gears:</strong> Wheels with teeth that interlock with other gears.</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A lever is used to lift a load of 100 N with an effort of 20 N. Calculate the mechanical advantage.</p>
        <p>Using the mechanical advantage formula:</p>
        <p>
            $$ \text{MA} = \frac{F_{\text{out}}}{F_{\text{in}}} = \frac{100 \text{ N}}{20 \text{ N}} = 5 $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A pulley system has an efficiency of 80%. If the input work is 500 J, find the useful output work.</p>
        <p>Using the efficiency formula:</p>
        <p>
            $$ \text{Efficiency} = \frac{\text{Useful Output Work}}{\text{Input Work}} \times 100\% $$
        </p>
        <p>Solving for the useful output work:</p>
        <p>
            $$ \text{Useful Output Work} = \text{Efficiency} \times \text{Input Work} = 0.80 \times 500 \text{ J} = 400 \text{ J} $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'heat energy measurement of temperature', 'notes': r'''<body>
    <h1>Heat Energy Measurement of Temperature: A Simple Explanation</h1>
    <p>Temperature is a measure of the average kinetic energy of particles in a substance. Heat energy is the total energy transferred between objects due to their temperature difference.</p>

    <h2>1. Temperature Scales</h2>
    <ul>
        <li><strong>Celsius:</strong> Water freezes at 0°C and boils at 100°C.</li>
        <li><strong>Fahrenheit:</strong> Water freezes at 32°F and boils at 212°F.</li>
        <li><strong>Kelvin:</strong> Absolute zero is 0 K; water freezes at 273.15 K and boils at 373.15 K.</li>
    </ul>

    <h2>2. Measuring Temperature</h2>
    <p>Temperature can be measured using thermometers, which come in various types:</p>
    <ul>
        <li><strong>Mercury Thermometers:</strong> Use mercury in a glass tube.</li>
        <li><strong>Digital Thermometers:</strong> Use electronic sensors.</li>
        <li><strong>Infrared Thermometers:</strong> Measure thermal radiation emitted by an object.</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Convert 25°C to Fahrenheit.</p>
        <p>Using the conversion formula:</p>
        <p>
            $$ F = \frac{9}{5}C + 32 $$
        </p>
        <p>Substituting \( C = 25 \):</p>
        <p>
            $$ F = \frac{9}{5} \times 25 + 32 = 77°F $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Convert 100°F to Celsius.</p>
        <p>Using the conversion formula:</p>
        <p>
            $$ C = \frac{5}{9}(F - 32) $$
        </p>
        <p>Substituting \( F = 100 \):</p>
        <p>
            $$ C = \frac{5}{9}(100 - 32) = 37.78°C $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'measurement of heat energy', 'notes': r'''<body>
    <h1>Measurement of Heat Energy: A Simple Explanation</h1>
    <p>Heat energy is measured in joules (J) and is the total energy transferred due to temperature differences.</p>

    <h2>1. Heat Capacity</h2>
    <p>Heat capacity is the amount of heat required to change the temperature of a substance by one degree Celsius:</p>
    <p>
        $$ Q = C \Delta T $$
    </p>
    <p>where \( Q \) is the heat energy, \( C \) is the heat capacity, and \( \Delta T \) is the change in temperature.</p>

    <h2>2. Specific Heat Capacity</h2>
    <p>Specific heat capacity is the heat required to raise the temperature of one kilogram of a substance by one degree Celsius:</p>
    <p>
        $$ Q = mc\Delta T $$
    </p>
    <p>where \( m \) is the mass, \( c \) is the specific heat capacity, and \( \Delta T \) is the change in temperature.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the heat required to raise the temperature of 2 kg of water from 20°C to 100°C. The specific heat capacity of water is \( 4184 \text{ J/kg°C} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ Q = mc\Delta T $$
        </p>
        <p>Substituting \( m = 2 \text{ kg} \), \( c = 4184 \text{ J/kg°C} \), and \( \Delta T = 80 \text{°C} \):</p>
        <p>
            $$ Q = 2 \times 4184 \times 80 = 669440 \text{ J} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A metal block with a mass of 0.5 kg absorbs 1500 J of heat and its temperature rises by 10°C. Find the specific heat capacity of the metal.</p>
        <p>Using the formula:</p>
        <p>
            $$ c = \frac{Q}{m \Delta T} $$
        </p>
        <p>Substituting \( Q = 1500 \text{ J} \), \( m = 0.5 \text{ kg} \), and \( \Delta T = 10 \text{°C} \):</p>
        <p>
            $$ c = \frac{1500}{0.5 \times 10} = 300 \text{ J/kg°C} $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'gas laws', 'notes': r'''<body>
    <h1>Gas Laws: A Simple Explanation</h1>
    <p>Gas laws describe the relationship between pressure, volume, and temperature of gases.</p>

    <h2>1. Boyle's Law</h2>
    <p>At constant temperature, the pressure of a gas is inversely proportional to its volume:</p>
    <p>
        $$ P \propto \frac{1}{V} $$
    </p>
    <p>Or, mathematically:</p>
    <p>
        $$ P_1 V_1 = P_2 V_2 $$
    </p>

    <h2>2. Charles's Law</h2>
    <p>At constant pressure, the volume of a gas is directly proportional to its absolute temperature:</p>
    <p>
        $$ V \propto T $$
    </p>
    <p>Or, mathematically:</p>
    <p>
        $$ \frac{V_1}{T_1} = \frac{V_2}{T_2} $$
    </p>

    <h2>3. Gay-Lussac's Law</h2>
    <p>At constant volume, the pressure of a gas is directly proportional to its absolute temperature:</p>
    <p>
        $$ P \propto T $$
    </p>
    <p>Or, mathematically:</p>
    <p>
        $$ \frac{P_1}{T_1} = \frac{P_2}{T_2} $$
    </p>

    <h2>4. Ideal Gas Law</h2>
    <p>The ideal gas law combines Boyle's, Charles's, and Gay-Lussac's laws:</p>
    <p>
        $$ PV = nRT $$
    </p>
    <p>where \( n \) is the number of moles and \( R \) is the ideal gas constant.</p>

    <h2>5. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A gas occupies 5 L at 2 atm. What will be its volume if the pressure is increased to 4 atm at constant temperature?</p>
        <p>Using Boyle's Law:</p>
        <p>
            $$ P_1 V_1 = P_2 V_2 $$
        </p>
        <p>Substituting \( P_1 = 2 \text{ atm} \), \( V_1 = 5 \text{ L} \), and \( P_2 = 4 \text{ atm} \):</p>
        <p>
            $$ 2 \times 5 = 4 \times V_2 $$
        </p>
        <p>Solving for \( V_2 \):</p>
        <p>
            $$ V_2 = \frac{2 \times 5}{4} = 2.5 \text{ L} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A gas has a volume of 300 mL at 27°C. What is its volume at 77°C if the pressure remains constant?</p>
        <p>Using Charles's Law:</p>
        <p>
            $$ \frac{V_1}{T_1} = \frac{V_2}{T_2} $$
        </p>
        <p>Substituting \( V_1 = 300 \text{ mL} \), \( T_1 = 27 + 273 = 300 \text{ K} \), and \( T_2 = 77 + 273 = 350 \text{ K} \):</p>
        <p>
            $$ \frac{300}{300} = \frac{V_2}{350} $$
        </p>
        <p>Solving for \( V_2 \):</p>
        <p>
            $$ V_2 = \frac{300 \times 350}{300} = 350 \text{ mL} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'reflection of light waves', 'notes': r'''<body>
    <h1>Reflection of Light Waves: A Simple Explanation</h1>
    <p>Reflection occurs when light waves bounce off a surface. It follows the law of reflection:</p>
    <p>
        $$ \text{Angle of Incidence} = \text{Angle of Reflection} $$
    </p>

    <h2>1. Types of Reflection</h2>
    <ul>
        <li><strong>Specular Reflection:</strong> Occurs on smooth surfaces like mirrors, where parallel rays of light reflect at the same angle.</li>
        <li><strong>Diffuse Reflection:</strong> Occurs on rough surfaces, scattering light in many directions.</li>
    </ul>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A light ray hits a mirror at an angle of 30°. What is the angle of reflection?</p>
        <p>According to the law of reflection:</p>
        <p>
            $$ \text{Angle of Reflection} = \text{Angle of Incidence} $$
        </p>
        <p>Therefore, the angle of reflection is:</p>
        <p>
            $$ \text{Angle of Reflection} = 30° $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> If a light ray is incident at 45° on a rough surface, how will the light be reflected?</p>
        <p>On a rough surface, the reflection will be diffuse, scattering light in many directions. The angle of incidence is still equal to the angle of reflection, but the reflected light will be spread out.</p>
    </div>
</body>'''}, 
 {'topic': 'waves', 'notes': r'''<body>
    <h1>Waves: A Simple Explanation</h1>
    <p>A wave is a disturbance that travels through a medium from one location to another. Waves transfer energy without transferring matter.</p>

    <h2>1. Types of Waves</h2>
    <ul>
        <li><strong>Mechanical Waves:</strong> Require a medium (e.g., sound waves, water waves).</li>
        <li><strong>Electromagnetic Waves:</strong> Do not require a medium (e.g., light waves, radio waves).</li>
    </ul>

    <h2>2. Properties of Waves</h2>
    <ul>
        <li><strong>Wavelength (λ):</strong> The distance between two consecutive crests or troughs.</li>
        <li><strong>Frequency (f):</strong> The number of waves passing a point per unit time.</li>
        <li><strong>Amplitude (A):</strong> The height of the wave crest or depth of the trough from the equilibrium position.</li>
        <li><strong>Speed (v):</strong> The speed at which the wave travels through the medium.</li>
    </ul>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> If a wave travels 100 meters in 10 seconds, what is its speed?</p>
        <p>Using the formula:</p>
        <p>
            $$ v = \frac{d}{t} $$
        </p>
        <p>Substituting \( d = 100 \text{ m} \) and \( t = 10 \text{ s} \):</p>
        <p>
            $$ v = \frac{100}{10} = 10 \text{ m/s} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A wave has a frequency of 5 Hz and a wavelength of 2 meters. What is its speed?</p>
        <p>Using the formula:</p>
        <p>
            $$ v = f \times \lambda $$
        </p>
        <p>Substituting \( f = 5 \text{ Hz} \) and \( \lambda = 2 \text{ m} \):</p>
        <p>
            $$ v = 5 \times 2 = 10 \text{ m/s} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'refraction of light waves at plane surfaces', 'notes': r'''<body>
    <h1>Refraction of Light Waves at Plane Surfaces: A Simple Explanation</h1>
    <p>Refraction occurs when light waves pass from one medium to another, causing a change in speed and direction.</p>

    <h2>1. Law of Refraction (Snell's Law)</h2>
    <p>Snell's Law relates the angles of incidence and refraction to the indices of refraction of the two media:</p>
    <p>
        $$ \frac{\sin \theta_1}{\sin \theta_2} = \frac{n_2}{n_1} $$
    </p>
    <p>where \( \theta_1 \) and \( \theta_2 \) are the angles of incidence and refraction, and \( n_1 \) and \( n_2 \) are the refractive indices of the first and second media, respectively.</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Light passes from air (n = 1.00) into water (n = 1.33) with an angle of incidence of 30°. What is the angle of refraction?</p>
        <p>Using Snell's Law:</p>
        <p>
            $$ \frac{\sin \theta_1}{\sin \theta_2} = \frac{n_2}{n_1} $$
        </p>
        <p>Substituting \( \theta_1 = 30° \), \( n_1 = 1.00 \), and \( n_2 = 1.33 \):</p>
        <p>
            $$ \sin \theta_2 = \frac{\sin 30°}{1.33} $$
        </p>
        <p>
            $$ \sin \theta_2 = \frac{0.5}{1.33} \approx 0.375 $$
        </p>
        <p>
            $$ \theta_2 \approx \sin^{-1}(0.375) \approx 22.2° $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> If light travels from water to glass (n = 1.50) and the angle of incidence is 45°, what is the angle of refraction?</p>
        <p>Using Snell's Law:</p>
        <p>
            $$ \frac{\sin \theta_1}{\sin \theta_2} = \frac{n_2}{n_1} $$
        </p>
        <p>Substituting \( \theta_1 = 45° \), \( n_1 = 1.33 \), and \( n_2 = 1.50 \):</p>
        <p>
            $$ \sin \theta_2 = \frac{\sin 45° \times 1.33}{1.50} $$
        </p>
        <p>
            $$ \sin \theta_2 = \frac{0.707 \times 1.33}{1.50} \approx 0.62 $$
        </p>
        <p>
            $$ \theta_2 \approx \sin^{-1}(0.62) \approx 38.3° $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'optical instruments', 'notes': r'''<body>
    <h1>Optical Instruments: A Simple Explanation</h1>
    <p>Optical instruments use lenses and mirrors to form images and magnify objects. Common optical instruments include microscopes, telescopes, and cameras.</p>

    <h2>1. Microscopes</h2>
    <p>Microscopes use multiple lenses to magnify small objects. The objective lens and the eyepiece lens work together to produce a magnified image:</p>
    <p>
        $$ M = M_o \times M_e $$
    </p>
    <p>where \( M \) is the total magnification, \( M_o \) is the magnification of the objective lens, and \( M_e \) is the magnification of the eyepiece lens.</p>

    <h2>2. Telescopes</h2>
    <p>Telescopes use lenses or mirrors to observe distant objects. They can be refracting (using lenses) or reflecting (using mirrors). The magnification is given by:</p>
    <p>
        $$ M = \frac{f_{t}}{f_{o}} $$
    </p>
    <p>where \( f_{t} \) is the focal length of the telescope and \( f_{o} \) is the focal length of the objective lens.</p>

    <h2>3. Cameras</h2>
    <p>Cameras capture images by focusing light through a lens onto a photographic film or digital sensor. The lens's focal length affects the image's size and clarity:</p>
    <p>
        $$ M = \frac{d_{i}}{d_{o}} $$
    </p>
    <p>where \( d_{i} \) is the image distance and \( d_{o} \) is the object distance.</p>

    <h2>4. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> A microscope has an objective lens with a magnification of 40x and an eyepiece lens with a magnification of 10x. What is the total magnification?</p>
        <p>Using the formula:</p>
        <p>
            $$ M = M_o \times M_e $$
        </p>
        <p>Substituting \( M_o = 40 \) and \( M_e = 10 \):</p>
        <p>
            $$ M = 40 \times 10 = 400x $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A telescope has a focal length of 1000 mm and an objective lens with a focal length of 50 mm. What is the magnification?</p>
        <p>Using the formula:</p>
        <p>
            $$ M = \frac{f_{t}}{f_{o}} $$
        </p>
        <p>Substituting \( f_{t} = 1000 \text{ mm} \) and \( f_{o} = 50 \text{ mm} \):</p>
        <p>
            $$ M = \frac{1000}{50} = 20x $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'propagation of sound waves', 'notes': r'''<body>
    <h1>Propagation of Sound Waves: A Simple Explanation</h1>
    <p>Sound waves are mechanical waves that propagate through a medium by causing particles in the medium to vibrate.</p>

    <h2>1. Speed of Sound</h2>
    <p>The speed of sound depends on the medium and its properties (e.g., temperature, density). The general formula for the speed of sound in air is:</p>
    <p>
        $$ v = \sqrt{\frac{\gamma \cdot R \cdot T}{M}} $$
    </p>
    <p>where \( \gamma \) is the adiabatic index, \( R \) is the gas constant, \( T \) is the temperature, and \( M \) is the molar mass of the gas.</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> If the speed of sound in air at 20°C is approximately 343 m/s, how long does it take for sound to travel 500 meters?</p>
        <p>Using the formula:</p>
        <p>
            $$ t = \frac{d}{v} $$
        </p>
        <p>Substituting \( d = 500 \text{ m} \) and \( v = 343 \text{ m/s} \):</p>
        <p>
            $$ t = \frac{500}{343} \approx 1.46 \text{ s} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> The speed of sound in water is approximately 1500 m/s. How far does sound travel in 2 seconds?</p>
        <p>Using the formula:</p>
        <p>
            $$ d = v \times t $$
        </p>
        <p>Substituting \( v = 1500 \text{ m/s} \) and \( t = 2 \text{ s} \):</p>
        <p>
            $$ d = 1500 \times 2 = 3000 \text{ m} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'gravitational field', 'notes': r'''<body>
    <h1>Gravitational Field: A Simple Explanation</h1>
    <p>A gravitational field is a region of space where a mass experiences a force due to the presence of another mass.</p>

    <h2>1. Gravitational Field Strength</h2>
    <p>The gravitational field strength \( g \) at a distance \( r \) from a point mass \( M \) is given by:</p>
    <p>
        $$ g = \frac{GM}{r^2} $$
    </p>
    <p>where \( G \) is the gravitational constant.</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> What is the gravitational field strength at the surface of the Earth (radius = 6.4 x 10^6 m) if the mass of the Earth is approximately 5.97 x 10^24 kg?</p>
        <p>Using the formula:</p>
        <p>
            $$ g = \frac{GM}{r^2} $$
        </p>
        <p>Substituting \( G = 6.67 \times 10^{-11} \text{ N m}^2/\text{kg}^2 \), \( M = 5.97 \times 10^{24} \text{ kg} \), and \( r = 6.4 \times 10^6 \text{ m} \):</p>
        <p>
            $$ g = \frac{6.67 \times 10^{-11} \times 5.97 \times 10^{24}}{(6.4 \times 10^6)^2} \approx 9.8 \text{ m/s}^2 $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> What is the gravitational field strength on the Moon, where the radius is about 1.74 x 10^6 m and the mass is 7.35 x 10^22 kg?</p>
        <p>Using the formula:</p>
        <p>
            $$ g = \frac{GM}{r^2} $$
        </p>
        <p>Substituting \( G = 6.67 \times 10^{-11} \text{ N m}^2/\text{kg}^2 \), \( M = 7.35 \times 10^{22} \text{ kg} \), and \( r = 1.74 \times 10^6 \text{ m} \):</p>
        <p>
            $$ g = \frac{6.67 \times 10^{-11} \times 7.35 \times 10^{22}}{(1.74 \times 10^6)^2} \approx 1.6 \text{ m/s}^2 $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'electric field charges', 'notes': r'''<body>
  <h1>Electric Field and Charges: A Simple Explanation</h1>
    <p>An electric field is a region where an electric charge experiences a force. It is created by other electric charges.</p>

    <h2>1. Electric Field Strength</h2>
    <p>The electric field strength \( E \) due to a point charge \( Q \) at a distance \( r \) is given by:</p>
    <p>
        $$ E = \frac{k \cdot Q}{r^2} $$
    </p>
    <p>where \( k \) is Coulomb's constant (\( 8.99 \times 10^9 \text{ N m}^2/\text{C}^2 \)).</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the electric field strength 2 meters away from a charge of \( 5 \times 10^{-6} \text{ C} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ E = \frac{k \cdot Q}{r^2} $$
        </p>
        <p>Substituting \( k = 8.99 \times 10^9 \text{ N m}^2/\text{C}^2 \), \( Q = 5 \times 10^{-6} \text{ C} \), and \( r = 2 \text{ m} \):</p>
        <p>
            $$ E = \frac{8.99 \times 10^9 \times 5 \times 10^{-6}}{2^2} = \frac{44.95 \times 10^3}{4} = 11.2375 \times 10^3 \text{ N/C} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Find the electric field strength 0.5 meters from a charge of \( 1 \times 10^{-8} \text{ C} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ E = \frac{k \cdot Q}{r^2} $$
        </p>
        <p>Substituting \( k = 8.99 \times 10^9 \text{ N m}^2/\text{C}^2 \), \( Q = 1 \times 10^{-8} \text{ C} \), and \( r = 0.5 \text{ m} \):</p>
        <p>
            $$ E = \frac{8.99 \times 10^9 \times 1 \times 10^{-8}}{0.5^2} = \frac{8.99 \times 10^1}{0.25} = 359.6 \text{ N/C} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'electric field current electricity', 'notes': r'''<body>
    <h1>Electric Field and Current Electricity: A Simple Explanation</h1>
    <p>Current electricity involves the flow of electric charge through a conductor. The electric field drives this flow.</p>

    <h2>1. Ohm's Law</h2>
    <p>Ohm's Law relates voltage \( V \), current \( I \), and resistance \( R \) in a circuit:</p>
    <p>
        $$ V = I \cdot R $$
    </p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> If a resistor of \( 10 \text{ Ω} \) has a current of \( 2 \text{ A} \) passing through it, what is the voltage across the resistor?</p>
        <p>Using Ohm's Law:</p>
        <p>
            $$ V = I \cdot R $$
        </p>
        <p>Substituting \( I = 2 \text{ A} \) and \( R = 10 \text{ Ω} \):</p>
        <p>
            $$ V = 2 \times 10 = 20 \text{ V} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> A circuit has a voltage of \( 12 \text{ V} \) and a resistance of \( 4 \text{ Ω} \). What is the current?</p>
        <p>Using Ohm's Law:</p>
        <p>
            $$ I = \frac{V}{R} $$
        </p>
        <p>Substituting \( V = 12 \text{ V} \) and \( R = 4 \text{ Ω} \):</p>
        <p>
            $$ I = \frac{12}{4} = 3 \text{ A} $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'magnetic field', 'notes': r'''<body>
    <h1>Magnetic Field: A Simple Explanation</h1>
    <p>A magnetic field is a field around a magnet or a current-carrying conductor where magnetic forces can be observed.</p>

    <h2>1. Magnetic Field Strength</h2>
    <p>The magnetic field strength \( B \) due to a current \( I \) in a long straight conductor at a distance \( r \) is given by:</p>
    <p>
        $$ B = \frac{\mu_0 \cdot I}{2 \pi r} $$
    </p>
    <p>where \( \mu_0 \) is the permeability of free space (\( 4 \pi \times 10^{-7} \text{ N/A}^2 \)).</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the magnetic field strength 0.1 meters away from a conductor carrying a current of \( 5 \text{ A} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ B = \frac{\mu_0 \cdot I}{2 \pi r} $$
        </p>
        <p>Substituting \( \mu_0 = 4 \pi \times 10^{-7} \text{ N/A}^2 \), \( I = 5 \text{ A} \), and \( r = 0.1 \text{ m} \):</p>
        <p>
            $$ B = \frac{4 \pi \times 10^{-7} \times 5}{2 \pi \times 0.1} = \frac{2 \times 10^{-6}}{0.2} = 1 \times 10^{-5} \text{ T} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> What is the magnetic field strength 1 meter from a conductor carrying a current of \( 10 \text{ A} \)?</p>
        <p>Using the formula:</p>
        <p>
            $$ B = \frac{\mu_0 \cdot I}{2 \pi r} $$
        </p>
        <p>Substituting \( \mu_0 = 4 \pi \times 10^{-7} \text{ N/A}^2 \), \( I = 10 \text{ A} \), and \( r = 1 \text{ m} \):</p>
        <p>
            $$ B = \frac{4 \pi \times 10^{-7} \times 10}{2 \pi \times 1} = 2 \times 10^{-6} \text{ T} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'simple alternating current circuits', 'notes': r'''<body>
    <h1>Simple Alternating Current Circuits: A Simple Explanation</h1>
    <p>Alternating current (AC) circuits involve currents that periodically reverse direction. The behavior of AC circuits can be analyzed using impedance and reactance.</p>

    <h2>1. Impedance</h2>
    <p>The impedance \( Z \) of an AC circuit containing a resistor \( R \), inductor \( L \), and capacitor \( C \) is given by:</p>
    <p>
        $$ Z = \sqrt{R^2 + (X_L - X_C)^2} $$
    </p>
    <p>where \( X_L = \omega L \) and \( X_C = \frac{1}{\omega C} \) are the inductive and capacitive reactances, respectively, and \( \omega \) is the angular frequency (\( \omega = 2 \pi f \)).</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the impedance of a circuit with \( R = 10 \text{ Ω} \), \( L = 0.1 \text{ H} \), and \( C = 100 \text{ μF} \) at a frequency of \( 50 \text{ Hz} \).</p>
        <p>First, calculate \( \omega \), \( X_L \), and \( X_C \):</p>
        <p>
            $$ \omega = 2 \pi f = 2 \pi \times 50 = 314.16 \text{ rad/s} $$
        </p>
        <p>
            $$ X_L = \omega L = 314.16 \times 0.1 = 31.42 \text{ Ω} $$
        </p>
        <p>
            $$ X_C = \frac{1}{\omega C} = \frac{1}{314.16 \times 100 \times 10^{-6}} = 31.42 \text{ Ω} $$
        </p>
        <p>
            $$ Z = \sqrt{10^2 + (31.42 - 31.42)^2} = 10 \text{ Ω} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> For a circuit with \( R = 5 \text{ Ω} \), \( L = 0.2 \text{ H} \), and \( C = 50 \text{ μF} \) at \( 60 \text{ Hz} \), find the impedance.</p>
        <p>First, calculate \( \omega \), \( X_L \), and \( X_C \):</p>
        <p>
            $$ \omega = 2 \pi f = 2 \pi \times 60 = 376.99 \text{ rad/s} $$
        </p>
        <p>
            $$ X_L = \omega L = 376.99 \times 0.2 = 75.40 \text{ Ω} $$
        </p>
        <p>
            $$ X_C = \frac{1}{\omega C} = \frac{1}{376.99 \times 50 \times 10^{-6}} = 10.61 \text{ Ω} $$
        </p>
        <p>
            $$ Z = \sqrt{5^2 + (75.40 - 10.61)^2} = \sqrt{25 + 4291.36} = \sqrt{4316.36} \approx 65.6 \text{ Ω} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'models of atoms and nuclear physics', 'notes': r'''<body>
    <h1>Models of Atoms and Nuclear Physics: A Simple Explanation</h1>
    <p>The atom is the basic unit of matter. Different models have been proposed to explain its structure.</p>

    <h2>1. Bohr's Model</h2>
    <p>In Bohr's model, electrons orbit the nucleus in fixed paths or orbits. The energy of an electron in an orbit is quantized.</p>

    <h2>2. Nuclear Physics</h2>
    <p>Nuclear physics studies the components and behavior of atomic nuclei. Key concepts include nuclear reactions and radioactivity.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the energy of an electron in the second orbit of a hydrogen atom using Bohr's model, where \( n = 2 \) and the energy in the first orbit is \( -13.6 \text{ eV} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ E_n = \frac{-13.6}{n^2} $$
        </p>
        <p>Substituting \( n = 2 \):</p>
        <p>
            $$ E_2 = \frac{-13.6}{2^2} = \frac{-13.6}{4} = -3.4 \text{ eV} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> If a nucleus undergoes alpha decay, it loses 2 protons and 2 neutrons. If the initial nucleus has a mass number of 200, what is the mass number of the new nucleus?</p>
        <p>Using the formula:</p>
        <p>
            $$ \text{New mass number} = \text{Initial mass number} - 4 $$
        </p>
        <p>Substituting initial mass number \( 200 \):</p>
        <p>
            $$ \text{New mass number} = 200 - 4 = 196 $$
        </p>
    </div>
</body>
'''}, 
 {'topic': 'energy quantitization', 'notes': r'''<body>
    <h1>Energy Quantization: A Simple Explanation</h1>
    <p>Energy quantization refers to the fact that energy levels in atoms and molecules are discrete, not continuous.</p>

    <h2>1. Quantized Energy Levels</h2>
    <p>In quantum mechanics, energy levels are quantized. For example, the energy of an electron in an atom is given by:</p>
    <p>
        $$ E_n = -\frac{13.6}{n^2} \text{ eV} $$
    </p>
    <p>where \( n \) is the principal quantum number.</p>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the energy difference between the first and second energy levels of a hydrogen atom.</p>
        <p>Using the formula for energy levels:</p>
        <p>
            $$ \Delta E = E_1 - E_2 $$
        </p>
        <p>Substituting \( E_1 = -13.6 \text{ eV} \) and \( E_2 = \frac{-13.6}{4} = -3.4 \text{ eV} \):</p>
        <p>
            $$ \Delta E = -13.6 - (-3.4) = -10.2 \text{ eV} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> What is the energy of the third energy level in a hydrogen atom?</p>
        <p>Using the formula:</p>
        <p>
            $$ E_n = -\frac{13.6}{n^2} \text{ eV} $$
        </p>
        <p>Substituting \( n = 3 \):</p>
        <p>
            $$ E_3 = \frac{-13.6}{3^2} = \frac{-13.6}{9} = -1.51 \text{ eV} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'electrical conduction through liquids and gases', 'notes': r'''<body>
    <h1>Electrical Conduction Through Liquids and Gases: A Simple Explanation</h1>
    <p>Electrical conduction in liquids and gases occurs when ions or charged particles move through the medium, carrying an electric current.</p>

    <h2>1. Conduction in Liquids</h2>
    <p>In liquids, electrical conduction is due to the movement of ions. Electrolytes are substances that dissolve in water to produce ions, which can conduct electricity.</p>

    <h2>2. Conduction in Gases</h2>
    <p>In gases, electrical conduction occurs when the gas is ionized. High voltage can ionize the gas, allowing it to conduct electricity.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the conductivity of a solution with a resistance of \( 10 \text{ Ω} \) and a cell constant of \( 1.5 \text{ cm}^{-1} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ \kappa = \frac{1}{R} \times \text{cell constant} $$
        </p>
        <p>Substituting \( R = 10 \text{ Ω} \) and cell constant \( 1.5 \text{ cm}^{-1} \):</p>
        <p>
            $$ \kappa = \frac{1}{10} \times 1.5 = 0.15 \text{ S/cm} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Determine the voltage required to ionize a gas with a breakdown voltage of \( 1000 \text{ V} \).</p>
        <p>Since the breakdown voltage is given directly:</p>
        <p>
            $$ V = 1000 \text{ V} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'fundamentals of electronics', 'notes': r'''<body>
    <h1>Fundamentals of Electronics: A Simple Explanation</h1>
    <p>Electronics involves the flow of electric charge through various components such as resistors, capacitors, and transistors.</p>

    <h2>1. Basic Components</h2>
    <p>Common electronic components include:</p>
    <ul>
        <li><strong>Resistors:</strong> Limit current flow.</li>
        <li><strong>Capacitors:</strong> Store and release electrical energy.</li>
        <li><strong>Transistors:</strong> Amplify or switch electronic signals.</li>
    </ul>

    <h2>2. Ohm's Law</h2>
    <p>Ohm's Law relates voltage (V), current (I), and resistance (R) in an electrical circuit:</p>
    <p>
        $$ V = I \times R $$
    </p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the total resistance of resistors in series with values \( 5 \text{Ω} \), \( 10 \text{Ω} \), and \( 15 \text{Ω} \).</p>
        <p>For resistors in series:</p>
        <p>
            $$ R_{total} = R_1 + R_2 + R_3 $$
        </p>
        <p>Substituting \( R_1 = 5 \text{ Ω} \), \( R_2 = 10 \text{ Ω} \), \( R_3 = 15 \text{ Ω} \):</p>
        <p>
            $$ R_{total} = 5 + 10 + 15 = 30 \text{Ω} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Using Ohm's Law, find the current flowing through a resistor of \( 10 \text{ Ω} \) with a voltage of \( 20 \text{ V} \).</p>
        <p>Using Ohm's Law:</p>
        <p>
            $$ I = \frac{V}{R} $$
        </p>
        <p>Substituting \( V = 20 \text{ V} \) and \( R = 10 \text{ Ω} \):</p>
        <p>
            $$ I = \frac{20}{10} = 2 \text{ A} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'electromagnetic field', 'notes': r'''<body>
    <h1>Electromagnetic Field: A Simple Explanation</h1>
    <p>An electromagnetic field consists of electric and magnetic fields that vary with time and are perpendicular to each other.</p>

    <h2>1. Maxwell's Equations</h2>
    <p>Maxwell's equations describe how electric and magnetic fields interact and propagate:</p>
    <ul>
        <li><strong>Gauss's Law:</strong> \( \nabla \cdot \mathbf{E} = \frac{\rho}{\epsilon_0} \)</li>
        <li><strong>Gauss's Law for Magnetism:</strong> \( \nabla \cdot \mathbf{B} = 0 \)</li>
        <li><strong>Faraday's Law:</strong> \( \nabla \times \mathbf{E} = -\frac{\partial \mathbf{B}}{\partial t} \)</li>
        <li><strong>Ampère's Law:</strong> \( \nabla \times \mathbf{B} = \mu_0 \mathbf{J} + \mu_0 \epsilon_0 \frac{\partial \mathbf{E}}{\partial t} \)</li>
    </ul>

    <h2>2. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the electric field \( \mathbf{E} \) due to a point charge \( Q = 5 \text{ μC} \) at a distance of \( 2 \text{ m} \).</p>
        <p>Using Coulomb's Law:</p>
        <p>
            $$ \mathbf{E} = \frac{1}{4 \pi \epsilon_0} \frac{Q}{r^2} $$
        </p>
        <p>Substituting \( Q = 5 \text{ μC} = 5 \times 10^{-6} \text{ C} \), \( r = 2 \text{ m} \), and \( \epsilon_0 = 8.85 \times 10^{-12} \text{ F/m} \):</p>
        <p>
            $$ \mathbf{E} = \frac{1}{4 \pi \times 8.85 \times 10^{-12}} \frac{5 \times 10^{-6}}{2^2} = 5.65 \times 10^5 \text{ N/C} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Determine the magnetic field \( \mathbf{B} \) inside a solenoid with \( N = 1000 \) turns, length \( l = 0.5 \text{ m} \), and current \( I = 2 \text{ A} \).</p>
        <p>Using the formula:</p>
        <p>
            $$ \mathbf{B} = \mu_0 \frac{N \cdot I}{l} $$
        </p>
        <p>Substituting \( \mu_0 = 4 \pi \times 10^{-7} \text{ N/A}^2 \), \( N = 1000 \), \( I = 2 \text{ A} \), and \( l = 0.5 \text{ m} \):</p>
        <p>
            $$ \mathbf{B} = 4 \pi \times 10^{-7} \frac{1000 \times 2}{0.5} = 8 \times 10^{-2} \text{ T} $$
        </p>
    </div>
</body>'''}, 
 {'topic': 'fluids at rest and in motion',
'notes': r'''<body>
    <h1>Fluids at Rest and in Motion: A Simple Explanation</h1>
    <p>Fluid mechanics is the study of fluids (liquids and gases) and their behavior at rest (hydrostatics) and in motion (dynamics).</p>

    <h2>1. Fluids at Rest (Hydrostatics)</h2>
    <p>In a fluid at rest, the pressure at any point is the same in all directions. This is described by Pascal's principle and can be calculated using:</p>
    <p>
        $$ P = \rho g h $$
    </p>
    <p>where \( \rho \) is the fluid density, \( g \) is the acceleration due to gravity, and \( h \) is the height of the fluid column.</p>

    <h2>2. Fluids in Motion (Dynamics)</h2>
    <p>For fluids in motion, the flow can be described using Bernoulli's equation:</p>
    <p>
        $$ P + \frac{1}{2} \rho v^2 + \rho gh = \text{constant} $$
    </p>
    <p>where \( v \) is the velocity of the fluid.</p>

    <h2>3. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the pressure at a depth of \( 10 \text{ m} \) in water (density \( 1000 \text{ kg/m}^3 \)).</p>
        <p>Using the formula:</p>
        <p>
            $$ P = \rho g h $$
        </p>
        <p>Substituting \( \rho = 1000 \text{ kg/m}^3 \), \( g = 9.8 \text{ m/s}^2 \), and \( h = 10 \text{ m} \):</p>
        <p>
            $$ P = 1000 \times 9.8 \times 10 = 98,000 \text{ Pa} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Determine the velocity of water exiting a hole at the bottom of a tank if the water level is \( 20 \text{ m} \) above the hole.</p>
        <p>Using Torricelli's theorem:</p>
        <p>
            $$ v = \sqrt{2gh} $$
        </p>
        <p>Substituting \( g = 9.8 \text{ m/s}^2 \) and \( h = 20 \text{ m} \):</p>
        <p>
            $$ v = \sqrt{2 \times 9.8 \times 20} = 19.8 \text{ m/s} $$
        </p>
    </div>
</body>'''}, {'topic': 'application of light waves', 'notes': r'''<body>
    <h1>Application of Light Waves: A Simple Explanation</h1>
    <p>Light waves have various applications in science and technology, including optics, communication, and medical imaging.</p>

    <h2>1. Optics</h2>
    <p>Optics deals with the behavior of light and its interactions with lenses, mirrors, and other optical devices. For example, magnifying glasses use lenses to focus light and magnify objects.</p>

    <h2>2. Communication</h2>
    <p>Fiber optic cables use light waves to transmit data over long distances with high speed and low loss. The principle of total internal reflection allows light to travel through the fiber without escaping.</p>

    <h2>3. Medical Imaging</h2>
    <p>Light waves are used in techniques such as endoscopy to view the inside of the body. These methods use light to capture images of internal organs and tissues.</p>

    <h2>4. Examples</h2>

    <div class="example">
        <p><strong>Example 1:</strong> Calculate the wavelength of light with a frequency of \( 5 \times 10^{14} \text{ Hz} \) in a vacuum.</p>
        <p>Using the formula:</p>
        <p>
            $$ \lambda = \frac{c}{f} $$
        </p>
        <p>where \( c = 3 \times 10^8 \text{ m/s} \) and \( f = 5 \times 10^{14} \text{ Hz} \):</p>
        <p>
            $$ \lambda = \frac{3 \times 10^8}{5 \times 10^{14}} = 6 \times 10^{-7} \text{ m} = 600 \text{ nm} $$
        </p>
    </div>

    <div class="example">
        <p><strong>Example 2:</strong> Determine the critical angle for light traveling from glass (refractive index \( n = 1.5 \)) into air (refractive index \( n = 1 \)).</p>
        <p>Using Snell's law:</p>
        <p>
            $$ \sin \theta_c = \frac{n_2}{n_1} $$
        </p>
        <p>Substituting \( n_1 = 1.5 \) and \( n_2 = 1 \):</p>
        <p>
            $$ \sin \theta_c = \frac{1}{1.5} = 0.667 $$
        </p>
        <p>
            $$ \theta_c = \sin^{-1}(0.667) \approx 41.8^\circ $$
        </p>
    </div>
</body>'''}

]