from django.apps import AppConfig


class PracsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pracs'

def ready(self):
    import pracs.signals