
# from reportlab.lib.pagesizes import letter
# from reportlab.lib import colors
# from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph
# from reportlab.lib.styles import getSampleStyleSheet
# from io import BytesIO


# def generate_pdf(first_name, last_name, article_content):
#     buffer = BytesIO()
#     width, height = letter

#     # Define the watermark function with personalized text
#     def add_watermark(canvas, doc):
#         watermark_text = f"This PDF belongs to {first_name} {last_name}"
#         canvas.saveState()
#         canvas.setFont("Helvetica", 30)  # Adjust font size if needed
#         canvas.setFillColor(colors.lightgrey)
#         canvas.translate(width / 2, height / 2)
#         canvas.rotate(45)
#         canvas.drawCentredString(0, 0, watermark_text)  # Centered watermark text
#         canvas.restoreState()

#     # Set up the document template with watermark on every page
#     doc = BaseDocTemplate(buffer, pagesize=letter)

#     # Define a frame for the content (leaving space for margins)
#     frame = Frame(50, 50, width - 100, height - 100, id='normal')

#     # Define a PageTemplate with the watermark function
#     template = PageTemplate(id='watermarked', frames=[frame], onPage=add_watermark)
#     doc.addPageTemplates([template])

#     # Prepare content for the PDF (long article broken into paragraphs)
#     styles = getSampleStyleSheet()
#     content = []
#     # Split by paragraphs
#     content.append(Paragraph([['a'], ['b'], ['body']], styles['BodyText']))

#     # Build the document with content and watermark on every page
#     doc.build(content)
#     buffer.seek(0)
#     return buffer
