from django import template
register = template.Library()
import random
from pracs.lessons import quiz
import re, ast
from datetime import datetime,timedelta
from django.utils import timezone
from pracs.models import Pinbin, User, League, Questions


translations = [
    {"id": "CHANGE VALUES", "en": "CHANGE VALUES", "esp": "CAMBIAR VALORES", "it": "CAMBIA VALORI", "fr": "CHANGER LES VALEURS", "hau": "CHANGE VALUES", "igb": "CHANGE VALUES", "yor": "CHANGE VALUES", "pid": "CHANGE VALUES"},
    {"id": "Change exactly the way the questions is", "en": "Change exactly the way the questions is", "esp": "Cambia exactamente la forma en que están las preguntas", "it": "Cambia esattamente il modo in cui sono le domande", "fr": "Changez exactement la manière dont sont les questions", "hau": "Canza daidai yadda tambayoyin suke", "igb": "Chọọ ụzọ ajụjụ si dị kpọmkwem", "yor": "Yi iyipada ni ọna ti awọn ibeere wa", "pid": "Change exactly the way the questions is"},
    {"id": "In the question", "en": "In the question", "esp": "En la pregunta", "it": "Nella domanda", "fr": "Dans la question", "hau": "A cikin tambayar", "igb": "Na ajụjụ", "yor": "Ninu ibeere", "pid": "For di question"},
    {"id": "the answer was", "en": "the answer was", "esp": "la respuesta fue", "it": "la risposta era", "fr": "la réponse était", "hau": "amsar ita ce", "igb": "azịza bụ", "yor": "idahun ni", "pid": "di answer na"},
    {"id": "In your values...", "en": "In your values...", "esp": "En tus valores...", "it": "Nei tuoi valori...", "fr": "Dans vos valeurs...", "hau": "A cikin dabi'un ku...", "igb": "N'ime ụkpụrụ gị...", "yor": "Ninu awọn iye rẹ...", "pid": "Inside your values..."},
    {"id": "You changed from", "en": "You changed from", "esp": "Cambiastes de", "it": "Hai cambiato da", "fr": "Vous avez changé de", "hau": "Kun canza daga", "igb": "Ị gbanwere site na", "yor": "O yi pada lati", "pid": "You don change from"},
    {"id": "to", "en": "to", "esp": "a", "it": "a", "fr": "à", "hau": "zuwa", "igb": "gaa", "yor": "si", "pid": "to"},
    {"id": "Your answer is", "en": "Your answer is", "esp": "Tu respuesta es", "it": "La tua risposta è", "fr": "Votre réponse est", "hau": "Amsar ku itace", "igb": "Azịza gị bụ", "yor": "Idahun rẹ jẹ", "pid": "Your answer na"},

    {"id": "CALIXGURU PRICINGS", "en": "CALIXGURU PRICINGS", "esp": "PRECIOS DE CALIXGURU", "it": "PREZZI CALIXGURU", "fr": "PRIX CALIXGURU", "hau": "CALIXGURU PRICES", "igb": "Ụdị ọnụahịa CALIXGURU", "yor": "ỌRỌ CALIXGURU", "pid": "CALIXGURU PRICINGS"},
    {"id": "Pay To: ", "en": "Pay To: ", "esp": "Pagar a: ", "it": "Paga a: ", "fr": "Payer à: ", "hau": "Biya zuwa: ", "igb": "Payị gaa: ", "yor": "Sanwo si: ", "pid": "Pay To: "},
    {"id": "Copy Account Number", "en": "Copy Account Number", "esp": "Copiar número de cuenta", "it": "Copia numero di conto", "fr": "Copier le numéro de compte", "hau": "Kwafi Lambar Asusun", "igb": "Detuo nọmba akaụntụ", "yor": "Daakọ Nọmba Iṣowo", "pid": "Copy Account Number"},
    {"id": "Daily", "en": "Daily", "esp": "Diario", "it": "Giornaliero", "fr": "Quotidien", "hau": "Kullum", "igb": "Kwa ụbọchị", "yor": "Ojoojumọ", "pid": "Daily"},
    {"id": "Deactivates 2 days after activation", "en": "Deactivates 2 days after activation", "esp": "Se desactiva 2 días después de la activación", "it": "Si disattiva 2 giorni dopo l'attivazione", "fr": "Se désactive 2 jours après l'activation", "hau": "Zai daina aiki kwanaki 2 bayan kunna shi", "igb": "Na-anwụ anwụ ụbọchị 2 mgbe mmega ahụ", "yor": "Yọkúrò ni ọjọ 2 lẹhin ìmúlòlù", "pid": "Deactivates 2 days after activation"},
    {"id": "Weekly", "en": "Weekly", "esp": "Semanal", "it": "Settimanale", "fr": "Hebdomadaire", "hau": "Kullum", "igb": "Kwa izu", "yor": "Sẹẹsẹ", "pid": "Weekly"},
    {"id": "Deactivates 8 days after activation", "en": "Deactivates 8 days after activation", "esp": "Se desactiva 8 días después de la activación", "it": "Si disattiva 8 giorni dopo l'attivazione", "fr": "Se désactive 8 jours après l'activation", "hau": "Zai daina aiki kwanaki 8 bayan kunna shi", "igb": "Na-anwụ anwụ ụbọchị 8 mgbe mmega ahụ", "yor": "Yọkúrò ni ọjọ 8 lẹhin ìmúlòlù", "pid": "Deactivates 8 days after activation"},
    {"id": "Monthly", "en": "Monthly", "esp": "Mensual", "it": "Mensile", "fr": "Mensuel", "hau": "Watan", "igb": "Kwa ọnwa", "yor": "Oṣooṣoo", "pid": "Monthly"},
    {"id": "Deactivates 32 days after activation", "en": "Deactivates 32 days after activation", "esp": "Se desactiva 32 días después de la activación", "it": "Si disattiva 32 giorni dopo l'attivazione", "fr": "Se désactive 32 jours après l'activation", "hau": "Zai daina aiki kwanaki 32 bayan kunna shi", "igb": "Na-anwụ anwụ ụbọchị 32 mgbe mmega ahụ", "yor": "Yọkúrò ni ọjọ 32 lẹhin ìmúlòlù", "pid": "Deactivates 32 days after activation"},
    {"id": "You will show proof of payment to our vendors to be activated for a day", "en": "You will show proof of payment to our vendors to be activated for a day", "esp": "Deberás mostrar prueba de pago a nuestros proveedores para ser activado por un día", "it": "Mostrerai prova di pagamento ai nostri fornitori per essere attivato per un giorno", "fr": "Vous montrerez une preuve de paiement à nos fournisseurs pour être activé pour un jour", "hau": "Za ku nuna shaida ta biyan kuɗi ga masu siyar da mu don a kunna ku na rana ɗaya", "igb": "Ị ga-egosipụta ihe akaebe nke ịkwụ ụgwọ na ndị na-eweta anyị ka a mepụta gị ụbọchị otu", "yor": "Iwọ yoo fihan ẹri isanwo si awọn alagbata wa lati ṣiṣẹ fun ọjọ kan", "pid": "You go show proof of payment to our vendors to be activated for a day"},
    {"id": "Cancel", "en": "Cancel", "esp": "Cancelar", "it": "Annulla", "fr": "Annuler", "hau": "Soke", "igb": "Kansela", "yor": "Fagilee", "pid": "Cancel"},

    {"id": "CHANGE VALUES", "en": "CHANGE VALUES", "esp": "CAMBIAR VALORES", "it": "CAMBIA VALORI", "fr": "CHANGER LES VALEURS", "hau": "CHANGE VALUES", "igb": "CHANGE VALUES", "yor": "CHANGE VALUES", "pid": "CHANGE VALUES"},
    {"id": "Change exactly the way the question is", "en": "Change exactly the way the question is", "esp": "Cambia exactamente la forma en que está la pregunta", "it": "Cambia esattamente il modo in cui è la domanda", "fr": "Changez exactement la manière dont est la question", "hau": "Canza daidai yadda tambayar take", "igb": "Gbanwee nke ọma otú ajụjụ ahụ dị", "yor": "Yi iyipada ni ọna ti ibeere naa", "pid": "Change exactly the way the question is"},
    {"id": "The question is...", "en": "The question is...", "esp": "La pregunta es...", "it": "La domanda è...", "fr": "La question est...", "hau": "Tambayar ita ce...", "igb": "Ajụjụ bụ...", "yor": "Ibeere naa ni...", "pid": "The question na..."},
    {"id": "The answer is", "en": "The answer is", "esp": "La respuesta es", "it": "La risposta è", "fr": "La réponse est", "hau": "Amsar ita ce", "igb": "Azịza bụ", "yor": "Idahun ni", "pid": "The answer na"},
    {"id": "Instead of", "en": "Instead of", "esp": "En lugar de", "it": "Invece di", "fr": "Au lieu de", "hau": "Maimakon", "igb": "N'ịbụ", "yor": "Dipo", "pid": "Instead of"},
    {"id": "SEE ANSWER", "en": "SEE ANSWER", "esp": "VER RESPUESTA", "it": "VEDI RISPOSTA", "fr": "VOIR LA RÉPONSE", "hau": "DUBA AMSA", "igb": "LEE AZỊZA", "yor": "WO IDAHUN", "pid": "SEE ANSWER"},

    {"id": "WORKING SHEET", "en": "WORKING SHEET", "esp": "HOJA DE TRABAJO", "it": "FOGLIO DI LAVORO", "fr": "FEUILLE DE TRAVAIL", "hau": "WORKING SHEET", "igb": "WORKING SHEET", "yor": "WORKING SHEET", "pid": "WORKING SHEET"},
    {"id": "How many decimal places do you want for your calculations", "en": "How many decimal places do you want for your calculations", "esp": "Cuántos lugares decimales quieres para tus cálculos", "it": "Quante cifre decimali vuoi per i tuoi calcoli", "fr": "Combien de décimales souhaitez-vous pour vos calculs", "hau": "Nawa yawan wuraren kidaya kake so don lissafin ka", "igb": "Ego ole ọnụ decimal ị chọrọ maka mgbakọ gị", "yor": "Iye iye awọn ipo iyatọ wo ni o fẹ fun awọn iṣiro rẹ", "pid": "How many decimal places you dey find for your calculations"},
    {"id": "Enter decimal places", "en": "Enter decimal places", "esp": "Ingrese lugares decimales", "it": "Inserisci i decimali", "fr": "Entrez les décimales", "hau": "Shigar da wuraren kidaya", "igb": "Tinye ebe decimal", "yor": "Tẹ awọn ipo iyatọ", "pid": "Enter decimal places"},
    {"id": "Your values of Column", "en": "Your values of Column", "esp": "Tus valores de la columna", "it": "I tuoi valori della colonna", "fr": "Vos valeurs de la colonne", "hau": "Kimar da column", "igb": "Ụzọ gị nke Column", "yor": "Awọn iye rẹ ti Column", "pid": "Your values of Column"},
    {"id": "value", "en": "value", "esp": "valor", "it": "valore", "fr": "valeur", "hau": "kimar", "igb": "ụzọ", "yor": "iye", "pid": "value"},
    {"id": "Okay now time to carefully input formulars for the remaining columns that you said will need formulars", "en": "Okay now time to carefully input formulars for the remaining columns that you said will need formulars", "esp": "Ahora es el momento de ingresar cuidadosamente las fórmulas para las columnas restantes que dijiste necesitarán fórmulas", "it": "Ora è il momento di inserire attentamente le formule per le colonne rimanenti che hai detto necessiteranno di formule", "fr": "Maintenant, il est temps de saisir soigneusement les formules pour les colonnes restantes que vous avez dit qu'elles nécessiteraient des formules", "hau": "To lokaci ne yanzu don shigar da duba cikin hankali don sauran columns da ka ce za su buƙaci formulars", "igb": "Ugbu a, oge ịtinye na-enweghị ntụpọ na ụdị maka ndị ọ bụla fọdụrụ nke ị kwubiri na ha ga-achọ formulars", "yor": "Bayi akoko ni lati fi awọn formulars sinu daradara fun awọn ọwọn ti o ku ti o sọ pe yoo nilo formulars", "pid": "Oya put formulars for the remaining columns wer yo talk say go need formulars"},
    {"id": "Column", "en": "Column", "esp": "Columna", "it": "Colonna", "fr": "Colonne", "hau": "Column", "igb": "Column", "yor": "Column", "pid": "Column"},
    {"id": "Formular", "en": "Formular", "esp": "Fórmula", "it": "Formula", "fr": "Formule", "hau": "Formular", "igb": "Formula", "yor": "Fọọmu", "pid": "Formular"},
    {"id": "If your table will need a graph, select the Y (vertical), X (horizontal) axis and type of plot you need respectively", "en": "If your table will need a graph, select the Y (vertical), X (horizontal) axis and type of plot you need respectively", "esp": "Si tu tabla necesita un gráfico, selecciona el eje Y (vertical), el eje X (horizontal) y el tipo de gráfico que necesitas respectivamente", "it": "Se la tua tabella necessita di un grafico, seleziona l'asse Y (verticale), l'asse X (orizzontale) e il tipo di grafico di cui hai bisogno", "fr": "Si votre tableau nécessite un graphique, sélectionnez l'axe Y (vertical), l'axe X (horizontal) et le type de graphique dont vous avez besoin", "hau": "Idan teburinka zai buƙaci hoto, zaɓi Y (sabon), X (horizontali) axis da nau'in jigon da kake buƙata", "igb": "Ọ bụrụ na tebụl gị chọrọ eserese, họrọ Y (ụdị) axis, X (dị) axis na ụdị eserese ị chọrọ", "yor": "Ti tabili rẹ ba nilo aworan, yan Y (ẹ̀yà), X (akọtọ) axis ati iru aworan ti o nilo", "pid": "If your table go need graph, select the Y (vertical), X (horizontal) axis and the kind plot you dey find"},
    {"id": "Y (vertical) axis", "en": "Y (vertical) axis", "esp": "Eje Y (vertical)", "it": "Asse Y (verticale)", "fr": "Axe Y (vertical)", "hau": "Y (sabon) axis", "igb": "Y (ụdị) axis", "yor": "Y (ẹ̀yà) axis", "pid": "Y (vertical) axis"},
    {"id": "X (horizontal) axis", "en": "X (horizontal) axis", "esp": "Eje X (horizontal)", "it": "Asse X (orizzontale)", "fr": "Axe X (horizontal)", "hau": "X (horizontali) axis", "igb": "X (dị) axis", "yor": "X (akọtọ) axis", "pid": "X (horizontal) axis"},
    {"id": "Type of plot", "en": "Type of plot", "esp": "Tipo de gráfico", "it": "Tipo di grafico", "fr": "Type de graphique", "hau": "Nau'in shahararrar", "igb": "Ụdị eserese", "yor": "Iru aworan", "pid": "Type of plot"},
    {"id": "Straight Line graph", "en": "Straight Line graph", "esp": "Gráfico de línea recta", "it": "Grafico a linea retta", "fr": "Graphique à ligne droite", "hau": "Hoto na layi kai tsaye", "igb": "Eserese ahịrị ziri ezi", "yor": "Aworan laini taara", "pid": "Straight Line graph"},
    {"id": "Select things you might want to calculate with your datas (Optional)", "en": "Select things you might want to calculate with your datas (Optional)", "esp": "Selecciona cosas que podrías querer calcular con tus datos (Opcional)", "it": "Seleziona le cose che potresti voler calcolare con i tuoi dati (Opzionale)", "fr": "Sélectionnez les éléments que vous pourriez vouloir calculer avec vos données (Facultatif)", "hau": "Zaɓi abubuwan da kake iya so ka ƙididdige tare da bayanan ka (Zaɓi)", "igb": "Họrọ ihe ndị ị nwere ike ịchọrọ iji gbakọọ na data gị (Ọrụ)", "yor": "Yan awọn nkan ti o le fẹ lati ṣe iṣiro pẹlu awọn data rẹ (Aṣayan)", "pid": "Select wetin you go like calculate with your datas (if you like am)"},
    {"id": "SUM", "en": "SUM", "esp": "SUMA", "it": "SOMMA", "fr": "SOMME", "hau": "SUM", "igb": "SUM", "yor": "SUM", "pid": "SUM"},
    {"id": "AVERAGE", "en": "AVERAGE", "esp": "PROMEDIO", "it": "MEDIA", "fr": "MOYENNE", "hau": "AVERAGE", "igb": "AVERAGE", "yor": "AVERAGE", "pid": "AVERAGE"},
    {"id": "CREATE", "en": "CREATE", "esp": "CREAR", "it": "CREA", "fr": "CRÉER", "hau": "CREATE", "igb": "CREATE", "yor": "CREATE", "pid": "CREATE"},
    {"id": "Formular Input", "en": "Formular Input", "esp": "Entrada de fórmula", "it": "Inserimento della formula", "fr": "Saisie de formule", "hau": "Shigar da Formular", "igb": "Nhazi njikere", "yor": "Ibi fọọmu", "pid": "Formular Input"},
    {"id": "EXIT", "en": "EXIT", "esp": "SALIR", "it": "ESCI", "fr": "SORTIR", "hau": "Fita", "igb": "Pụọ", "yor": "EXIT", "pid": "KOMOT"},

    {"id": "SOLUTION SHEET", "en": "SOLUTION SHEET", "esp": "HOJA DE SOLUCIÓN", "it": "FOGLIO DI SOLUZIONE", "fr": "FEUILLE DE SOLUTION", "hau": "TAFASASSEN SHAWARA", "igb": "Oge Ntụrụndụ", "yor": "IWE SOLUTION", "pid": "SOLUTION SHEET"},

    {"id": "CUSTOM SHEET", "en": "CUSTOM SHEET", "esp": "HOJA PERSONALIZADA", "it": "FOGLIO PERSONALIZZATO", "fr": "FEUILLE PERSONNALISÉE", "hau": "SHATIN NA ZABI", "igb": "ỤLỌ ỌRỤ", "yor": "BULỌ ỌJỌ", "pid": "CUSTOM SHEET"},
    {"id": "How many rows will you need", "en": "How many rows will you need", "esp": "Cuántas filas necesitarás", "it": "Quante righe ti serviranno", "fr": "Combien de lignes aurez-vous besoin", "hau": "Nawa za ku buƙaci layuka", "igb": "Ego rows ị ga-achọ", "yor": "Iye awọn ila wo ni iwọ yoo nilo", "pid": "How many rows you dey find"},
    {"id": "Enter number of rows", "en": "Enter number of rows", "esp": "Ingrese el número de filas", "it": "Inserisci il numero di righe", "fr": "Entrez le nombre de lignes", "hau": "Shigar da adadin layuka", "igb": "Tinye ọnụ ọgụgụ nke ahịrị", "yor": "Tẹ nọmba awọn ila", "pid": "Enter number of rows"},
    {"id": "How many columns will you need", "en": "How many columns will you need", "esp": "Cuántas columnas necesitarás", "it": "Quante colonne ti serviranno", "fr": "Combien de colonnes aurez-vous besoin", "hau": "Nawa za ku buƙaci ginshiƙai", "igb": "Ego columns ị ga-achọ", "yor": "Iye awọn kọlọmu wo ni iwọ yoo nilo", "pid": "How many columns you dey find"},
    {"id": "Enter number of columns", "en": "Enter number of columns", "esp": "Ingrese el número de columnas", "it": "Inserisci il numero di colonne", "fr": "Entrez le nombre de colonnes", "hau": "Shigar da adadin ginshiƙai", "igb": "Tinye ọnụ ọgụgụ nke kọlụm", "yor": "Tẹ nọmba awọn kọlọmu", "pid": "Enter number of columns"},
    {"id": "How many of those columns will you need formulars to get", "en": "How many of those columns will you need formulars to get", "esp": "Cuántas de esas columnas necesitarás fórmulas para obtener", "it": "Quante di quelle colonne ti serviranno formule", "fr": "Combien de ces colonnes aurez-vous besoin de formules", "hau": "Nawa daga cikin waɗannan ginshiƙai kuke buƙatar tsarin samun", "igb": "Ego nke kọlụm ndị ahụ ị ga-achọ usoro", "yor": "Iye awọn kọlọmu wo ni iwọ yoo nilo awọn fọọmu lati gba", "pid": "How many of those columns go find formulars"},
    {"id": "Enter number of columns with formular", "en": "Enter number of columns with formular", "esp": "Ingrese el número de columnas con fórmula", "it": "Inserisci il numero di colonne con formula", "fr": "Entrez le nombre de colonnes avec formule", "hau": "Shigar da adadin ginshiƙai tare da tsarin", "igb": "Tinye ọnụ ọgụgụ nke kọlụm nwere usoro", "yor": "Tẹ nọmba awọn kọlọmu pẹlu fọọmu", "pid": "Enter number of columns wer go need formulars"},
    {"id": "CONTINUE", "en": "CONTINUE", "esp": "CONTINUAR", "it": "CONTINUA", "fr": "CONTINUER", "hau": "CI GABA", "igb": "Gaa n'ihu", "yor": "Tesiwaju", "pid": "CONTINUE"},


    {"id": "CALIXGURU", "en": "CALIXGURU", "esp": "CALIXGURU", "it": "CALIXGURU", "fr": "CALIXGURU", "hau": "CALIXGURU", "igb": "CALIXGURU", "yor": "CALIXGURU", "pid": "CALIXGURU"},
    {"id": "ADMIN DASHBOARD", "en": "ADMIN DASHBOARD", "esp": "TABLERO ADMINISTRATIVO", "it": "CRUSCOTTO AMMINISTRATIVO", "fr": "TABLEAU DE BORD ADMINISTRATIF", "hau": "FADAR GIDAN ADMIN", "igb": "ỌDỤDỤ NZUZI", "yor": "DASHBOARD ADẸNI", "pid": "ADMIN DASHBOARD"},
    {"id": "Go Home", "en": "Go Home", "esp": "Ir a Casa", "it": "Vai a Casa", "fr": "Aller à la Maison", "hau": "Koma Gida", "igb": "Lọ N'ụlọ", "yor": "Lọ Si Ile", "pid": "Go Home"},
    {"id": "Total Users", "en": "Total Users", "esp": "Usuarios Totales", "it": "Utenti Totali", "fr": "Utilisateurs Totals", "hau": "Jimlar Masu Amfani", "igb": "Ọnụọgụgụ Ndị", "yor": "Lapapọ Awọn olumulo", "pid": "Total Users"},
    {"id": "Activated Users", "en": "Activated Users", "esp": "Usuarios Activados", "it": "Utenti Attivati", "fr": "Utilisateurs Activés", "hau": "Masu Amfani da Aka kunna", "igb": "Ndị A Kwusiri Ike", "yor": "Awọn olumulo ti a muu ṣiṣẹ", "pid": "Activated Users"},
    {"id": "Generated", "en": "Generated", "esp": "Generado", "it": "Generato", "fr": "Généré", "hau": "An Haɓaka", "igb": "E mepụtara", "yor": "Ti a Ṣẹda", "pid": "Generated"},
    {"id": "Active Users", "en": "Active Users", "esp": "Usuarios Activos", "it": "Utenti Attivi", "fr": "Utilisateurs Actifs", "hau": "Masu Amfani da Aiki", "igb": "Ndị Ọrụ", "yor": "Awọn olumulo Ti nṣiṣe lọwọ", "pid": "Active Users"},
    {"id": "Send General Mail", "en": "Send General Mail", "esp": "Enviar Correo General", "it": "Invia Posta Generale", "fr": "Envoyer un Courrier Général", "hau": "Aika Wasika Gabaɗaya", "igb": "Zipu Ọkwa n’Ezie", "yor": "Firanṣẹ Awọn apamọ Gbogbogbo", "pid": "Send General Mail"},
    {"id": "Email", "en": "Email", "esp": "Correo Electrónico", "it": "Email", "fr": "Courriel", "hau": "Imel", "igb": "Email", "yor": "Imeeli", "pid": "Email"},
    {"id": "Bought Date", "en": "Bought Date", "esp": "Fecha de Compra", "it": "Data di Acquisto", "fr": "Date d’Achat", "hau": "Ranar Sayi", "igb": "Ụbọchị Ezigbo", "yor": "Ọjọ Ráwọn", "pid": "Bought Date"},
    {"id": "Expiration Date", "en": "Expiration Date", "esp": "Fecha de Vencimiento", "it": "Data di Scadenza", "fr": "Date d’Expiration", "hau": "Ranar Karewa", "igb": "Ụbọchị Ọgwụgwụ", "yor": "Ọjọ Ipari", "pid": "Expiration Date"},
    {"id": "Personal Mail", "en": "Personal Mail", "esp": "Correo Personal", "it": "Posta Personale", "fr": "Courrier Personnel", "hau": "Wasika Ta Kanka", "igb": "Ọkwa Nke Onwe", "yor": "Imeeli Ti ara", "pid": "Personal Mail"},
    {"id": "Send", "en": "Send", "esp": "Enviar", "it": "Invia", "fr": "Envoyer", "hau": "Aika", "igb": "Zipu", "yor": "Fi Ránṣẹ", "pid": "Send"},
    {"id": "All Users", "en": "All Users", "esp": "Todos los Usuarios", "it": "Tutti gli Utenti", "fr": "Tous les Utilisateurs", "hau": "Duk Masu Amfani", "igb": "Ndị Ọrụ Nile", "yor": "Gbogbo Awọn olumulo", "pid": "All Users"},
    {"id": "Copy all Mail", "en": "Copy all Mail", "esp": "Copiar Todo el Correo", "it": "Copia Tutta la Posta", "fr": "Copier Tout le Courrier", "hau": "Kwafi Duk Wasika", "igb": "Detuo Maahịa Ndị Ọzọ", "yor": "Daakọ Gbogbo Awọn imeeli", "pid": "Copy all Mail"},
    {"id": "User Details", "en": "User Details", "esp": "Detalles del Usuario", "it": "Dettagli dell’Utente", "fr": "Détails de l’Utilisateur", "hau": "Cikakken Bayani Game da Masu Amfani", "igb": "Nkowa Onye Ọrụ", "yor": "Apejuwe Ọmọniyan", "pid": "User Details"},
    {"id": "Name", "en": "Name", "esp": "Nombre", "it": "Nome", "fr": "Nom", "hau": "Suna", "igb": "Aha", "yor": "Orukọ", "pid": "Name"},
    {"id": "Department", "en": "Department", "esp": "Departamento", "it": "Dipartimento", "fr": "Département", "hau": "Sashen", "igb": "Ngalaba", "yor": "Ẹka", "pid": "Department"},
    {"id": "Bi-Weekly", "en": "Bi-Weekly", "esp": "Quincenal", "it": "Ogni Due Settimane", "fr": "Bimensuel", "hau": "Sau Dukan Mako Biyu", "igb": "Nke ọ bụla Izu abụọ", "yor": "Ẹẹkeji Oṣù", "pid": "Bi-Weekly"},
    {"id": "More Info", "en": "More Info", "esp": "Más Información", "it": "Maggiori Informazioni", "fr": "Plus d’Informations", "hau": "Karin Bayani", "igb": "Ihe Ụzọ Dị Ọzọ", "yor": "Alaye Di Siwaju", "pid": "More Info"},
    {"id": "Activate", "en": "Activate", "esp": "Activar", "it": "Attivare", "fr": "Activer", "hau": "Kunne", "igb": "Kwusilọ", "yor": "Mu ṣiṣẹ", "pid": "Activate"},

    {
    "id": "AUTOMATIONS",
    "en": "AUTOMATIONS",
    "esp": "AUTOMATIZACIONES",
    "it": "AUTOMAZIONI",
    "fr": "AUTOMATISATIONS",
    "hau": "AUTOMATIONS",
    "igb": "AUTOMATION",
    "yor": "ÌPÍLẸ̀ Ẹ̀RỌ",
    "pid": "AUTOMATIONS"
},
{
    "id": "PHYSICS PRACTICAL SOLVER",
    "en": "PHYSICS PRACTICAL SOLVER",
    "esp": "SOLUCIONADOR PRÁCTICO DE FÍSICA",
    "it": "RISOLUTORE PRATICO DI FISICA",
    "fr": "SOLVEUR PRATIQUE DE PHYSIQUE",
    "hau": "SOLVER PRACTICAL PHYSICS",
    "igb": "NGWA PUTARA ULOMWALIRI NKE FIZIKS",
    "yor": "OLUṢE ṢEṢE FÍSÍKS",
    "pid": "SOLVER PHYSICS PRACTICAL"
},
{
    "id": "1ST SEMESTER",
    "en": "1ST SEMESTER",
    "esp": "PRIMER SEMESTRE",
    "it": "PRIMO SEMESTRE",
    "fr": "PREMIER SEMESTRE",
    "hau": "KARATU NA FARKO",
    "igb": "NKA MBỤ",
    "yor": "ÌGBÈKẸ̀KÀN",
    "pid": "1ST SEMESTER"
},
{
    "id": "2ND SEMESTER",
    "en": "2ND SEMESTER",
    "esp": "SEGUNDO SEMESTRE",
    "it": "SECONDO SEMESTRE",
    "fr": "DEUXIÈME SEMESTRE",
    "hau": "KARATU NA BIYU",
    "igb": "NKA NA ABỤỌ",
    "yor": "ÌGBÈKẸ̀JÌ",
    "pid": "2ND SEMESTER"
},
{
    "id": "ASSIGNMENTS",
    "en": "ASSIGNMENTS",
    "esp": "TAREAS",
    "it": "COMPITI",
    "fr": "DEVOIRS",
    "hau": "AIKIN",
    "igb": "NDI NTOZI",
    "yor": "ÀṢẸ",
    "pid": "ASSIGNMENTS"
},
{
    "id": "CLICK HERE FOR MORE",
    "en": "CLICK HERE FOR MORE",
    "esp": "HAZ CLIC AQUÍ PARA MÁS",
    "it": "CLICCA QUI PER MAGGIORI INFORMAZIONI",
    "fr": "CLIQUEZ ICI POUR EN SAVOIR PLUS",
    "hau": "DANNAN ANAN DON KARA",
    "igb": "PIA EBERE MFE ANO",
    "yor": "TẸ IBERE FUN SỌ SIWAJU",
    "pid": "CLICK HERE FOR MORE"
},
{
    "id": "PERSONAL LESSON/TEST",
    "en": "PERSONAL LESSON/TEST",
    "esp": "LECCIÓN/PRUEBA PERSONAL",
    "it": "LEZIONE/TEST PERSONALE",
    "fr": "LEÇON/TEST PERSONNEL",
    "hau": "DARASI/WAJEN KAI",
    "igb": "LESON OZI/ULE",
    "yor": "Ẹ̀KỌ́ TÌTÌ",
    "pid": "LESSON/TEST PERSONAL"
},
{
    "id": "You will have 50 minutes to answer 20 questions",
    "en": "You will have 50 minutes to answer 20 questions",
    "esp": "Tendrás 50 minutos para responder 20 preguntas",
    "it": "Avrai 50 minuti per rispondere a 20 domande",
    "fr": "Vous aurez 50 minutes pour répondre à 20 questions",
    "hau": "Zaku sami mintuna 50 don amsa tambayoyi 20",
    "igb": "I nwere ihe dị ka nkeji 50 iji zaa ajụjụ iri abụọ",
    "yor": "Iwọ yoo ni iṣẹju 50 lati dahun awọn ibeere 20",
    "pid": "You go get 50 minutes answer 20 questions"
},
{
    "id": "MATHEMATICS",
    "en": "MATHEMATICS",
    "esp": "MATEMÁTICAS",
    "it": "MATEMATICA",
    "fr": "MATHÉMATIQUES",
    "hau": "LISSAFI",
    "igb": "NKA",
    "yor": "Ọ̀DỌ̀TỌ",
    "pid": "MATHEMATICS"
},
{
    "id": "This quiz will be available soon",
    "en": "This quiz will be available soon",
    "esp": "Este cuestionario estará disponible pronto",
    "it": "Questo quiz sarà disponibile a breve",
    "fr": "Ce quiz sera bientôt disponible",
    "hau": "Wannan gwajin zai kasance a nan ba da jimawa ba",
    "igb": "Nyochaa a ga-enwe n'oge na-adịghị anya",
    "yor": "Akọsilẹ yìí yoo wa ni kete",
    "pid": "This quiz go soon dey available"
},
{
    "id": "GST (USE OF ENGLISH)",
    "en": "GST (USE OF ENGLISH)",
    "esp": "GST (USO DEL INGLÉS)",
    "it": "GST (USO DELL'INGLESE)",
    "fr": "GST (UTILISATION DE L'ANGLAIS)",
    "hau": "GST (AMFANI DA ENGLISH)",
    "igb": "GST (IJIRI NKE ENGLISH)",
    "yor": "GST (LILO TI Ẹ̀DÁ)",
    "pid": "GST (USE OF ENGLISH)"
},

{
    "id": "WORKSPACE",
    "en": "WORKSPACE",
    "esp": "ESPACIO DE TRABAJO",
    "it": "SPAZIO DI LAVORO",
    "fr": "ESPACE DE TRAVAIL",
    "hau": "WURIN AIKI",
    "igb": "OGE NTỌRỤNDU",
    "yor": "ÌBI ÌṢẸ́",
    "pid": "WORKSPACE"
},
{
    "id": "CUSTOM WORKS",
    "en": "CUSTOM WORKS",
    "esp": "TRABAJOS PERSONALIZADOS",
    "it": "LAVORI PERSONALIZZATI",
    "fr": "TRAVAUX PERSONNALISÉS",
    "hau": "AIKINA NA MUSAMMAN",
    "igb": "ỌRỤ ỌMA",
    "yor": "ÌṢẸ́ ÀGBẸ́YẸ̀WỌ́N",
    "pid": "CUSTOM WORKS"
},
{
    "id": "Create your own table and formulars",
    "en": "Create your own table and formulars",
    "esp": "Cree su propia tabla y formularios",
    "it": "Crea la tua tabella e i tuoi formulari",
    "fr": "Créez votre propre tableau et formulaires",
    "hau": "Ƙirƙiri teburinka da tsarin bayanan",
    "igb": "Kere oke gi na ihe odide",
    "yor": "Ṣẹda tabili ati awọn fọọmu tirẹ",
    "pid": "Create your own table and formulars"
},
{
    "id": "SPECIAL REQUESTS",
    "en": "SPECIAL REQUESTS",
    "esp": "SOLICITUDES ESPECIALES",
    "it": "RICHIESTE SPECIALI",
    "fr": "DEMANDES SPÉCIALES",
    "hau": "BUKATUWAR MUSAMMAN",
    "igb": "ARỌRỌ ARỌRỌ",
    "yor": "Ẹ̀BẸ̀ PÀTÀKÌ",
    "pid": "SPECIAL REQUESTS"
},
{
    "id": "Post Personal Assignments, projects, etc",
    "en": "Post Personal Assignments, projects, etc",
    "esp": "Publica tareas personales, proyectos, etc.",
    "it": "Pubblica compiti personali, progetti, ecc.",
    "fr": "Publiez des devoirs personnels, projets, etc.",
    "hau": "Sanya aikinku na kaina, ayyuka, da sauransu",
    "igb": "Depuo onwe gi n'ọrụ, ọrụ, wdg.",
    "yor": "Ṣe atẹjade iṣẹ ikọkọ, awọn iṣẹ akanṣe, ati bẹbẹ lọ.",
    "pid": "Post Personal Assignments, projects, etc"
},

{
    "id": "SPECIAL REQUEST/ASSIGNMENTS",
    "en": "SPECIAL REQUEST/ASSIGNMENTS",
    "esp": "SOLICITUDES ESPECIALES/ASIGNACIONES",
    "it": "RICHIESTE SPECIALI/COMPITI",
    "fr": "DEMANDES SPÉCIALES/DEVOIRS",
    "hau": "BUKATUN MUSAMMAN/AIKIN",
    "igb": "ARỌRỌ ARỌRỌ / NJEDERE",
    "yor": "Ẹ̀BẸ̀ PÀTÀKÌ / ÀṢẸ̀",
    "pid": "SPECIAL REQUEST/ASSIGNMENTS"
},
{
    "id": "POST ASSIGNMENT/PROJECT",
    "en": "POST ASSIGNMENT/PROJECT",
    "esp": "PUBLICAR ASIGNACIÓN/PROYECTO",
    "it": "PUBBLICA ASSEGNO/PROGETTO",
    "fr": "PUBLIER DEVOIR/PROJET",
    "hau": "SAKA AIKI/AYYUKA",
    "igb": "POST NKA/ỌRỤ",
    "yor": "ṢẸ̀KÀN ÀṢẸ̀ / ISÉ",
    "pid": "POST ASSIGNMENT/PROJECT"
},
{
    "id": "Preview",
    "en": "Preview",
    "esp": "Vista previa",
    "it": "Anteprima",
    "fr": "Aperçu",
    "hau": "Dubawa",
    "igb": "Nlele",
    "yor": "Awotẹlẹ",
    "pid": "Preview"
},
{
    "id": "Select a Category",
    "en": "Select a Category",
    "esp": "Seleccione una categoría",
    "it": "Seleziona una categoria",
    "fr": "Sélectionnez une catégorie",
    "hau": "Zaɓi Rukuni",
    "igb": "Họrọ otu",
    "yor": "Yan ẹ̀ka kan",
    "pid": "Select a Category"
},
{
    "id": "Caption",
    "en": "Caption",
    "esp": "Subtítulo",
    "it": "Didascalia",
    "fr": "Légende",
    "hau": "Kalmomi",
    "igb": "Nkebiokwu",
    "yor": "Àkọlé",
    "pid": "Caption"
},
{
    "id": "Thumbnail",
    "en": "Thumbnail",
    "esp": "Miniatura",
    "it": "Miniatura",
    "fr": "Vignette",
    "hau": "Hoto ƙarama",
    "igb": "Obere oyiri",
    "yor": "Àwọn òrísà",
    "pid": "Thumbnail"
},
{
    "id": "Body of your project",
    "en": "Body of your project",
    "esp": "Cuerpo de tu proyecto",
    "it": "Corpo del tuo progetto",
    "fr": "Corps de votre projet",
    "hau": "Jikin aikin ku",
    "igb": "Ahụ ọrụ gị",
    "yor": "Ara iṣẹ́ rẹ",
    "pid": "Body of your project"
},
{
    "id": "POST PROJECT",
    "en": "POST PROJECT",
    "esp": "PUBLICAR PROYECTO",
    "it": "PUBBLICA PROGETTO",
    "fr": "PUBLIER PROJET",
    "hau": "SAKA AIKI",
    "igb": "POST ỌRỤ",
    "yor": "ṢẸ̀KÀN ISÉ",
    "pid": "POST PROJECT"
},

{
        "id": "Go Home",
        "en": "Go Home",
        "esp": "Ir a casa",
        "it": "Vai a casa",
        "fr": "Aller à la maison",
        "hau": "Komawa gida",
        "igb": "Lọ ụlọ",
        "yor": "Padà si ile",
        "pid": "Go House"
    },
    {
        "id": "SETTINGS",
        "en": "SETTINGS",
        "esp": "AJUSTES",
        "it": "IMPOSTAZIONI",
        "fr": "PARAMÈTRES",
        "hau": "SAITIN",
        "igb": "NTỌNTỌ",
        "yor": "ETO",
        "pid": "SETTING"
    },
    {
        "id": "Change Language",
        "en": "Change Language",
        "esp": "Cambiar idioma",
        "it": "Cambia lingua",
        "fr": "Changer de langue",
        "hau": "Canja Harshe",
        "igb": "Gbanwee Asụsụ",
        "yor": "Yi ede pada",
        "pid": "Change Language"
    },
    {
        "id": "Select Language",
        "en": "Select Language",
        "esp": "Seleccionar idioma",
        "it": "Seleziona lingua",
        "fr": "Sélectionner la langue",
        "hau": "Zaɓi Harshe",
        "igb": "Họrọ Asụsụ",
        "yor": "Yan ede",
        "pid": "Select Language"
    },
    {
        "id": "Change",
        "en": "Change",
        "esp": "Cambiar",
        "it": "Cambiare",
        "fr": "Changer",
        "hau": "Canja",
        "igb": "Gbanwee",
        "yor": "Yi pada",
        "pid": "Change"
    },
    {
        "id": "Cancel",
        "en": "Cancel",
        "esp": "Cancelar",
        "it": "Annullare",
        "fr": "Annuler",
        "hau": "Soke",
        "igb": "Kagbuo",
        "yor": "Fagilé",
        "pid": "Cancel"
    },
    {
        "id": "YOU ARE NOT ACTIVATED",
        "en": "YOU ARE NOT ACTIVATED",
        "esp": "NO ESTÁS ACTIVADO",
        "it": "NON SEI ATTIVATO",
        "fr": "VOUS N'ÊTES PAS ACTIVÉ",
        "hau": "BA A KUNNA KU BA",
        "igb": "ANAGHỊ AKTỊVÉ Ị",
        "yor": "Ẹ KO ṢÉ NÍPÍN",
        "pid": "YOU NEVER ACTIVATE"
    },
    {
        "id": "Activate",
        "en": "Activate",
        "esp": "Activar",
        "it": "Attivare",
        "fr": "Activer",
        "hau": "Kunna",
        "igb": "Kpụlite",
        "yor": "Ṣiṣẹ",
        "pid": "Activate"
    },
    {
        "id": "Your whatsapp Contact",
        "en": "Your whatsapp Contact",
        "esp": "Tu contacto de whatsapp",
        "it": "Il tuo contatto whatsapp",
        "fr": "Votre contact whatsapp",
        "hau": "Tuntube ku na whatsapp",
        "igb": "Kpọtụrụ gị na whatsapp",
        "yor": "Awọn olubasọrọ rẹ lori whatsapp",
        "pid": "Your whatsapp Contact"
    },
    {
        "id": "You have not added your whatsapp link",
        "en": "You have not added your whatsapp link",
        "esp": "No has agregado tu enlace de whatsapp",
        "it": "Non hai aggiunto il tuo link whatsapp",
        "fr": "Vous n'avez pas ajouté votre lien whatsapp",
        "hau": "Ba ku kara mahaɗin whatsapp ɗin ku ba",
        "igb": "I nwebeghị njikọ whatsapp gị",
        "yor": "O ko ti fi ọna asopọ whatsapp rẹ kun",
        "pid": "You never add your whatsapp link"
    },
    {
        "id": "Social handle",
        "en": "Social handle",
        "esp": "Mango social",
        "it": "Manico sociale",
        "fr": "Poignée sociale",
        "hau": "Rike zamantakewa",
        "igb": "Handle nke ọha",
        "yor": "Mimu aye",
        "pid": "Social handle"
    },
    {
        "id": "Edit Personal Details",
        "en": "Edit Personal Details",
        "esp": "Editar detalles personales",
        "it": "Modifica i dettagli personali",
        "fr": "Modifier les détails personnels",
        "hau": "Gyara Cikakken Bayani",
        "igb": "Dezie Ndụmọdụ Nkeonwe",
        "yor": "Ṣatunkọ Awọn Alaye Ti Ara ẹni",
        "pid": "Edit Personal Details"
    },
    {
        "id": "First Name",
        "en": "First Name",
        "esp": "Primer nombre",
        "it": "Nome di battesimo",
        "fr": "Prénom",
        "hau": "Sunan Farko",
        "igb": "Aha Mbu",
        "yor": "Orukọ Àkọ́kọ́",
        "pid": "First Name"
    },
    {
        "id": "Last Name",
        "en": "Last Name",
        "esp": "Apellido",
        "it": "Cognome",
        "fr": "Nom de famille",
        "hau": "Sunan Mahaifi",
        "igb": "Aha ikpeazụ",
        "yor": "Orúkọ Gbẹ́yìn",
        "pid": "Last Name"
    },
    {
        "id": "Change Profile Picture",
        "en": "Change Profile Picture",
        "esp": "Cambiar foto de perfil",
        "it": "Cambia immagine del profilo",
        "fr": "Changer la photo de profil",
        "hau": "Canja hoton bayanin kanka",
        "igb": "Gbanwee foto profaịlụ",
        "yor": "Yi aworan profaili pada",
        "pid": "Change Profile Picture"
    },
    {
        "id": "Save",
        "en": "Save",
        "esp": "Guardar",
        "it": "Salva",
        "fr": "Enregistrer",
        "hau": "Ajiye",
        "igb": "Chekwaa",
        "yor": "Fipamọ",
        "pid": "Save"
    },

{
        "id": "Phone Number",
        "en": "Phone Number",
        "esp": "Número de teléfono",
        "it": "Numero di telefono",
        "fr": "Numéro de téléphone",
        "hau": "Lambar waya",
        "igb": "Nọmba ekwentị",
        "yor": "Nọmba foonu",
        "pid": "Phone Number"
    },
{
        "id": "Whatsapp Link",
        "en": "Whatsapp Link",
        "esp": "Enlace de Whatsapp",
        "it": "Collegamento Whatsapp",
        "fr": "Lien Whatsapp",
        "hau": "Mahada na Whatsapp",
        "igb": "Njikọ Whatsapp",
        "yor": "Asopọ Whatsapp",
        "pid": "Whatsapp Link"
    },
    {
        "id": "SIGN IN",
        "en": "SIGN IN",
        "esp": "INICIAR SESIÓN",
        "it": "ACCEDI",
        "fr": "CONNEXION",
        "hau": "SHIGA",
        "igb": "BANYERE",
        "yor": "WỌLE",
        "pid": "SIGN IN"
    },
    {
        "id": "Email",
        "en": "Email",
        "esp": "Correo electrónico",
        "it": "Email",
        "fr": "Email",
        "hau": "Imel",
        "igb": "Email",
        "yor": "Imeeli",
        "pid": "Email"
    },
    {
        "id": "Password",
        "en": "Password",
        "esp": "Contraseña",
        "it": "Password",
        "fr": "Mot de passe",
        "hau": "Kalmar wucewa",
        "igb": "Okwuntughe",
        "yor": "Ọrọ igbaniwọle",
        "pid": "Password"
    },
    {
        "id": "Remember me",
        "en": "Remember me",
        "esp": "Recuérdame",
        "it": "Ricordami",
        "fr": "Se souvenir de moi",
        "hau": "Tuna ni",
        "igb": "Cheta m",
        "yor": "Ranti mi",
        "pid": "Remember me"
    },
    {
        "id": "Forgot Password?",
        "en": "Forgot Password?",
        "esp": "¿Olvidaste tu contraseña?",
        "it": "Password dimenticata?",
        "fr": "Mot de passe oublié ?",
        "hau": "Kuna Mantawa?",
        "igb": "Ichefuru okwuntughe?",
        "yor": "Ṣe o gbagbe ọrọ igbaniwọle?",
        "pid": "Forgot Password?"
    },
    {
        "id": "Create an Account",
        "en": "Create an Account",
        "esp": "Crear una cuenta",
        "it": "Crea un account",
        "fr": "Créer un compte",
        "hau": "Ƙirƙiri asusu",
        "igb": "Mepụta akaụntụ",
        "yor": "Ṣẹda iroyin",
        "pid": "Create an Account"
    },
    {
        "id": "Firstname",
        "en": "Firstname",
        "esp": "Nombre",
        "it": "Nome",
        "fr": "Prénom",
        "hau": "Suna",
        "igb": "Aha mbụ",
        "yor": "Oruko akọkọ",
        "pid": "Firstname"
    },
    {
        "id": "Lastname",
        "en": "Lastname",
        "esp": "Apellido",
        "it": "Cognome",
        "fr": "Nom de famille",
        "hau": "Sunan mahaifi",
        "igb": "Aha ikpeazụ",
        "yor": "Oruko idile",
        "pid": "Lastname"
    },
    {
        "id": "Password confirmation",
        "en": "Password confirmation",
        "esp": "Confirmación de contraseña",
        "it": "Conferma password",
        "fr": "Confirmation du mot de passe",
        "hau": "Tabbatar da kalmar wucewa",
        "igb": "Nkwenye okwuntughe",
        "yor": "Ìmúdájú ọrọ igbaniwọle",
        "pid": "Password confirmation"
    },
    {
        "id": "I agree to the terms and conditions",
        "en": "I agree to the terms and conditions",
        "esp": "Acepto los términos y condiciones",
        "it": "Accetto i termini e le condizioni",
        "fr": "J'accepte les termes et conditions",
        "hau": "Na yarda da sharuɗɗa da yanayi",
        "igb": "Anaghị m ekwekọ na ụkpụrụ na ọnọdụ",
        "yor": "Mo gba awọn ofin ati ipo",
        "pid": "I gree to the terms and conditions"
    },
    {
        "id": "Sign in",
        "en": "Sign in",
        "esp": "Iniciar sesión",
        "it": "Accedi",
        "fr": "Se connecter",
        "hau": "Shiga",
        "igb": "Banye",
        "yor": "Wọle",
        "pid": "Sign in"
    },
    {
        "id": "Sign up",
        "en": "Sign up",
        "esp": "Registrarse",
        "it": "Registrati",
        "fr": "S'inscrire",
        "hau": "Yi rajista",
        "igb": "Debanye aha",
        "yor": "Forukọsilẹ",
        "pid": "Sign up"
    },
    {
        "id": "Login to Account",
        "en": "Login to Account",
        "esp": "Inicia sesión en la cuenta",
        "it": "Accedi al tuo account",
        "fr": "Se connecter au compte",
        "hau": "Shiga cikin asusu",
        "igb": "Banye na akaụntụ",
        "yor": "Wọle si iroyin",
        "pid": "Login to Account"
    },
    {
  "id": "Login",
    "en": "Login",
    "esp": "Iniciar sesión",
    "it": "Accedi",
    "fr": "Connexion",
    "hau": "Shiga",
    "igb": "Banye",
    "yor": "Wọle",
    "pid": "Login"
  },
  {
  "id": "Dashboard",
    "en": "Dashboard",
    "esp": "Tablero",
    "it": "Cruscotto",
    "fr": "Tableau de bord",
    "hau": "Allon aiki",
    "igb": "Dashboard",
    "yor": "Dashboard",
    "pid": "Dashboard"
  },
  {
  "id": "Subscribe",
    "en": "Subscribe",
    "esp": "Suscribirse",
    "it": "Abbonati",
    "fr": "S'abonner",
    "hau": "Yi rajista",
    "igb": "Debanye aha",
    "yor": "Forukọsilẹ",
    "pid": "Subscribe"
  },
{
  "id": "Logout",
    "en": "Logout",
    "esp": "Cerrar sesión",
    "it": "Disconnettersi",
    "fr": "Déconnexion",
    "hau": "Fita",
    "igb": "Pụọ",
    "yor": "Bọ lati",
    "pid": "Logout"
  },
  {
  "id": "CALIXGURU",
    "en": "CALIXGURU",
    "esp": "CALIXGURU",
    "it": "CALIXGURU",
    "fr": "CALIXGURU",
    "hau": "CALIXGURU",
    "igb": "CALIXGURU",
    "yor": "CALIXGURU",
    "pid": "CALIXGURU"
  },
  {
  "id": "Digital Learning at its finest",
    "en": "Digital Learning at its finest",
    "esp": "Aprendizaje digital en su máxima expresión",
    "it": "Apprendimento digitale al massimo",
    "fr": "L'apprentissage numérique à son meilleur",
    "hau": "Koyon dijital a mafi kyau",
    "igb": "Akwụkwọ ọmụmụ dijital na kacha mma",
    "yor": "Ikẹkọ oni-nọmba ni o dara julọ",
    "pid": "Digital Learning at its finest"
  },
{
  "id": "Contact us",
    "en": "Contact us",
    "esp": "Contáctanos",
    "it": "Contattaci",
    "fr": "Contactez-nous",
    "hau": "Tuntuɓi mu",
    "igb": "Kpọtụrụ anyị",
    "yor": "Kan si wa",
    "pid": "Contact us"
  },
{
  "id": "Subscribe",
    "en": "Subscribe",
    "esp": "Suscribirse",
    "it": "Abbonati",
    "fr": "S'abonner",
    "hau": "Yi rajista",
    "igb": "Debanye aha",
    "yor": "Forukọsilẹ",
    "pid": "Subscribe"
  },
{
  "id": "Terms & Conditions",
    "en": "Terms & Conditions",
    "esp": "Términos y Condiciones",
    "it": "Termini e Condizioni",
    "fr": "Conditions Générales",
    "hau": "Sharuɗɗa & Yanayi",
    "igb": "Okwu na ọnọdụ",
    "yor": "Awọn ofin & Awọn ipo",
    "pid": "Terms & Conditions"
  },
{
  "id": "Copyright ©2022 All rights reserved | CALIXGURU",
    "en": "Copyright ©2022 All rights reserved | CALIXGURU",
    "esp": "Copyright ©2022 Todos los derechos reservados | CALIXGURU",
    "it": "Copyright ©2022 Tutti i diritti riservati | CALIXGURU",
    "fr": "Copyright ©2022 Tous droits réservés | CALIXGURU",
    "hau": "Hakkin mallaka ©2022 Duk hakkoki an kiyaye | CALIXGURU",
    "igb": "Ikike ©2022 Nchekwa niile | CALIXGURU",
    "yor": "Aṣẹ ©2022 Gbogbo awọn ẹtọ wa ni a pamọ | CALIXGURU",
    "pid": "Copyright ©2022 All rights reserved | CALIXGURU"
  },
  {
        "id": "Digital Learning",
        "en": "Digital Learning",
        "esp": "Aprendizaje Digital",
        "it": "Apprendimento Digitale",
        "fr": "Apprentissage Numérique",
        "hau": "Koyo na Dijital",
        "igb": "Amụma Dijitalụ",
        "yor": "Ẹkọ Oni-nọmba",
        "pid": "Digital Learning"
    },
    {
        "id": "at its finest",
        "en": "at it's finest",
        "esp": "en su máxima expresión",
        "it": "al suo meglio",
        "fr": "à son meilleur",
        "hau": "a mafi kyau",
        "igb": "na ya kacha mma",
        "yor": "ni ti o dara julọ",
        "pid": "at it's finest"
    },
    {
        "id": "Calixguru gives you the best experience to learn and adapt to digital education",
        "en": "Calixguru gives you the best experience to learn and adapt to digital education",
        "esp": "Calixguru te ofrece la mejor experiencia para aprender y adaptarte a la educación digital",
        "it": "Calixguru ti offre la migliore esperienza per apprendere e adattarti all'istruzione digitale",
        "fr": "Calixguru vous offre la meilleure expérience pour apprendre et vous adapter à l'éducation numérique",
        "hau": "Calixguru yana ba ku mafi kyawun kwarewa don koyon da daidaita da ilimin dijital",
        "igb": "Calixguru na-enye gị ahụmịhe kacha mma iji mụta ma na-adapt na agụmakwụkwọ dijitalụ",
        "yor": "Calixguru n fun ọ ni iriri ti o dara julọ lati kọ ẹkọ ati ṣe atunṣe si eto-ẹkọ oni-nọmba",
        "pid": "Calixguru go free you the best experience make you learn and adapt to digital education"
    },
    {
        "id": "Start Learning",
        "en": "Start Learning",
        "esp": "Empieza a Aprender",
        "it": "Inizia a Imparare",
        "fr": "Commencer à Apprendre",
        "hau": "Fara Koyo",
        "igb": "Malite Ịmụta",
        "yor": "Bẹrẹ Kọ",
        "pid": "Start Learning"
    },
    {
        "id": "What is",
        "en": "What is",
        "esp": "¿Qué es",
        "it": "Cos'è",
        "fr": "Qu'est-ce que",
        "hau": "Menene",
        "igb": "Kedu ihe bụ",
        "yor": "Kí ni",
        "pid": "Wetin be"
    },
    {
        "id": "Calixguru allows you learn in the most digital way possible, creating lessons, quizzes and assessments for fast learning.",
        "en": "Calixguru allows you learn in the most digital way possible, creating lessons, quizzes and assessments for fast learning.",
        "esp": "Calixguru te permite aprender de la manera más digital posible, creando lecciones, cuestionarios y evaluaciones para un aprendizaje rápido.",
        "it": "Calixguru ti consente di apprendere nel modo più digitale possibile, creando lezioni, quiz e valutazioni per un apprendimento veloce.",
        "fr": "Calixguru vous permet d'apprendre de la manière la plus numérique possible, en créant des leçons, des quiz et des évaluations pour un apprentissage rapide.",
        "hau": "Calixguru yana ba ka damar koyon hanyar dijital yadda ya kamata, yana ƙirƙirar darussa, tambayoyi da kimantawa don koyon sauri.",
        "igb": "Calixguru na-enye gị ohere ịmụ na ụzọ dijitalụ kachasị mma, ịmepụta klas, ajụjụ na nyocha maka ọmụmụ ọsọ.",
        "yor": "Calixguru n gba ọ laaye lati kọ ni ọna oni-nọmba ti o ṣee ṣe, ṣẹda awọn ẹkọ, awọn ibeere ati awọn igbimọ fun ẹkọ yarayara.",
        "pid": "Calixguru dey do make you learn for the most digital way possible, creating lessons, quizzes and assessments for fast learning."
    },
    {
        "id": "Calixguru also admits private educational assignments and projects and delivers really quickly. Join us today",
        "en": "Calixguru also admits private educational assignments and projects and delivers really quickly. Join us today",
        "esp": "Calixguru también admite tareas y proyectos educativos privados y entrega muy rápidamente. Únete a nosotros hoy",
        "it": "Calixguru ammette anche incarichi e progetti educativi privati e consegna molto rapidamente. Unisciti a noi oggi",
        "fr": "Calixguru accepte également les missions et projets éducatifs privés et livre très rapidement. Rejoignez-nous dès aujourd'hui",
        "hau": "Calixguru kuma yana karɓar aikin ilimi na sirri da ayyuka kuma yana kawo su cikin sauri. Shiga mu yau",
        "igb": "Calixguru na-agba akwụkwọ akwụkwọ na ọrụ agụmakwụkwọ nkeonwe ma na-ewere ya ngwa ngwa. Jikọọ anyị taa",
        "yor": "Calixguru tun gba awọn iṣẹ-ṣiṣe ẹkọ ikọkọ ati awọn iṣẹ akanṣe ati fi wọn ranṣẹ ni iyara pupọ. Darapọ mọ wa loni",
        "pid": "Calixguru follow admits private educational assignments and projects e dey deliver sharp. You no for like join us today"
    },
    {
        "id": "Automations makes an average student very productive",
        "en": "Automations makes an average student very productive",
        "esp": "Las automatizaciones hacen que un estudiante promedio sea muy productivo",
        "it": "Le automazioni rendono uno studente medio molto produttivo",
        "fr": "Les automatisations rendent un étudiant moyen très productif",
        "hau": "Ayyukan atomatik suna sanya ɗalibai na matsakaici su zama masu kyau",
        "igb": "Ịrụ ọrụ na-eme ka ụmụ akwụkwọ nkịtị bụrụ ndị nwere ezigbo arụmọrụ",
        "yor": "Awọn ohun elo ṣiṣe jẹ ki ọmọ ile-iwe deede jẹ alagbara pupọ",
        "pid": "Automations dey make average student dey very productive"
    },
    {
        "id": "Tell us your mind about Calixguru",
        "en": "Tell us your mind about Calixguru",
        "esp": "Cuéntanos tu opinión sobre Calixguru",
        "it": "Raccontaci la tua opinione su Calixguru",
        "fr": "Dites-nous ce que vous pensez de Calixguru",
        "hau": "Faɗa mana ra'ayinka akan Calixguru",
        "igb": "Gwa anyị echiche gị banyere Calixguru",
        "yor": "So wa ni ero rẹ nipa Calixguru",
        "pid": "Yan us wetin dey your mind about Calixguru"
    },
    {
    "id": "We allow students to create and solve their own problems and help improve their level of reasoning",
    "en": "We allow students to create and solve their own problems and help improve their level of reasoning",
    "esp": "Permitimos a los estudiantes crear y resolver sus propios problemas y ayudar a mejorar su nivel de razonamiento",
    "it": "Permettiamo agli studenti di creare e risolvere i propri problemi e aiutare a migliorare il loro livello di ragionamento",
    "fr": "Nous permettons aux étudiants de créer et de résoudre leurs propres problèmes et d'améliorer leur niveau de raisonnement",
    "hau": "Muna ba da damar dalibai su ƙirƙira da warware matsalolinsu da taimaka wajen inganta matakin tunaninsu",
    "igb": "Anyị na-enye ụmụ akwụkwọ ohere ịmepụta ma dozie nsogbu ha na-enyere aka ịmepụta nke ọma",
    "yor": "A gba awọn ọmọ ile-iwe laaye lati ṣẹda ati yanju awọn iṣoro wọn ati iranlọwọ lati mu ipele ero wọn dara",
    "pid": "We dey allow students create and solve their own wahala and help improve the way dem d reason"
    },

    {
    "id": "in the 21st century",
    "en": "in the 21st century",
    "esp": "en el siglo XXI",
    "it": "nel 21° secolo",
    "fr": "au 21ème siècle",
    "hau": "a ƙarni na 21",
    "igb": "n’afọ 21st",
    "yor": "ni ọdun 21st",
    "pid": "for 21st century"
},
{
    "id": "Active till",
    "en": "Active till",
    "esp": "Activo hasta",
    "it": "Attivo fino a",
    "fr": "Actif jusqu'à",
    "hau": "Aiki har",
    "igb": "Na-arụ ọrụ ruo",
    "yor": "Ṣiṣẹ titi di",
    "pid": "Active till"
},
{
    "id": "Account Number Copied",
    "en": "Account Number Copied",
    "esp": "Número de cuenta copiado",
    "it": "Numero di conto copiato",
    "fr": "Numéro de compte copié",
    "hau": "Lambar asusu an kwafa",
    "igb": "Nọmba akaụntụ a kwadoro",
    "yor": "Nọmba àkọọlẹ ti ko",
    "pid": "Account Number Copied"
},

{
        "id": "Terms and Conditions for Calixguru",
        "en": "Terms and Conditions for Calixguru",
        "esp": "Términos y condiciones para Calixguru",
        "it": "Termini e condizioni per Calixguru",
        "fr": "Conditions générales pour Calixguru",
        "hau": "Sharuɗɗa da yanayi na Calixguru",
        "igb": "Okwu na ọnọdụ maka Calixguru",
        "yor": "Àwọn òrò àti Àwọn àtúnbí fún Calixguru",
        "pid": "Terms and Conditions for Calixguru"
    },

{
        "id": "Effective Date: July, 2024",
        "en": "Effective Date: July, 2024",
        "esp": "Fecha de entrada en vigor: julio de 2024",
        "it": "Data di entrata in vigore: luglio 2024",
        "fr": "Date d'entrée en vigueur : juillet 2024",
        "hau": "Ranar inganta: Yuli, 2024",
        "igb": "Ọnwa mmalite: July, 2024",
        "yor": "Ọjọ ti o ni ipa: Keje, 2024",
        "pid": "Date wey e go start: July, 2024"
    },
    {
        "id": "Terms and Conditions for Calixguru",
        "en": "Terms and Conditions for Calixguru",
        "esp": "Términos y condiciones para Calixguru",
        "it": "Termini e condizioni per Calixguru",
        "fr": "Conditions générales pour Calixguru",
        "hau": "Sharuɗɗa da yanayi na Calixguru",
        "igb": "Okwu na ọnọdụ maka Calixguru",
        "yor": "Àwọn òrò àti Àwọn àtúnbí fún Calixguru",
        "pid": "Terms and Conditions for Calixguru"
    },
    {    "id": "By using Calixguru, you agree to these Terms and Conditions. If you do not agree, please refrain from using the platform. Calixguru reserves the right to modify these terms at any time, and such modifications will be effective immediately upon posting.",
        "en": "By using Calixguru, you agree to these Terms and Conditions. If you do not agree, please refrain from using the platform. Calixguru reserves the right to modify these terms at any time, and such modifications will be effective immediately upon posting.",
        "esp": "Al utilizar Calixguru, usted acepta estos Términos y Condiciones. Si no está de acuerdo, por favor, absténgase de usar la plataforma. Calixguru se reserva el derecho de modificar estos términos en cualquier momento, y dichas modificaciones serán efectivas inmediatamente después de su publicación.",
        "it": "Utilizzando Calixguru, accetti questi Termini e Condizioni. Se non sei d'accordo, ti preghiamo di astenerti dall'utilizzare la piattaforma. Calixguru si riserva il diritto di modificare questi termini in qualsiasi momento e tali modifiche saranno efficaci immediatamente dopo la loro pubblicazione.",
        "fr": "En utilisant Calixguru, vous acceptez ces termes et conditions. Si vous n'êtes pas d'accord, veuillez vous abstenir d'utiliser la plateforme. Calixguru se réserve le droit de modifier ces termes à tout moment, et ces modifications prendront effet immédiatement après leur publication.",
        "hau": "Ta hanyar amfani da Calixguru, kun amince da waɗannan Sharuɗɗan da Yanayi. Idan baku yarda ba, da fatan za ku daina amfani da dandamali. Calixguru yana da haƙƙin canza waɗannan sharuɗɗan a kowane lokaci, kuma waɗannan canje-canje za su fara aiki nan take bayan an sanya su.",
        "igb": "Site n'iji Calixguru, ị kwenyere na Okwu na Ọnọdụ ndị a. Ọ bụrụ na ị naghị ekweta, biko gbanwee iji nyiwe ahụ. Calixguru nwere ikike ịgbanwe ọnọdụ ndị a n'oge ọ bụla, na mgbanwe ndị a ga-amalite ozugbo enwere ike.",
        "yor": "Nígbà tí o bá lo Calixguru, o gba àwọn òrò àti àwọn àtúnṣe yìí. Bí o kò bá gba, jọwọ má lo pẹpẹ náà. Calixguru ní ẹtọ láti tún àwọn òrò wọnyí ṣe nígbà gbogbo, àti àwọn àtúnṣe yìí yóò di mímúṣẹ lára láti ìgbà tí ó bá ti nífá ìtẹwé.",
        "pid": "Wey you dey use Calixguru, you agree to this Terms and Conditions. If you no agree, abeg no use the platform again. Calixguru fit change this terms anytime, and this change go start to dey work immediately when them post am."
    },
    {
        "id": "General Terms",
        "en": "General Terms",
        "esp": "Términos generales",
        "it": "Termini generali",
        "fr": "Termes généraux",
        "hau": "Sharuɗɗa na gaba ɗaya",
        "igb": "Ọnọdụ Ọmụma",
        "yor": "Àwọn òrò Gbogbo-gbò",
        "pid": "General Terms"
    },
    {    "id": "As a user of Calixguru, you agree to use the platform responsibly. You will not engage in any activities that are harmful, illegal, or disruptive to other users or to the platform itself. You are responsible for maintaining the confidentiality of your account information, including your password, and for all activities that occur under your account.",
        "en": "As a user of Calixguru, you agree to use the platform responsibly. You will not engage in any activities that are harmful, illegal, or disruptive to other users or to the platform itself. You are responsible for maintaining the confidentiality of your account information, including your password, and for all activities that occur under your account.",
        "esp": "Como usuario de Calixguru, usted acepta utilizar la plataforma de manera responsable. No se involucrará en actividades que sean perjudiciales, ilegales o disruptivas para otros usuarios o para la plataforma en sí. Usted es responsable de mantener la confidencialidad de la información de su cuenta, incluyendo su contraseña, y de todas las actividades que ocurran bajo su cuenta.",
        "it": "Come utente di Calixguru, accetti di utilizzare la piattaforma in modo responsabile. Non ti impegnerai in attività che siano dannose, illegali o dirompenti per gli altri utenti o per la piattaforma stessa. Sei responsabile di mantenere la riservatezza delle informazioni del tuo account, inclusa la tua password, e di tutte le attività che si verificano nel tuo account.",
        "fr": "En tant qu'utilisateur de Calixguru, vous acceptez d'utiliser la plateforme de manière responsable. Vous ne vous engagerez pas dans des activités nuisibles, illégales ou perturbatrices pour les autres utilisateurs ou pour la plateforme elle-même. Vous êtes responsable de la confidentialité des informations de votre compte, y compris votre mot de passe, et de toutes les activités qui se déroulent sous votre compte.",
        "hau": "A matsayin mai amfani da Calixguru, kun amince da yin amfani da dandamali cikin kulawa. Ba za ku shiga cikin ayyuka waɗanda suke da lahani ba, haramtacciya, ko kuma suka katse sauran masu amfani ko kuma dandalin kansa. Kuna da alhakin kiyaye sirrin bayanan asusun ku, ciki har da kalmar sirri, da duk ayyukan da suka faru a ƙarƙashin asusunku.",
        "igb": "Dị ka onye ọrụ Calixguru, ị kwenyere na iji nyiwe ahụ n'uche. Ị gaghị eji aka na ọrụ ọ bụla dị njọ, na-ezighị ezi, ma ọ bụ na-eme ka ndị ọrụ ndị ọzọ bụrụ ndị ọzọ ma ọ bụ na nyiwe n'onwe ya. Ị na-elekọta nchekwa nke ozi akaụntụ gị, gụnyere paswọọdụ gị, na maka ọrụ niile na-eme na akaụntụ gị.",
        "yor": "Gẹ́gẹ́ bí aṣojú Calixguru, o gba láti lo pẹpẹ náà pẹ̀lú ojúṣe. Wí pé ìwọ kò ní lo ni ṣe pẹlu àwọn iṣẹ́ ìbá jẹ́ náà, ìṣòro, tàbí èyí tí yóò máa dáwa láti lo pẹpẹ náà tàbí àwọn tó máa ń lo. O jẹ́ ojúṣe rẹ láti máa bójú tó ìkòkò ọrọ rẹ, àti gbogbo iṣẹ́ tí ó máa n ṣẹlẹ lábẹ́ àkọọlẹ rẹ.",
        "pid": "As a user of Calixguru, you don agree say you go dey use the platform well. You no go dey do wetin fit cause wahala for other people or the platform. You go make sure say you keep your account information and password well, and you go take care of wetin happen for your account."
    },
    { "id": "All content on Calixguru, including text, graphics, logos, images, and software, is the property of Calixguru or its content suppliers and is protected by intellectual property laws. Unauthorized use of any content on the platform is strictly prohibited. Users may not copy, distribute, or create derivative works based on any content from Calixguru without explicit permission.",
        "en": "All content on Calixguru, including text, graphics, logos, images, and software, is the property of Calixguru or its content suppliers and is protected by intellectual property laws. Unauthorized use of any content on the platform is strictly prohibited. Users may not copy, distribute, or create derivative works based on any content from Calixguru without explicit permission.",
        "esp": "Todo el contenido en Calixguru, incluyendo textos, gráficos, logotipos, imágenes y software, es propiedad de Calixguru o de sus proveedores de contenido y está protegido por las leyes de propiedad intelectual. El uso no autorizado de cualquier contenido en la plataforma está estrictamente prohibido. Los usuarios no pueden copiar, distribuir o crear obras derivadas basadas en cualquier contenido de Calixguru sin permiso explícito.",
        "it": "Tutti i contenuti su Calixguru, inclusi testi, grafica, loghi, immagini e software, sono di proprietà di Calixguru o dei suoi fornitori di contenuti e sono protetti dalle leggi sulla proprietà intellettuale. L'uso non autorizzato di qualsiasi contenuto sulla piattaforma è severamente vietato. Gli utenti non possono copiare, distribuire o creare opere derivate basate su qualsiasi contenuto di Calixguru senza esplicita autorizzazione.",
        "fr": "Tout le contenu sur Calixguru, y compris les textes, graphiques, logos, images et logiciels, est la propriété de Calixguru ou de ses fournisseurs de contenu et est protégé par les lois sur la propriété intellectuelle. L'utilisation non autorisée de tout contenu sur la plateforme est strictement interdite. Les utilisateurs ne peuvent pas copier, distribuer ou créer des œuvres dérivées basées sur tout contenu de Calixguru sans autorisation explicite.",
        "hau": "Dukkan abun ciki a Calixguru, gami da rubutu, zane-zane, tambura, hotuna, da software, mallakar Calixguru ne ko masu samar da abun ciki kuma ana kiyaye shi ta dokokin haƙƙin mallaka. An hana yin amfani da duk wani abun ciki akan dandalin ba tare da izini ba. Masu amfani ba za su iya kwafi, rarraba, ko ƙirƙirar ayyukan da aka samo daga duk wani abun ciki daga Calixguru ba tare da izini bayyananne ba.",
        "igb": "Ihe niile dị na Calixguru, gụnyere ederede, eserese, logos, onyonyo, na sọftụwia, bụ ihe nke Calixguru ma ọ bụ ndị na-enye ọdịnaya ya ma na-echebe ya site na iwu ikike echiche. Emeghị nke ọma iji ihe ọ bụla dị na nyiwe ahụ machibidoro. Ndị ọrụ agaghị ekwe ka ha copy, kesaa, ma ọ bụ mepụta ọrụ sitere na ọdịnaya ọ bụla site na Calixguru na-enweghị ikike doro anya.",
        "yor": "Gbogbo akoonu lori Calixguru, pẹlu ọrọ, eya, ami, aworan, ati sọfitiwia, jẹ ti Calixguru tabi awọn olupese akoonu rẹ ati pe o ni aabo nipasẹ awọn ofin ohun-ini ọpọlọ. Lilo ti ko gba laaye ti akoonu eyikeyi lori pẹpẹ jẹ eewọ ni muna. Awọn olumulo ko le daakọ, kaakiri, tabi ṣẹda awọn iṣẹ ipilẹ ti eyikeyi akoonu lati Calixguru laisi igbanilaaye kedere.",
        "pid": "All the content wey dey for Calixguru, including text, graphics, logos, images, and software, na property of Calixguru or the people wey dey supply content for the platform and the content dey protected by intellectual property laws. No be you get the right to use any content wey dey the platform anyhow. If you wan use any content wey dey Calixguru, you must get explicit permission before you go fit use am."
    },

    {"id": "Calixguru allows users to create and share content, including lessons, quizzes, and assessments. By submitting content to the platform, you grant Calixguru a non-exclusive, royalty-free, worldwide license to use, reproduce, modify, and distribute your content. You represent and warrant that you have the right to submit the content and that it does not infringe the rights of any third party.",
        "en": "Calixguru allows users to create and share content, including lessons, quizzes, and assessments. By submitting content to the platform, you grant Calixguru a non-exclusive, royalty-free, worldwide license to use, reproduce, modify, and distribute your content. You represent and warrant that you have the right to submit the content and that it does not infringe the rights of any third party.",
        "esp": "Calixguru permite a los usuarios crear y compartir contenido, incluyendo lecciones, cuestionarios y evaluaciones. Al enviar contenido a la plataforma, usted otorga a Calixguru una licencia no exclusiva, libre de regalías y a nivel mundial para usar, reproducir, modificar y distribuir su contenido. Usted declara y garantiza que tiene derecho a enviar el contenido y que no infringe los derechos de ningún tercero.",
        "it": "Calixguru consente agli utenti di creare e condividere contenuti, inclusi lezioni, quiz e valutazioni. Inviando contenuti alla piattaforma, concedi a Calixguru una licenza non esclusiva, esente da diritti d'autore, a livello mondiale, per utilizzare, riprodurre, modificare e distribuire i tuoi contenuti. Dichiarate e garantite di avere il diritto di inviare i contenuti e che questi non violano i diritti di terzi.",
        "fr": "Calixguru permet aux utilisateurs de créer et de partager du contenu, y compris des leçons, des quiz et des évaluations. En soumettant du contenu à la plateforme, vous accordez à Calixguru une licence non exclusive, libre de droits, mondiale pour utiliser, reproduire, modifier et distribuer votre contenu. Vous déclarez et garantissez que vous avez le droit de soumettre le contenu et qu'il ne porte pas atteinte aux droits d'un tiers.",
        "hau": "Calixguru yana ba masu amfani damar ƙirƙira da raba abun ciki, gami da darussan, tambayoyi, da kimantawa. Ta hanyar gabatar da abun ciki zuwa dandalin, kuna ba Calixguru lasisi wanda ba na musamman ba, ba tare da royalty ba, lasisi na duniya don amfani, haifuwa, gyara, da rarraba abun cikin ku. Kuna wakilta da tabbaci cewa kuna da haƙƙin gabatar da abun ciki kuma ba ya ƙeta haƙƙin kowane ɓangare na uku.",
        "igb": "Calixguru na-enye ndị ọrụ ohere ịmepụta na ịkekọrịta ọdịnaya, gụnyere ihe nkuzi, ajụjụ, na nyocha. Site n'ịnyefe ọdịnaya na nyiwe ahụ, ị na-enye Calixguru ikike na-abụghị nke pụrụ iche, enweghị ụgwọ royalty, ikike ụwa niile iji, mepụta, gbanwee, na kesaa ọdịnaya gị. Ị na-anọchi anya na nkwa na ị nwere ikike ịnyefe ọdịnaya ahụ na na ọ naghị emebi ikike nke ụdị ọ bụla nke atọ.",
        "yor": "Calixguru gba awon olumulo laaye lati se akoonu ati pin akoonu, eyi ti o wa pelu awon ikowe, awon ayewo ati awon idanwo. Nigba ti o ba ranse akoonu si pẹpẹ naa, o fun Calixguru ni aṣẹ alailẹgbẹ, laisi-royalty, aṣẹ agbaye lati lo, tun ṣe, ṣe atunṣe, ati pin akoonu rẹ. Iwọ n ṣàpẹẹrẹ ati bẹbẹ lọ pe o ni ẹtọ lati ranse akoonu naa ati pe ko da lori ẹtọ ẹnikẹta kankan.",
        "pid": "Calixguru dey allow users to create and share content, including lessons, quizzes, and assessments. If you submit content to the platform, you give Calixguru non-exclusive, royalty-free, worldwide license to use, reproduce, modify, and distribute your content. You go confirm say you get the right to submit the content and say the content no dey infringe on the rights of any third party."
    },
    {   "id": "Your privacy is important to us. Calixguru collects and uses personal information in accordance with our Privacy Policy. By using the platform, you consent to the collection and use of your information as described in the Privacy Policy.",
        "en": "Your privacy is important to us. Calixguru collects and uses personal information in accordance with our Privacy Policy. By using the platform, you consent to the collection and use of your information as described in the Privacy Policy.",
        "esp": "Su privacidad es importante para nosotros. Calixguru recopila y utiliza información personal de acuerdo con nuestra Política de Privacidad. Al utilizar la plataforma, usted consiente la recopilación y el uso de su información como se describe en la Política de Privacidad.",
        "it": "La tua privacy è importante per noi. Calixguru raccoglie e utilizza informazioni personali in conformità con la nostra Informativa sulla Privacy. Utilizzando la piattaforma, acconsenti alla raccolta e all'utilizzo delle tue informazioni come descritto nell'Informativa sulla Privacy.",
        "fr": "Votre vie privée est importante pour nous. Calixguru collecte et utilise des informations personnelles conformément à notre Politique de Confidentialité. En utilisant la plateforme, vous consentez à la collecte et à l'utilisation de vos informations comme décrit dans la Politique de Confidentialité.",
        "hau": "Sirrin ku yana da mahimmanci a gare mu. Calixguru yana tattarawa da amfani da bayanan sirri bisa ga manufar mu ta sirri. Ta hanyar amfani da dandalin, kun yarda da tattarawa da amfani da bayananku kamar yadda aka bayyana a cikin Dokar Sirri.",
        "igb": "Nzuzo gị dị mkpa maka anyị. Calixguru na-anakọta ma jiri ozi nkeonwe dị ka iwu Nzuzo anyị si dị. Site n'iji nyiwe ahụ, ị na-ekweta na anakọta ma jiri ozi gị dị ka e depụtara na iwu Nzuzo.",
        "yor": "Ìgbéyàwò rẹ ṣe pàtàkì sí wa. Calixguru ń gba àti lo ìwé àkọọlẹ rẹ gẹ́gẹ́ bí Ìlànà Àkọọlẹ wa. Nígbà tí o bá lo pẹpẹ náà, o gba láti fún ní ìwé àkọọlẹ rẹ àti lo èyí gẹ́gẹ́ bí Ìlànà Àkọọlẹ.",
        "pid": "Your privacy dey important to us. Calixguru dey collect and use personal information according to our Privacy Policy. If you dey use the platform, you don agree say you go allow us to collect and use your information as we talk for our Privacy Policy."
    },
    {    "id": "Calixguru is provided \"as is\" and \"as available\" without any warranties, express or implied. Calixguru does not guarantee the accuracy, reliability, or availability of the platform or its content. To the fullest extent permitted by law, Calixguru disclaims all liability for any damages arising out of or in connection with the use of the platform.",
        "en": "Calixguru is provided \"as is\" and \"as available\" without any warranties, express or implied. Calixguru does not guarantee the accuracy, reliability, or availability of the platform or its content. To the fullest extent permitted by law, Calixguru disclaims all liability for any damages arising out of or in connection with the use of the platform.",
        "esp": "Calixguru se proporciona \"tal cual\" y \"según disponibilidad\" sin ninguna garantía, expresa o implícita. Calixguru no garantiza la exactitud, fiabilidad o disponibilidad de la plataforma o su contenido. En la máxima medida permitida por la ley, Calixguru rechaza toda responsabilidad por cualquier daño que surja o esté relacionado con el uso de la plataforma.",
        "it": "Calixguru è fornito \"così com'è\" e \"come disponibile\" senza alcuna garanzia, espressa o implicita. Calixguru non garantisce l'accuratezza, l'affidabilità o la disponibilità della piattaforma o dei suoi contenuti. Nella misura massima consentita dalla legge, Calixguru declina ogni responsabilità per eventuali danni derivanti da o in connessione con l'uso della piattaforma.",
        "fr": "Calixguru est fourni \"tel quel\" et \"selon disponibilité\" sans aucune garantie, expresse ou implicite. Calixguru ne garantit pas l'exactitude, la fiabilité ou la disponibilité de la plateforme ou de son contenu. Dans toute la mesure permise par la loi, Calixguru décline toute responsabilité pour tout dommage résultant de ou en relation avec l'utilisation de la plateforme.",
        "hau": "Calixguru yana samuwa \"kamar yadda yake\" kuma \"kamar yadda ake samu\" ba tare da wata tabbaci ba, bayyananne ko an fahimta. Calixguru baya ba da tabbacin daidaito, aminci, ko samun damar dandalin ko abubuwan ciki. Har zuwa mafi girman izinin doka, Calixguru yana ƙin duk wata alhakin ga duk wani lahani da ya taso daga ko yana da alaƙa da amfani da dandalin.",
        "igb": "A na-enye Calixguru “dị ka o si dị” na “dị ka a ga-enweta” na-enweghị nkwa ọ bụla, nkwupụta ma ọ bụ nghọta. Calixguru adịghị ekwe nkwa izi ezi, ntụkwasị obi, ma ọ bụ nnweta nke nyiwe ma ọ bụ ọdịnaya ya. Na oke kacha kwere mee n'okpuru iwu, Calixguru na-ewepụ ọrụ ọ bụla maka mmebi ọ bụla sitere na ma ọ bụ n'ime njikọ na iji nyiwe ahụ.",
        "yor": "Calixguru nípamọ “bí ó ti ń jẹ́” àti “bí ó ti wà”, láìsí àbẹ́yọrí, ìtẹ́wọ́gba tàbí ìdárí. Calixguru kò ṣe ìdíyèwò pé gbogbo ẹ̀dá, ààyè tàbí ìgbàdá-lé, lẹ́nu, tàbí pẹpẹ náà tàbí àkóónú rẹ̀. Ni ìlànà tí ó pé níwọ́n òfin, Calixguru kì yóò gbéjọ́ ẹ̀jọ́ fún gbogbo àwọn ìpalára tàbí ìpalára tí wọ́n ń ṣẹlẹ̀ láìsí àkóónú pẹpẹ náà.",
        "pid": "Calixguru dey provided “as is” and “as available” without any warranties, express or implied. Calixguru no dey guarantee the accuracy, reliability, or availability of the platform or the content wey dey the platform. To the fullest extent wey the law allow, Calixguru dey disclaim any liability for any damages wey go come from or dey related to the use of the platform."
    },
     {
        "id": "If you have any questions or concerns about these Terms and Conditions, please contact us at support@calixguru.com.",
        "en": "If you have any questions or concerns about these Terms and Conditions, please contact us at support@calixguru.com.",
        "esp": "Si tiene alguna pregunta o inquietud sobre estos Términos y Condiciones, comuníquese con nosotros a support@calixguru.com.",
        "it": "Se hai domande o dubbi su questi Termini e condizioni, contattaci a support@calixguru.com.",
        "fr": "Si vous avez des questions ou des préoccupations concernant ces Termes et Conditions, veuillez nous contacter à support@calixguru.com.",
        "hau": "Idan kuna da wasu tambayoyi ko damuwa game da waɗannan Sharuɗɗan da Yanayi, don Allah a tuntube mu a support@calixguru.com.",
        "igb": "Ọ bụrụ na ị nwere ajụjụ ma ọ bụ nchegbu gbasara ndị a Terms and Conditions, biko kpọtụrụ anyị na support@calixguru.com.",
        "yor": "Tí o bá ní àwọn ìbéèrè tàbí àníyàn nípa àwọn Ìpinnu àti Àwọn Òfin yìí, jọwọ pe wa ní support@calixguru.com.",
        "pid": "If you get any question or concern about these Terms and Conditions, abeg contact us for support@calixguru.com."
    },
    {
    "id": "If you have any questions or concerns about these Terms and Conditions, please contact us via our ",
    "en": "If you have any questions or concerns about these Terms and Conditions, please contact us via our ",
    "esp": "Si tienes alguna pregunta o inquietud sobre estos Términos y Condiciones, comunícate con nosotros a través de nuestro ",
    "it": "Se hai domande o preoccupazioni riguardo a questi Termini e Condizioni, contattaci tramite il nostro ",
    "fr": "Si vous avez des questions ou des préoccupations concernant ces Termes et Conditions, veuillez nous contacter via notre ",
    "hau": "Idan kuna da tambayoyi ko damuwa game da waɗannan Sharuɗɗan da Yanayi, don Allah ku tuntuɓe mu ta hanyar ",
    "igb": "Ọ bụrụ na ị nwere ajụjụ ma ọ bụ nchegbu gbasara Okwu na Ọnọdụ ndị a, biko kpọtụrụ anyị site na ",
    "yor": "Ti o ba ni awọn ibeere tabi awọn iṣoro nipa Awọn ofin ati Awọn ipo wọnyi, jọwọ kan si wa nipasẹ ",
    "pid": "If you get any question or wahala about these Terms and Conditions, abeg contact us through our "
},
{
    "id": "email",
    "en": "email",
    "esp": "correo electrónico",
    "it": "email",
    "fr": "email",
    "hau": "imel",
    "igb": "email",
    "yor": "imeeli",
    "pid": "email"
},
{
    "id": "or",
    "en": "or",
    "esp": "o",
    "it": "o",
    "fr": "ou",
    "hau": "ko",
    "igb": "ma",
    "yor": "tabi",
    "pid": "or"
},
{
    "id": "whatsapp",
    "en": "whatsapp",
    "esp": "whatsapp",
    "it": "whatsapp",
    "fr": "whatsapp",
    "hau": "whatsapp",
    "igb": "whatsapp",
    "yor": "whatsapp",
    "pid": "whatsapp"
},
{
    "id": "Language changed to",
    "en": "Language changed to",
    "esp": "Idioma cambiado a",
    "it": "Lingua cambiata a",
    "fr": "Langue changée en",
    "hau": "Harshe an canza zuwa",
    "igb": "Asụsụ gbanwere na",
    "yor": "Ede ti yipada si",
    "pid": "Language don change to"
},
{
        "id": "Account Created Successfully",
        "en": "Account Created Successfully",
        "esp": "Cuenta creada con éxito",
        "it": "Account creato con successo",
        "fr": "Compte créé avec succès",
        "hau": "An ƙirƙiri asusun cikin nasara",
        "igb": "Akwụkwọ ndebanye aha emere nke ọma",
        "yor": "Iṣẹ́ aṣàdá àkọọlẹ́ ni aṣeyọrí",
        "pid": "Account creation dey alright now"
    },
    {
        "id": "Details Edited Successfully",
        "en": "Details Edited Successfully",
        "esp": "Detalles editados con éxito",
        "it": "Dettagli modificati con successo",
        "fr": "Détails modifiés avec succès",
        "hau": "Bayanai sun canza cikin nasara",
        "igb": "Nkọwa gbanwere nke ọma",
        "yor": "Alaye ti yipada ni aṣeyọrí",
        "pid": "Details don edit successfully"
    },
    {
        "id": "Post Unsuccessful",
        "en": "Post Unsuccessful",
        "esp": "Publicación no exitosa",
        "it": "Post non riuscito",
        "fr": "Publication échouée",
        "hau": "Sako bai yi nasara ba",
        "igb": "Ozi ahụghị éxito",
        "yor": "Ìwé náà kọ́ ṣeyọrí",
        "pid": "Post no dey successful"
    },
    {
        "id": "Post Successful, Awaiting Approval",
        "en": "Post Successful, Awaiting Approval",
        "esp": "Publicación exitosa, en espera de aprobación",
        "it": "Post riuscito, in attesa di approvazione",
        "fr": "Publication réussie, en attente d'approbation",
        "hau": "Sako ya yi nasara, ana jiran amincewa",
        "igb": "Ozi rụrụ nke ọma, na-eche nkwenye",
        "yor": "Ìwé náà ti ṣeyọrí, ń retí ìmúlọ́kànṣo",
        "pid": "Post don dey successful, chill for approval"
    },
    {
        "id": "Login Successful",
        "en": "Login Successful",
        "esp": "Inicio de sesión exitoso",
        "it": "Accesso riuscito",
        "fr": "Connexion réussie",
        "hau": "Shiga ciki ya yi nasara",
        "igb": "Nbanye gara nke ọma",
        "yor": "Ìbáṣepọ̀ wọlé ṣeyọrí",
        "pid": "Login dey alright"
    },
    {
        "id": "Invalid Credentials",
        "en": "Invalid Credentials",
        "esp": "Credenciales inválidas",
        "it": "Credenziali non valide",
        "fr": "Identifiants invalides",
        "hau": "Bayanai ba su yi daidai ba",
        "igb": "Ozi nkwenye adịghị mma",
        "yor": "Ìmọ̀lára kì í ṣe tó",
        "pid": "Credentials no dey valid"
    },
    {
    "id": "Learn the simplest way with Calixguru",
    "en": "Learn the simplest way with Calixguru",
    "esp": "Aprende de la manera más simple con Calixguru",
    "it": "Impara nel modo più semplice con Calixguru",
    "fr": "Apprenez de la manière la plus simple avec Calixguru",
    "hau": "Koyi hanyar mafi sauƙi tare da Calixguru",
    "igb": "Mụta ụzọ kachasị mfe na Calixguru",
    "yor": "Kọ ẹkọ ni ọna ti o rọọrun julọ pẹlu Calixguru",
    "pid": "Learn for the simplest way with Calixguru"
},
{
    "id": "Please select areas of concentration to continue",
    "en": "Please select areas of concentration to continue",
    "esp": "Por favor seleccione áreas de concentración para continuar",
    "it": "Si prega di selezionare le aree di concentrazione per continuare",
    "fr": "Veuillez sélectionner des domaines de concentration pour continuer",
    "hau": "Don Allah zaɓi yankuna na hankali don ci gaba",
    "igb": "Biko họrọ ebe mmasị ka ị gaa n'ihu",
    "yor": "Jọwọ yan awọn agbegbe ti idojukọ lati tẹsiwaju",
    "pid": "Abeg select areas wey you wan focus on to continue"
},
{
    "id": "Please select at least one topic to study",
    "en": "Please select at least one topic to study",
    "esp": "Por favor seleccione al menos un tema para estudiar",
    "it": "Si prega di selezionare almeno un argomento da studiare",
    "fr": "Veuillez sélectionner au moins un sujet à étudier",
    "hau": "Don Allah zaɓi aƙalla jigo ɗaya don yin nazari",
    "igb": "Biko họrọ opekata mpe otu isiokwu ka ị mụta",
    "yor": "Jọwọ yan o kere ju akọle kan lati kẹkọọ",
    "pid": "Abeg select at least one topic wer you wan study"
},
{
    "id": "You selected the following courses",
    "en": "You selected the following courses",
    "esp": "Has seleccionado los siguientes cursos",
    "it": "Hai selezionato i seguenti corsi",
    "fr": "Vous avez sélectionné les cours suivants",
    "hau": "Ka zabi darussan masu zuwa",
    "igb": "Ị họọrọ ndị a dị ka ndekọ ọmụmụ",
    "yor": "O yan awọn iṣẹ́ tó tẹ̀lé",
    "pid": "You don select these courses"
},
{
    "id": "Continue",
    "en": "Continue",
    "esp": "Continuar",
    "it": "Continua",
    "fr": "Continuer",
    "hau": "Ci gaba",
    "igb": "Gaa n’ihu",
    "yor": "Tesiwaju",
    "pid": "Oya na"
},
{
    "id": "Courses selected",
    "en": "Courses selected",
    "esp": "Cursos seleccionados",
    "it": "Corsi selezionati",
    "fr": "Cours sélectionnés",
    "hau": "An zaɓi darussa",
    "igb": "A họọrọ ndekọ ọmụmụ",
    "yor": "Àwọn ìṣe ti a yàn",
    "pid": "Courses wey you select"
},
{
    "id": "Next",
    "en": "Next",
    "esp": "Siguiente",
    "it": "Prossimo",
    "fr": "Suivant",
    "hau": "Na gaba",
    "igb": "Nke ọzọ",
    "yor": "Tó kàn",
    "pid": "Next"
},
{
    "id": "Previous",
    "en": "Previous",
    "esp": "Anterior",
    "it": "Precedente",
    "fr": "Précédent",
    "hau": "Na baya",
    "igb": "Nke gara aga",
    "yor": "Tẹlẹ",
    "pid": "Before"
},
{
    "id": "Take Test",
    "en": "Take Test",
    "esp": "Tomar Prueba",
    "it": "Fare il Test",
    "fr": "Passer le Test",
    "hau": "Yi Gwajin",
    "igb": "Were Ule",
    "yor": "Ṣe Àdánwò",
    "pid": "Run Test"
},
{
    "id": "Activate",
    "en": "Activate",
    "esp": "Activar",
    "it": "Attivare",
    "fr": "Activer",
    "hau": "Kunna",
    "igb": "Ruo ọrụ",
    "yor": "Mu ṣiṣẹ",
    "pid": "Activate"
},
{
    "id": "Add your phone number",
    "en": "Add your phone number",
    "esp": "Agrega tu número de teléfono",
    "it": "Aggiungi il tuo numero di telefono",
    "fr": "Ajoutez votre numéro de téléphone",
    "hau": "Ƙara lambar wayarku",
    "igb": "Tinye nọmba ekwentị gị",
    "yor": "Ṣafikun nọmba foonu rẹ",
    "pid": "Add your phone number"
},
{
    "id": "Add your whatsapp link",
    "en": "Add your whatsapp link",
    "esp": "Agrega tu enlace de whatsapp",
    "it": "Aggiungi il tuo link whatsapp",
    "fr": "Ajoutez votre lien whatsapp",
    "hau": "Ƙara hanyar haɗin whatsapp ɗinku",
    "igb": "Tinye njikọ whatsapp gị",
    "yor": "Ṣafikun ọna asopọ whatsapp rẹ",
    "pid": "Add your whatsapp link"
}

]

# @register.filter(name='translate')
# def translate(id_value, id):
#     try:
#         user = User.objects.get(id=id)
#         user_language = user.language.lower()
#         translation = next((d[user_language] for d in translations if d["id"] == id_value), None)
#         emerge = id_value
#         return translation if translation else emerge
#     except User.DoesNotExist:
#         emerge = id_value
#         return emerge


@register.filter(name='new_translate')
def new_translate(id_value, la):
    translation = next((d[la] for d in translations if d["id"] == id_value), None)
    emerge = id_value
    return translation if translation else emerge

@register.filter(name='remove')
def remove(value):
    if isinstance(value, str) and len(value) > 2:
        return value[2:]
    return value

@register.filter(name='first')
def first(value):
    if isinstance(value, str):
        return value[:20]
    return value

@register.filter(name='first2')
def first2(value):
    if isinstance(value, str):
        ret = []
        return value.strip().split(' ')[0]
    return value

@register.filter(name='first3')
def first3(value):
    words = value.split()
    if not words:
        return ''
    first = words[0][:3]
    last = words[-1][:3] if len(words) > 1 else ''
    return f'{first}/{last}'.strip()

@register.filter(name='map')
def correct(value):
    map = {'A':0,'B':1,'C':2,'D':3,}
    return map.get(value, value)

@register.filter(name='answer')
def answer(value):
    if isinstance(value, str) and len(value) > 2:
        return value[0]
    return value

@register.filter(name='uppercase')
def uppercase(value):
    return value.upper()

# @register.filter(name='time')
# def time(value):
#     return value.upper()

@register.filter(name='shuffle')
def shuffle(value):
    if isinstance(value, list):
        shuff = list(value)
        random.shuffle(shuff)
        return shuff[:20]
    return value

@register.filter(name='shuffle2')
def shuffle(value, num):
    if isinstance(value, list):
        shuff = list(value)
        random.shuffle(shuff)
        return shuff[:num]
    return value

@register.filter(name='rand')
def rand(value):
    ran = random.choice(value)
    return ran

@register.filter(name='rep')
def rep(value):
    ran = value.replace('"', '*')
    return ran

@register.filter(name='replace')
def replace(value):
    return value.replace('-', ' ')


@register.filter(name='lastcalc')
def lastcalc(value,target):
    output = []
    for num in value:
        if num == target:
            break
        output.append(num)
    return output

@register.filter(name='count')
def count(value):
    """
    Converts a large number into a human-readable format,
    like 1.5K, 2.3M, 4.2B, etc.
    """
    try:
        value = float(value)
    except (ValueError, TypeError):
        return value  # Return the original value if conversion fails

    if value >= 1000000000:
        return f'{value / 1000000000:.1f}B'
    elif value >= 1000000:
        return f'{value / 1000000:.1f}M'
    elif value >= 1000:
        return f'{value / 1000:.0f}K'
    else:
        return str(int(value))


@register.filter(name='single_space')
def single_space(value):
    """
    Replaces multiple spaces with a single space in the given string.
    """
    if isinstance(value, str):
        return re.sub(r'\s+', ' ', value)
    return value

@register.filter(name='time_left')
def time_left(date, left):
    duration = {'daily': 2, 'weekly': 8, 'monthly': 32, }
    future = date + timedelta(days=duration[left])
    time = future - timezone.now()
    return future

@register.filter(name='options')
def options(value):
    opts = {1:'A', 2:'B', 3:'C', 4:'D', 'null': ''}
    return opts[value]

@register.filter
def pin_status(pin):
    try:
        user = Pinbin.objects.get(pin=pin)
        return user.name.email
    except Pinbin.DoesNotExist:
        return "No owner"

@register.filter
def zip_lists(a, b):
    return zip(a, b)

@register.filter
def get_item(lst, idx):
    try:
        return lst[idx]
    except (IndexError, TypeError):
        return None

@register.filter(name='replace_asterisk')
def replace_asterisk(value):
    """
    Replaces all '*' characters in the string with '"'.
    """
    if isinstance(value, str):
        return value.replace('*', '"').replace('—', ' ')
    return value  # Return unchanged if not a string

@register.filter(name='remove_asterisk')
def remove_asterisk(value):
    """
    Replaces all '*' characters in the string with ''.
    """
    if isinstance(value, str):
        return value.replace('-', ' ')
    return value  # Return unchanged if not a string

@register.filter(name='replace_pdf')
def replace_pdf(value):
    return value.replace(".pdf", "_compressed.pdf")

@register.filter(name='display_details')
def display_details(user_id):
    try:
        user = User.objects.get(id=user_id)
        return f"{user.firstname} {user.lastname}"
    except User.DoesNotExist:
        return "No name" # Return None if the user doesn't exist

@register.filter(name='get_user_dept')
def get_user_dept(user_id):
    try:
        user = League.objects.get(id=user_id)
        return f"{user.department}"
    except League.DoesNotExist:
        return "Eliminated" # Return None if the user doesn't exist

@register.filter
def zip_lists(a, b):
    """Zips two lists together."""
    return zip(a, b)

@register.filter
def ordinal(value):
    try:
        value = int(value)
        if 10 <= value % 100 <= 20:  # Special case for 11th, 12th, 13th, etc.
            suffix = "th"
        else:
            suffixes = {1: "st", 2: "nd", 3: "rd"}
            suffix = suffixes.get(value % 10, "th")
        return f"{value}{suffix}"
    except (ValueError, TypeError):
        return value  # Return the original value if it's not a number

@register.filter
def get_item2(dictionary, key):
    """Fetches the value from a dictionary using the given key."""
    return dictionary.get(str(key), None)

@register.filter(name='get_course')
def get_course(value):
    # c = {'Mathematics': "MTH121",'Physics': "PHY121",'General Studies': "GST112",
            # 'Chemistry':"CHM121",'Biology': "BIO121", 'General Studies': "EDU121"}
    c = {"MTH": 'Mathematics', "PHY": 'Physics', "GST": 'General Studies', 'JIL': 'Legal Methods',
            "CHM": 'Chemistry', "BIO": 'Biology', "EDU": 'Education', "GK": 'General Knowledge', "Opal Rumble": 'Opal Rumble'}
    return c[value]

@register.filter(name='to_list')
def to_list(value):
    return ast.literal_eval(value)

@register.filter(name='roun')
def roun(value):
    return round(value, 2)


@register.filter
def sci_to_std(value):
    """
    Convert scientific notation (e.g., 4e-6) to standard form like 4 × 10<sup>-6</sup>
    """
    try:
        value = str(value)
        match = re.match(r'^([\-]?\d*\.?\d+)[eE]([\-+]?\d+)$', value)
        if match:
            base, exponent = match.groups()
            return f'{base} × 10<sup>{int(exponent)}</sup>'
        return value
    except:
        return value
    

@register.filter
def cut_after_dots(value, count=2):
    """
    Cuts the text after the specified number of full stops.
    Usage in template: {{ text|cut_after_dots:3 }}
    """
    if not isinstance(value, str):
        return value

    sentences = value.split('.')
    if len(sentences) <= count:
        return value

    shortened = '.'.join(sentences[:count]) + '.'
    return shortened.strip()