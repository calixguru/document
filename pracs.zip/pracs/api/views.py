from rest_framework.decorators import api_view
from rest_framework.response import Response
from pracs.models import User, Cbtroom
from .serializers import UserSerializer, RoomSerializer
from pracs.api import serializers
# from django.contrib.auth.models import User
from rest_framework import status
from pracs.forms import Request, MyUserCreationForm, Pin, UserForm

@api_view(['GET'])
def getRoutes(request):
    routes = [
        'GET /api',
        'GET /api/user',
        'GET /api/user/:id',
        'GET /api/rooms',
        'GET /api/room/:id'
    ]
    return Response(routes)


@api_view(['GET'])
def getUsers(request):
    user = User.objects.all()
    serializer = UserSerializer(user, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def getUser(request, pk):
    user = User.objects.get(id=pk)
    serializer = UserSerializer(user, many=False)
    return Response(serializer.data)


@api_view(['GET'])
def getRooms(request):
    rooms = Cbtroom.objects.all()
    serializer = RoomSerializer(rooms, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def getRoom(request, pk):
    room = Cbtroom.objects.get(id=pk)
    serializer = RoomSerializer(room, many=False)
    return Response(serializer.data)

@api_view(['POST'])
def createUser(request):
    if request.method == 'POST':
        email = request.data.get('email')
        firstname = request.data.get('firstname')
        lastname = request.data.get('lastname')
        password = request.data.get('password')
        if not email or not firstname or not lastname or not password:
            return Response({'error': 'Email, Firstname, Lastname and Password are required'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            if User.objects.filter(email=email):
                return Response({'error': 'Email already exists'}, status=status.HTTP_400_BAD_REQUEST)
            else:
                user = User.objects.create(email=email, firstname=firstname, lastname=lastname)
                user.set_password(password)
                user.save()
                return Response({'message': 'User created successfully'}, status=status.HTTP_201_CREATED)
    


# {"firstname": "Joy2","lastname": "Otu2","email": "joyiniotu2@gmail.com","password":"Marriage1084"}
