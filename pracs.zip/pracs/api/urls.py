from django.urls import path
from . import views

urlpatterns = [
    path('',  views.getRoutes),
    path('users/', views.getUsers),
    path('user/<str:pk>/', views.getUser),
    path('rooms/', views.getRooms),
    path('createuser/', views.createUser),
    path('room/<str:pk>/', views.getRoom),
]
