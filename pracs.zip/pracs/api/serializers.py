from rest_framework.serializers import ModelSerializer
from pracs.models import User, Cbtroom


class UserSerializer(ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'


class RoomSerializer(ModelSerializer):
    class Meta:
        model = Cbtroom
        fields = '__all__'

