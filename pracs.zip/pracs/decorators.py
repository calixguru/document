from functools import wraps
from .models import Pins, User, Cbtroom
from django.shortcuts import render, redirect
from django.contrib import messages




def cbt_room(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        subs = []
        for v in Cbtroom.objects.all():
            for i in v.allowed:
                subs.append(i)
        if request.user.is_authenticated and request.user.email in subs:
            return view_func(request, *args, **kwargs)
        messages.error(request, "You must be a subscriber in at least 1 CBT room to use this feature")
        return redirect("cbt")
    return _wrapped_view

# def monthly(func):
#     @wraps(func)
#     def wrapper(*args, **kwargs):
#         ids = []
#         for i in Pins.objects.filter(pin=request.user.id):
#             ids.append(i.pin)
#         if request.user.id in ids:
#             return func(*args, **kwargs)
#         else:
#             messages.error(request, "Only monthly subscribers can create a room")
#             return redirect(request.META.get('HTTP_REFERER', '/'))
#     return wrapper

def monthly(func):
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        try:
            check = Pins.objects.filter(pin = request.user.id)
            if check.duration == 'monthly':
                return func(request, *args, **kwargs)
            else:
                messages.error(request, "Only monthly subscribers can use that")
                return redirect(request.META.get('HTTP_REFERER', '/'))
        except:
            messages.error(request, "Only monthly subscribers can use that")
            return redirect(request.META.get('HTTP_REFERER', '/'))
    return wrapper

from functools import wraps
from django.shortcuts import redirect
from django.contrib.auth.models import User

def check_user_in_database(model, redirect_view_name):
    """
    A decorator to check if a user's ID exists in the given model.

    Args:
        model (django.db.models.Model): The model to query for the user ID.
        redirect_view_name (str): The name of the view to redirect to if the check fails.

    Usage:
        @check_user_in_database(MyModel, 'redirect_view_name')
        def my_view(request):
            ...
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            # Get the logged-in user's ID
            user_id = request.user.id

            # Check if the user ID exists in the database model
            if not model.objects.filter(id=user_id).exists():
                return redirect(redirect_view_name)

            # Proceed to the view if the check passes
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator

