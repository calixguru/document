from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(User)
admin.site.register(Pins)
admin.site.register(Pinbin)
admin.site.register(Req)
admin.site.register(Cbtroom)
admin.site.register(Message)
admin.site.register(Tutor)
admin.site.register(Pays)
admin.site.register(CoverPage)
admin.site.register(Room)
admin.site.register(Question)
admin.site.register(Questions)
admin.site.register(BlogPost)
admin.site.register(TakenT)
admin.site.register(Payment)
admin.site.register(Contact)
admin.site.register(UploadedFile)
admin.site.register(League)
# admin.site.register(Mails)
