
import random
import hashlib
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse
import random
from .models import *
from .assignment import uniuyo1, uniuyo2, uniuyo3, uniuyo4, uniuyo5, uniuyo6, uniuyo7, uniuyo8, uniuyo9, akscoe1, akscoe2, uniuyo10, uniuyo11, uniuyo56
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.core.mail import EmailMessage
from django.conf import settings
from io import BytesIO
from django.http import JsonResponse
from .models import Asspin
from pracs.league import questions
from .pins import CoverBorders

import datetime
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from django.http import FileResponse


covers = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,27]

@login_required(login_url='login')
def uniuyo_ass(request):
    # Define common context
    schools = {'uniuyo': 'UNIVERSITY OF UYO',
               'aksu': 'AKWA IBOM STATE UNIVERSITY',
               'akscoe': 'AKWA IBOM STATE COLLEGE OF EDUCATION'}
    name = request.GET.get('name').upper()
    reg = request.GET.get('reg').upper()
    ass = request.GET.get('ass')
    dept = request.GET.get('dept').upper()
    fac = request.GET.get('fac').upper()
    institution = schools[request.GET.get('inst')]
    
    if ass.lower() == 'GST211(book1)'.lower():
        context = {
            'list': list(range(1, 101)),
            'chapter': [1, 2, 3, 4, 5, 6, 7, 8, 9],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'Take a CBT test on book 1',
            'info': 'You are about to download a review for the initial GST textbook',
            'choice': 'chapter',
            'main_list': uniuyo1,  # Assuming dbdemo2 is defined for book 2
            'dblink': 'cbtb1',
            'text': 'text1'
        }

        # Determine which book's data to use

        if request.method == "POST":
            user = request.user
            if Pins.objects.filter(pin=user.id):
                try:
                    num = int() - 1
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    messages.error(request, "Please enter valid details")
                    return redirect(request.path)

                first_name = user.firstname
                last_name = user.lastname

                def shuffle_lists(main_list, choice):
                    for inner_list in main_list:
                        random.seed(choice)
                        random.shuffle(inner_list)
                    return main_list

                def shuffle_list(main_list, choice):
                    random.seed(choice)
                    random.shuffle(main_list)
                    return main_list

                main_list = context['main_list'].chapters[num]
                shuffled_main_list = shuffle_lists(main_list['body'], choice)
                intro = shuffle_list(main_list['intro'], choice)
                end = shuffle_list(main_list['conclusion'], choice)

                html_string = render_to_string('pdf/cover_page.html', {
                    'data': shuffled_main_list,
                    'main': main_list,
                    'chapter': num + 1,
                    'intro': intro,
                    'end': end,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'cor': 'Dr. Sunday Akpan'.upper(),
                    'course': 'gst211: philosophy and human existence'.upper(),
                    'department': 'department of philosophy'.upper()
                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')

        return render(request, 'base/gst.html', context)
    elif ass.lower() == 'GST211(book2)'.lower():
        context = {
            'list': list(range(1, 101)),
            'chapter': [1, 2, 3, 4, 5, 6, 7, 8, 9],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'Take a CBT test on book 2',
            'info': 'You are about to download a review for the 2nd GST textbook',
            'choice': 'chapter',
            'main_list': uniuyo2,  # Assuming dbdemo2 is defined for book 2
            'dblink': 'cbtb2',
            'text': 'text2'
        }

        # Determine which book's data to use

        if request.method == "POST":
            user = request.user
            if Pins.objects.filter(pin=user.id):
                try:
                    num = int(request.POST.get("chapter")) - 1
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    messages.error(request, "Please enter valid details")
                    return redirect(request.path)

                first_name = user.firstname
                last_name = user.lastname

                def shuffle_lists(main_list, choice):
                    for inner_list in main_list:
                        random.seed(choice)
                        random.shuffle(inner_list)
                    return main_list

                def shuffle_list(main_list, choice):
                    random.seed(choice)
                    random.shuffle(main_list)
                    return main_list

                main_list = context['main_list'].chapters[num]
                shuffled_main_list = shuffle_lists(main_list['body'], choice)
                intro = shuffle_list(main_list['intro'], choice)
                end = shuffle_list(main_list['conclusion'], choice)

                html_string = render_to_string('pdf/cover_page.html', {
                    'data': shuffled_main_list,
                    'main': main_list,
                    'chapter': num + 1,
                    'intro': intro,
                    'end': end,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'cor': 'Dr. Sunday Akpan'.upper(),
                    'course': 'gst211: philosophy and human existence'.upper(),
                    'department': 'department of philosophy'.upper()

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')

        return render(request, 'base/gst.html', context)
    elif ass.lower() == 'LIT214'.lower():
        context = {
            'list': list(range(1, 151)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'notyet',
            'info': '''You are about to download LIT214 assignment for contrast
            and comparison of Chinua Achebe's 'Things fall apart' and Abasseno Uko's Joe Levi and the prince of persia''',
            'choice': 'chapter',
            'main_list': uniuyo4,
            'dblink': 'cbtb2',
            'text': 'text2'
        }
        # Determine which book's data to use
        choices = []
        for i in Gst2.objects.all():
            choices.append(i.score)
        context['choices'] = choices
        books = uniuyo4.books
        if request.method == "POST":
            user = request.user
            choice = int(request.POST.get("choice"))
            if user.has_downloaded > 0:

                def generate_spaced_combinations():
                    book = books[0]  # Assuming we are working with book ID 1

                    combinations = []
                    num_combinations = 150

                    for i in range(num_combinations):
                        # Get spaced out indices for each category
                        intro_idx = (i * 3) % len(book["Introduction"])
                        theme_idx = (i * 7) % len(book["Theme"])
                        charac_idx = (i * 5) % len(book["Character"])
                        con_idx = (i * 11) % len(book["Conflict"])
                        story_idx = (i * 7) % len(book["Story"])
                        concl_idx = (i * 5) % len(book["Conclusion"])

                        combinations.append({
                            "Introduction": book["Introduction"][intro_idx],
                            "Theme": book["Theme"][theme_idx],
                            "Character": book["Character"][charac_idx],
                            "Conflict": book["Conflict"][con_idx],
                            "Story": book["Story"][story_idx],
                            "Conclusion": book["Conclusion"][concl_idx],
                        })

                    return combinations

                # Pre-generate 150 combinations
                combinations = generate_spaced_combinations()

                # Function to get the combination for a specific input
                def get_combination_by_type(type_id):
                    if 1 <= type_id <= 150:
                        return combinations[type_id - 1]
                    else:
                        return {"error": "Invalid type ID. Please input a number between 1 and 150."}


                html_string = render_to_string('pdf/cover_page2.html', {
                    # 'data': shuffled_main_list,
                    "intro": get_combination_by_type(choice),
                    # "intro": intro,
                    # "theme": theme,
                    # "character": charac,
                    # "conflict": con,
                    # "story": story,
                    # "conclu": concl,
                    # 'chapter': num + 1,
                    # 'intro': intro,
                    # 'end': end,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'cor': 'Dr. Sunday Akpan'.upper(),
                    'course': 'gst211: philosophy and human existence'.upper(),
                    'department': 'department of philosophy'.upper()

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                # if choice in choices:
                #     messages.error(request, f"Type {choice} was already downloaded by another student")
                #     return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                # Gst2.objects.create(firstname=user.firstname, lastname=user.lastname,
                #                     department=dept, score=choice)
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)
    elif ass.lower() == 'GST111'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = []
        context = {
            'list': list(range(1, 101)),
            'chapter': ['English Idioms and Figurative Expressions: A Use of English Handbook',
                        'The Turning Point and Other Plays',
                        'Part-time Lovers',
                        'When Uncle Coro-Coro Came to Town',
                        'A Pathfinder'],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'main_list': uniuyo3,
            'choice': 'book',
            'institution': institution,

        }


        if request.method == "POST":
            user = request.user
            books = uniuyo3.books
            if user.has_downloaded > 0:
                try:
                    text = int(request.POST.get("chapter")) - 1
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                if text+1 in allow:
                    messages.error(request, f"Review for {books[text]['Title']} is not yet ready for download")
                else:

                    selected_book = books[text]
                    conts = []
                    for i in selected_book["Contents"]:
                        conts.append(random.choice(i))


                    # Shuffle the book data to create unique combinations
                    book_data = {
                            "Title": selected_book["Title"],
                            "Author": selected_book["Author"],
                            "Place": selected_book["Place of Publication"],
                            "Publishers": selected_book["Publishers"],
                            "Year": selected_book["Year of Publication"],
                            "Pages": selected_book["Number of Pages"],
                            # Use sorted to ensure a list can be passed to random.sample
                            "Introduction": random.choice(selected_book["Introduction"]),
                            "Contents": conts,
                            "Evaluation": random.choice(selected_book["Evaluation"]),
                            "Conclusion": random.choice(selected_book["Conclusion"]),
                            "Recommendation": random.choice(selected_book["Recommendation"])
                        }


                    html_string = render_to_string('pdf/cover_page3.html', {
                        'data': book_data,
                        # 'intro': introduction,
                        # 'end': conclusion,
                        # 'eval': evaluation,
                        'conts': conts,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Dr. Idara Thomas'.upper(),
                        'course': 'GST111: USE OF ENGLISH 1'.upper(),
                        'department': 'department of english'.upper()

                    })

                    response = HttpResponse(content_type='application/pdf')
                    response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                    pisa_status = pisa.CreatePDF(html_string, dest=response)

                    if pisa_status.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    pdf_buffer = BytesIO()
                    pisa_status2 = pisa.CreatePDF(html_string, dest=pdf_buffer)
                    if pisa_status2.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    user.has_downloaded -= 1
                    user.save()
                    pdf_buffer.seek(0)
                    pdf_data = pdf_buffer.getvalue()

                    # Step 2: Send PDF via email
                    email = EmailMessage(
                        subject=f'{name} Assignment PDF',
                        body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        to=[user.email],
                    )
                    email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    email.send()
                    return response
            else:
                messages.error(request, "You have to buy downloads to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'GST121'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = []
        context = {
            'list': list(range(1, 101)),
            'chapter': [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'main_list': uniuyo3,
            'choice': 'chapter',
            'institution': institution,

        }


        if request.method == "POST":
            def random_column_wise_choice(list_of_lists):
                if not list_of_lists or not list_of_lists[0]:
                    return []

                num_positions = len(list_of_lists[0])  # Length of each sublist
                result = []

                for i in range(num_positions):
                    # Pick a random element from the ith position across all sublists
                    choice = random.choice([lst[i] for lst in list_of_lists])
                    result.append(choice)

                return result
            user = request.user
            books = uniuyo11
            if user.has_downloaded > 0:
                try:
                    text = int(request.POST.get("chapter"))
                    choice = int(request.POST.get("choice"))
                    text2 = int(request.POST.get("chapter2"))
                    choice2 = int(request.POST.get("choice2"))
                except ValueError:
                    return redirect(request.path)

                if text+1 in allow:
                    messages.error(request, f"Review for {books[text]['Title']} is not yet ready for download")
                else:

                    chap1 = random_column_wise_choice(books.chapters[text-1])
                    chap2 = random_column_wise_choice(books.chapters[text2-1])
                    # Shuffle the book data to create unique combinations
                    book_data = {
                            "Title": f"Chapter {text} and Chapter {text2} of Nigerian peoples and culture textbook",
                            "Editors": "PROF. FRIDAY E. UDE, DR. STEINER B. IFEKWE, DR. ESIN O. EMINUE",
                            "Place": "UYO, NIGERIA",
                            "Publishers": "DIRECTORATE OF GENERAL STUDIES, UNIVERSITY OF UYO",
                            "Year": "2024",
                            "Pages": "viii + 204",
                            # Use sorted to ensure a list can be passed to random.sample
                            "Introduction": random.choice(books.introductions),
                            "Contents1": chap1,
                            "Contents2": chap2,
                            "Evaluation": random.choice(books.evaluations),
                            "Conclusion": random.choice(books.conclusions),
                            "Recommendation": random.choice(books.recommendations)
                        }


                    html_string = render_to_string('pdf/cover_page33.html', {
                        'data': book_data,
                        'text': text,
                        'text2': text2,
                        # 'eval': evaluation,
                        'dict1': books.dict[text-1],
                        'dict2': books.dict[text2-1],
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Dr Bernard Steiner Ifekwe'.upper(),
                        'course': 'GST121: NIGERIAN PEOPLES AND CULTURE'.upper(),
                        'department': 'department of history and international studies'.upper()

                    })

                    response = HttpResponse(content_type='application/pdf')
                    response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                    pisa_status = pisa.CreatePDF(html_string, dest=response)

                    if pisa_status.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    pdf_buffer = BytesIO()
                    pisa_status2 = pisa.CreatePDF(html_string, dest=pdf_buffer)
                    if pisa_status2.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    try:
                        pdf_buffer.seek(0)
                        pdf_data = pdf_buffer.getvalue()
                        email = EmailMessage(
                            subject=f'{name} Assignment PDF',
                            body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                            from_email=settings.DEFAULT_FROM_EMAIL,
                            to=[user.email],
                        )
                        email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                        email.send()
                    except:
                        pass
                    user.has_downloaded -= 1
                    user.save()
                    return response
            else:
                messages.error(request, "You have to buy downloads to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'ENT221'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = []
        context = {
            'list': list(range(1, 201)),
            'chapter': ["All chapters"],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'main_list': uniuyo3,
            'choice': 'chapter',
            'institution': institution,
            'covers': covers,

        }


        if request.method == "POST":
            def random_column_wise_choice(list_of_lists):
                if not list_of_lists or not list_of_lists[0]:
                    return []

                num_positions = len(list_of_lists[0])  # Length of each sublist
                result = []

                for i in range(num_positions):
                    # Pick a random element from the ith position across all sublists
                    choice = random.choice([lst[i] for lst in list_of_lists])
                    result.append(choice)

                return result
            user = request.user
            books = uniuyo56
            if user.has_downloaded > 0:
                cover = request.POST.get("cover")
                try:
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                if choice in allow:
                    messages.error(request, f"Review not yet ready for download")
                else:
                    book_data = {
                            "Title": f"ENTREPRENEURSHIP AND INNOVATION",
                            "Editors": "PROF. FRIDAY E. UDE, PROF. NTIEDO J. UMOREN, SUNDAY S. AKPAN, PH.D",
                            "Place": "UYO, NIGERIA",
                            "Publishers": "DIRECTORATE OF GENERAL STUDIES, UNIVERSITY OF UYO",
                            "Year": "2025",
                            "Pages": "xvi + 323",
                            # Use sorted to ensure a list can be passed to random.sample
                            "Introduction": random.sample(books.intro, 2),
                            "Evaluation": random.sample(books.eval, 1),
                            "Conclusion": random.sample(books.conc, 3),
                            "Recommendation": random.sample(books.recom, 3),
                            "chapters": [random.choice(books.ch1),
                                        random.choice(books.ch2),
                                        random.choice(books.ch3),
                                        random.choice(books.ch4),
                                        random.choice(books.ch5),
                                        random.choice(books.ch6),
                                        random.choice(books.ch7),
                                        random.choice(books.ch8),
                                        random.choice(books.ch9),
                                        random.choice(books.ch10),
                                        random.choice(books.ch11),
                                        random.choice(books.ch12),
                                        random.choice(books.ch13),
                                        random.choice(books.ch14),
                                        random.choice(books.ch15),
                                        random.choice(books.ch16),
                                        random.choice(books.ch17),
                                        random.choice(books.ch18),]
                        }


                    html_string = render_to_string('pdf/cover_page34.html', {
                        'data': book_data,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor': 'Dr Sunday S. Akpan, Ph.D'.upper(),
                        'course': 'ENT221: ENTREPRENEURSHIP AND INNOVATION'.upper(),
                        'department': 'department of insurance and risk management'.upper(),
                        'faculty': 'Management science'.upper()

                    })

                    response = HttpResponse(content_type='application/pdf')
                    response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                    pisa_status = pisa.CreatePDF(html_string, dest=response)

                    if pisa_status.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    pdf_buffer = BytesIO()
                    pisa_status2 = pisa.CreatePDF(html_string, dest=pdf_buffer)
                    if pisa_status2.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))


                    def generate_assignment_pdf():
                        buffer = BytesIO()
                        doc = SimpleDocTemplate(
                            buffer,
                            pagesize=A4,
                            rightMargin=50,
                            leftMargin=50,
                            topMargin=60,
                            bottomMargin=50,
                        )

                        # ---- Styles ----
                        styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(name="TitleCustom", fontSize=22, alignment=1, spaceAfter=20, leading=26, textColor=colors.HexColor("#1a1a1a")))
                        styles.add(ParagraphStyle(name="SubTitle", fontSize=12, alignment=1, spaceAfter=12, textColor=colors.HexColor("#333333")))
                        styles.add(ParagraphStyle(name="Chapter", fontSize=15, alignment=1, spaceBefore=20, spaceAfter=10, textColor=colors.HexColor("#111111"), leading=20))
                        styles.add(ParagraphStyle(name="NormalText", fontSize=11, leading=15, spaceAfter=10))

                        elements = []

                        # ---- Dummy Student ----
                        student = {
                            "name": name,
                            "reg": reg,
                            "dept": dept,
                            "fac": fac,
                            "institution": institution,
                            "lecturer": "Dr Linus Edem",
                            "course": ass,
                            "department": dept,
                        }

                        # ---- Dummy Book Data ----
                        data = {
                            "Title": "Fundamentals of Business Administration in Nigerian Educational Sector",
                            "Editors": "John Smith & Mary Johnson",
                            "Place": "London, UK",
                            "Publishers": "Pearson Education",
                            "Year": "2020",
                            "Pages": "450",
                            "Introduction": [
                                "This book provides a clear foundation in the principles of business administration.",
                                "It introduces students to business structures, objectives, and management practices.",
                                "The authors emphasize practical applications and real-world examples for better understanding."
                            ],
                            "chapters": [
                                "The Concept and Nature of Business",
                                "Objectives and Functions of Business",
                                "Forms of Business Ownership",
                                "Management Principles and Practices",
                            ],
                            "Evaluation": [
                                "The book is well structured, written in simple language, and covers a wide range of topics.",
                                "Each chapter ends with review questions that encourage critical thinking.",
                            ],
                            "Recommendation": [
                                "This book is recommended for first-year business students.",
                                "It should also be used as a reference for entrepreneurship courses."
                            ],
                            "Conclusion": [
                                "Overall, the book achieves its aim of providing fundamental knowledge.",
                                "Its practical examples make it highly valuable to students and lecturers alike."
                            ]
                        }

                        # styles = getSampleStyleSheet()
                        styles.add(ParagraphStyle(
                            name="CoverTitle",
                            fontName="Helvetica-Bold",
                            fontSize=22,
                            alignment=1,
                            leading=28,       # better line spacing
                            spaceAfter=30,
                        ))
                        styles.add(ParagraphStyle(
                            name="Heading",
                            fontName="Helvetica-Bold",
                            fontSize=14,
                            alignment=1,
                            leading=20,
                            spaceAfter=20,
                        ))
                        styles.add(ParagraphStyle(
                            name="Body",
                            fontName="Times-Roman",
                            fontSize=12,
                            alignment=1,
                            leading=18,       # adds breathing room if text wraps
                            spaceAfter=10,
                        ))
                        styles.add(ParagraphStyle(
                            name="FooterSemiRight",
                            fontName="Times-Roman",
                            fontSize=14,
                            alignment=2,      # start as right-aligned
                            rightIndent=100,  # pull it inward so it’s between center & right
                            spaceAfter=20,
                        ))

                        

                        # === Cover Page ===
                        # elements.append(Spacer(1, 20))
                        # elements.append(Paragraph("PROJECT COVER PAGE", styles["CoverTitle"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("AN ASSIGNMENT", styles["Heading"]))
                        elements.append(Paragraph("ON", styles["Heading"]))
                        elements.append(Paragraph(f"<b>{data['Title'].upper()}</b>", styles["Heading"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("BY", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"NAME: {student['name']}", styles["Body"]))
                        elements.append(Paragraph(f"REG NO: {student['reg']}", styles["Body"]))
                        elements.append(Paragraph(f"DEPARTMENT: {student['dept']}", styles["Body"]))
                        elements.append(Paragraph(f"FACULTY: {student['fac']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 20))

                        elements.append(Paragraph("SUBMITTED TO", styles["Heading"]))
                        elements.append(Spacer(1, 10))

                        elements.append(Paragraph(f"{student['lecturer']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['course']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['department']}", styles["Body"]))
                        elements.append(Paragraph(f"{student['institution']}", styles["Body"]))
                        elements.append(Spacer(1, 80))
                        date_str = datetime.datetime.now().strftime("%B, %Y")
                        elements.append(Paragraph(f"{date_str}".upper(), styles["FooterSemiRight"]))

                        

                        elements.append(PageBreak())
                        # ---- CONTENT PAGES ----
                        elements.append(Paragraph("BOOK REVIEW OVERVIEW", styles["Chapter"]))
                        elements.append(Paragraph(f"<b>BOOK:</b> {data['Title']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>EDITORS:</b> {data['Editors']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PLACE OF PUBLICATION:</b> {data['Place']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>PUBLISHERS:</b> {data['Publishers']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>YEAR OF PUBLICATION:</b> {data['Year']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>NUMBER OF PAGES:</b> {data['Pages']}", styles["NormalText"]))
                        elements.append(Paragraph(f"<b>REVIEWER:</b> {student['name']}", styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("INTRODUCTION", styles["Chapter"]))
                        for para in data["Introduction"]:
                            elements.append(Paragraph(para, styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("ORGANIZATION OF CONTENTS", styles["Chapter"]))
                        for idx, ch in enumerate(data["chapters"], start=1):
                            elements.append(Paragraph(f"<b>CHAPTER {idx}:</b> {ch}", styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("EVALUATION", styles["Chapter"]))
                        for para in data["Evaluation"]:
                            elements.append(Paragraph(para, styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("RECOMMENDATION", styles["Chapter"]))
                        for para in data["Recommendation"]:
                            elements.append(Paragraph(para, styles["NormalText"]))
                        elements.append(PageBreak())

                        elements.append(Paragraph("CONCLUSION", styles["Chapter"]))
                        for para in data["Conclusion"]:
                            elements.append(Paragraph(para, styles["NormalText"]))             

                        def draw_content_border(canvas, doc):
                            width, height = A4

                            # === Footer line ===
                            canvas.setStrokeColor(colors.grey)
                            canvas.setLineWidth(0.5)
                            canvas.line(50, 40, width - 50, 40)

                            # === Clickable footer text ===
                            footer_text = "Calixguru Book Review System - Confidential"
                            canvas.setFont("Times-Roman", 9)
                            canvas.setFillColor(colors.red)  # typical link color
                            text_width = canvas.stringWidth(footer_text, "Times-Roman", 9)
                            x_pos = (width - text_width) / 2
                            y_pos = 28
                            canvas.drawString(x_pos, y_pos, footer_text)

                            # Make it clickable
                            canvas.linkURL(
                                "https://calixguru.pythonanywhere.com/",
                                (x_pos, y_pos - 2, x_pos + text_width, y_pos + 10),
                                relative=0,
                            )

                            # === Watermark ===
                            canvas.saveState()
                            canvas.setFont("Helvetica-Oblique", 65)  # Oblique = slanted
                            canvas.setFillColorRGB(0.6, 0.6, 0.6, alpha=0.2)  # light gray + transparency
                            canvas.translate(width / 2, height / 2)  # move origin to page center
                            canvas.rotate(45)  # rotate for slant
                            canvas.drawCentredString(0, 0, "C A L I X G U R U")
                            canvas.restoreState()

                        cover_functions = {
                                "Blank": CoverBorders.draw_cover_border0,
                                "cover 1": CoverBorders.draw_cover_border1,
                                "cover 2": CoverBorders.draw_cover_border2,
                                "cover 3": CoverBorders.draw_cover_border3,
                                "cover 4": CoverBorders.draw_cover_border4,
                                "cover 5": CoverBorders.draw_cover_border5,
                                "cover 6": CoverBorders.draw_cover_border6,
                                "cover 7": CoverBorders.draw_cover_border7,
                                "cover 8": CoverBorders.draw_cover_border8,
                                "cover 9": CoverBorders.draw_cover_border9,
                                "cover 10": CoverBorders.draw_cover_border10,
                                "cover 11": CoverBorders.draw_cover_border11,
                                "cover 12": CoverBorders.draw_cover_border12,
                                "cover 13": CoverBorders.draw_cover_border13,
                                "cover 14": CoverBorders.draw_cover_border14,
                                "cover 15": CoverBorders.draw_cover_border15,
                                "cover 16": CoverBorders.draw_cover_border16,
                                "cover 17": CoverBorders.draw_cover_border17,
                                "cover 18": CoverBorders.draw_cover_border18,
                                "cover 19": CoverBorders.draw_cover_border19,
                                "cover 20": CoverBorders.draw_cover_border20,
                                "cover 21": CoverBorders.draw_cover_border21,
                                "cover 22": CoverBorders.draw_cover_border22,
                                "cover 23": CoverBorders.draw_cover_border23,
                                "cover 24": CoverBorders.draw_cover_border24,
                                "cover 25": CoverBorders.draw_cover_border25,
                                # "cover 26": pins.draw_cover_border25,
                                "cover 27": CoverBorders.draw_cover_border,
                            }

                    
                        # ---- Build PDF ----
                        doc.build(elements, onFirstPage=cover_functions[cover], onLaterPages=draw_content_border)

                        buffer.seek(0)
                        return FileResponse(buffer, as_attachment=True, filename=f"cover_page.pdf")


                    # try:
                    #     pdf_buffer.seek(0)
                    #     pdf_data = pdf_buffer.getvalue()
                    #     email = EmailMessage(
                    #         subject=f'{name} Assignment PDF',
                    #         body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                    #         from_email=settings.DEFAULT_FROM_EMAIL,
                    #         to=[user.email],
                    #     )
                    #     email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                    #     email.send()
                    # except:
                    #     pass
                    # user.has_downloaded -= 1
                    user.save()
                    response = generate_assignment_pdf()
                    return response
            else:
                messages.error(request, "You have to buy downloads to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'CUSTOM'.lower():
        types = ['Assignment', 'Term paper', 'Book review']
        months = ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"]

        if request.user.email != 'calixotu@gmail.com':
            messages.error(request, "Sorry you can't access that")
            return redirect('select-tournament')
        context = {
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'months': months,
            'institution': institution,
            'types': types,
        }

        if request.method == "POST":
            user = request.user
            if user.email == 'calixotu@gmail.com':
                try:
                    main_title = request.POST.get("main")
                    type = request.POST.get("type")
                    introduction = request.POST.get("introduction", "").strip() or ""
                    abstract = request.POST.get("abstract", "").strip() or ""

                    include_headers = request.POST.get("include_headers") == "on"
                    table_of_contents = request.POST.get("table_of_contents") == "on"

                    chap_headers = request.POST.get("chap_headers", "[]").strip()
                    chap_body = request.POST.get("chap_body", "[]").strip().replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ')
                    recommendation = request.POST.get("recommendation", "").strip() or ""
                    conclusion = request.POST.get("conclusion", "").strip() or ""
                    reference = request.POST.get("reference", "[]").strip()

                    lecturer_name = request.POST.get("lecturer_name", "").strip()
                    course_name = request.POST.get("course_name", "").strip()
                    month = request.POST.get("month", "").strip()
                    lecturer_dept = request.POST.get("lecturer_dept", "").strip()
                    hmm = []
                    for i, v in zip(eval(chap_headers), eval(chap_body)):
                        hmm.append({'head': i.upper(), 'body': v.replace('-', ' ')})

                    # chap_headers = [line.strip() for line in chap_headers.splitlines() if line.strip()]
                    # chap_body = [line.strip() for line in chap_body.splitlines() if line.strip()]
                    # reference = [line.strip() for line in reference.splitlines() if line.strip()]

                    body = []
                    if include_headers == 'on':
                        for u, v in zip(chap_headers, chap_body):
                            body.append({'head':'', 'title':u, 'body': v})
                    else:
                        start = 1
                        for u,v in zip(chap_headers, chap_body):
                            body.append({'head':f'Chapter {start}', 'title':u, 'body': v})
                            start = start + 1


                except ValueError:
                    messages.error(request, "Please enter valid details")
                    return redirect(request.path)



                html_string = render_to_string('pdf/custom.html', {
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'month': month.upper(),
                    "main_title": main_title.upper(),
                    "type": type.upper(),
                    "Introduction": introduction,
                    "Abstract": abstract,
                    # "Body": eval(chap_body),
                    "Body": hmm,
                    "Recommendation": recommendation,
                    "Conclusion": conclusion,
                    "Reference": reference,

                    'cor': lecturer_name.upper(),
                    'course': course_name.upper(),
                    'department': lecturer_dept.upper()
                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                return response
            else:
                messages.error(request, "You are not allowed to do that")
                return redirect(request.META.get('HTTP_REFERER', '/'))

        return render(request, 'base/gst_custom.html', context)
    elif ass.lower() == 'AED111'.lower():
        context = {
            'list': list(range(1, 64)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'notyet',
            'info': '''You are about to download AED111 assignment' ''',
            'choice': 'chapter',
            'main_list': uniuyo5,
            'dblink': 'cbtb2',
            'text': 'text2'
        }
        # Determine which book's data to use
        # choices = []
        # for i in Gst2.objects.all():
        #     choices.append(i.score)
        # context['choices'] = choices
        books = uniuyo8
        if request.method == "POST":
            user = request.user
            choice = int(request.POST.get("choice"))
            if user.has_downloaded > 0:
                intro = random.choice(books.intros)
                conc = random.choice(books.conclusions)
                # Assuming books.minerals1 is a list of dictionaries
                selected_names = set()  # To track unique names
                m1 = []  # To store selected dictionaries

                while len(m1) < 20:
                    mineral = random.choice(books.minerals1)  # Pick a random mineral
                    if mineral["name"] not in selected_names:  # Check for uniqueness
                        selected_names.add(mineral["name"])  # Add name to the set
                        m1.append(mineral)  # Add the dictionary to the final list

                m2 = random.sample(books.minerals2, 10)
                ref = random.sample(books.references, 10)


                html_string = render_to_string('pdf/cover_page10.html', {
                # return render(request, 'pdf/cover_page6.html', {
                    'intro' : intro,
                    'conc' : conc,
                    'm1': m1,
                    'm2' : m2,
                    'ref' : ref,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'cor': 'Associate Prof. Patrick Sambo William'.upper(),
                    'course': 'AED111'.upper(),
                    'department': 'Department of Agricultural Education'.upper()

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if request.user.email != 'calixotu@gmail.com':
                    messages.error(request, 'Only admins can download this assignment')

                    # Get user's first name
                    user_firstname = request.user.first_name if request.user.first_name else "User"

                    # WhatsApp URL with a prefilled message
                    whatsapp_url = f"https://wa.me/2349071902185?text=Hello%20calixguru,%20my%20name%20is%20{user_firstname}.%20Please%20I%20need%20to%20download%20a%20copy%20of%20GET111%20assignment"

                    return redirect(whatsapp_url)

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                # if choice in choices:
                #     messages.error(request, f"Type {choice} was already downloaded by another student")
                #     return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                # Gst2.objects.create(firstname=user.firstname, lastname=user.lastname,
                #                     department=dept, score=choice)
                return response

            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)

    elif ass.lower() == 'ESSAY'.lower():
        set1 = [
                    "How My First Two Months at UniUyo Have Changed My Perspective on University Life",
                    "How I Managed to Study in a Noisy Hostel Environment",
                    "How I Realized the Importance of Making Friends in My First Two Months at UniUyo",
                    "How I Managed to Balance Academics and Social Life",
                    "How I Almost Got Scammed by Someone Pretending to Sell Lecture Materials",]

                    # Second Set of Topics
        set2 = [    "How I Managed to Adapt to Life Without Home-Cooked Meals",
                    "How I Handled My First Cash Shortage in School",
                    "The Day I Almost Got Locked Out of My Hostel at Night",
                    "How I Dealt with My First Academic Challenge at UniUyo",
                    "The First Time I Had to Read Overnight for an Upcoming Test",]

                    # Third Set of Topics
        set3 =[     "How I Managed My Finances as a Freshman at UniUyo",
                    "My First Sunday Service in a Campus Fellowship at UniUyo",
                    "The First Time I Ate in the School Cafeteria and My Impression",
                    "How I Overcame My Fear of Speaking in a Large Lecture Hall",
                    "The First Time I Missed a Class at UniUyo and the Lesson I Learned",]

        set4 = [
                    "Should social media influencers be held accountable for misinformation?",
                    "Is online learning as effective as classroom learning?",
                    "Are exams the best way to test knowledge?",]
        set5 = [
                    "Should Nigeria adopt electronic voting?",
                    "Is a cashless economy good for Nigeria?",
                    "Should celebrities be considered role models?",
                    "Should students be paid for good grades?",
                    "Is democracy the best form of government?",
                    "Should phone use be banned in classrooms?",]
        set6 = [
                    "Should students wear school uniforms in universities?",
                    "Is online shopping better than physical shopping?",
                    "Is remote work the future of employment?",
                    "Is English necessary as Nigeria’s official language?"
                ]
        context = {
            'list': list(range(1, 64)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'notyet',
            'info': '''You are about to download an essay for the topics below ''',
            'choice': 'chapter',
            'main_list': uniuyo6,
            'dblink': 'cbtb2',
            'text': 'text2',
            'narrate': set1+set2+set3,
            'arguments': set4+set5+set6
        }
        set_map = {
            "set1": set1,
            "set2": set2,
            "set3": set3,
            "set4": set4,
            "set5": set5,
            "set6": set6
        }

        # Function to check which set contains the input string
        def find_set(user_input):
            for set_name, items in set_map.items():
                if user_input in items:
                    return set_name
            return "String not found in any set."
        books = uniuyo6
        if request.method == "POST":
            user = request.user
            choice = request.POST.get("choice")
            found = find_set(choice)
            if user.has_downloaded > 0:
                topic = choice
                if found == 'set1':
                    intro = books.set1[0][topic]['introduction']
                    p1 = books.set1[1][topic]['paragraph_1']
                    p2 = books.set1[2][topic]['paragraph_2']
                    p3 = books.set1[3][topic]['paragraph_3']
                    p4 = books.set1[4][topic]['paragraph_4']
                    conc = books.set1[5][topic]['conclusion']
                    result = [intro,p1,p2,p3,p4,conc]
                elif found == 'set2':
                    intro = books.set2[0][topic]['introduction']
                    p1 = books.set2[1][topic]['paragraph_1']
                    p2 = books.set2[2][topic]['paragraph_2']
                    p3 = books.set2[3][topic]['paragraph_3']
                    p4 = books.set2[4][topic]['paragraph_4']
                    conc = books.set2[5][topic]['conclusion']
                    result = [intro,p1,p2,p3,p4,conc]
                elif found == 'set3':
                    intro = books.set3[0][topic]['introduction']
                    p1 = books.set3[1][topic]['paragraph1']
                    p2 = books.set3[2][topic]['paragraph2']
                    p3 = books.set3[3][topic]['paragraph3']
                    p4 = books.set3[4][topic]['paragraph4']
                    conc = books.set3[5][topic]['conclusion']
                    result = [intro,p1,p2,p3,p4,conc]
                elif found == 'set4':
                    intro = books.set4[0][topic]
                    p1 = books.set4[1][topic]
                    p2 = books.set4[2][topic]
                    p3 = books.set4[3][topic]
                    p4 = books.set4[4][topic]
                    conc = books.set4[5][topic]
                    result = [intro,p1,p2,p3,p4,conc]
                elif found == 'set5':
                    intro = books.set5[0][topic]
                    p1 = books.set5[1][topic]
                    p2 = books.set5[2][topic]
                    p3 = books.set5[3][topic]
                    p4 = books.set5[4][topic]
                    conc = books.set5[5][topic]
                    result = [intro,p1,p2,p3,p4,conc]
                elif found == 'set6':
                    intro = books.set6[0][topic]
                    p1 = books.set6[1][topic]
                    p2 = books.set6[2][topic]
                    p3 = books.set6[3][topic]
                    p4 = books.set6[4][topic]
                    conc = books.set6[5][topic]
                    result = [intro,p1,p2,p3,p4,conc]
                else:
                    messages.error(request, 'Nothing found')

                html_string = render_to_string('pdf/cover_page7.html', {
                # return render(request, 'pdf/cover_page6.html', {
                    'result' : result,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'choice': choice.upper(),
                    'institution': institution,
                    'department': 'Department of Mechanical Engineering'.upper()

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if request.user.email != 'calixotu@gmail.com':
                    messages.error(request, 'Only admins can download this assignment')

                    # Get user's first name
                    user_firstname = request.user.first_name if request.user.first_name else "User"

                    # WhatsApp URL with a prefilled message
                    whatsapp_url = f"https://wa.me/2349071902185?text=Hello%20calixguru,%20my%20name%20is%20{user_firstname}.%20Please%20I%20need%20to%20download%20a%20copy%20of%20GET111%20assignment"

                    return redirect(whatsapp_url)

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                # if choice in choices:
                #     messages.error(request, f"Type {choice} was already downloaded by another student")
                #     return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                # Gst2.objects.create(firstname=user.firstname, lastname=user.lastname,
                #                     department=dept, score=choice)
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst essay.html', context)
    elif ass.lower() == 'COS111'.lower():
        context = {
            'list': list(range(1, 64)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'notyet',
            'info': '''You are about to download a term paper for COS111 below ''',
            'choice': 'chapter',
            'main_list': uniuyo6,
            'dblink': 'cbtb2',
            'text': 'text2',
        }
        books = uniuyo7
        if request.method == "POST":
            user = request.user
            choice = request.POST.get("choice")
            if user.has_downloaded > 0:
                intro = random.choice(books.introductions1+books.introductions2)
                history = random.choice(books.histories1+books.histories2+books.histories3)
                positive = random.choice(books.positive_impacts1+books.positive_impacts2+books.positive_impacts3)
                negative = random.choice(books.negative_impacts1+books.negative_impacts2+books.negative_impacts3)
                future = random.choice(books.future_of_computers1+books.future_of_computers2+books.future_of_computers3)
                conclusion = random.choice(books.conclusion1+books.conclusion2+books.conclusion3)
                ref = random.sample(books.references, 10)

                html_string = render_to_string('pdf/cover_page9.html', {

                    'data' : [
    [
    "International trade, often referred to as the exchange of goods and services across national boundaries, has been a central part of human civilization since its earliest days. In simple terms, trade is the process of transferring commodities from one person to another, whether within the same country or between different countries. Historically, the earliest form of trade was barter, where goods and services were directly exchanged without the use of money. Over time, the barter system was replaced by monetary exchange, a development that greatly promoted trade by introducing a convenient medium of exchange. Trade can be classified into two main forms: bilateral trade, which involves two parties or countries, and multilateral trade, which involves more than two. The primary reason trade exists is because nature has distributed resources unevenly across the earth, making it impossible for every nation to produce all the commodities its people require. International trade, in particular, is not a new concept. Historical evidence suggests that trading activities were present in ancient times, but the modern era—with its advanced technology, improved transportation systems, outsourcing of manufacturing, and rapid industrialization—has given international trade unprecedented momentum. Today, trade is not only a means to earn profit but also a crucial way of providing goods and services to consumers, satisfying ever-changing human wants, and improving standards of living. It has become a vital social activity, ensuring a constant flow of products to meet the demands of society. Trade has existed alongside human life from the beginning and will continue as long as people live on earth. The mutual benefits it offers—such as increased consumer choice, improved production efficiency, and stronger economic ties between nations—make it indispensable in both domestic and global economic systems."
],
[
    "Trade can be broadly divided into two main categories: internal (or domestic) trade and external (or international) trade. Internal trade, also known as home trade, occurs entirely within the political and geographical boundaries of a country. It involves the buying and selling of goods and services between different regions or states of the same nation. For example, the trade between Lagos and Abuja in Nigeria is classified as internal trade. This form of trade can take place at local, regional, or national levels and is further subdivided into wholesale trade and retail trade. Wholesale trade involves the purchase of goods in large quantities directly from manufacturers or producers, which are then resold in smaller quantities to retailers. The wholesaler acts as a crucial link between the manufacturer and the retailer, playing a central role in the distribution process. Retail trade, on the other hand, occurs when retailers sell goods in small quantities directly to consumers for personal use. This is the final stage in the distribution chain, ensuring that products reach the end-user.\n\nExternal trade, also known as foreign or international trade, involves the exchange of goods and services between two or more countries. It plays a significant role in connecting national economies to the global market. External trade can be further classified into three types: export trade, import trade, and entrepôt trade. Export trade occurs when a country sells its goods or services to foreign markets; for example, when Nigeria exports crude oil to other nations. Import trade happens when a country purchases goods or services from abroad to meet domestic demand, such as importing electronics or machinery. Entrepôt trade is a unique form where goods are imported from one country, modified or processed, and then re-exported to the same or another country. Each of these trade types contributes to economic growth, enhances product variety, and fosters international economic relationships."
],
[
    "The history of trade is as old as human civilization itself, with its roots stretching back to prehistoric times when early humans exchanged goods and services through barter. This direct exchange system was the foundation of economic interaction before the invention of money. As societies evolved, so did trade practices, moving from simple local exchanges to long-distance commerce between regions and eventually between continents. Ancient civilizations such as the Hebrews, Greeks, and Romans highly valued trade, recognizing it as an essential driver of prosperity and social cohesion. Philosophers like Plato and Aristotle acknowledged its importance, though they often emphasized that trade should be conducted in a just and ethical manner. In the Roman era, prominent thinkers such as Lucius Annaeus Seneca, Marcus Tullius Cicero, and Pliny the Elder discussed trade not only as an economic activity but also as a contributor to the strength and stability of the state. During the medieval period, trade remained a central economic activity, guided by moral and religious principles. Economic thinkers of the time promoted fairness and mutual benefit in trade transactions.\n\nThe mercantilist period, emerging in the 16th and 17th centuries, marked a shift toward a more strategic and nationalistic approach to trade. Mercantilists believed that a nation's wealth and power depended largely on the accumulation of precious metals, which could be achieved by maximizing exports and minimizing imports. This policy aimed to generate a favorable balance of trade, thereby increasing the inflow of gold and silver. The mercantilists prioritized foreign trade over domestic trade and placed heavy emphasis on government control to protect and promote national economic interests.\n\nBy the mid-18th century, the physiocrats in France challenged the mercantilist perspective. They advocated the idea of a 'natural order' in economics and placed agriculture at the center of national wealth. Although they emphasized the primacy of agricultural production, they did not disregard the importance of trade, acknowledging its role in improving society’s well-being. The evolution of trade thought reached a major turning point in 1776 when Adam Smith published 'The Wealth of Nations.' This work laid the foundation for modern economics and introduced a new, logical, and evidence-based approach to understanding trade and economic development, ultimately shifting the focus toward free trade and specialization."
],
[
    "The classical era of economic thought brought a significant shift in the understanding of international trade, largely influenced by the groundbreaking work of Adam Smith. In 1776, Smith published 'The Wealth of Nations,' a comprehensive study of economic principles that challenged the prevailing mercantilist doctrines of the time. Smith rejected the mercantilist belief that trade was a zero-sum game in which one nation could only gain at the expense of another. Instead, he argued that trade could be mutually beneficial if countries specialized in producing goods in which they held an advantage. This concept became known as the 'Absolute Advantage Theory.' According to Smith, absolute advantage refers to a nation's ability to produce a good more efficiently—using fewer resources—than another country. He emphasized that under free trade, each nation should specialize in producing goods it could produce most efficiently and then trade for goods that other nations could produce more efficiently.\n\nSmith illustrated his theory with the example of two countries—such as the United States and India—producing two different commodities, for instance, rubber and textiles. If the United States could produce rubber using fewer resources than India, and India could produce textiles more efficiently than the United States, both countries would benefit by specializing and trading with each other. This specialization would result in increased productivity, better use of resources, and improved living standards for all trading partners.\n\nA key element of Smith's theory was the division of labour. He argued that when labour is divided into specialized tasks, workers become more skilled and efficient, leading to greater overall output. This principle applied not only within domestic production but also in the international context, where countries acted as specialized producers in the global marketplace.\n\nSmith’s model assumed several conditions for trade to function optimally: labour as the sole factor of production, homogeneous labour, fixed proportions of inputs in production, immobility of labour across countries, absence of transportation costs, and the use of constant technology. Despite these simplifying assumptions, the model provided a powerful argument for free trade and economic cooperation among nations. Smith envisioned a world where trade promoted peace and prosperity, fostering honest and mutually advantageous relationships between countries. His Absolute Advantage Theory laid the foundation for later developments in trade theory, influencing economists like David Ricardo, who expanded upon it to address cases where one country could be more efficient in producing multiple goods."
],
[
    "While Adam Smith’s Absolute Advantage Theory explained how two countries could benefit from trade when each had a clear efficiency advantage in producing certain goods, it did not account for situations where one nation was more efficient in producing all goods. This limitation led to the development of the Comparative Cost Theory, most famously refined by David Ricardo. Ricardo argued that even if one country could produce all goods more efficiently than another, there could still be mutual benefits from trade if each country specialized in producing the goods for which it had the greatest relative efficiency, or the lowest opportunity cost. Opportunity cost refers to the value of the best alternative forgone when a choice is made. In trade terms, it is the amount of one good that must be sacrificed to produce more of another good.\n\nLater, economist Gottfried Haberler reformulated Ricardo’s concept into the 'Opportunity Cost Approach,' making it more general and applicable beyond the labour-only assumptions of classical theory. Haberler introduced the idea of the Production Possibility Curve (also called the Transformation Curve), which graphically represents the maximum combinations of two goods that can be produced with available resources and technology. According to this theory, trade occurs because the opportunity costs of producing goods differ between countries. By specializing in goods with the lowest opportunity costs and trading for others, nations can increase overall production and consumption.\n\nHaberler’s model operated under specific assumptions: only two countries engaged in trade, two commodities and two factors of production (labour and capital) existed, factors were fully employed, trade was free of restrictions, and markets were perfectly competitive. Within this framework, different cost conditions—constant, increasing, or decreasing opportunity costs—determined the extent of trade gains. Under constant opportunity costs, the gains from trade are straightforward; under increasing opportunity costs, specialization is partial; and under decreasing costs, specialization can lead to significant efficiency gains.\n\nThe Comparative Cost and Opportunity Cost theories provided a more flexible and realistic understanding of trade than Adam Smith’s model. They showed that trade benefits were not dependent on absolute superiority in production but rather on relative efficiency. This insight was critical in justifying trade between countries with very different levels of productivity, including trade between developed and developing nations. It also reinforced the principle that resource allocation, guided by comparative advantage, leads to more efficient global production, higher total output, and improved welfare for all participants in the trading system."
],
[
    "John Stuart Mill, one of the most influential economists of the 19th century, made a significant contribution to international trade theory through his 'Theory of Reciprocal Demand.' While he acknowledged the importance of David Ricardo’s Comparative Cost Theory, Mill criticized it for overlooking a key aspect of trade: the determination of the actual exchange ratio, or terms of trade, between two countries. Ricardo’s theory explained why trade occurred and how countries could benefit from specialization, but it assumed that the rate at which one good would be exchanged for another was fixed or given. Mill recognized that this was unrealistic and set out to explain how the terms of trade are determined in practice.\n\nAccording to Mill, the terms of trade between two countries depend on the relative strength of each country’s demand for the other’s products. In other words, the amount of one commodity that a country is willing to give up in exchange for another is influenced by both its domestic needs and the intensity of foreign demand. This concept became known as 'reciprocal demand.' For trade to occur and be sustained, each country must find the exchange rate that balances its exports with its imports, creating an equilibrium in international markets.\n\nMill’s model was based on specific assumptions, often summarized as a 2 x 2 x 1 framework—two countries, two commodities, and one factor of production (labour). He assumed constant returns to scale, perfect competition, full employment in both countries, and no transportation costs. Trade was also assumed to be free from restrictions such as tariffs or quotas. Within these conditions, the terms of trade are determined by the intersection of each country’s offer curves, which show the quantities of one good a country is willing to export in exchange for varying quantities of another good it wishes to import.\n\nThe Theory of Reciprocal Demand was an important refinement to classical trade theory because it addressed how the actual prices of traded goods are set in the global market. It revealed that trade outcomes are influenced not only by production capabilities but also by the interplay of international demand patterns. By incorporating demand-side factors into trade analysis, Mill’s theory provided a more complete and realistic picture of how trade operates. This made it a crucial link between the classical theories of production-based trade and later models that integrated both supply and demand factors into international economics."
],
[
    "The Heckscher-Ohlin (H-O) Factor Endowment Theory represents one of the most significant advances in the study of international trade, moving beyond the classical focus on labour productivity to examine the role of a country’s resource base in shaping trade patterns. Developed initially by Eli Heckscher in 1919 and later expanded by his student Bertil Ohlin in 1933, the theory proposes that differences in countries’ relative factor endowments—such as labour, capital, and land—are the primary determinants of what goods they produce and export. In simple terms, a country will export goods that intensively use the factors of production it has in abundance, and it will import goods that require factors in which it is relatively scarce.\n\nFor example, a capital-abundant country like the United States would specialize in and export capital-intensive goods such as advanced machinery or aircraft, while a labour-abundant country such as India would specialize in and export labour-intensive goods like textiles or handcrafts. This specialization arises because factor abundance makes the production of certain goods relatively cheaper domestically, giving those goods a competitive edge in international markets.\n\nThe H-O theory rests on several key assumptions: two countries, two commodities, and two factors of production (labour and capital) are considered; production functions differ between goods; perfect competition exists in both goods and factor markets; production is subject to constant returns to scale; transportation and insurance costs are negligible; factors of production are immobile between countries but fully mobile within each country; there is full employment of all factors; technological knowledge remains constant; and consumers in both countries have identical preferences.\n\nUnder these conditions, the theory predicts that international trade will lead to a convergence in the prices of factors of production, a result known as the Factor Price Equalization Theorem. This means that, over time, wages for similar labour and returns on capital will tend to equalize across trading nations, provided the assumptions hold. The H-O model also suggests that trade can act as a substitute for the international movement of factors, achieving similar outcomes through the exchange of goods rather than the migration of labour or capital.\n\nWhile the Heckscher-Ohlin theory has been influential, it has also faced empirical challenges, such as the Leontief Paradox, which found results contrary to its predictions in the case of U.S. trade patterns. Nonetheless, the H-O framework remains a cornerstone of modern trade theory, offering valuable insights into how differences in resource endowments shape the structure and direction of global trade."
],
[
    "Beyond the classical and Heckscher-Ohlin models, several economists have offered extensions and modifications to better explain patterns of trade. One notable contribution is L.B. Kravis’s Availability Theory, proposed in 1956. Kravis challenged the assumption in classical theory that technology was uniform across countries and instead argued that trade is primarily determined by the availability of goods within a country. According to this view, a country tends to export goods that are available in abundance domestically—whether due to natural resources, technological advancements, product differentiation, or government policies—and import goods that are not available or are scarce. For example, a nation rich in oil reserves will naturally export petroleum products while importing items like diamonds or specialized machinery that it cannot easily produce. Kravis identified several key factors influencing availability: the presence of specific natural resources, the possession of technical knowledge, the temporary monopoly created by product differentiation, and the impact of government policies, which can either encourage or obstruct trade. This framework shifted focus from purely cost-based explanations to the role of resource endowment and innovation in shaping trade flows.\n\nAnother important extension came from Swedish economist Staffan Burenstam Linder, who sought to explain the volume of trade in manufactured goods between countries. Linder observed that the Heckscher-Ohlin model was better suited to explaining trade in primary products than in manufactured goods, where patterns often did not follow factor endowment predictions. He proposed the 'Preference Similarity' hypothesis, which suggests that a country’s exports of manufactured goods are largely determined by the nature of domestic demand. In other words, foreign trade is an extension of domestic trade: the products that find high demand at home are more likely to be competitive abroad. Linder argued that producers develop products with their home market in mind, and only after satisfying domestic demand do they turn to export opportunities. Consequently, countries with similar income levels and demand patterns are more likely to trade manufactured goods with each other. This explains why high-income nations often have significant trade volumes among themselves, exchanging similar categories of advanced manufactured products.\n\nBoth Kravis’s and Linder’s theories add nuance to the understanding of trade by incorporating demand conditions, innovation, and resource availability. They highlight that while cost advantages and factor endowments remain important, the composition and volume of trade are also shaped by what a country can produce in surplus, the preferences of its consumers, and the similarities it shares with its trading partners. These perspectives help explain real-world trade patterns that deviate from traditional models, especially in sectors driven by technological change and consumer demand."
],
[
    "In 1961, economist Michael V. Posner introduced the Technological Gap Theory, also known as the Imitation Gap Theory, as a way to explain how differences in technological innovation influence international trade patterns. Posner’s approach built on earlier ideas by Kravis but placed even greater emphasis on the dynamic role of technological change. Traditional trade theories, such as Ricardian and Heckscher-Ohlin models, assumed that technology was the same in all countries. Posner rejected this assumption, arguing instead that technological disparities between nations create temporary advantages in trade.\n\nThe theory is based on the idea that when a new product or production process is developed in an innovating country, it enjoys a period of temporary monopoly in world markets. This period lasts until firms in other countries are able to imitate the innovation, a process known as the 'imitation lag.' During the imitation lag, the innovating country can export the new product, benefiting from higher profits and an absolute advantage in that good. The imitation lag length varies depending on the complexity of the product, the capacity of other countries to reverse-engineer or replicate it, and the speed of information flow.\n\nPosner further introduced the concept of 'demand lag,' which is the time it takes for consumers in other countries to adopt and develop a preference for the new product. The total period during which the innovating country exports the product is determined by the difference between the imitation lag and the demand lag. If the imitation lag is long and the demand lag short, the innovating country enjoys a longer window of export advantage. Conversely, if imitation is quick and consumer adoption slow, the export window is shortened.\n\nHe also identified three critical phases in the technological gap: foreign reaction lag (the time for foreign firms to start production after innovation), domestic reaction lag (the time for local competitors to respond to innovation within the home country), and the learning period (the time needed for foreign producers to master the production process). When the imitation gap closes, the product may lose its export advantage unless the innovating country introduces new innovations, creating a cycle of continuous product development.\n\nPosner’s theory underscores the importance of 'dynamism' in international trade—the speed at which a country can innovate and imitate. Countries with higher innovation rates and faster learning processes are better positioned to sustain competitive advantages in global markets. By focusing on technological change, the Technological Gap Theory offers a more realistic and dynamic explanation of trade flows, especially in industries where innovation is rapid and product life cycles are short."
],
[
    "In 1966, economist Raymond Vernon introduced the Product Cycle Theory to explain how the comparative advantage of producing certain goods changes over time, influencing trade patterns. Based largely on the experience of the United States economy, Vernon observed that new products tend to go through a predictable series of stages, and as they progress, their production location and trade flows shift. The theory was particularly relevant for explaining trade in technologically advanced, capital-intensive goods during the post-war period.\n\nThe Product Cycle Theory begins with the 'Introduction Stage.' At this point, a new product is developed in a capital-rich country, typically in response to the needs of its domestic market. The innovators are often unaware of, or initially unconcerned with, conditions in foreign markets. Production is small-scale, close to research and development facilities, and relies heavily on skilled labour and flexible manufacturing systems. The domestic market is the primary focus, and exports, if they occur, are minimal.\n\nAs the product gains acceptance at home, it enters the 'Growth Stage.' Demand rises rapidly, both domestically and internationally. Mass production techniques are introduced to reduce costs, and exports to foreign markets increase. The innovating country enjoys a strong comparative advantage at this stage, often becoming the leading exporter of the product. Technological leadership and brand reputation allow it to maintain high profit margins.\n\nThe next phase is the 'Maturity Stage.' By now, the product design has stabilized, production processes are standardized, and cost reduction becomes the main competitive strategy. Foreign competitors, having observed and learned from the innovator, begin producing the product—sometimes under licensing agreements, other times through direct imitation. As production spreads, especially to countries with lower labour costs, the innovating country’s export share begins to decline.\n\nIn the 'Saturation Stage,' the product becomes widely available globally. Price competition intensifies, profit margins shrink, and production is increasingly shifted to developing countries where costs are lower. The original innovator may even start importing the product it once exported.\n\nFinally, in the 'Decline Stage,' the product loses market relevance, often replaced by newer innovations. At this point, production may be concentrated almost entirely in low-cost regions, with minimal involvement from the original innovating country.\n\nVernon’s theory highlighted the dynamic nature of comparative advantage, showing that it is not fixed but evolves over a product’s life cycle. It also demonstrated how technological innovation initially benefits advanced economies but eventually leads to production relocation to lower-cost regions, reshaping global trade patterns. This model remains influential in understanding trade in manufactured goods with relatively short innovation cycles."
],
[
    "Two additional approaches that broaden the understanding of international trade are Peter B. Kenen’s Human Capital Theory and the Gravity Model of Trade. Kenen, writing in 1965, emphasized the role of human capital—rather than just physical capital or natural resources—in shaping a country’s trade patterns. Human capital refers to the skills, knowledge, and training possessed by a nation’s labour force. According to Kenen, investment in education and training increases the productivity of workers, thereby enhancing a country’s competitiveness in producing certain goods and services. He argued that while land and unskilled labour are original factors of production, their productive potential can be greatly enhanced through the application of capital in the form of education, skill development, and technological training. Countries that invest heavily in improving their labour force can specialize in producing more sophisticated, skill-intensive goods, allowing them to capture higher-value segments of the global market. This perspective highlighted that resource endowments are not fixed; through investment in human capital, a country can effectively alter its comparative advantage over time.\n\nThe Gravity Model of Trade, on the other hand, offers a more empirical framework for understanding trade flows between countries. This model draws an analogy from Newton’s law of gravity, suggesting that the volume of trade between two nations is directly proportional to the size of their economies—measured by Gross Domestic Product (GDP)—and inversely proportional to the distance between them. In mathematical form, the model is often expressed as: Tij = A × (Yi × Yj) / Dij, where Tij represents the trade volume between countries i and j, Yi and Yj are their respective GDPs, Dij is the distance between them, and A is a constant. The intuition behind the model is straightforward: larger economies have more capacity to produce and consume goods, leading to higher trade volumes, while greater physical distance tends to reduce trade due to higher transportation costs, longer delivery times, and cultural or language barriers.\n\nThe Gravity Model also helps explain why countries often trade most heavily with geographically close and economically large partners. For instance, the United States conducts substantial trade with Canada and Mexico, both of which are geographically proximate and have significant economic size. The model can be extended to include other factors such as shared language, colonial history, trade agreements, and infrastructure quality, all of which can further increase trade volumes. Together, Kenen’s Human Capital Theory and the Gravity Model expand the analysis of trade beyond resource endowments and production costs, incorporating human development and geographical-economic relationships into the picture."
],

# [
#     "The study of international trade and economic developments reveals a long and evolving journey, beginning from simple barter systems in ancient societies to the highly interconnected global trade networks of today. Historically, trade emerged as a necessity because no single country could produce all the goods and services its population needed, due to the uneven distribution of resources. Early civilizations such as the Hebrews, Greeks, and Romans understood the value of commerce, while medieval thinkers framed it within moral and ethical considerations. The mercantilists of the 16th and 17th centuries emphasized maximizing exports and accumulating precious metals, while the physiocrats highlighted agriculture as the foundation of national wealth without ignoring the role of trade.\n\nThe classical economists brought a major shift, particularly through Adam Smith’s Absolute Advantage Theory, which demonstrated that mutual benefits could be gained through specialization and free trade. David Ricardo’s Comparative Cost Theory, refined by Haberler’s Opportunity Cost Approach, expanded this insight by showing that even when one country is more efficient in producing all goods, trade can still be advantageous if each focuses on goods with the lowest opportunity costs. Mill’s Theory of Reciprocal Demand added a demand-side perspective, explaining how the terms of trade are determined by mutual willingness to exchange.\n\nModern trade theories, such as the Heckscher-Ohlin Factor Endowment model, linked trade patterns to differences in countries’ resource bases, while subsequent extensions—like Kravis’s Availability Theory and Linder’s Volume of Trade Theory—introduced factors like resource abundance, technological capacity, and domestic demand patterns. The dynamic influence of technology was captured in Posner’s Technological Gap Theory and Vernon’s Product Cycle Theory, both illustrating how innovation changes the location and nature of production over time. Kenen’s Human Capital Theory emphasized the transformative power of education and skills in shaping comparative advantage, and the Gravity Model provided an empirical framework linking trade volumes to economic size and geographic proximity.\n\nTaken together, these theories and models offer a comprehensive view of how and why trade occurs, the benefits it generates, and the factors influencing its patterns. They show that trade is not static; it evolves in response to technological change, shifts in resource endowments, policy decisions, and changing consumer preferences. In today’s globalized economy, understanding these principles is crucial for policymakers, businesses, and workers alike. Trade fosters economic growth, increases consumer choice, encourages innovation, and strengthens ties between nations. While challenges such as trade imbalances, protectionism, and unequal gains remain, the historical and theoretical foundations of trade provide a roadmap for building more equitable and mutually beneficial global economic relationships in the future."
# ],
],
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'choice': choice.upper(),
                    'cor': 'DR. I. J. UMOEKA',
                    'institution': institution,
                    'department': 'Department of Computer science'.upper()

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status1 = pisa.CreatePDF(html_string, dest=response)
                if pisa_status1.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                pdf_buffer = BytesIO()
                pisa_status2 = pisa.CreatePDF(html_string, dest=pdf_buffer)
                if pisa_status2.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if request.user.email != 'calixotu@gmail.com':
                    messages.error(request, 'Only admins can download this assignment')

                    # Get user's first name
                    user_firstname = request.user.first_name if request.user.first_name else "User"

                    # WhatsApp URL with a prefilled message
                    whatsapp_url = f"https://wa.me/2349071902185?text=Hello%20calixguru,%20my%20name%20is%20{user_firstname}.%20Please%20I%20need%20to%20download%20a%20copy%20of%20GET111%20assignment"

                    return redirect(whatsapp_url)

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                # if choice in choices:
                #     messages.error(request, f"Type {choice} was already downloaded by another student")
                #     return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                # Gst2.objects.create(firstname=user.firstname, lastname=user.lastname,
                #                     department=dept, score=choice)

                pdf_buffer.seek(0)
                pdf_data = pdf_buffer.getvalue()

                # Step 2: Send PDF via email
                # email = EmailMessage(
                #     subject=f'{name} Assignment PDF',
                #     body=f'Hello {request.user.firstname}, please find your {ass} assignment PDF attached below.',
                #     from_email=settings.DEFAULT_FROM_EMAIL,
                #     to=[user.email],
                # )
                # email.attach(f"{name}_{ass}_assignment.pdf", pdf_data, 'application/pdf')
                # email.send()
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)
    elif ass.lower() == 'EEE111'.lower():

        context = {
            'list': list(range(1, 11)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'notyet',
            'info': '''You are about to download an assignment for EEE111 below ''',
            'choice': 'chapter',
            'main_list': uniuyo9,
            'dblink': 'cbtb2',
            'text': 'text2',
        }
        books = uniuyo9
        if request.method == "POST":
            user = request.user
            choice = int(request.POST.get("choice"))-1
            if user.has_downloaded > 0:
                intro = books.introductions[choice]
                para1 = books.para1[choice]
                para2 = books.para2[choice]
                para3 = books.para3[choice]
                para4 = books.para4[choice]
                para5 = books.para5[choice]
                para6 = books.para6[choice]
                conclusion = books.conclusions[choice]
                ref = random.sample(books.references, 10)

                html_string = render_to_string('pdf/cover_page11.html', {

                    'intro' : intro,
                    'para1' : para1,
                    'para2' : para2,
                    'para3' : para3,
                    'para4' : para4,
                    'para5' : para5,
                    'para6' : para6,
                    'ref' : ref,
                    'conclusion' : conclusion,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'choice': choice,
                    'institution': institution,
                    'cor': 'Dr. Kufre Udofia'.upper(),
                    'course': 'EEE111: Introduction to Electrical and Electronics Engineering'.upper(),
                    'department': 'Department of ELECT/ELECT Engineering'.upper()

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_EEE111_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                allo = ['calixotu@gmail.com','iniubongudoessien@gmail.com']
                if request.user.email not in allo:
                    messages.error(request, 'Only the requester can download this assignment')

                    # Get user's first name
                    user_firstname = request.user.first_name if request.user.first_name else "User"

                    # WhatsApp URL with a prefilled message
                    whatsapp_url = f"https://wa.me/2349071902185?text=Hello%20calixguru,%20my%20name%20is%20{user_firstname}.%20Please%20I%20need%20to%20download%20a%20copy%20of%20GET111%20assignment"

                    return redirect(whatsapp_url)

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))
                # if choice in choices:
                #     messages.error(request, f"Type {choice} was already downloaded by another student")
                #     return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                # Gst2.objects.create(firstname=user.firstname, lastname=user.lastname,
                #                     department=dept, score=choice)
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)
    elif ass.lower() == 'CHM111'.lower():
        context = {
            'list': list(range(1, 151)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'institution': institution,
            'test': 'notyet',
            'info': '''You are about to download LIT214 assignment for contrast
            and comparison of Chinua Achebe's 'Things fall apart' and Abasseno Uko's Joe Levi and the prince of persia''',
            'choice': 'chapter',
            'main_list': uniuyo4,
            'dblink': 'cbtb2',
            'text': 'text2'
        }

        return render(request, 'pdf/cover_form5.html', context)
    else:
        messages.error(request, f'{ass} assignment is not available at the moment. You will be notified via email once it is')
        return redirect('select-tournament')


@login_required(login_url='login')
def akscoe_ass(request):
    # Define common context
    schools = {'uniuyo': 'UNIVERSITY OF UYO',
               'aksu': 'AKWA IBOM STATE UNIVERSITY',
               'akscoe': 'AKWA IBOM STATE COLLEGE OF EDUCATION'}
    name = request.GET.get('name').upper()
    reg = request.GET.get('reg').upper()
    ass = request.GET.get('ass')
    dept = request.GET.get('dept').upper()
    fac = request.GET.get('fac').upper()
    institution = schools[request.GET.get('inst')]

    if ass.lower() == 'GST111'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = []
        context = {
            'list': list(range(1, 101)),
            'chapter': ['Exiles',],
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'test': 'notyet',
            'main_list': akscoe1,
            'choice': 'book',
            'institution': institution,
        }


        if request.method == "POST":
            user = request.user
            books = akscoe1.books
            if user.has_downloaded > 0:
                try:
                    text = int(request.POST.get("chapter")) - 1
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                if text+1 in allow:
                    messages.error(request, f"Review for {books[text]['Title']} is not yet ready for download")
                else:

                    selected_book = books[text]
                    conts = []
                    for i in selected_book["Contents"]:
                        conts.append(random.choice(i))


                    # Shuffle the book data to create unique combinations
                    book_data = {
                            "Title": selected_book["Title"],
                            "Author": selected_book["Author"],
                            "Place": selected_book["Place of Publication"],
                            "Publishers": selected_book["Publishers"],
                            "Year": selected_book["Year of Publication"],
                            "Pages": selected_book["Number of Pages"],
                            # Use sorted to ensure a list can be passed to random.sample
                            "Introduction": random.choice(selected_book["Introduction"]),
                            "Contents": conts,
                            "Evaluation": random.choice(selected_book["Evaluation"]),
                            "Conclusion": random.choice(selected_book["Conclusion"]),
                            "Recommendation": random.choice(selected_book["Recommendation"])
                        }


                    html_string = render_to_string('pdf/cover_page4.html', {
                        'data': book_data,
                        # 'intro': introduction,
                        # 'end': conclusion,
                        # 'eval': evaluation,
                        'conts': conts,
                        'name': name,
                        'reg': reg,
                        'dept': dept,
                        'fac': fac,
                        'institution': institution,
                        'cor':   'Godwin Akpan'.upper(),
                        'course': 'GST111: USE OF ENGLISH 1'.upper(),
                        'department': 'department of english'.upper()

                    })

                    response = HttpResponse(content_type='application/pdf')
                    response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                    pisa_status = pisa.CreatePDF(html_string, dest=response)

                    if pisa_status.err:
                        messages.error(request, 'Error generating PDF')
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    if user.has_downloaded < 1:
                        messages.error(request, "You cannot download any material at the moment")
                        return redirect(request.META.get('HTTP_REFERER', '/'))

                    user.has_downloaded -= 1
                    user.save()
                    return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)
    elif ass.lower() == 'EDU101'.lower():
        # messages.error(request, f'We are currently working on {ass} assignment. You will be notified via email once it is ready')
        # return redirect('select-tournament')
        allow = []
        context = {
            'list': list(range(1, 71)),
            'chapter': 'none',
            'name': name,
            'reg': reg,
            'dept': dept,
            'fac': fac,
            'ass': ass,
            'info': '''You are about to download EDU101 Assignment ''',
            'test': 'notyet',
            'main_list': akscoe1,
            'choice': 'book',
            'institution': institution,
        }


        if request.method == "POST":
            user = request.user
            books = akscoe2.books
            if user.has_downloaded > 0:
                try:
                    # text = int(request.POST.get("chapter")) - 1
                    choice = int(request.POST.get("choice"))
                except ValueError:
                    return redirect(request.path)

                p1 = random.choice(books[0]["p1"])
                p2 = random.choice(books[0]["p2"])
                p3 = random.choice(books[0]["p3"])
                p4 = random.choice(books[0]["p4"])
                p5 = random.choice(books[0]["p5"])
                p6 = random.choice(books[0]["p6"])
                p7 = random.choice(books[0]["p7"])
                p8 = random.choice(books[0]["p8"])

                intro = random.choice(books[0]["Introduction"])
                conclusion = random.choice(books[0]["Conclusion"])
                num_references = random.randint(7, 10)
                references = random.sample(books[0]["Reference"], num_references)

                # Get user input
                # user_input = choice
                # result = generate_combination(user_input)

                # if result:
                #     val = []
                #     for key, value in result.items():
                #         val.append(value)

                html_string = render_to_string('pdf/cover_page8.html', {
                    # 'data': val,
                    "Introduction": intro,
                    "p1": p1[0],
                    "p2": p2[0],
                    "p3": p3[0],
                    "p4": p4[0],
                    "p5": p5[0],
                    "p6": p6[0],
                    "p7": p7[0],
                    "p8": p8[0],
                    "Conclusion": conclusion,
                    "References": references,
                    'name': name,
                    'reg': reg,
                    'dept': dept,
                    'fac': fac,
                    'institution': institution,
                    'cor':   'Lecturer Name here...'.upper(),
                    'course': 'EDU101: Introduction to teaching and Educational foundation'.upper(),
                    'department': 'LECTURER DEPARTMENT HERE'

                })

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{name}_assignment.pdf"'
                pisa_status = pisa.CreatePDF(html_string, dest=response)

                if pisa_status.err:
                    messages.error(request, 'Error generating PDF')
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                if user.has_downloaded < 1:
                    messages.error(request, "You cannot download any material at the moment")
                    return redirect(request.META.get('HTTP_REFERER', '/'))

                user.has_downloaded -= 1
                user.save()
                return response
            else:
                messages.error(request, "You have to be activated to do that")
                return redirect('buypin')
        return render(request, 'base/gst.html', context)
    else:
        messages.error(request, f'{ass} assignment is not available at the moment. You will be notified via email once it is')
        return redirect('select-tournament')


from django.views.decorators.csrf import csrf_exempt
import json

sample_data = questions.sample_data

def assignment_view(request):
    # pins = set()
    # while len(pins) < 100:
    #     pins.add(str(random.randint(100000, 999999)))  # always 6 digits

    # for code in pins:
    #     Asspin.objects.create(code=code)
    code = Asspin.objects.all()
    return render(request, "assignment/task.html", {'code': code})

csrf_exempt  # remove if frontend sends CSRF correctly
def validate_pin(request):
    if request.method != "POST":
        return JsonResponse({"valid": False, "error": "POST required"}, status=400)

    try:
        data = json.loads(request.body.decode("utf-8"))
    except Exception:
        return JsonResponse({"valid": False, "error": "Invalid JSON"}, status=400)

    pin_code = data.get("pin", "")
    try:
        pin = Asspin.objects.get(code=pin_code, used=False)

        # Generate device_id only if first time use
        if not pin.device_id:
            device_id = str(uuid.uuid4())
            pin.device_id = device_id
            pin.save()
            request.session['device_id'] = device_id
        else:
            # If already used on another device, block
            if request.session.get("device_id") != pin.device_id:
                return JsonResponse({"valid": False, "error": "PIN already bound to another device"}, status=403)

        return JsonResponse({"valid": True, "progress": pin.current_index})
    except Asspin.DoesNotExist:
        return JsonResponse({"valid": False})


def get_data(request, index):
    pin = request.GET.get("pin")
    try:
        pin_obj = Asspin.objects.get(code=pin, used=False)

        # Check device binding
        if request.session.get("device_id") != pin_obj.device_id:
            return JsonResponse({"done": True, "error": "Unauthorized device"}, status=403)

        if index >= len(sample_data):
            pin_obj.used = True
            pin_obj.save()
            return JsonResponse({"done": True})

        return JsonResponse(sample_data[index])
    except Asspin.DoesNotExist:
        return JsonResponse({"done": True})


@csrf_exempt
def update_progress(request):
    try:
        data = json.loads(request.body)
    except Exception:
        return JsonResponse({"ok": False, "error": "Invalid JSON"}, status=400)

    try:
        pin = Asspin.objects.get(code=data['pin'], used=False)

        # Check device binding
        if request.session.get("device_id") != pin.device_id:
            return JsonResponse({"ok": False, "error": "Unauthorized device"}, status=403)

        pin.current_index = data['progress']
        if data['progress'] >= len(sample_data):
            pin.used = True
        pin.save()
        return JsonResponse({"ok": True})
    except Asspin.DoesNotExist:
        return JsonResponse({"ok": False})